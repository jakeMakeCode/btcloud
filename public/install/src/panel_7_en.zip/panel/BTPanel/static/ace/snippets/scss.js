define("ace/snippets/scss",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="scss"});                (function() {
                    window.require(["ace/snippets/scss"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            