import logging
import sys
import json
import os
import threading
import time
import re
import uuid
import psutil

panel_path = '/www/server/bt-monitor'

os.chdir(panel_path)
if not 'modules/' in sys.path:
    sys.path.insert(0, 'modules/')

# 保存初始的allowed_gai_family信息
import requests.packages.urllib3.util.connection as urllib3_conn
default_allowed_gai_family = urllib3_conn.allowed_gai_family


from flask import Config, Flask, session, render_template, send_file, request, redirect, g, make_response, \
    render_template_string, abort,stream_with_context, Response as Resp

from core.include.cachelib.simple import SimpleCache
from core.include.flask_session import Session
from core.include.flask_compress import Compress
from werkzeug.wrappers import Response
import core.include.public as public
from flask_sock import Sock

cache = SimpleCache(9999999)

# 初始化Flask应用
app = Flask(__name__, template_folder="template/",static_folder="static/",root_path=panel_path)
Compress(app)
sockets = Sock(app)

# 公开服务
app1 = Flask('app1', template_folder="template/",static_folder="static/",root_path=panel_path)
Compress(app1)
sockets1 = Sock(app1)


try:
    if not os.path.exists('config/config.json'):
        # 初始化配置文件
        public.save_config('config', {
            'API': {
                'encrypt': True,
                'open': True
            },
            'home': 'https://www.bt.cn',
            'admin_path': '/{}'.format(public.md5(public.GetRandomString(16))[:9]),
            'accept_ip': [],
            'accept_domain': '',
            'debug': False,
            'session_timeout': 86400,
            'password_expire': 180,
            'port': 806,
            'not_login_modules': ['plugin', 'api'],
            'not_login_uri': ['/user/login', '/user/check_two_auth_login'],
            'automatic_scan': False,

        })
    panel_config = public.read_config('config')
    for key in panel_config.keys():
        app.config[str.upper(key)] = panel_config[key]
except: pass

is_debug = app.config.get('DEBUG', False)

# 设置BasicAuth
basic_auth_conf = 'config/basic_auth.json'
app.config['BASIC_AUTH_OPEN'] = False
if os.path.exists(basic_auth_conf):
    try:
        ba_conf = json.loads(public.readFile(basic_auth_conf))
        app.config['BASIC_AUTH_USERNAME'] = ba_conf['basic_user']
        app.config['BASIC_AUTH_PASSWORD'] = ba_conf['basic_pwd']
        app.config['BASIC_AUTH_OPEN'] = ba_conf['open']
    except:
        pass

# 初始化SESSION服务
app.secret_key = public.md5('BT_MONITOR__' + str(os.uname()) + str(psutil.boot_time())) # uuid.UUID(int=uuid.getnode()).hex[-12:]
local_ip = None
my_terms = {}
servers_ws = {}

app.config['SESSION_MEMCACHED'] = SimpleCache(1000, 86400)
app.config['SESSION_TYPE'] = 'memcached'
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'BT_:'
app.config['SESSION_COOKIE_NAME'] = public.md5(app.secret_key)
app.config['PERMANENT_SESSION_LIFETIME'] = 86400 * 30
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = True

Session(app)

method_all = ['GET', 'POST']
method_get = ['GET']
method_post = ['POST']
json_header = {'Content-Type': 'application/json; charset=utf-8'}
text_header = {'Content-Type': 'text/plain; charset=utf-8'}
uri_match = re.compile(r"(^/static/[\w_\./\-]+\.(js|css|png|jpg|gif|ico|svg|woff|woff2|ttf|otf|eot|map)$|^/[\w_\./\-]*$)")

sampling_global = {}  # 全局采样
sampling_closed = {}  # 指定采样

# =============================== 公开服务 ===============================
@app1.route('/', methods=method_get)
def public_server():
    return render_template('server.html')

@app1.route('/dashboard/get_public_server_list', methods=method_get)
def get_public_server_list():
    '''
         @name 获取公开的主机列表信息
         @return list
     '''
    # 获取公开的服务器列表
    path = '{}/config/public_server_list.json'.format(public.get_panel_path())
    if not os.path.exists(path):
        return public.return_data(False, "未设置公开的服务器列表!")
    else:
        public_server_list = json.loads(public.readFile(path))
    sid_list = public_server_list.get('sid_list', [])
    open = public_server_list.get('open', False)
    if not open:
        return public.return_data(False, "未开启公开服务, 请先开启!")
    from core.include.monitor_helpers import basic_monitor_obj
    query = basic_monitor_obj.db_easy('servers') \
        .alias('s') \
        .left_join('server_group sg', 's.group_id=sg.id') \
        .where_in("s.sid", sid_list) \
        .where('s.is_authorized=?', 1)

    query.field(
        'sid',
        'group_id',
        'sg.name as group_name',
        'status',
        'is_authorized',
        'allow_notify',
        'ip',
        'remark',
        's.create_time',
        'last_active_time',
        "ssh_info",
        "panel_info",
        's.sampling',
        's.type'
    ).order('s.create_time', 'DESC')

    ret_list = query.select()
    ret = {'total': 0, 'list': []}

    # 查询主机漏洞数
    server_bugs = basic_monitor_obj.db_easy('server_bug_total') \
        .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
        .field('sid', '`bugs` - `ignored` - `fixed` as `bugs`') \
        .column('bugs', 'sid')

    # 查询主机挖矿木马数
    server_minings = basic_monitor_obj.db_easy('server_mining_total') \
        .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
        .field('sid', '`minings` - `ignored` - `fixed` as `minings`') \
        .column('minings', 'sid')

    # 查询主机详细信息关联数据
    for item in ret_list:
        # 实时数据
        item.update(basic_monitor_obj.cache_realtime_server_info(item['sid']))

        # 更新主机状态
        _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])

        # 显示主机漏洞数
        item['bugs'] = server_bugs.get(item['sid'], 0)

        # 显示主机挖矿木马数
        item['minings'] = server_minings.get(item['sid'], 0)

        if item['status'] == 0:
            item['disk_info'] = [{'read_bytes_per_second': -1, 'write_bytes_per_second': -1}, ]
            item['load_avg'] = {}
            item['net_info'] = [{'recv_per_second': -1, 'sent_per_second': -1, 'recv': -1, 'sent': -1}]
            item['bugs'] = -1
            item['minings'] = -1
        # 去掉敏感信息
        del (item['cpu_info']['model_name'])
        del (item['host_info']['host_name'])
        del (item['host_info']['kernel_version'])
        del (item['host_info']['platform_version'])
        del (item['host_info']['platform_family'])
        del (item['ip'])
    ret['total'] = len(ret_list)
    auth_info = basic_monitor_obj.get_auth_info()
    if not auth_info:
        ret['available_auth_num'] = basic_monitor_obj.get_available_clients()

        # 获取当前已授权的客户端数量
        ret['cur_auth_num'] = basic_monitor_obj.db_easy('servers') \
            .where('is_authorized=1') \
            .where_in('status', [0, 1]) \
            .count()
    else:
        ret['available_auth_num'] = auth_info.get('clients', 0)
        ret['cur_auth_num'] = auth_info.get('cur_auth_num', 0)

    # 加上排序
    p_server_detail = public_server_list.get('p_server_detail', [])
    p_server_detail_new = {}
    for item in p_server_detail:
        p_server_detail_new[item["sid"]] = item.get("sort_key", 0)
    # 列表内加入排序字段
    for item in ret_list:
        item['sort_key'] = p_server_detail_new.get(item['sid'], 0)
    ret_list = sorted(ret_list, key=lambda x: x.get('sort_key', 0), reverse=False)

    ret['list'] = ret_list

    # 统计公开页访问次数
    basic_monitor_obj.set_module_logs('cloud_monitor', 'public_page')
    return public.return_data(True, ret)


# =============================== 路由 ===============================
@app.route('/',methods=method_get)
def index():
    '''
        @name 首页
        @author hwliangG
        @return Response
    '''
    # 检查是否登录
    if not check_login():
        admin_path = public.get_admin_path()
        if admin_path in ['', '/', '/login']:
            return render_template('login.html')
        abort(403)
        # return redirect(public.get_admin_path())
    return render_template('index.html')

@app.route(public.get_admin_path(), methods=method_get)
def login():
    '''
        @name 登录页面
        @author hwliang
        @return Response
    '''
    return render_template('login.html')

@app.route('/records/<filename>', methods=method_get)
def records(filename):
    with open('/www/server/bt-monitor/data/asciinemadir/{}'.format(filename), 'r') as fp:
        return fp.read()

mod_action_match = re.compile("^[\w\-]+$")
not_login_uri = app.config.get('NOT_LOGIN_URI', [])              # 免登录路由
not_login_modules = app.config.get('NOT_LOGIN_MODULES', [])    # 免登录模块
@app.route('/<module>/<action>', methods=method_all)
def http_route(module, action):
    '''
        @name HTTP入口
        @author hwliang
        @param module 模块名
        @param action 方法名
        @return Response
    '''
    # URI格式验证
    if not mod_action_match.match(module) or not mod_action_match.match(action):
        return public.response(False,'错误的模块名或方法名', 400)
    g.module = module
    g.action = action

    # 检查是否登录
    uri = '/{}/{}'.format(module, action)
    if not uri in not_login_uri and not module in not_login_modules:
        if not check_login():
            return public.response(False,'请先登录',401)

        # CSRF验证
        if not check_csrf():
            return public.response(False, 'CSRF验证失败',401)

    # 调用模块方法
    import core.loader as loader
    result =  loader.http_run(module, action)

    # 如果是登录后台，且登录成功，写cookie-token
    if module == 'user' and action == 'login':
        result = is_login(result)
    return result

@sockets.route('/ws')
def ws_route(ws):
    '''
        @name WebSocket入口
        @author hwliang
        @param ws: WebSocket对象
        @return void
    '''
    import core.loader as loader
    loader.ws_run(ws)


@app.route('/code',methods=method_get)
def code():
    '''
        @name 获取图形验证码
        @author hwliang
        @return Response
    '''
    # if not 'login_code' in session: return ''
    # if not session['login_code']: return ''
    # 获取图片验证码
    try:
        import core.include.vilidate as vilidate
    except:
        return "Pillow not install!"
    vie = vilidate.vieCode()
    codeImage = vie.GetCodeImage(80, 4)

    from io import BytesIO
    out = BytesIO()
    codeImage[0].save(out, "png")
    cache.set("codeStr", public.md5("".join(codeImage[1]).lower()), 180)
    cache.set("codeOut", 1, 0.1)
    out.seek(0)
    return public.send_file(out, mimetype='image/png')

@app.route('/tips', methods=method_get)
def tips():
    '''
        @name 浏览器兼容提示页面
        @author Zhj<2022-07-25>
        @return Response
    '''
    return render_template('tips.html')

# @app.route('/test_player/<filename>', methods=method_get)
# def test_player(filename):
#     '''
#         @name 浏览器兼容提示页面
#         @author Zhj<2022-07-25>
#         @return Response
#     '''
#
#     return render_template('asciinema_player.html', filename=filename)

# =============================== 路由 ===============================

# =============================== FLASK HOOK ===============================

auth_skip_pattern = re.compile(r'^\/(?:api\/\w+|ws\/?)$')
# Flask请求勾子
@app.before_request
def request_check():
    '''
        @name Flask请求前检查
        @author hwliang
        @return Response or None
    '''
    if request.method not in ['GET','POST']:return abort(404)

    # 宝塔面板请求代理
    if "Referer" in request.headers and not request.full_path.startswith("/static/panel"):
        referer = request.headers["Referer"]
        try:
            from urllib.parse import urlparse
        except:
            from urlparse import urlparse
        parse_result = urlparse(referer)
        match_res = re.search("cmproxy/(\d+)/", parse_result.path)
        if match_res:
            to_server_id = match_res[1]
            proxy_path = request.full_path

            # 附加Referer查询参数
            referer_query_str = ''

            if request.headers['Referer'].find('?') > -1:
                referer_query_str = str(request.headers['Referer'].split('?')[1]).strip()

            if len(proxy_path) > 0:
                if proxy_path.find('?') > -1:
                    proxy_path += '&' + referer_query_str
                else:
                    proxy_path += '?' + referer_query_str

            if not proxy_path:
                proxy_path = "/"
            import core.loader as loader
            g.module = "cmproxy"
            g.action = "proxy"
            args = public.dict_obj()
            args.sid = to_server_id
            args.path_full = proxy_path
            return loader.http_run("cmproxy", "proxy", args)

    g.request_time = time.time()
    # 路由和URI长度过滤
    if len(request.path) > 256: return abort(403)
    if len(request.url) > 1024: return abort(403)
    # URI过滤
    if not uri_match.match(request.path): return abort(403)

    # POST参数过滤
    pdata = request.form.to_dict()
    for k in pdata.keys():
        if len(k) > 48: return abort(403)
        # if len(pdata[k]) > 256: return abort(403)

    if auth_skip_pattern.match(request.path) is None:
        # HTTP认证
        if app.config['BASIC_AUTH_OPEN']:
            auth = request.authorization
            if not auth: return send_authenticated()
            tips = '_bt.cn'
            if public.md5(auth.username.strip() + tips) != app.config['BASIC_AUTH_USERNAME'] \
                    or public.md5(auth.password.strip() + tips) != app.config['BASIC_AUTH_PASSWORD']:
                return send_authenticated()

        # 检查访问IP限制
        ip_check = public.check_ip_panel()
        if ip_check: return ip_check

        # 检查域名访问限制
        domain_check = public.check_domain_panel()
        if domain_check: return domain_check


# Flask 请求结束勾子
@app.teardown_request
def request_end(reques=None):
    '''
        @name Flask请求结束处理事项
        @author hwliang
        @return None
    '''
    if request.method not in ['GET','POST']: return

    # 写访问日志
    if request.full_path.find('/static/') == -1:
        public.write_request_log()


# Flask 404页面勾子
@app.errorhandler(404)
def error_404(e):
    if request.method not in ['GET','POST']:return
    if session.get('login',None):
        return render_template('index.html')
        # g.auth_error = True
        # return public.error_not_login()
    errorStr = '''<html>
<head><title>404 Not Found</title></head>
<body>
<center><h1>404 Not Found</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=404, headers=headers)


# Flask 403页面勾子
@app.errorhandler(403)
def error_403(e):
    if request.method not in ['GET','POST']:return
    # if not session.get('login',None):
    #     g.auth_error = True
    #     return public.error_not_login()
    errorStr = '''<html>
<head><title>403 Forbidden</title></head>
<body>
<center><h1>403 Forbidden</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=403, headers=headers)


# Flask 500页面勾子
@app.errorhandler(500)
def error_500(e=None, title=None):
    if request.method not in ['GET','POST']:return

    # if not session.get('login',None):
    #     g.auth_error = True
    #     return public.error_not_login()
    ss = '''404 Not Found: The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.

During handling of the above exception, another exception occurred:'''
    error_info = public.get_error_info().strip().split(ss)[-1].strip()
    _form = request.form.to_dict()
    if 'username' in _form: _form['username'] = '******'
    if 'password' in _form: _form['password'] = '******'
    if 'phone' in _form: _form['phone'] = '******'
    request_info = '''REQUEST_DATE: {request_date}
 PAN_VERSION: {panel_version}
  OS_VERSION: {os_version}
 REMOTE_ADDR: {remote_addr}
 REQUEST_URI: {method} {full_path}
REQUEST_FORM: {request_form}
  USER_AGENT: {user_agent}'''.format(
    request_date = public.getDate(),
    remote_addr = public.GetClientIp(),
    method = request.method,
    full_path = request.full_path,
    request_form = _form,
    user_agent = request.headers.get('User-Agent'),
    panel_version = public.version(),
    os_version = public.get_os_version()
)
    error_title = error_info.split("\n")[-1].replace('public.PanelError: ', '').strip()
    if error_info.find('连接云端服务器失败') != -1:
        error_title = "连接云端服务器失败!"
    result = public.readFile(public.get_panel_path() + '/template/panel_error.html').format(title=title or '出错了，面板运行时发生错误！', error_title=error_title, request_info=request_info, error_msg=error_info)
    return Resp(result,500)

# =============================== FLASK HOOK ===============================


# =============================== 函数 ===============================
def send_authenticated():
    '''
        @name 发送HTTP认证信息
        @author hwliang
        @return Response
    '''
    request_host = public.GetHost()
    result = Response('', 401, {'WWW-Authenticate': 'Basic realm="%s"' % request_host.strip()})
    return result


def check_login():
    '''
        @name 检查登录状态
        @author hwliang
        @return bool
    '''
    if not session.get('login', None):
        return False

    # 检查会话是否过期
    stime = int(time.time())
    if stime - session.get('last_login_time', 0) > app.config['SESSION_TIMEOUT']:
        # public.WriteLog("用户登录", "会话过期,请重新登录")
        public.print_log("{} 的会话过期,请重新登录, {}, {}".format(session.get('username'), session.get('last_login_time'), stime))
        session.clear()
        return False

    # 设置最后活动时间
    session['last_login_time'] = stime

    return True


def is_login(result):
    # 判断是否登录
    if 'login' in session:
        if session['login'] == True:
            result = make_response(result)
            request_token = public.GetRandomString(48)
            session['request_token'] = request_token
            samesite = app.config['SESSION_COOKIE_SAMESITE']
            secure = app.config['SESSION_COOKIE_SECURE']
            samesite = 'None'
            secure = True
            result.set_cookie('request_token__btm', request_token,
            max_age=86400 * 30,
            samesite= samesite,
            secure=secure
            )
    return result


def check_csrf():
    # CSRF校验
    if is_debug: return True

    request_token = request.cookies.get('request_token__btm','')
    if session.get('request_token', '') == request_token: return True

    http_token = request.headers.get('x-http-token__btm')
    if not http_token: return False

    if http_token != session.get('request_token_head'): return False
    cookie_token = request.headers.get('x-cookie-token__btm')

    if cookie_token != session.get('request_token'): return False

    return True


# 获取输入数据
def get_input():
    data = public.dict_obj()
    exludes = ['blob']
    for key in request.args.keys():
        data[key] = str(request.args.get(key, ''))
    try:
        for key in request.form.keys():
            if key in exludes: continue
            data[key] = str(request.form.get(key, ''))
    except:
        try:
            post = request.form.to_dict()
            for key in post.keys():
                if key in exludes: continue
                data[key] = str(post[key])
        except:
            pass

    # 获取json数据
    if request.is_json:
        json_data = request.get_json()
        for k in json_data.keys():
            data[k] = json_data[k]

    # 获取form-data数据
    if 'form_data' in g:
        for k in g.form_data.keys():
            data[k] = str(g.form_data[k])

    # 获取上传文件流
    if hasattr(request, 'files'):
        data['FILES'] = request.files

    if not hasattr(data, 'data'): data.data = []
    return data


# 取数据对象
def get_input_data(data):
    pdata = public.dict_obj()
    for key in data.keys():
        pdata[key] = str(data[key])
    return pdata

# =============================== 函数 ===============================

@sockets.route('/cmproxy/<int:ssh_id>/webssh')
def panel_webssh(ws, ssh_id=0):
    if not check_login():
        return abort(403)
    import core.loader as loader
    module = "terminal"
    action = "run"
    args = public.dict_obj()
    # args.sid = sid
    args.id = ssh_id
    args.ws = ws
    g.module = module
    g.action = action
    from core.include.monitor_helpers import basic_monitor_obj
    basic_monitor_obj.set_module_logs(f'{g.module}', f'{g.action}')

    try:
        result = loader.loader(module, action).run(args)
        if result is not None:
            if isinstance(result, str):
                ws.send(result)
            else:
                ws.send(json.dumps(result, ensure_ascii=False))
    except BaseException as e:
        # public.print_exc_stack(e)
        try:
            ws.send(str(e))
        except: pass

    try:
        ws.close()
    except: pass
    # return loader.http_run(module, action, args)



@app.route("/cmproxy/<int:sid>/<path:path_full>", methods=method_all)
def cloud_monitor_proxy2(sid=0, path_full = None):
    """代理被控面板"""
    if not check_login():
        return abort(403)

    import core.loader as loader
    g.module = "cmproxy"
    g.action = "proxy"
    args = public.dict_obj()
    args.sid = sid
    args.path_full = path_full
    from core.include.monitor_helpers import basic_monitor_obj
    basic_monitor_obj.set_module_logs(f'{g.module}', f'{g.action}')
    return loader.http_run("cmproxy", "proxy", args)
