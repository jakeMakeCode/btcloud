# -*- encoding: utf-8 -*-
#
# 云监控常量
# @author Zhj<2023-01-07>

SAMPLING_TYPE__GLOBAL = 0 # 监控数据采集类型 全局
SAMPLING_TYPE__CPU = 1 # 监控数据采集类型 CPU占用
SAMPLING_TYPE__MEM = 2 # 监控数据采集类型 内存占用
SAMPLING_TYPE__SWAP = 3 # 监控数据采集类型 SWAP占用(主机)
SAMPLING_TYPE__LOAD_AVG = 4 # 监控数据采集类型 平均负载(主机)
SAMPLING_TYPE__DISK_IO = 5 # 监控数据采集类型 磁盘IO(进程)
SAMPLING_TYPE__NET_IO = 6 # 监控数据采集类型 网络IO
SAMPLING_TYPE__DISK = 7 # 监控数据采集类型 磁盘占用(主机)
SAMPLING_TYPE__OPENED_THREADS = 8 # 打开线程数(进程)
SAMPLING_TYPE__OPENED_FILES = 9 # 打开文件数(进程)

SAMPLING_GLOBAL__SERVER = 1 # 全局监控数据采样设置 主机基础监控数据
SAMPLING_GLOBAL__PROCESS = 2 # 全局监控数据采样设置 进程监控数据

# 日志告警级别常量
LOG_LEVEL__INFO = 0
LOG_LEVEL__DEBUG = 1
LOG_LEVEL__WARNING = 2
LOG_LEVEL__ERROR = 3

LOG_LEVEL__MAP = {
    'info': LOG_LEVEL__INFO,
    'debug': LOG_LEVEL__DEBUG,
    'warning': LOG_LEVEL__WARNING,
    'error': LOG_LEVEL__ERROR,
}

LOG_LEVEL__CUR = LOG_LEVEL__ERROR  # 当前日志告警级别，低于该级别时记录日志