import copy
import os, time, re, datetime, json
import threading
from glob import glob
from contextlib import contextmanager
from threading import Lock, Thread
import core.include.public as public
from sqlite_server import Db
# from core.include.sqlite_easy import Db
from inspect import isfunction
import py7zr
from core.include.Locker import acquire, acquire_with_file

import sys

os.chdir('/www/server/bt-monitor')
sys.path.insert(0, "/www/server/bt-monitor")

# 线程锁对象
_LOCK = Lock()

# 主数据库名称
_DB_MGR = 'monitor_mgr'

# 独立数据库文件夹
_SINGLE_BASE_DIR = 'monitor_databases'

# 子数据库(每月)建表语句列表
_SUB_DB_SQL_LIST = [
    # 创建主机CPU信息收集数据库
    ('server_cpu_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 设置Sqlite
        -- PRAGMA synchronous = 0;
        -- PRAGMA page_size = 4096;
        -- PRAGMA journal_mode = wal;

        -- 主机CPU信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_cpu_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `percent` REAL NOT NULL DEFAULT 0.00,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverCpuInfoList_sid_percent_createTime`
            ON `bt_server_cpu_info_list` (`sid`, `percent`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机内存信息收集数据库
    ('server_mem_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机内存信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_mem_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `percent` REAL NOT NULL DEFAULT 0.00,
            `used`	INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverMemInfoList_sid_percent_createTime`
            ON `bt_server_mem_info_list` (`sid`, `percent`, `create_time`);

        CREATE INDEX IF NOT EXISTS `serverMemInfoList_sid_used_createTime`
            ON `bt_server_mem_info_list` (`sid`, `used`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机SWAP信息收集数据库
    ('server_swap_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机SWAP信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_swap_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `percent` REAL NOT NULL DEFAULT 0.00,
            `used` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverSwapInfoList_sid_percent_createTime`
            ON `bt_server_swap_info_list` (`sid`, `percent`, `create_time`);

        CREATE INDEX IF NOT EXISTS `serverSwapInfoList_sid_used_createTime`
            ON `bt_server_swap_info_list` (`sid`, `used`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机网卡信息收集数据库
    ('server_net_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机网卡信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_net_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `name` TEXT NOT NULL DEFAULT '',
            `sent_per_second` INTEGER NOT NULL DEFAULT 0,
            `recv_per_second` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverNetInfoList_sid_name_createTime`
            ON `bt_server_net_info_list` (`sid`, `name`, `create_time`);

        CREATE INDEX IF NOT EXISTS `serverNetInfoList_sentPerSecond_name_sid`
            ON `bt_server_net_info_list` (`sent_per_second`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverNetInfoList_recvPerSecond_name_sid`
            ON `bt_server_net_info_list` (`recv_per_second`, `name`, `sid`);

        -- 提交事务
        commit;
    '''),

    # 创建主机磁盘信息收集数据库
    ('server_disk_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机磁盘信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_disk_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `name` TEXT NOT NULL DEFAULT '',
            `used` INTEGER NOT NULL DEFAULT 0,
            `used_percent` REAL NOT NULL DEFAULT 0.00,
            `inodes_used` INTEGER NOT NULL DEFAULT 0,
            `inodes_used_percent` REAL NOT NULL DEFAULT 0.00,
            `iops` INTEGER NOT NULL DEFAULT 0,
            `io_percent` REAL NOT NULL DEFAULT 0.00,
            `read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_sid_name_createTime`
            ON `bt_server_disk_info_list` (`sid`, `name`, `create_time`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_readBytesPerSecond_name_sid`
            ON `bt_server_disk_info_list` (`read_bytes_per_second`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_writeBytesPerSecond_name_sid`
            ON `bt_server_disk_info_list` (`write_bytes_per_second`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_usedPercent_name_sid`
            ON `bt_server_disk_info_list` (`used_percent`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_inodeUsedPercent_name_sid`
            ON `bt_server_disk_info_list` (`inodes_used_percent`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_ioPercent_name_sid`
            ON `bt_server_disk_info_list` (`io_percent`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_readBytesPerSecond_name_sid`
            ON `bt_server_disk_info_list` (`read_bytes_per_second`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_writeBytesPerSecond_name_sid`
            ON `bt_server_disk_info_list` (`write_bytes_per_second`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_used_name_sid`
            ON `bt_server_disk_info_list` (`used`, `name`, `sid`);

        CREATE INDEX IF NOT EXISTS `serverDiskInfoList_inodesUsed_name_sid`
            ON `bt_server_disk_info_list` (`inodes_used`, `name`, `sid`);

        -- 提交事务
        commit;
    '''),

    # 创建主机负载信息收集数据库
    ('server_loadavg_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 负载信息收集表
        CREATE TABLE IF NOT EXISTS `bt_server_loadavg_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `last_1_min` REAL NOT NULL DEFAULT 0.00,
            `last_5_min` REAL NOT NULL DEFAULT 0.00,
            `last_15_min` REAL NOT NULL DEFAULT 0.00,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverLoadavgInfoList_sid_last1min_last5min_last15min_createTime`
            ON `bt_server_loadavg_info_list` (`sid`, `last_1_min`, `last_5_min`, `last_15_min`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机端口测试记录收集数据库
    ('port_connection_logs', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 端口连接测试记录表
        CREATE TABLE IF NOT EXISTS `bt_port_connection_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `port_id` INTEGER NOT NULL DEFAULT 0,
            `port` INTEGER NOT NULL DEFAULT 0,
            `test_method` TEXT NOT NULL DEFAULT '',
            `ok` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `portConnectionLogs_sid_port_ok_createTime`
            ON `bt_port_connection_logs` (`sid`, `port`, `ok`, `create_time`);

        CREATE INDEX IF NOT EXISTS `portConnectionLogs_portId_createTime`
            ON `bt_port_connection_logs` (`port_id`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机系统防火墙启停记录收集数据库
    ('firewall_start_stop_logs', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 系统防火墙启停记录表
        CREATE TABLE IF NOT EXISTS `bt_firewall_start_stop_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `status` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `firewallStartStopLogs_sid_status_createTime`
            ON `bt_firewall_start_stop_logs` (`sid`, `status`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机系统防火墙规则修改记录收集数据库
    ('firewall_rule_change_logs', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 系统防火墙规则修改记录表
        CREATE TABLE IF NOT EXISTS `bt_firewall_rule_change_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `add` TEXT NOT NULL DEFAULT '[]',
            `del` TEXT NOT NULL DEFAULT '[]',
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `firewallRuleChangeLogs_sid_createTime`
            ON `bt_firewall_rule_change_logs` (`sid`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建主机进程数收集数据库
    ('server_process_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机进程数收集表
        CREATE TABLE IF NOT EXISTS `bt_server_process_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `total` INTEGER NOT NULL DEFAULT 0,
            `running` INTEGER NOT NULL DEFAULT 0,
            `sleep` INTEGER NOT NULL DEFAULT 0,
            `stop` INTEGER NOT NULL DEFAULT 0,
            `zombie` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverProcessInfoList_sid_createTime_total_running_sleep_stop_zombie`
            ON `bt_server_process_info_list` (`sid`, `create_time`, `total`, `running`, `sleep`, `stop`, `zombie`);

        CREATE INDEX IF NOT EXISTS `serverProcessInfoList_createTime`
            ON `bt_server_process_info_list` (`create_time`);

        -- 提交事务
        commit;
    '''),
]

# 进程数据收集数据库(每天)建表语句
_PROCESS_DB_LIST = [
    # 创建进程CPU信息收集数据库
    ('process_cpu_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程CPU信息收集表
        CREATE TABLE IF NOT EXISTS `bt_process_cpu_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `percent` REAL NOT NULL DEFAULT 0.00,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processCpuInfoList_processId_percent_createTime`
            ON `bt_process_cpu_info_list` (`process_id`, `percent`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程内存信息收集数据库
    ('process_mem_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程内存信息收集表
        CREATE TABLE IF NOT EXISTS `bt_process_mem_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `percent` REAL NOT NULL DEFAULT 0.00,
            `used`	INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processMemInfoList_processId_percent_createTime`
            ON `bt_process_mem_info_list` (`process_id`, `percent`, `create_time`);

        CREATE INDEX IF NOT EXISTS `processMemInfoList_processId_used_createTime`
            ON `bt_process_mem_info_list` (`process_id`, `used`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程磁盘IO信息收集数据库
    ('process_disk_io_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程磁盘IO信息收集表
        CREATE TABLE IF NOT EXISTS `bt_process_disk_io_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processDiskIoInfoList_processId_readBytesPerSecond_createTime`
            ON `bt_process_disk_io_info_list` (`process_id`, `read_bytes_per_second`, `create_time`);

        CREATE INDEX IF NOT EXISTS `processDiskIoInfoList_processId_writeBytesPerSecond_createTime`
            ON `bt_process_disk_io_info_list` (`process_id`, `write_bytes_per_second`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程网络IO信息收集数据库
    ('process_network_io_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程网络IO信息收集表
        CREATE TABLE IF NOT EXISTS `bt_process_network_io_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `sent_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `recv_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processNetworkIoInfoList_processId_sentBytesPerSecond_createTime`
            ON `bt_process_network_io_info_list` (`process_id`, `sent_bytes_per_second`, `create_time`);

        CREATE INDEX IF NOT EXISTS `processNetworkIoInfoList_processId_recvBytesPerSecond_createTime`
            ON `bt_process_network_io_info_list` (`process_id`, `recv_bytes_per_second`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程打开文件数收集数据库
    ('process_opened_files_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程打开文件数收集表
        CREATE TABLE IF NOT EXISTS `bt_process_opened_files_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `opened_files` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processOpenedFilesInfoList_processId_openedFiles_createTime`
            ON `bt_process_opened_files_info_list` (`process_id`, `opened_files`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程网络连接数收集数据库
    ('process_opened_connections_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程网络连接数收集表
        CREATE TABLE IF NOT EXISTS `bt_process_opened_connections_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `opened_connections` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processOpenedConnectionsInfoList_processId_openedConnections_createTime`
            ON `bt_process_opened_connections_info_list` (`process_id`, `opened_connections`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # 创建进程打开线程数收集数据库
    ('process_opened_threads_info_list', '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程打开线程数收集表
        CREATE TABLE IF NOT EXISTS `bt_process_opened_threads_info_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `process_id` INTEGER NOT NULL DEFAULT 0,
            `opened_threads` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `processOpenedThreadsInfoList_processId_openedThreads_createTime`
            ON `bt_process_opened_threads_info_list` (`process_id`, `opened_threads`, `create_time`);

        -- 提交事务
        commit;
    '''),

    # nginx
    ("process_nginx_stats_list", '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- nginx 连接数据
        CREATE TABLE IF NOT EXISTS `bt_process_nginx_stats_list` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `requests` INTEGER NOT NULL DEFAULT 0,
            `accepts` INTEGER NOT NULL DEFAULT 0,
            `waiting` INTEGER NOT NULL DEFAULT 0,
            `active_connections` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `Nginx_Stats_createTime`
            ON `bt_process_nginx_stats_list` (`create_time`);

        -- 提交事务
        commit;
    '''),
]

# 子数据库(常时)建表语句
_SUB_SINGLE_DB_SQL_LIST = {
    # SSH登录日志
    'ssh_login_logs': '''
        -- 开启wal模式
        PRAGMA journal_mode=wal;

        -- 关闭同步
        PRAGMA synchronous=0;

        -- 开启事务
        begin;

        -- SSH登录信息收集表
        CREATE TABLE IF NOT EXISTS `bt_ssh_login_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `ip` TEXT NOT NULL DEFAULT '',
            `port` INTEGER NOT NULL DEFAULT 0,
            `ip_place` TEXT NOT NULL DEFAULT '',
            `user` TEXT NOT NULL DEFAULT '',
            `success` INTEGER NOT NULL DEFAULT 0,
            `login_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_success_loginTime`
            ON `bt_ssh_login_logs` (`success`, `login_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_user_success_loginTime`
            ON `bt_ssh_login_logs` (`user`, `success`, `login_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_ip_success_loginTime`
            ON `bt_ssh_login_logs` (`ip`, `success`, `login_time`);

        -- CREATE INDEX IF NOT EXISTS `sshLoginLogs_loginTime_ipPlace`
        --    ON `bt_ssh_login_logs` (`login_time`, `ip_place`);

        -- 提交事务
        commit;
    ''',

    # 创建会话记录收集数据库
    'playrecords': '''
            -- DROP TABLE IF EXISTS `bt_playrecords`;
        
            -- 开启wal模式
            PRAGMA journal_mode = wal;
    
            -- 关闭同步
            PRAGMA synchronous = 0;
    
            -- 开启事务
            begin;
    
            -- 会话记录收集表
            CREATE TABLE IF NOT EXISTS `bt_playrecords` (
                `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                `host` TEXT NOT NULL DEFAULT '',
                `playback` TEXT NOT NULL DEFAULT '',
                `username` TEXT NOT NULL DEFAULT '',
                `uid` INTEGER NOT NULL DEFAULT 0,
                `port` INTEGER NOT NULL DEFAULT 0,
                `login_mode` TEXT NOT NULL DEFAULT '',
                `count_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
            );
    
            CREATE INDEX IF NOT EXISTS `btPlayRecords_createTime`
                ON `bt_playrecords` (`create_time`);
            
            -- 提交事务
            commit;
        ''',

    # nginx 信息表
    'nginx_stats_info': '''
            -- DROP TABLE IF EXISTS `bt_nginx_stats_info`;

            -- 开启wal模式
            PRAGMA journal_mode = wal;
    
            -- 关闭同步
            PRAGMA synchronous = 0;
    
            -- 开启事务
            begin;
    
            -- nginx 信息表
            CREATE TABLE IF NOT EXISTS `bt_nginx_stats_info` (
                `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                `version` TEXT NOT NULL DEFAULT '',
                `start_cmd` TEXT NOT NULL DEFAULT '',
                `conf_path` TEXT NOT NULL DEFAULT '',
                `ports` TEXT NOT NULL DEFAULT '',
                `modules` TEXT NOT NULL DEFAULT '',
                `worker_processes` TEXT NOT NULL DEFAULT '',
                `worker_connections` INTEGER NOT NULL DEFAULT 0,
                `keepalive_timeout` INTEGER NOT NULL DEFAULT 0,
                `gzip` TEXT NOT NULL DEFAULT '',
                `gzip_min_length` INTEGER NOT NULL DEFAULT 0,
                `gzip_comp_level` INTEGER NOT NULL DEFAULT 0,
                `client_max_body_size` INTEGER NOT NULL DEFAULT 0,
                `server_names_hash_bucket_size` INTEGER NOT NULL DEFAULT 0,
                `client_header_buffer_size` INTEGER NOT NULL DEFAULT 0,
                `client_body_buffer_size` INTEGER NOT NULL DEFAULT 0,
                `process` INTEGER NOT NULL DEFAULT 0,
                `website` INTEGER NOT NULL DEFAULT 0,
                `website_list` TEXT NOT NULL DEFAULT '',
                `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
            );
    
            CREATE INDEX IF NOT EXISTS `bt_Nginx_Stats_createTime`
                ON `bt_nginx_stats_info` (`create_time`);
    
            -- 提交事务
            commit;
        ''',

    # 安全监控-漏洞表
    'server_bugs': '''
        -- 开启wal模式
        PRAGMA journal_mode=wal;

        -- 关闭同步
        PRAGMA synchronous=0;

        -- 开启事务
        begin;

        -- 安全监控-漏洞表
        CREATE TABLE IF NOT EXISTS `bt_server_bugs` (
            `id` INTEGER NOT NULL PRIMARY KEY, -- hash(sid|vuln_id)
            `vuln_id` INTEGER NOT NULL DEFAULT 0, -- 漏洞ID
            `usable` INTEGER NOT NULL DEFAULT 0, -- 漏洞是否可用
            `status` INTEGER NOT NULL DEFAULT 0, -- 漏洞状态 0-未处理 1-已忽略 2-已处理
            `ignore_operator` INTEGER NOT NULL DEFAULT 0, -- 操作忽略的用户UID
            `ignore_time` INTEGER NOT NULL DEFAULT 0, -- 漏洞设置为已忽略的时间
            `handle_operator` INTEGER NOT NULL DEFAULT 0, -- 操作处理的用户UID
            `handled_time` INTEGER NOT NULL DEFAULT 0, -- 漏洞设置为已处理的时间
            `create_time` INTEGER NOT NULL DEFAULT 0, -- 漏洞首次扫描时间
            `update_time` INTEGER NOT NULL DEFAULT 0, -- 上一次扫描漏洞时间
            `level` INTEGER NOT NULL DEFAULT 0, -- 漏洞级别 0-低 1-中 2-高 3-危险
            `cve_id` TEXT NOT NULL DEFAULT '', -- 漏洞CVE编号
            `type` TEXT NOT NULL DEFAULT '', -- 漏洞类型 system-系统漏洞 apply-插件/软件/文件漏洞
            `vuln_name` TEXT NOT NULL DEFAULT '', -- 漏洞标题
            `soft_source` TEXT NOT NULL DEFAULT '', --  命令行工具/插件/软件的安装来源、文件路径 cmd-系统命令 apt/rpm/yum-软件仓库 file-文件
            `soft_name` TEXT NOT NULL DEFAULT '', -- 引发漏洞的命令行工具或插件/软件
            `soft_version` TEXT NOT NULL DEFAULT '', -- 引发漏洞的软件版本号(不是软件则为空 '')
            `file_path` TEXT NOT NULL DEFAULT '', -- 漏洞文件路径
            `tag` TEXT NOT NULL DEFAULT '[]', -- 漏洞特征列表 ['漏洞特征1', '漏洞特征2']
            `ps` TEXT NOT NULL DEFAULT '', -- 漏洞描述
            `suggestions` TEXT NOT NULL DEFAULT '', -- 修复建议
            `fix_remark` TEXT NOT NULL DEFAULT '' -- 处理人备注
        );

        CREATE INDEX IF NOT EXISTS `serverBugs_usable_status`
            ON `bt_server_bugs` (`usable`, `status`);

        CREATE INDEX IF NOT EXISTS `serverBugs_level_type_cveId`
            ON `bt_server_bugs` (`level`, `type`, 'cve_id');

        -- 提交事务
        commit;
    ''',

    # 安全监控-挖矿木马表
    'server_minings': '''
        -- 开启wal模式
        PRAGMA journal_mode=wal;

        -- 关闭同步
        PRAGMA synchronous=0;

        -- 开启事务
        begin;

        -- 安全监控-挖矿木马表
        CREATE TABLE IF NOT EXISTS `bt_server_minings` (
            `id` INTEGER NOT NULL PRIMARY KEY, -- hash(sid|vuln_id)
            `vuln_id` INTEGER NOT NULL DEFAULT 0, -- 挖矿木马ID
            `usable` INTEGER NOT NULL DEFAULT 0, -- 挖矿木马是否存在
            `status` INTEGER NOT NULL DEFAULT 0, -- 漏洞状态 0-未处理 1-已忽略 2-已处理
            `ignore_operator` INTEGER NOT NULL DEFAULT 0, -- 操作忽略的用户UID
            `ignore_time` INTEGER NOT NULL DEFAULT 0, -- 设置为已忽略的时间
            `handle_operator` INTEGER NOT NULL DEFAULT 0, -- 操作处理的用户UID
            `handled_time` INTEGER NOT NULL DEFAULT 0, -- 设置为已处理的时间
            `create_time` INTEGER NOT NULL DEFAULT 0, -- 首次扫描时间
            `update_time` INTEGER NOT NULL DEFAULT 0, -- 上一次扫描漏洞时间
            `type` TEXT NOT NULL DEFAULT '', -- 挖矿木马类型 xmrig-门罗币挖矿木马
            `title` TEXT NOT NULL DEFAULT '', -- 挖矿木马标题
            `ps` TEXT NOT NULL DEFAULT '', -- 漏洞描述
            `suggestions` TEXT NOT NULL DEFAULT '', -- 修复建议
            `fix_remark` TEXT NOT NULL DEFAULT '', -- 处理人备注
            `process_info` TEXT NOT NULL DEFAULT '{}' -- 进程信息
        );

        CREATE INDEX IF NOT EXISTS `serverMininigs_usable_status`
            ON `bt_server_minings` (`usable`, `status`);

        CREATE INDEX IF NOT EXISTS `serverMinings_type`
            ON `bt_server_minings` (`type`);

        -- 提交事务
        commit;
    ''',
}

# 独立数据库建表语句
_SINGLE_DB_SQL_LIST = {
    # 主机端口列表(准备废弃)
    'server_ports': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机端口列表
        CREATE TABLE IF NOT EXISTS `bt_server_ports` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `ip` TEXT NOT NULL DEFAULT '',
            `port` INTEGER NOT NULL DEFAULT 0,
            `protocol` TEXT	NOT NULL DEFAULT '',
            `process_name` TEXT NOT NULL DEFAULT '',
            `process_path` TEXT NOT NULL DEFAULT '',
            `status` INTEGER NOT NULL DEFAULT 0,
            `test_connection` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `last_test_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `serverPorts_sid_port_status_createTime_lastTestTime`
            ON `bt_server_ports` (`sid`, `port`, `status`, `create_time`, `last_test_time`);

        CREATE INDEX IF NOT EXISTS `serverPorts_testConnection_sid`
            ON `bt_server_ports` (`test_connection`, `sid`);

        -- 提交事务
        commit;
    ''',

    # 进程列表
    'processes': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程信息收集表
        CREATE TABLE IF NOT EXISTS `bt_processes` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `pne_id` INTEGER NOT NULL DEFAULT 0, -- 进程名称与启动路径hash
            -- `name` TEXT NOT NULL DEFAULT '',
            `status` TEXT NOT NULL DEFAULT 'sleep',
            `boot_time` INTEGER NOT NULL DEFAULT 0,
            -- `boot_command` TEXT NOT NULL DEFAULT '',
            `boot_user` TEXT NOT NULL DEFAULT '',
            `opened_files` INTEGER NOT NULL DEFAULT 0,
            `opened_connections` INTEGER NOT NULL DEFAULT 0,
            `opened_threads` INTEGER NOT NULL DEFAULT 0,
            `disk_read_bytes` INTEGER NOT NULL DEFAULT 0,
            `disk_write_bytes` INTEGER NOT NULL DEFAULT 0,
            `disk_read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `disk_write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `net_sent_bytes` INTEGER NOT NULL DEFAULT 0,
            `net_recv_bytes` INTEGER NOT NULL DEFAULT 0,
            `net_sent_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `net_recv_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
            `cpu_used_percent` REAL NOT NULL DEFAULT 0.00,
            `mem_used_percent` REAL NOT NULL DEFAULT 0.00,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        -- CREATE INDEX IF NOT EXISTS `processes_pneId_sid`
        --     ON `bt_processes` (`pne_id`, `sid`);

        CREATE INDEX IF NOT EXISTS `processes_sid_updateTime`
            ON `bt_processes` (`sid`, `update_time`);

        DROP INDEX IF EXISTS `processes_sid_name_createTime`;

        CREATE INDEX IF NOT EXISTS `processes_sid_status_createTime`
            ON `bt_processes` (`sid`, `status`, `create_time`);

        CREATE INDEX IF NOT EXISTS `processes_openedConnections_createTime_sid`
            ON `bt_processes` (`opened_connections`, `create_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `processes_netRecvBytes_netSentBytes_createTime_sid`
            ON `bt_processes` (`net_recv_bytes`, `net_sent_bytes`, `create_time`, `sid`);

        DROP INDEX IF EXISTS `processes_cpuUsedPercent_memUsedPercent_createTime_sid`;

        CREATE INDEX IF NOT EXISTS `processes_cpuUsedPercent_memUsedPercent_createTime_sid`
            ON `bt_processes` (`cpu_used_percent`, `mem_used_percent`, `create_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `processes_netRecvBytesPerSecond_netSentBytesPerSecond_createTime_sid`
            ON `bt_processes` (`net_recv_bytes_per_second`, `net_sent_bytes_per_second`, `create_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `processes_diskWriteBytesPerSecond_diskReadBytesPerSecond_createTime_sid`
            ON `bt_processes` (`disk_write_bytes_per_second`, `disk_read_bytes_per_second`, `create_time`, `sid`);

        -- 提交事务
        commit;
    ''',

    # SSH登录日志
    'ssh_login_logs': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- SSH登录信息收集表
        CREATE TABLE IF NOT EXISTS `bt_ssh_login_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `ip` TEXT NOT NULL DEFAULT '',
            `port` INTEGER NOT NULL DEFAULT 0,
            `ip_place` TEXT NOT NULL DEFAULT '',
            `user` TEXT NOT NULL DEFAULT '',
            `success` INTEGER NOT NULL DEFAULT 0,
            `login_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_sid_success_loginTime`
            ON `bt_ssh_login_logs` (`sid`, `success`, `login_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_user_success_loginTime`
            ON `bt_ssh_login_logs` (`user`, `success`, `login_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginLogs_ip_success_loginTime`
            ON `bt_ssh_login_logs` (`ip`, `success`, `login_time`);

        -- CREATE INDEX IF NOT EXISTS `sshLoginLogs_loginTime_ipPlace`
        --    ON `bt_ssh_login_logs` (`login_time`, `ip_place`);

        -- 提交事务
        commit;
    ''',

    # 告警任务
    'warning_tasks': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 告警任务表
        CREATE TABLE IF NOT EXISTS `bt_warning_tasks` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `conf_id` INTEGER NOT NULL DEFAULT 0,
            `title` TEXT NOT NULL DEFAULT '',
            `content` TEXT NOT NULL DEFAULT '',
            `status` INTEGER NOT NULL DEFAULT 0,
            `is_pushed` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `push_time` INTEGER NOT NULL DEFAULT 0,
            `handle_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `warningTasks_sid_status_createTime_pushTime`
            ON `bt_warning_tasks` (`sid`, `status`, `create_time`, `push_time`);

        CREATE INDEX IF NOT EXISTS `warningTasks_confId_createTime`
            ON `bt_warning_tasks` (`conf_id`, `create_time`);

        CREATE INDEX IF NOT EXISTS `warningTasks_createTime`
            ON `bt_warning_tasks` (`create_time`);

        CREATE INDEX IF NOT EXISTS `warningTasks_title_sid_createTime`
            ON `bt_warning_tasks` (`title`, `sid`, `create_time`);

        -- 提交事务
        commit;
    ''',

    # 命令执行日志
    'command_execute_logs': '''
         -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 命令执行记录表
        CREATE TABLE IF NOT EXISTS `bt_command_execute_logs` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `user` TEXT NOT NULL DEFAULT '',
            `command` TEXT NOT NULL DEFAULT '',
            `is_sensitive` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `commandExecuteLogs_sid_createTime_command_user`
            ON `bt_command_execute_logs` (`sid`, `create_time`, `command`, `user`);

        -- 提交事务
        commit;
    ''',

    # 危险命令表
    'danger_commands': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 危险命令表
        CREATE TABLE IF NOT EXISTS `bt_danger_commands` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `command` TEXT NOT NULL DEFAULT '',
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `dangerCommands_command`
            ON `bt_danger_commands` (`command`);

        CREATE INDEX IF NOT EXISTS `dangerCommands_createTime`
            ON `bt_danger_commands` (`create_time`);

        -- 提交事务
        commit;
    ''',

    # 服务端IP配置记录
    'server_ip_records': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 服务端IP记录表
        CREATE TABLE IF NOT EXISTS `bt_server_ip_records` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `ip` TEXT NOT NULL DEFAULT '',
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverIpRecords_ip_createTime`
            ON `bt_server_ip_records` (`ip`, `create_time`);

        CREATE INDEX IF NOT EXISTS `serverIpRecords_createTime`
            ON `bt_server_ip_records` (`create_time`);

        -- 提交事务
        commit;
    ''',

    # 主机数据库记录表
    'server_databases': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 主机数据库记录表
        CREATE TABLE IF NOT EXISTS `bt_server_databases` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `db_name` TEXT NOT NULL DEFAULT '',
            `table_name` TEXT NOT NULL DEFAULT '',
            `db_path` TEXT NOT NULL DEFAULT '',
            `db_date` INTEGER NOT NULL DEFAULT 202208,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `archive_time` INTEGER NOT NULL DEFAULT 0,
            `unarchive_time` INTEGER NOT NULL DEFAULT 0,
            `archive_path` TEXT NOT NULL DEFAULT '',
            `delete_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `serverDatabases_sid_deleteTime_dbDate_tableName_archiveTime_unarchiveTime`
            ON `bt_server_databases` (`sid`, `delete_time`, `db_date`, `table_name`, `archive_time`, `unarchive_time`);

        -- 提交事务
        commit;
    ''',

    # 版本补丁记录表
    'version_patches': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 版本补丁记录表
        CREATE TABLE IF NOT EXISTS `bt_version_patches` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `version` TEXT NOT NULL DEFAULT '1.0.0',
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `versionPatches_createTime_version`
            ON `bt_version_patches` (`create_time`, `version`);

        -- 提交事务
        commit;
    ''',

    # 创建主机磁盘阵列信息数据库
    'server_raid_info': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        CREATE TABLE IF NOT EXISTS `bt_server_raid_info` (
            `sid` INTEGER PRIMARY KEY,
            `detail` TEXT,
            `output` TEXT,
            `ctrlcount` INTEGER DEFAULT 0,
            `check_result` TEXT,
            `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        -- 提交事务
        commit;
    ''',

    # 常用登录地点表
    'usually_login_place': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 常用登录地点记录表
        CREATE TABLE IF NOT EXISTS `bt_usually_login_place` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `type` TEXT NOT NULL DEFAULT '',
            `sid` INTEGER NOT NULL DEFAULT 0,
            `login_place` TEXT NOT NULL DEFAULT '',
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `usuallyLoginPlace_type_loginPlace_sid`
            ON `bt_usually_login_place` (`type`, `login_place`, `sid`);

        -- 提交事务
        commit;
    ''',

    # SSH登录次数统计表(每天)
    'ssh_login_total_daily': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- SSH登录次数统计表(每天)
        CREATE TABLE IF NOT EXISTS `bt_ssh_login_total_daily` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `success` INTEGER NOT NULL DEFAULT 0,
            `fail` INTEGER NOT NULL DEFAULT 0,
            `day_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `sshLoginTotalDaily_sid`
            ON `bt_ssh_login_total_daily` (`sid`);

        CREATE INDEX IF NOT EXISTS `sshLoginTotalDaily_success_dayTime_sid`
            ON `bt_ssh_login_total_daily` (`success`, `day_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `sshLoginTotalDaily_fail_dayTime_sid`
            ON `bt_ssh_login_total_daily` (`fail`, `day_time`, `sid`);

        -- 提交事务
        commit;
    ''',

    # SSH登录IP统计表(每天)
    'ssh_login_ip_total_daily': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- SSH登录IP统计表(每天)
        CREATE TABLE IF NOT EXISTS `bt_ssh_login_ip_total_daily` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `ip` TEXT NOT NULL DEFAULT '',
            `ports` TEXT NOT NULL DEFAULT '[]',
            `success` INTEGER NOT NULL DEFAULT 0,
            `fail` INTEGER NOT NULL DEFAULT 0,
            `ip_place` TEXT NOT NULL DEFAULT '',
            `day_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `sshLoginIpTotalDaily_sid_dayTime`
            ON `bt_ssh_login_ip_total_daily` (`sid`, `day_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginIpTotalDaily_success_dayTime_sid`
            ON `bt_ssh_login_ip_total_daily` (`success`, `day_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `sshLoginIpTotalDaily_fail_dayTime_sid`
            ON `bt_ssh_login_ip_total_daily` (`fail`, `day_time`, `sid`);

        -- 提交事务
        commit;
    ''',

    # SSH登录用户统计表(每天)
    'ssh_login_user_total_daily': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- SSH登录用户统计表(每天)
        CREATE TABLE IF NOT EXISTS `bt_ssh_login_user_total_daily` (
            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `user` TEXT NOT NULL DEFAULT '',
            `success` INTEGER NOT NULL DEFAULT 0,
            `fail` INTEGER NOT NULL DEFAULT 0,
            `day_time` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `sshLoginUserTotalDaily_sid_user_dayTime`
            ON `bt_ssh_login_user_total_daily` (`sid`, `user`, `day_time`);

        CREATE INDEX IF NOT EXISTS `sshLoginUserTotalDaily_success_user_dayTime_sid`
            ON `bt_ssh_login_user_total_daily` (`success`, `user`, `day_time`, `sid`);

        CREATE INDEX IF NOT EXISTS `sshLoginUserTotalDaily_fail_user_dayTime_sid`
            ON `bt_ssh_login_user_total_daily` (`fail`, `user`, `day_time`, `sid`);

        -- 提交事务
        commit;
    ''',

    # 进程名称与进程启动程序绝对路径
    'process_name_exe': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 进程名称与进程启动程序绝对路径
        CREATE TABLE IF NOT EXISTS `bt_process_name_exe` (
            `id` INTEGER NOT NULL PRIMARY KEY,
            `name` TEXT NOT NULL DEFAULT 0,
            `exe` TEXT NOT NULL DEFAULT ''
        );

        CREATE INDEX IF NOT EXISTS `processNameExe_name`
            ON `bt_process_name_exe` (`name`);

        -- 提交事务
        commit;
    ''',

    # 主机端口连接测试列表
    'server_port_connection_test': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        DROP TABLE IF EXISTS `bt_process_name_exe`;

        -- 主机端口连接测试列表
        CREATE TABLE IF NOT EXISTS `bt_server_port_connection_test` (
            `id` INTEGER NOT NULL PRIMARY KEY,
            `sid` INTEGER NOT NULL DEFAULT 0,
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );

        CREATE INDEX IF NOT EXISTS `serverPortConnectionTest_sid_createTime`
            ON `bt_server_port_connection_test` (`sid`, `create_time`);

        -- 提交事务
        commit;
    ''',

    # 监控数据采样设置数据库
    'sampling_settings': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 监控设置表
        CREATE TABLE IF NOT EXISTS `bt_sampling_settings` (
            `id` INTEGER NOT NULL PRIMARY KEY, -- hash(<server|process>|<主机ID|进程ID>|数据采集类型)
            `status` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `samplingSettings_status`
            ON `bt_sampling_settings` (`status`);

        -- 提交事务
        commit;
    ''',

    # 创建监控PORT配置表
    'availability_port': '''
        -- 开启wal模式
        PRAGMA journal_mode = wal;

        -- 关闭同步
        PRAGMA synchronous = 0;

        -- 开启事务
        begin;

        -- 监控PORT配置表
        CREATE TABLE IF NOT EXISTS `bt_availability_port` (
            `id` INTEGER NOT NULL PRIMARY KEY,
            `sid` INTEGER DEFAULT 0,
            `uid` INTEGER NOT NULL  DEFAULT 0,
            `add_type` INTEGER NOT NULL DEFAULT 0,
            `ip` TEXT NOT NULL DEFAULT '',
            `port` INTEGER NOT NULL DEFAULT 0,
            `task_name` TEXT NOT NULL DEFAULT '',
            `push_methods` TEXT NOT NULL DEFAULT '',
            `type` TEXT NOT NULL DEFAULT 'port',
            `frequency` INTEGER NOT NULL DEFAULT 20,
            `count` INTEGER NOT NULL DEFAULT 0,
            `protocol` INTEGER NOT NULL DEFAULT 0,
            `warning_mode` INTEGER NOT NULL DEFAULT 0,
            `last_warning_time` INTEGER NOT NULL DEFAULT 0,
            `warning` INTEGER NOT NULL DEFAULT 1,
            `port_hash` INTEGER DEFAULT 0,
            `node` INTEGER NOT NULL DEFAULT 0,
            `suspend` INTEGER NOT NULL DEFAULT 0,
            `nodes` TEXT NOT NULL DEFAULT '0',
            `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
            `retries` INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS `btAvailabilityPort_uid_ip_port_creatTime`
            ON `bt_availability_port` (`uid`,`ip`,`port`,`create_time`);

        CREATE INDEX IF NOT EXISTS `btAvailabilityPort_taskName`
            ON `bt_availability_port` (`task_name`);

        -- 提交事务
        commit;
    ''',

    # 创建监控PORT信息表
    'availability_port_info': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 监控PORT信息表
         CREATE TABLE IF NOT EXISTS `bt_availability_port_info` (
             `id` INTEGER NOT NULL PRIMARY KEY,
             `uid` INTEGER NOT NULL DEFAULT 0,
             `port_id` INTEGER NOT NULL DEFAULT 0,         
             `node` INTEGER NOT NULL DEFAULT 0,
             `is_connect` INTEGER NOT NULL DEFAULT 0,
             `delay` INTEGER DEFAULT 0,
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityPort_uid_creatTime`
             ON `bt_availability_port_info` (`uid`, `create_time`);

         -- 提交事务
         commit;
    ''',

    # 创建监控PING配置表
    'availability_ping': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 监控Ping表
         CREATE TABLE IF NOT EXISTS `bt_availability_ping` (
             `id` INTEGER NOT NULL PRIMARY KEY,
             `uid` INTEGER NOT NULL DEFAULT 0,
             `task_name` TEXT NOT NULL DEFAULT '',
             `add_type` INTEGER NOT NULL DEFAULT 0,
             `ip_src` INTEGER NOT NULL DEFAULT 0,
             `ip_dsc` TEXT NOT NULL DEFAULT '',
             `network` TEXT NOT NULL DEFAULT '',
             `warning` INTEGER NOT NULL DEFAULT 1,
             `last_warning_time` INTEGER NOT NULL DEFAULT 0,
             `w_loss_ratio` INTEGER NOT NULL DEFAULT 0,
             `w_delay` INTEGER NOT NULL DEFAULT 0,                          
             `node` INTEGER NOT NULL DEFAULT 0,
             `frequency` INTEGER NOT NULL DEFAULT 20,
             `count` INTEGER NOT NULL DEFAULT 2,
             `push_methods` TEXT NOT NULL DEFAULT '',
             `type` TEXT NOT NULL DEFAULT 'ping',
             `suspend` INTEGER NOT NULL DEFAULT 0,
             `nodes` TEXT NOT NULL DEFAULT '0',
             `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
             `retries` INTEGER NOT NULL DEFAULT 0
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityPing_uid_creatTime`
             ON `bt_availability_ping` (`uid`, `create_time`);

         CREATE INDEX IF NOT EXISTS `btAvailabilityPing_taskName`
             ON `bt_availability_ping` (`task_name`);

         -- 提交事务
         commit;
    ''',

    # 创建监控PING信息表
    'availability_ping_info': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 监控Ping信息表
         CREATE TABLE IF NOT EXISTS `bt_availability_ping_info` (
             `id` INTEGER NOT NULL PRIMARY KEY,
             `uid` INTEGER NOT NULL DEFAULT 0,
             `ping_id` INTEGER NOT NULL DEFAULT 0,
             `ip_dsc` TEXT NOT NULL DEFAULT '',
             `loss_ratio` INTEGER NOT NULL DEFAULT 0,
             `delay` INTEGER  DEFAULT 0,
             `is_ping` INTEGER NOT NULL DEFAULT 0,
             `node` INTEGER NOT NULL DEFAULT 0,
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityPingInfo_uid_creatTime`
             ON `bt_availability_ping_info` (`uid`, `create_time`);

         CREATE INDEX IF NOT EXISTS `btAvailabilityPingInfo_pingId`
             ON `bt_availability_ping_info` (`ping_id`);


         -- 提交事务
         commit;
    ''',

    # 创建监控HTTP(S)配置表
    'availability_http': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 监控http表
         CREATE TABLE IF NOT EXISTS `bt_availability_http` (
             `id` INTEGER NOT NULL PRIMARY KEY,       
             `task_name` TEXT NOT NULL DEFAULT '',
             `add_type` INTEGER NOT NULL DEFAULT 0,
             `uid` INTEGER NOT NULL DEFAULT 0,
             `url` TEXT NOT NULL DEFAULT '',
             `method` INTEGER NOT NULL DEFAULT 0,
             `frequency` INTEGER NOT NULL DEFAULT 20,
             `count` INTEGER NOT NULL DEFAULT 2,
             `status` TEXT NOT NULL DEFAULT '200-299',
             `head` TEXT NOT NULL DEFAULT '',
             `body` TEXT NOT NULL DEFAULT '',
             `keyword` TEXT DEFAULT '',
             `push_methods` TEXT NOT NULL DEFAULT '',
             `type` TEXT NOT NULL DEFAULT 'http',
             `warning` INTEGER NOT NULL DEFAULT 1,
             `last_warning_time` INTEGER NOT NULL DEFAULT 0,
             `node` INTEGER NOT NULL DEFAULT 0,
             `warning_mode` INTEGER NOT NULL DEFAULT 0,
             `is_basic` INTEGER NOT NULL DEFAULT 0,
             `bs_user` TEXT NOT NULL DEFAULT '',
             `bs_pwd` TEXT NOT NULL DEFAULT '',
             `suspend` INTEGER NOT NULL DEFAULT 0,
             `nodes` TEXT NOT NULL DEFAULT '0',
             `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
             `retries` INTEGER NOT NULL DEFAULT 0
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityHttp_creatTime`
             ON `bt_availability_http` (`create_time`);

         CREATE INDEX IF NOT EXISTS `btAvailabilityHttp_taskName`
             ON `bt_availability_http` (`task_name`);

         -- 提交事务
         commit;
    ''',

    # 创建监控HTTP(S)信息表
    'availability_http_info': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 监控Http信息表
         CREATE TABLE IF NOT EXISTS `bt_availability_http_info` (
             `id` INTEGER NOT NULL PRIMARY KEY,
             `uid` INTEGER NOT NULL DEFAULT 0,
             `http_id` INTEGER NOT NULL DEFAULT 0,       
             `response_time` INTEGER DEFAULT 0,       
             `response` TEXT DEFAULT '',
             `validity_period` INTEGER NOT NULL DEFAULT 0,
             `node` INTEGER NOT NULL DEFAULT 0,
             `is_ok` INTEGER NOT NULL DEFAULT 0,
             `start_time` INTEGER DEFAULT 0,
             `end_time` INTEGER DEFAULT 0,
             `subject` TEXT DEFAULT '',
             `issuer` TEXT DEFAULT '',
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityHttpInfo_uid_creatTime`
             ON `bt_availability_http_info` (`uid`, `create_time`);

         CREATE INDEX IF NOT EXISTS `btAvailabilityHttpInfo_httpId`
             ON `bt_availability_http_info` (`http_id`);


         -- 提交事务
         commit;
    ''',

    # 创建告警日志信息表
    'availability_wanrning_log': '''
         -- 开启wal模式
         PRAGMA journal_mode = wal;

         -- 关闭同步
         PRAGMA synchronous = 0;

         -- 开启事务
         begin;

         -- 告警日志信息表
         CREATE TABLE IF NOT EXISTS `bt_availability_wanrning_log` (
             `id` INTEGER NOT NULL PRIMARY KEY, 
             `task_id` INTEGER NOT NULL DEFAULT 0,    
             `type` TEXT NOT NULL DEFAULT '',
             `content` TEXT NOT NULL DEFAULT '',
             `task_name` TEXT NOT NULL DEFAULT '',
             `push_methods` TEXT NOT NULL DEFAULT '',
             `subject` TEXT NOT NULL DEFAULT '',
             `message` TEXT NOT NULL DEFAULT '',
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
         );

         CREATE INDEX IF NOT EXISTS `btAvailabilityWanrningLog_creatTime`
             ON `bt_availability_wanrning_log` (`create_time`);

         -- 提交事务
         commit;
    ''',

    # 安全监控-漏洞扫描统计表
    'server_bug_total': '''
         -- 开启wal模式
         PRAGMA journal_mode=wal;

         -- 关闭同步
         PRAGMA synchronous=0;

         -- 开启事务
         begin;

         -- 安全监控-漏洞扫描统计表
         CREATE TABLE IF NOT EXISTS `bt_server_bug_total` (
             `sid` INTEGER NOT NULL PRIMARY KEY, -- 主机ID
             `bugs` INTEGER NOT NULL DEFAULT 0, -- 漏洞总数    
             `ignored` INTEGER NOT NULL DEFAULT 0, -- 已忽略漏洞数
             `handled` INTEGER NOT NULL DEFAULT 0, -- 已处理漏洞数
             `fixed` INTEGER NOT NULL DEFAULT 0, -- 已修复漏洞数
             `last_scan_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')), -- 上次扫描时间
             `level_0` INTEGER NOT NULL DEFAULT 0, -- 低危数
             `level_1` INTEGER NOT NULL DEFAULT 0, -- 中危数
             `level_2` INTEGER NOT NULL DEFAULT 0, -- 高危数
             `level_3` INTEGER NOT NULL DEFAULT 0 -- 严重数
         );

         CREATE INDEX IF NOT EXISTS `btServerBugTotal_bugs_ignored_handled_fixed`
             ON `bt_server_bug_total` (`bugs`, 'ignored', 'handled', 'fixed');

         -- 提交事务
         commit;
    ''',

    # 安全监控-挖矿木马统计表
    'server_mining_total': '''
         -- 开启wal模式
         PRAGMA journal_mode=wal;

         -- 关闭同步
         PRAGMA synchronous=0;

         -- 开启事务
         begin;

         -- 安全监控-漏洞扫描统计表
         CREATE TABLE IF NOT EXISTS `bt_server_mining_total` (
             `sid` INTEGER NOT NULL PRIMARY KEY, -- 主机ID
             `minings` INTEGER NOT NULL DEFAULT 0, -- 挖矿木马总数    
             `ignored` INTEGER NOT NULL DEFAULT 0, -- 已忽略挖矿木马数
             `handled` INTEGER NOT NULL DEFAULT 0, -- 已处理挖矿木马数
             `fixed` INTEGER NOT NULL DEFAULT 0, -- 已修复挖矿木马数
             `last_scan_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 上次扫描时间
             
         );

         CREATE INDEX IF NOT EXISTS `ServerMiningTotal_minings_ignored_handled_fixed`
             ON `bt_server_mining_total` (`minings`, 'ignored', 'handled', 'fixed');

         -- 提交事务
         commit;
    ''',

    # 安全监控-病毒扫描
    'malicious_scan': '''
        -- 开启wal模式
         PRAGMA journal_mode=wal;

         -- 关闭同步
         PRAGMA synchronous=0;

         -- 开启事务
         begin;

         -- 安全监控-病毒扫描任务表
         CREATE TABLE IF NOT EXISTS `bt_malicious_scan_tasks` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- 任务ID
             `creator` INTEGER NOT NULL DEFAULT 0, -- 创建此任务的用户UID
             `stop_operator` INTEGER NOT NULL DEFAULT 0, -- 强制结束此任务的用户UID
             `stop_time` INTEGER NOT NULL DEFAULT 0, -- 任务强制结束时间
             `scan_type` INTEGER NOT NULL DEFAULT 0, -- 扫描类型 0-全盘扫描 1-快速扫描 2-指定目录扫描
             `status` INTEGER NOT NULL DEFAULT 0, -- 扫描状态 0-扫描中 1-扫描成功 2-扫描失败
             `scan_progress` INTEGER NOT NULL DEFAULT 0, -- 扫描进度(5位整数)
             `finish_time` INTEGER NOT NULL DEFAULT 0, -- 扫描完成时间
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')), -- 添加时间
             `scan_dir` TEXT NOT NULL DEFAULT '/www', -- 扫描目录
             `name` TEXT NOT NULL DEFAULT '' -- 任务名称
         );

         CREATE INDEX IF NOT EXISTS `maliciousScanTasks_status_createTime_finishTime`
             ON `bt_malicious_scan_tasks` (`status`, `create_time`, `finish_time`);

         -- 安全监控-主机&病毒扫描任务关联表
         CREATE TABLE IF NOT EXISTS `bt_server_malicious_scan_task` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- 主键ID
             `task_id` INTEGER NOT NULL DEFAULT 0, -- 任务ID
             `sid` INTEGER NOT NULL DEFAULT 0, -- 主机ID    
             `scan_pid` INTEGER NOT NULL DEFAULT 0, -- 扫描进程PID
             `scan_process_exists` INTEGER NOT NULL DEFAULT 0, -- 扫描是否存活
             `stop_operator` INTEGER NOT NULL DEFAULT 0, -- 强制结束此任务的用户UID
             `stop_time` INTEGER NOT NULL DEFAULT 0, -- 任务强制结束时间
             `status` INTEGER NOT NULL DEFAULT 0, -- 扫描状态 0-扫描中 1-扫描成功 2-扫描失败
             `progress` INTEGER NOT NULL DEFAULT 0, -- 扫描进度(5位整数)
             `start_time` INTEGER NOT NULL DEFAULT 0, -- 扫描开始时间
             `finish_time` INTEGER NOT NULL DEFAULT 0 -- 扫描完成时间
         );

         CREATE INDEX IF NOT EXISTS `serverMaliciousScanTask_taskId_sid_progress_finishTime`
             ON `bt_server_malicious_scan_task` (`task_id`, `sid`, `progress`, `finish_time`);
         
         CREATE INDEX IF NOT EXISTS `serverMaliciousScanTask_sid`
             ON `bt_server_malicious_scan_task` (`sid`);
         
         CREATE INDEX IF NOT EXISTS `serverMaliciousScanTask_finishTime`
             ON `bt_server_malicious_scan_task` (`finish_time`);
         
         -- 安全监控-病毒扫描结果表
         CREATE TABLE IF NOT EXISTS `bt_malicious_scan_results` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- 主键ID
             `sid` INTEGER NOT NULL DEFAULT 0, -- 主机ID    
             `task_id` INTEGER NOT NULL DEFAULT 0, -- 扫描任务ID
             `status` INTEGER NOT NULL DEFAULT 0, -- 状态 0-未处理 1-已处理 2-已忽略(误报)
             `level` INTEGER NOT NULL DEFAULT 0, -- 风险级别 0-低风险 1-中风险 2-高风险 3-严重
             `white_list_id` INTEGER NOT NULL DEFAULT 0, -- 白名单ID(0表示没有加入白名单)
             `handle_operator` INTEGER NOT NULL DEFAULT 0, -- 处理人UID
             `handled_time` INTEGER NOT NULL DEFAULT 0, -- 处理时间
             `ignore_operator` INTEGER NOT NULL DEFAULT 0, -- 忽略人UID
             `ignore_time` INTEGER NOT NULL DEFAULT 0, -- 忽略时间
             `create_time` INTEGER NOT NULL DEFAULT 0, -- 扫描时间
             `file_path` TEXT NOT NULL DEFAULT '', -- 文件路径
             `fix_remark` TEXT NOT NULL DEFAULT '' -- 处理人备注
         );

         CREATE INDEX IF NOT EXISTS `maliciousScanResults_sid_taskId_status_createTime`
             ON `bt_malicious_scan_results` (`sid`, `task_id`, `status`, `create_time`);
         
         CREATE INDEX IF NOT EXISTS `maliciousScanResults_status_level`
             ON `bt_malicious_scan_results` (`status`, `level`);
         
         CREATE INDEX IF NOT EXISTS `maliciousScanResults_whiteListId`
             ON `bt_malicious_scan_results` (`white_list_id`);
         
         -- 安全监控-病毒扫描白名单
         CREATE TABLE IF NOT EXISTS `bt_malicious_white_lists` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- 白名单ID
             `is_dir` INTEGER NOT NULL DEFAULT 0, -- 是否为目录
             `creator` INTEGER NOT NULL DEFAULT 0, -- 添加此白名单的用户UID
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')), -- 添加时间
             `file_path` TEXT NOT NULL DEFAULT '', -- 文件/目录路径
             `name` TEXT NOT NULL DEFAULT '', -- 名称
             `ps` TEXT NOT NULL DEFAULT '' -- 描述
         );

         CREATE INDEX IF NOT EXISTS `maliciousWhiteLists_isDir_filePath`
             ON `bt_malicious_white_lists` (`is_dir`, `file_path`);
         
         CREATE INDEX IF NOT EXISTS `maliciousScanResults_createTime_creator`
             ON `bt_malicious_white_lists` (`create_time`, `creator`);
         
         CREATE INDEX IF NOT EXISTS `maliciousScanResults_name`
             ON `bt_malicious_white_lists` (`name`);

         -- 提交事务
         commit;
    ''',

    # 安全监控-病毒扫描统计表
    'server_malicious_scan_total': '''
        -- 开启wal模式
         PRAGMA journal_mode=wal;

         -- 关闭同步
         PRAGMA synchronous=0;

         -- 开启事务
         begin;

         -- 安全监控-病毒扫描统计表
         CREATE TABLE IF NOT EXISTS `bt_server_malicious_scan_total` (
             `sid` INTEGER NOT NULL PRIMARY KEY, -- 主机ID
             `danger` INTEGER NOT NULL DEFAULT 0, -- 严重病毒文件数量    
             `high` INTEGER NOT NULL DEFAULT 0, -- 高风险病毒文件数量
             `middle` INTEGER NOT NULL DEFAULT 0, -- 中风险病毒文件数量
             `low` INTEGER NOT NULL DEFAULT 0, -- 低风险病毒文件数量
             `handled` INTEGER NOT NULL DEFAULT 0, -- 已处理的病毒文件数量
             `ignored` INTEGER NOT NULL DEFAULT 0, -- 已忽略(误报)的病毒文件数量
             `white` INTEGER NOT NULL DEFAULT 0 -- 在白名单内的病毒文件数量
         );

         CREATE INDEX IF NOT EXISTS `serverMaliciousScanTotal_danger_high_middle_low_handled_ignored_white`
             ON `bt_server_malicious_scan_total` (`danger`, 'high', 'middle', 'low', `handled`, `ignored`, `white`);

         -- 提交事务
         commit;
    ''',

    # 自定义监控 进程监控 进程规则中间表 执行结果表
    'custom_process': '''
        -- 开启wal模式
         PRAGMA journal_mode=wal;

         -- 关闭同步
         PRAGMA synchronous=0;

         -- 开启事务
         begin;

         -- 自定义监控-进程监控表
         CREATE TABLE IF NOT EXISTS `bt_custom_process` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
             `pne_id` TEXT NOT NULL DEFAULT '', -- 进程id
             `sid` INTEGER NOT NULL DEFAULT 0, -- sid
             `is_push` INTEGER NOT NULL DEFAULT 0, -- 是否推送
             `push_methods` TEXT NOT NULL DEFAULT '', -- 推送方式
             `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),-- 修改时间
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 添加时间   
         );

         CREATE INDEX IF NOT EXISTS `customProcess_pneId_sid`
             ON `bt_custom_process` (`pne_id`, `sid`);
         CREATE INDEX IF NOT EXISTS `customProcess_createTime`
             ON `bt_custom_process` (`create_time`);
             
             
         -- 自定义监控- 进程 规则 (脚本)关联表 中间表
         CREATE TABLE IF NOT EXISTS `bt_custom_process_rule_script` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
             `pro_id` INTEGER NOT NULL DEFAULT 0, -- 进程监控id  表bt_custom_process --id
             `rule_id` INTEGER NOT NULL DEFAULT 0, -- 规则id 关联bt_warning_configurations表
             `push_condition` INTEGER NOT NULL DEFAULT 0,-- 推送条件  0-终止 1-恢复
             `is_push` INTEGER NOT NULL DEFAULT 0, -- 是否推送
             `script` TEXT NOT NULL DEFAULT '' -- 脚本内容
         );
         
         CREATE INDEX IF NOT EXISTS `customProcessRuleScript_proId`
             ON `bt_custom_process_rule_script` (`pro_id`);
         CREATE INDEX IF NOT EXISTS `customProcessRuleScript_ruleId`
             ON `bt_custom_process_rule_script` (`rule_id`);  
         CREATE INDEX IF NOT EXISTS `customProcessRuleScript_script`
             ON `bt_custom_process_rule_script` (`script`);  

         -- 自定义监控-进程监控脚本执行 结果表
         CREATE TABLE IF NOT EXISTS `bt_custom_process_script_result` (
             `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
             `pro_id` INTEGER NOT NULL DEFAULT 0, -- 进程监控id  表bt_custom_process --id
             `center_id` INTEGER NOT NULL DEFAULT 0, --中间表id 表bt_custom_process_rule_script
             `result` TEXT NOT NULL DEFAULT '', -- 脚本执行结果
             `err_msg` TEXT NOT NULL DEFAULT '', -- 错误信息
             `status` INTEGER NOT NULL DEFAULT 1, --执行状态 1成功 0 失败
             `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),-- 修改时间
             `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 添加时间   
         );

         CREATE INDEX IF NOT EXISTS `customProcessScriptResult_centerId`
             ON `bt_custom_process_script_result` (`center_id`);
         CREATE INDEX IF NOT EXISTS `customProcessScriptResult_proId`
             ON `bt_custom_process_script_result` (`pro_id`);     
         CREATE INDEX IF NOT EXISTS `customProcessScriptResult_createTime`
             ON `bt_custom_process_script_result` (`create_time`);

         -- 提交事务
         commit;
    ''',

    # 堡垒机终端会话记录表
    'fortress_player': '''
     -- 开启wal模式
     PRAGMA journal_mode=wal;

     -- 关闭同步
     PRAGMA synchronous=0;

     -- 开启事务
     begin;

    CREATE TABLE IF NOT EXISTS `bt_fortress_player` (
        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        `ssh_id` INTEGER NOT NULL DEFAULT 0,
        `host` TEXT NOT NULL DEFAULT '',
        `playback` TEXT NOT NULL DEFAULT '',
        `username` TEXT NOT NULL DEFAULT '',
        `uid` INTEGER NOT NULL DEFAULT 0,
        `port` INTEGER NOT NULL DEFAULT 0,
        `login_mode` TEXT NOT NULL DEFAULT '',
        `count_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
        `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );

    CREATE INDEX IF NOT EXISTS `btFortress_Player_createTime`
        ON `bt_fortress_player` (`create_time`);

    -- 提交事务
     commit;
''',

    # 堡垒机终端命令表
    'fortress_command': '''
     -- 开启wal模式
     PRAGMA journal_mode=wal;

     -- 关闭同步
     PRAGMA synchronous=0;

     -- 开启事务
     begin;

    CREATE TABLE IF NOT EXISTS `bt_fortress_command` (
        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        `title` TEXT NOT NULL DEFAULT '',
        `shell` TEXT NOT NULL DEFAULT '',
        `uid` INTEGER NOT NULL DEFAULT 0,
        `order_number` INTEGER NOT NULL DEFAULT 0,
        `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),-- 修改时间
        `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 添加时间 
    );

    CREATE INDEX IF NOT EXISTS `btFortress_Command_createTime`
        ON `bt_fortress_command` (`create_time`);

    -- 提交事务
     commit;
''',

    # 自定义监控 脚本监控
    'custom_script': '''
    -- 开启wal模式
     PRAGMA journal_mode=wal;

     -- 关闭同步
     PRAGMA synchronous=0;

     -- 开启事务
     begin;

     -- 自定义监控-脚本监控表
     CREATE TABLE IF NOT EXISTS `bt_custom_script` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `name` TEXT NOT NULL DEFAULT '', -- 监控名称
         `sid` INTEGER NOT NULL DEFAULT 0, -- sid
         `frequency` INTEGER NOT NULL DEFAULT 20, -- 检测频率 执行间隔 20s  
         `alarm_frequency` INTEGER NOT NULL DEFAULT 600, -- 告警频率 告警间隔 600s 
         `last_warning_time` INTEGER NOT NULL DEFAULT 0, -- 最后一次告警时间
         `condition` INTEGER NOT NULL DEFAULT 0, -- 推送条件      0不匹配时推送   1匹配时
         `is_push` INTEGER NOT NULL DEFAULT 0, -- 是否推送
         `push_methods` TEXT NOT NULL DEFAULT '', -- 推送方式
         `result_type` INTEGER NOT NULL DEFAULT 0, -- 脚本结果类型判定  1字符串   0 数值
         `result_match` INTEGER NOT NULL DEFAULT 0, -- 匹配方式   result_match 12345
         `script` TEXT NOT NULL DEFAULT '', -- 脚本命令
         `result_key` TEXT NOT NULL DEFAULT '', -- 返回结果关键词  多个,隔开
         `suspend` INTEGER NOT NULL DEFAULT 0, -- 暂停1   运行中0
         `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),-- 修改时间
         `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 添加时间  
     );

     CREATE INDEX IF NOT EXISTS `customScript_sid`
         ON `bt_custom_script` (`sid`);
     CREATE INDEX IF NOT EXISTS `customScript_createTime`
         ON `bt_custom_script` (`create_time`);

     -- 自定义监控-脚本监控 结果表
     CREATE TABLE IF NOT EXISTS `bt_custom_script_result` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `script_id` INTEGER NOT NULL DEFAULT 0, -- 脚本监控id  表bt_custom_script->id 
         `result` TEXT NOT NULL DEFAULT '', -- 脚本执行结果
         `err_msg` TEXT NOT NULL DEFAULT '', -- 错误信息
         `status` INTEGER NOT NULL DEFAULT 1, --执行状态 1成功 0 失败
         `is_warning` INTEGER NOT NULL DEFAULT 0, --是否推送了  记录推送次数
         `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')) -- 添加时间   
     );

     CREATE INDEX IF NOT EXISTS `customScriptResult_scriptId`
         ON `bt_custom_script_result` (`script_id`);     
     CREATE INDEX IF NOT EXISTS `customScriptResult_createTime`
         ON `bt_custom_script_result` (`create_time`);

     -- 提交事务
     commit;
''',

    # ssh登录日志数据库最新的数据
    'ssh_login_logs_latest': None,

    # 入侵检测
    'hids': '''
    -- 开启wal模式
     PRAGMA journal_mode=wal;

     -- 关闭同步
     PRAGMA synchronous=0;

     -- 开启事务
     begin;

     -- 入侵检测表 hids_list
     CREATE TABLE IF NOT EXISTS `bt_hids_list` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `sid` INTEGER NOT NULL DEFAULT 0, -- sid
         `level` INTEGER NOT NULL DEFAULT 0, -- 危险级别 0-低 1-中 2-高 3-危险
         `data_type` INTEGER NOT NULL DEFAULT 0, -- 规则类型 数字 带外攻击-601 提权攻击-611 代码执行-59 恶意连接-42
         `status` INTEGER NOT NULL DEFAULT 0, -- 处理状态0-未处理 1-已处理
         `white` INTEGER NOT NULL DEFAULT 0, -- 白名单id 不是白名单显示0
         `handle_operator` INTEGER NOT NULL DEFAULT 0, -- 操作已处理此任务的用户UID
         `handled_time` INTEGER NOT NULL DEFAULT 0, -- 设置为已处理时间
         `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')), -- 添加时间
         `vulnname` TEXT NOT NULL DEFAULT '', -- 名称
         `msg` TEXT NOT NULL DEFAULT '', -- 告警描述
         `suggestions` TEXT NOT NULL DEFAULT '', --处理建议
         `exe` TEXT NOT NULL DEFAULT '', -- 进程二进制文件
         `pid` TEXT NOT NULL DEFAULT '', -- 进程PID
         `argv` TEXT NOT NULL DEFAULT '', -- 进程命令行
         `type` TEXT NOT NULL DEFAULT '', -- 规则类型 汉字
         `other` TEXT NOT NULL DEFAULT '' -- 其他配置 存json

     );

     CREATE INDEX IF NOT EXISTS `hidsList_sid`
         ON `bt_hids_list` (`sid`);
     CREATE INDEX IF NOT EXISTS `hidsList_level`
         ON `bt_hids_list` (`level`);
     CREATE INDEX IF NOT EXISTS `hidsList_dataType`
         ON `bt_hids_list` (`data_type`);
     CREATE INDEX IF NOT EXISTS `hidsList_status`
         ON `bt_hids_list` (`status`);
     CREATE INDEX IF NOT EXISTS `hidsList_white`
         ON `bt_hids_list` (`white`);


     -- 入侵检测白名单 hids_white_list
     CREATE TABLE IF NOT EXISTS `bt_hids_white_list` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `type` INTEGER NOT NULL DEFAULT 0, -- 规则类型 带外攻击-601 提权攻击-611 代码执行-59 恶意连接-42
         `creator` INTEGER NOT NULL DEFAULT 0, -- 操作已处理此任务的用户UID
         `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')), -- 添加时间
         `match_type` INTEGER NOT NULL DEFAULT 1,  -- 检测结果项的匹配规则  1-完全相等 冗余字段
         `vulnname` TEXT NOT NULL DEFAULT '', -- 名称
         `ps` TEXT NOT NULL DEFAULT '', -- 描述
         `match_detail` TEXT NOT NULL DEFAULT '' -- 其他配置 存json

     );

     CREATE INDEX IF NOT EXISTS `hidsWhiteList_type`
         ON `bt_hids_white_list` (`type`);
     CREATE INDEX IF NOT EXISTS `hidsWhiteList_vulnname`
         ON `bt_hids_white_list` (`vulnname`);
     CREATE INDEX IF NOT EXISTS `hidsWhiteList_ps`
         ON `bt_hids_white_list` (`ps`);
     CREATE INDEX IF NOT EXISTS `hidsWhiteList_matchDetail`
         ON `bt_hids_white_list` (`match_detail`);


     -- 入侵检测运行状态配置开关 hids_setting
     CREATE TABLE IF NOT EXISTS `bt_hids_setting` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `sid` INTEGER NOT NULL DEFAULT 0, -- sid
         `open` INTEGER NOT NULL DEFAULT 1  -- 开关 0关闭 1开启

     );

     CREATE UNIQUE INDEX IF NOT EXISTS `hidsSetting_sid`
         ON `bt_hids_setting` (`sid`);

     CREATE INDEX IF NOT EXISTS `hidsSetting_open`
         ON `bt_hids_setting` (`open`);

     -- 入侵检测告警开关 hids_warning
     CREATE TABLE IF NOT EXISTS `bt_hids_warning` (
         `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
         `sid` INTEGER NOT NULL DEFAULT 0, -- sid
         `open` INTEGER NOT NULL DEFAULT 1,  -- 开关 0关闭 1开启
         `count` INTEGER NOT NULL DEFAULT 1,  -- 重复推送的间隔次数
         `warning_count` INTEGER NOT NULL DEFAULT 0  -- 累计需要推送的次数

     );
     CREATE UNIQUE INDEX IF NOT EXISTS `hidsWarning_sid`
         ON `bt_hids_warning` (`sid`);
     CREATE INDEX IF NOT EXISTS `hidsWarning_sid_open_count`
         ON `bt_hids_warning` (`sid`, `open`, `count`);

     -- 提交事务
     commit;
''',

    # 进程top5数据表
    'process_top_list': '''
     -- 开启wal模式
     PRAGMA journal_mode=wal;

     -- 关闭同步
     PRAGMA synchronous=0;

     -- 开启事务
     begin;

    CREATE TABLE IF NOT EXISTS `bt_process_top_list` (
        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        `sid` INTEGER NOT NULL DEFAULT 0,
        `type` INTEGER NOT NULL DEFAULT 0, --top类型  1-cpu_top,  2-mem_top, 3-disk_top, 4-network_top
        `time_slot` INTEGER NOT NULL DEFAULT 0, --时间段  每个时间段的top5, 7.5min/次
        `data` TEXT NOT NULL DEFAULT '' --top5数据 json格式
    );

    CREATE INDEX IF NOT EXISTS `btProcessTopList_sid`
        ON `bt_process_top_list` (`sid`);
    CREATE INDEX IF NOT EXISTS `btProcessTopList_type`
        ON `bt_process_top_list` (`type`);
    CREATE INDEX IF NOT EXISTS `btProcessTopList_timeSlot`
        ON `bt_process_top_list` (`time_slot`);

    -- 提交事务
     commit;
''',


}


def db_mgr(db_name=_DB_MGR, brandnew=True):
    '''
        @name 获取主数据库连接对象
        @author Zhj<2022-08-15>
        @param db_name<?string> 数据库名称[可选]
        @return Db
    '''
    if is_single_db(db_name):
        return Db('{}/{}'.format(_SINGLE_BASE_DIR, db_name), brandnew).synchronous_off_wal()
        # return Db('{}/{}'.format(_SINGLE_BASE_DIR, db_name), brandnew)

    return Db(db_name, brandnew).synchronous_off_wal()
    # return Db(db_name, brandnew)


def is_single_db(table_name):
    '''
        @name 检查是否独立数据库
        @author Zhj<2022-08-23>
        @param table_name<string> 表名
        @return bool
    '''
    if table_name in _SINGLE_DB_SQL_LIST:
        return True

    return False


def _init_mgr_db(force=False):
    '''
        @name 初始化主数据库
        @author Zhj<2022-08-23>
        @return bool
    '''
    ret = True

    cache_key = 'MONITOR_MGR_DB_INITIALIZED'

    # 已初始化过，跳过
    if not force and public.cache_get(cache_key):
        return ret

    # 上锁
    # with Locker.acquire(_LOCK):
    try:
        # if os.path.exists('{}/data/{}.db'.format(public.get_panel_path(), _DB_MGR)):
        #     raise BtMonitorException('database monitor_mgr has been initialized.')
        with db_mgr() as db:
            db.query().execute_script('''
                -- 开启wal模式
                PRAGMA journal_mode = wal;

                -- 开启事务
                begin;

                -- 主机信息表
                CREATE TABLE IF NOT EXISTS `bt_servers` (
                    `sid` INTEGER NOT NULL PRIMARY KEY,
                    `ip` TEXT NOT NULL DEFAULT '',
                    `remark` TEXT NOT NULL DEFAULT '',
                    `status` INTEGER NOT NULL DEFAULT 0,
                    `is_authorized` INTEGER NOT NULL DEFAULT 0,
                    `allow_notify` INTEGER NOT NULL DEFAULT 1,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `last_active_time` INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS `servers_ip`
                    ON `bt_servers` (`ip`);

                CREATE INDEX IF NOT EXISTS `servers_status_isAuthorized_allowNotify`
                    ON `bt_servers` (`status`, `is_authorized`, `allow_notify`);

                CREATE INDEX IF NOT EXISTS `servers_remark`
                    ON `bt_servers` (`remark`);

                CREATE INDEX IF NOT EXISTS `servers_createTime`
                    ON `bt_servers` (`create_time`);

                CREATE INDEX IF NOT EXISTS `servers_lastActiveTime`
                    ON `bt_servers` (`last_active_time`);

                -- 主机组表
                CREATE TABLE IF NOT EXISTS `bt_server_group` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `name` text NOT NULL DEFAULT '',
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverGroup_name`
                    ON `bt_server_group` (`name`);

                CREATE INDEX IF NOT EXISTS `serverGroup_createTime_updateTime`
                    ON `bt_server_group` (`create_time`, `update_time`);

                -- 主机详细信息表
                CREATE TABLE IF NOT EXISTS `bt_server_details` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `host_info` TEXT NOT NULL DEFAULT '{}',
                    `cpu_info` TEXT NOT NULL DEFAULT '{}',
                    `mem_info` TEXT NOT NULL DEFAULT '{}',
                    `disk_info` TEXT NOT NULL DEFAULT '[]',
                    `net_info` TEXT NOT NULL DEFAULT '[]',
                    `load_avg` TEXT NOT NULL DEFAULT '{}',
                    `firewall_info` TEXT NOT NULL DEFAULT '{}',
                    `port_info` TEXT NOT NULL DEFAULT '{}',
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverDetails_sid`
                    ON `bt_server_details` (`sid`);

                CREATE INDEX IF NOT EXISTS `serverDetails_createTime_updateTime`
                    ON `bt_server_details` (`create_time`, `update_time`);

                -- 主机告警模板包关联表
                CREATE TABLE IF NOT EXISTS `bt_server_warning_template_package_merge` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `package_id` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverWarningTemplatePackageMerge_sid_packageId_createTime`
                    ON `bt_server_warning_template_package_merge` (`sid`, `package_id`, `create_time`);

                -- 告警模板包表
                CREATE TABLE IF NOT EXISTS `bt_warning_template_packages` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `name` TEXT NOT NULL DEFAULT '',
                    `push_methods` TEXT NOT NULL DEFAULT '',
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `warningTemplatePackages_name`
                    ON `bt_warning_template_packages` (`name`);

                CREATE INDEX IF NOT EXISTS `warningTemplatePackages_createTime_updateTime`
                    ON `bt_warning_template_packages` (`create_time`, `update_time`);

                -- 告警模板表
                CREATE TABLE IF NOT EXISTS `bt_warning_templates` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `package_id` INTEGER NOT NULL DEFAULT 0,
                    `watch_type` INTEGER NOT NULL DEFAULT 1,
                    `is_push` INTEGER NOT NULL DEFAULT 0,
                    `scores` INTEGER NOT NULL DEFAULT 0, -- 告警得分(0~100) 用于判断告警级别
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `linked_all_server` INTEGER NOT NULL DEFAULT 0, -- 是否关联所有主机
                    `type` TEXT NOT NULL DEFAULT 'resource',
                    `watch_target` TEXT NOT NULL DEFAULT '',
                    `watch_value` TEXT NOT NULL DEFAULT '',
                    `push_methods` TEXT NOT NULL DEFAULT '',
                    `linked_server_groups` TEXT NOT NULL DEFAULT '', -- 关联的主机分组ID,多个使用[,]分隔
                    `title` TEXT NOT NULL DEFAULT '',
                    `sub_type` TEXT NOT NULL DEFAULT '',
                    `content` TEXT NOT NULL DEFAULT '',
                    `remark` TEXT NOT NULL DEFAULT '' -- 备注
                );

                CREATE INDEX IF NOT EXISTS `warningTemplates_packageId`
                    ON `bt_warning_templates` (`package_id`);

                CREATE INDEX IF NOT EXISTS `warningTemplates_title`
                    ON `bt_warning_templates` (`title`);

                CREATE INDEX IF NOT EXISTS `warningTemplates_type_subType`
                    ON `bt_warning_templates` (`type`, `sub_type`);

                CREATE INDEX IF NOT EXISTS `warningTemplates_createTime`
                    ON `bt_warning_templates` (`create_time`);

                -- 告警配置表
                CREATE TABLE IF NOT EXISTS `bt_warning_configurations` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `template_id` INTEGER NOT NULL DEFAULT 0, -- 模板规则ID
                    `watch_type` INTEGER NOT NULL DEFAULT 1,
                    `is_push` INTEGER NOT NULL DEFAULT 0,
                    `scores` INTEGER NOT NULL DEFAULT 0, -- 告警得分(0~100) 用于判断告警级别
                    `add_source` INTEGER NOT NULL DEFAULT 0,--添加来源 1-自定义监控 2-入侵检测规则 3-病毒扫描
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `type` TEXT NOT NULL DEFAULT 'resource',
                    `watch_target` TEXT NOT NULL DEFAULT '',
                    `watch_value` TEXT NOT NULL DEFAULT '',
                    `push_methods` TEXT NOT NULL DEFAULT '',
                    `title` TEXT NOT NULL DEFAULT '',
                    `sub_type` TEXT NOT NULL DEFAULT '',
                    `content` TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS `warningConfigurations_title`
                    ON `bt_warning_configurations` (`title`);

                CREATE INDEX IF NOT EXISTS `warningConfigurations_sid_type_subType`
                    ON `bt_warning_configurations` (`sid`, `type`, `sub_type`);

                CREATE INDEX IF NOT EXISTS `warningConfigurations_createTime`
                    ON `bt_warning_configurations` (`create_time`);

                -- 被控面板配置表
                CREATE TABLE IF NOT EXISTS "bt_panel_info" (
                    "sid"	INTEGER,
                    "panel_address"	VARCHAR(48),
                    "token"	VARCHAR(64),
                    "panel_version" TEXT DEFAULT '',
                    PRIMARY KEY("sid")
                );

                -- SSH终端配置表
                CREATE TABLE IF NOT EXISTS "bt_ssh_info" (
                    "sid"	INTEGER,
                    "username"	VARCHAR(24),
                    "password"	VARCHAR(255),
                    "host"	VARCHAR(48),
                    "port"	INTEGER(11) DEFAULT (22),
                    "addtime"	INTEGER(11),
                    "pkey"	TEXT DEFAULT '',
                    PRIMARY KEY("sid")
                );
                
               -- 堡垒机权限表
                CREATE TABLE IF NOT EXISTS `bt_fortress_role` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `role_id` INTEGER NOT NULL DEFAULT 0,
                    `ssh_id` INTEGER NOT NULL DEFAULT 0,
                    `type` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );
                
                -- 提交事务
                commit;
            ''')

        # 标记初始化成功
        public.cache_set(cache_key, 1, 2678400)
    except BaseException as e:
        # 记录异常堆栈
        public.print_exc_stack(e)

    return ret


def _init_single_db(force=False):
    '''
        @name 初始化独立数据库
        @author Zhj<2022-08-23>
        @return bool
    '''
    ret = True

    cache_key = 'MONITOR_SINGLE_DB_INITIALIZED'

    # 已初始化过，跳过
    if not force and public.cache_get(cache_key):
        return ret

    # 上锁
    # with Locker.acquire(_LOCK):
    try:
        # 确保目录存在
        db_path = '{}/data/{}'.format(public.get_panel_path(), _SINGLE_BASE_DIR)

        # 目录不存在则创建
        if not os.path.isdir(db_path):
            os.makedirs(db_path, 0o755)

        for tbl_name, sql_txt in _SINGLE_DB_SQL_LIST.items():
            if sql_txt is None:
                continue
            try:
                with Db('{}/{}'.format(_SINGLE_BASE_DIR, tbl_name)) as db:
                    db.query().execute_script(sql_txt)
            except BaseException as e:
                public.print_exc_stack(e)

        # 标记初始化成功
        public.cache_set(cache_key, 1, 2678400)
    except BaseException as e:
        # 记录异常堆栈
        public.print_exc_stack(e)

        ret = False

    return ret


# 初始化内存临时数据库
def _init_memory_db(force=False):
    ret = True

    cache_key = 'MONITOR_MEMORY_DB_INITIALIZED'

    # 已初始化过，跳过
    if not force and public.cache_get(cache_key):
        return ret

    try:
        with Db('/dev/shm/monitor_tmp') as db:
            db.query().execute_script('''
                -- 开启wal模式
                PRAGMA journal_mode=wal;

                -- 关闭同步
                PRAGMA synchronous=0;

                -- 开启事务
                begin;

                -- 主机心跳表
                -- CREATE TABLE IF NOT EXISTS `bt_server_heartbeat` (
                --     `sid` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                --     `last_heartbeat_time` INTEGER NOT NULL DEFAULT 0
                -- );

                -- CREATE INDEX IF NOT EXISTS `serverHeartbeat_lastHeartbeatTime`
                --     ON `bt_server_heartbeat` (`last_heartbeat_time`);

                -- 主机CPU信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_cpu_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `percent` REAL NOT NULL DEFAULT 0.00,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverCpuInfoList_sid_percent_createTime`
                    ON `bt_server_cpu_info_list` (`sid`, `percent`, `create_time`);

                -- 主机内存信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_mem_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `percent` REAL NOT NULL DEFAULT 0.00,
                    `used`	INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverMemInfoList_sid_percent_createTime`
                    ON `bt_server_mem_info_list` (`sid`, `percent`, `create_time`);

                CREATE INDEX IF NOT EXISTS `serverMemInfoList_sid_used_createTime`
                    ON `bt_server_mem_info_list` (`sid`, `used`, `create_time`);

                -- 主机SWAP信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_swap_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `percent` REAL NOT NULL DEFAULT 0.00,
                    `used` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverSwapInfoList_sid_percent_createTime`
                    ON `bt_server_swap_info_list` (`sid`, `percent`, `create_time`);

                CREATE INDEX IF NOT EXISTS `serverSwapInfoList_sid_used_createTime`
                    ON `bt_server_swap_info_list` (`sid`, `used`, `create_time`);

                -- 主机网卡信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_net_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `name` TEXT NOT NULL DEFAULT '',
                    `sent_per_second` INTEGER NOT NULL DEFAULT 0,
                    `recv_per_second` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverNetInfoList_sid_name_createTime`
                    ON `bt_server_net_info_list` (`sid`, `name`, `create_time`);

                CREATE INDEX IF NOT EXISTS `serverNetInfoList_sentPerSecond_name_sid`
                    ON `bt_server_net_info_list` (`sent_per_second`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverNetInfoList_recvPerSecond_name_sid`
                    ON `bt_server_net_info_list` (`recv_per_second`, `name`, `sid`);

                -- 主机磁盘信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_disk_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `name` TEXT NOT NULL DEFAULT '',
                    `used` INTEGER NOT NULL DEFAULT 0,
                    `used_percent` REAL NOT NULL DEFAULT 0.00,
                    `inodes_used` INTEGER NOT NULL DEFAULT 0,
                    `inodes_used_percent` REAL NOT NULL DEFAULT 0.00,
                    `iops` INTEGER NOT NULL DEFAULT 0,
                    `io_percent` REAL NOT NULL DEFAULT 0.00,
                    `read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_sid_name_createTime`
                    ON `bt_server_disk_info_list` (`sid`, `name`, `create_time`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_readBytesPerSecond_name_sid`
                    ON `bt_server_disk_info_list` (`read_bytes_per_second`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_writeBytesPerSecond_name_sid`
                    ON `bt_server_disk_info_list` (`write_bytes_per_second`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_usedPercent_name_sid`
                    ON `bt_server_disk_info_list` (`used_percent`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_inodeUsedPercent_name_sid`
                    ON `bt_server_disk_info_list` (`inodes_used_percent`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_ioPercent_name_sid`
                    ON `bt_server_disk_info_list` (`io_percent`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_readBytesPerSecond_name_sid`
                    ON `bt_server_disk_info_list` (`read_bytes_per_second`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_writeBytesPerSecond_name_sid`
                    ON `bt_server_disk_info_list` (`write_bytes_per_second`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_used_name_sid`
                    ON `bt_server_disk_info_list` (`used`, `name`, `sid`);

                CREATE INDEX IF NOT EXISTS `serverDiskInfoList_inodesUsed_name_sid`
                    ON `bt_server_disk_info_list` (`inodes_used`, `name`, `sid`);

                -- 负载信息收集表
                CREATE TABLE IF NOT EXISTS `bt_server_loadavg_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `last_1_min` REAL NOT NULL DEFAULT 0.00,
                    `last_5_min` REAL NOT NULL DEFAULT 0.00,
                    `last_15_min` REAL NOT NULL DEFAULT 0.00,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverLoadavgInfoList_sid_last1min_last5min_last15min_createTime`
                    ON `bt_server_loadavg_info_list` (`sid`, `last_1_min`, `last_5_min`, `last_15_min`, `create_time`);

                -- 端口连接测试记录表
                CREATE TABLE IF NOT EXISTS `bt_port_connection_logs` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `port_id` INTEGER NOT NULL DEFAULT 0,
                    `port` INTEGER NOT NULL DEFAULT 0,
                    `test_method` TEXT NOT NULL DEFAULT '',
                    `ok` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `portConnectionLogs_sid_port_ok_createTime`
                    ON `bt_port_connection_logs` (`sid`, `port`, `ok`, `create_time`);

                CREATE INDEX IF NOT EXISTS `portConnectionLogs_portId_createTime`
                    ON `bt_port_connection_logs` (`port_id`, `create_time`);

                -- 进程信息收集表
                CREATE TABLE IF NOT EXISTS `bt_processes` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `sid` INTEGER NOT NULL DEFAULT 0,
                    `pne_id` INTEGER NOT NULL DEFAULT 0,
                    -- `name` TEXT NOT NULL DEFAULT '',
                    `status` TEXT NOT NULL DEFAULT 'sleep',
                    `boot_time` INTEGER NOT NULL DEFAULT 0,
                    -- `boot_command` TEXT NOT NULL DEFAULT '',
                    `boot_user` TEXT NOT NULL DEFAULT '',
                    `opened_files` INTEGER NOT NULL DEFAULT 0,
                    `opened_connections` INTEGER NOT NULL DEFAULT 0,
                    `opened_threads` INTEGER NOT NULL DEFAULT 0,
                    `disk_read_bytes` INTEGER NOT NULL DEFAULT 0,
                    `disk_write_bytes` INTEGER NOT NULL DEFAULT 0,
                    `disk_read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `disk_write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `net_sent_bytes` INTEGER NOT NULL DEFAULT 0,
                    `net_recv_bytes` INTEGER NOT NULL DEFAULT 0,
                    `net_sent_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `net_recv_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `cpu_used_percent` REAL NOT NULL DEFAULT 0.00,
                    `mem_used_percent` REAL NOT NULL DEFAULT 0.00,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                    `update_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processes_pneId_sid`
                    ON `bt_processes` (`pne_id`, `sid`);

                CREATE INDEX IF NOT EXISTS `processes_sid_updateTime`
                    ON `bt_processes` (`sid`, `update_time`);

                CREATE INDEX IF NOT EXISTS `processes_sid_status_createTime`
                    ON `bt_processes` (`sid`, `status`, `create_time`);

                CREATE INDEX IF NOT EXISTS `processes_openedConnections_createTime_sid`
                    ON `bt_processes` (`opened_connections`, `create_time`, `sid`);

                CREATE INDEX IF NOT EXISTS `processes_netRecvBytes_netSentBytes_createTime_sid`
                    ON `bt_processes` (`net_recv_bytes`, `net_sent_bytes`, `create_time`, `sid`);

                CREATE INDEX IF NOT EXISTS `processes_cpuUsedPercent_memUsedPercent_createTime_sid`
                    ON `bt_processes` (`cpu_used_percent`, `mem_used_percent`, `create_time`, `sid`);

                CREATE INDEX IF NOT EXISTS `processes_netRecvBytesPerSecond_netSentBytesPerSecond_createTime_sid`
                    ON `bt_processes` (`net_recv_bytes_per_second`, `net_sent_bytes_per_second`, `create_time`, `sid`);

                CREATE INDEX IF NOT EXISTS `processes_diskWriteBytesPerSecond_diskReadBytesPerSecond_createTime_sid`
                    ON `bt_processes` (`disk_write_bytes_per_second`, `disk_read_bytes_per_second`, `create_time`, `sid`);

                -- 主机进程数收集表
                -- CREATE TABLE IF NOT EXISTS `bt_server_process_info_list` (
                --     `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                --     `sid` INTEGER NOT NULL DEFAULT 0,
                --     `total` INTEGER NOT NULL DEFAULT 0,
                --     `running` INTEGER NOT NULL DEFAULT 0,
                --     `sleep` INTEGER NOT NULL DEFAULT 0,
                --     `stop` INTEGER NOT NULL DEFAULT 0,
                --     `zombie` INTEGER NOT NULL DEFAULT 0,
                --     `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                -- );

                -- CREATE INDEX IF NOT EXISTS `serverProcessInfoList_sid_createTime_total_running_sleep_stop_zombie`
                --     ON `bt_server_process_info_list` (`sid`, `create_time`, `total`, `running`, `sleep`, `stop`, `zombie`);

                -- CREATE INDEX IF NOT EXISTS `serverProcessInfoList_createTime`
                --     ON `bt_server_process_info_list` (`create_time`);

                -- 进程CPU信息收集表
                CREATE TABLE IF NOT EXISTS `bt_process_cpu_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `percent` REAL NOT NULL DEFAULT 0.00,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processCpuInfoList_processId_percent_createTime`
                    ON `bt_process_cpu_info_list` (`process_id`, `percent`, `create_time`);

                -- 进程内存信息收集表
                CREATE TABLE IF NOT EXISTS `bt_process_mem_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `percent` REAL NOT NULL DEFAULT 0.00,
                    `used`	INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processMemInfoList_processId_percent_createTime`
                    ON `bt_process_mem_info_list` (`process_id`, `percent`, `create_time`);

                CREATE INDEX IF NOT EXISTS `processMemInfoList_processId_used_createTime`
                    ON `bt_process_mem_info_list` (`process_id`, `used`, `create_time`);

                -- 进程磁盘IO信息收集表
                CREATE TABLE IF NOT EXISTS `bt_process_disk_io_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `read_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `write_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processDiskIoInfoList_processId_readBytesPerSecond_createTime`
                    ON `bt_process_disk_io_info_list` (`process_id`, `read_bytes_per_second`, `create_time`);

                CREATE INDEX IF NOT EXISTS `processDiskIoInfoList_processId_writeBytesPerSecond_createTime`
                    ON `bt_process_disk_io_info_list` (`process_id`, `write_bytes_per_second`, `create_time`);

                -- 进程网络IO信息收集表
                CREATE TABLE IF NOT EXISTS `bt_process_network_io_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `sent_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `recv_bytes_per_second` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processNetworkIoInfoList_processId_sentBytesPerSecond_createTime`
                    ON `bt_process_network_io_info_list` (`process_id`, `sent_bytes_per_second`, `create_time`);

                CREATE INDEX IF NOT EXISTS `processNetworkIoInfoList_processId_recvBytesPerSecond_createTime`
                    ON `bt_process_network_io_info_list` (`process_id`, `recv_bytes_per_second`, `create_time`);

                -- 进程打开文件数收集表
                CREATE TABLE IF NOT EXISTS `bt_process_opened_files_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `opened_files` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processOpenedFilesInfoList_processId_openedFiles_createTime`
                    ON `bt_process_opened_files_info_list` (`process_id`, `opened_files`, `create_time`);

                -- 进程网络连接数收集表
                CREATE TABLE IF NOT EXISTS `bt_process_opened_connections_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `opened_connections` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processOpenedConnectionsInfoList_processId_openedConnections_createTime`
                    ON `bt_process_opened_connections_info_list` (`process_id`, `opened_connections`, `create_time`);

                -- 进程网络连接数收集表
                CREATE TABLE IF NOT EXISTS `bt_process_opened_threads_info_list` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `process_id` INTEGER NOT NULL DEFAULT 0,
                    `opened_threads` INTEGER NOT NULL DEFAULT 0,
                    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `processOpenedThreadsInfoList_processId_openedThreads_createTime`
                    ON `bt_process_opened_threads_info_list` (`process_id`, `opened_threads`, `create_time`);

                -- 告警限流次数记录表
                CREATE TABLE IF NOT EXISTS `bt_warning_threshold_logs` (
                    `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    `conf_id` INTEGER NOT NULL DEFAULT 0,
                    `push_time` INTEGER NOT NULL DEFAULT 0,
                    `threshold_rule_time` INTEGER NOT NULL DEFAULT 0
                );
            
                
                CREATE INDEX IF NOT EXISTS `warningThresholdLogs_confId`
                    ON `bt_warning_threshold_logs` (`conf_id`);
                    
                CREATE INDEX IF NOT EXISTS `warningThresholdLogs_pushTime`
                    ON `bt_warning_threshold_logs` (`push_time`);
            
                CREATE INDEX IF NOT EXISTS `warningThresholdLogs_thresholdRuleTime`
                    ON `bt_warning_threshold_logs` (`threshold_rule_time`);


                --  进程状态记录表
               CREATE TABLE IF NOT EXISTS `bt_process_active_status` (
                `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                `process_id` INTEGER NOT NULL DEFAULT 0,
                `status` TEXT NOT NULL DEFAULT ''
                );
            
                
                CREATE INDEX IF NOT EXISTS `processActiveState_processId`
                    ON `bt_process_active_status` (`process_id`);
                    
                CREATE INDEX IF NOT EXISTS `processActiveState_status`
                    ON `bt_process_active_status` (`status`);

                -- 提交事务
                commit;
              
            ''')

        # 标记初始化成功
        public.cache_set(cache_key, 1, 2678400)
    except BaseException as e:
        # 记录异常堆栈
        public.print_exc_stack(e)

        ret = False

    return ret


# 清理内存临时数据库
def _vacuum_memory_db():
    with Db('/dev/shm/monitor_tmp') as db:
        db.query().execute_script('''
            -- 开启wal模式
            PRAGMA journal_mode=wal;

            -- 关闭同步
            PRAGMA synchronous=0;

            -- 开启事务
            begin;

            -- 清空主机CPU信息收集表
            DELETE FROM `bt_server_cpu_info_list`;

            -- 清空主机内存信息收集表
            DELETE FROM `bt_server_mem_info_list`;

            -- 清空主机SWAP信息收集表
            DELETE FROM `bt_server_swap_info_list`;

            -- 清空主机网卡信息收集表
            DELETE FROM `bt_server_net_info_list`;

            -- 清空主机磁盘信息收集表
            DELETE FROM `bt_server_disk_info_list`;

            -- 清空负载信息收集表
            DELETE FROM `bt_server_loadavg_info_list`;

            -- 清空端口连接测试记录表
            DELETE FROM `bt_port_connection_logs`;

            -- 清空进程信息收集表
            DELETE FROM `bt_processes`;

            -- 清空进程CPU信息收集表
            DELETE FROM `bt_process_cpu_info_list`;

            -- 清空进程内存信息收集表
            DELETE FROM `bt_process_mem_info_list`;

            -- 清空进程磁盘IO信息收集表
            DELETE FROM `bt_process_disk_io_info_list`;

            -- 清空进程网络IO信息收集表
            DELETE FROM `bt_process_network_io_info_list`;

            -- 清空进程打开文件数收集表
            DELETE FROM `bt_process_opened_files_info_list`;

            -- 清空进程网络连接数收集表
            DELETE FROM `bt_process_opened_connections_info_list`;

            -- 清空进程网络连接数收集表
            DELETE FROM `bt_process_opened_threads_info_list`;

            -- 清空告警限流次数记录表
            DELETE FROM `bt_warning_threshold_logs`;
            
            --  清空进程状态记录表
            DELETE FROM `bt_process_active_status`;

            -- 提交事务
            commit;

            -- 重新整理数据库文件
            vacuum;
        ''')


# 初始化safety数据库
def _init_safety_db(force=False):
    ret = True

    cache_key = 'MONITOR_SAFETY_DB_INITIALIZED'

    # 已初始化过，跳过
    if not force and public.cache_get(cache_key):
        return ret

    try:
        with db_mgr('safety') as db_safety:
            # 创建数据表
            db_safety.query().execute_script('''
                PRAGMA journal_mode = wal;
            
                -- 开启事务
                begin;
    
                -- 设置Sqlite
                -- PRAGMA synchronous = 0;
                -- PRAGMA page_size = 4096;
    
                -- 权限表
                CREATE TABLE IF NOT EXISTS `bt_access` (
                    `role_id` INTEGER NOT NULL DEFAULT 0,
                    `node_id` INTEGER NOT NULL DEFAULT 0,
                    `level`   INTEGER NOT NULL DEFAULT 0,
                    `sid`   INTEGER NOT NULL DEFAULT 0
                );
    
                CREATE INDEX IF NOT EXISTS `access_nodeId`
                    on `bt_access` (`node_id`);
    
                CREATE INDEX IF NOT EXISTS `access_roleId`
                    on `bt_access` (`role_id`);
    
                -- 授权Token表
                CREATE TABLE IF NOT EXISTS `bt_auth_token` (
                    `auth_id`     INTEGER PRIMARY KEY AUTOINCREMENT,
                    `uid`         INTEGER NOT NULL DEFAULT 0,
                    `access_key`  TEXT NOT NULL DEFAULT '',
                    `secret_key`  TEXT NOT NULL DEFAULT '',
                    `address`     TEXT NOT NULL DEFAULT '',
                    `ps`          TEXT NOT NULL DEFAULT '',
                    `create_time` INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now'))
                );
    
                -- 系统日志表
                CREATE TABLE IF NOT EXISTS `bt_logs` (
                    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
                    `uid`         INTEGER NOT NULL DEFAULT 0,
                    `username`    TEXT NOT NULL DEFAULT '',
                    `type`        TEXT NOT NULL DEFAULT '',
                    `log`         TEXT NOT NULL DEFAULT '',
                    `addtime`     INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now')),
                    `status_code` INTEGER NOT NULL DEFAULT 1,
                    `error_info`  TEXT NOT NULL DEFAULT ''
                );
    
                CREATE INDEX IF NOT EXISTS `logs_uid`
                    ON `bt_logs` (`uid`);
    
                CREATE INDEX IF NOT EXISTS `logs_statusCode`
                    ON `bt_logs` (`status_code`);
    
                CREATE INDEX IF NOT EXISTS `logs_addtime_type`
                    ON `bt_logs` (`addtime`, `type`);
    
                -- 权限节点表
                CREATE TABLE IF NOT EXISTS bt_node (
                    `node_id` INTEGER PRIMARY KEY AUTOINCREMENT,
                    `name` VARCHAR (128),
                    `title` VARCHAR (128),
                    `ps` VARCHAR (128),
                    `pid` INTEGER,
                    `level` INTEGER DEFAULT (0)
                );
    
                CREATE INDEX IF NOT EXISTS `node_pid`
                    on `bt_node` (`pid`);
    
                CREATE INDEX IF NOT EXISTS `node_level`
                    on `bt_node` (`level`);
    
                CREATE INDEX IF NOT EXISTS `node_name`
                    on `bt_node` (`name`);
    
                -- 用户组表
                CREATE TABLE IF NOT EXISTS `bt_role` (
                  `role_id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                  `name` TEXT NOT NULL DEFAULT '',
                  `pid` INTEGER NOT NULL DEFAULT 0,
                  `status` INTEGER NOT NULL DEFAULT 0,
                  `ps` TEXT NOT NULL DEFAULT NULL
                );
    
                CREATE INDEX IF NOT EXISTS `role_pid`
                    on `bt_role` (`pid`);
    
                CREATE INDEX IF NOT EXISTS `role_status`
                    on `bt_role` (`status`);
    
                -- 用户与用户组关联表
                CREATE TABLE IF NOT EXISTS `bt_role_user` (
                  `role_id` INTEGER NOT NULL DEFAULT 0,
                  `uid` INTEGER NOT NULL DEFAULT 0
                );
    
                CREATE INDEX IF NOT EXISTS `roleUser_roleId`
                    on `bt_role_user` (`role_id`);
    
                CREATE INDEX IF NOT EXISTS `roleUser_uid`
                    on `bt_role_user` (`uid`);
    
                -- 客户端列表
                CREATE TABLE IF NOT EXISTS `bt_server_list` (
                    `sid` INTEGER PRIMARY KEY AUTOINCREMENT,
                    `server_id`  TEXT NOT NULL DEFAULT '',
                    `access_key` TEXT NOT NULL DEFAULT '',
                    `secret_key` TEXT NOT NULL DEFAULT '',
                    `status`     INTEGER NOT NULL DEFAULT 0,
                    `address`    TEXT NOT NULL DEFAULT '',
                    `ps`         TEXT NOT NULL DEFAULT '',
                    `addtime`    INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now'))
                );
    
                CREATE INDEX IF NOT EXISTS `serverList_serverId`
                    on `bt_server_list` (`server_id`);
    
                CREATE INDEX IF NOT EXISTS `serverList_addtime`
                    on `bt_server_list` (`addtime`);
    
                CREATE INDEX IF NOT EXISTS `serverList_status`
                    on `bt_server_list` (`status`);
    
                -- 用户表
                CREATE TABLE IF NOT EXISTS `bt_users` (
                    `uid` INTEGER PRIMARY KEY AUTOINCREMENT,
                    `gid`             INTEGER NOT NULL DEFAULT 0,
                    `username`        TEXT NOT NULL DEFAULT '',
                    `username_hash`   TEXT NOT NULL DEFAULT '',
                    `password`        TEXT NOT NULL DEFAULT '',
                    `nickname`        TEXT NOT NULL DEFAULT '',
                    `salt`            TEXT NOT NULL DEFAULT '',
                    `status`          INTEGER NOT NULL DEFAULT 1,
                    `ps`              TEXT NOT NULL DEFAULT '',
                    `last_login_time` INTEGER,
                    `last_login_ip`   TEXT NOT NULL DEFAULT '',
                    `create_time`     INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now')),
                    `pwd_update_time` INTEGER NOT NULL DEFAULT 0,
                    `expire_day`      INTEGER NOT NULL DEFAULT 0
                );
    
                CREATE INDEX IF NOT EXISTS `user_gid`
                    on `bt_users` (`gid`);
    
                CREATE INDEX IF NOT EXISTS `user_username`
                    on `bt_users` (`username`);
    
                CREATE INDEX IF NOT EXISTS `user_usernameHash_password`
                    on `bt_users` (`username_hash`, `password`);
    
                -- 提交事务
                commit;
            ''')

            # 创建默认用户组
            if not db_safety.query().name('role').where('role_id>0').exists():
                db_safety.query() \
                    .name('role') \
                    .insert_all([
                    {
                        'name': '超级管理员',
                        'status': 1,
                        'ps': '超级管理员',
                    }
                ])
    except BaseException as e:
        # 记录异常堆栈
        public.print_exc_stack(e)

        ret = False

    return ret


def _ensure_db_date(raw_time, precision='month'):
    '''
        @name 确保输出指定格式的日期整数
        @author Zhj<2022-08-15>
        @param raw_time<integer|string> 输入时间
        @param precision<?string> 精确到xx[可选 默认'month'] year 年、month 月、day 天
        @return integer
    '''
    patterns = {
        'year': ('%Y', 2022, 9999),
        'month': ('%Y%m', 202207, 999999),
        'day': ('%Y%m%d', 20220701, 99999999),
    }

    conf = patterns.get(precision, None)

    if conf is None:
        raise RuntimeError('无效的参数precision: {}'.format(precision))

    # 检查输入时间是否是数字
    if public.is_number(raw_time):

        raw_time = int(raw_time)

        # 时间戳
        if 1000000000 < raw_time and raw_time < 9999999999:
            return int(time.strftime(conf[0], time.localtime(raw_time)))

        # 日期 yyyymm
        if conf[1] < raw_time and raw_time < conf[2]:
            return raw_time

    raise Exception('无法将 {} 转换成 {}格式的日期整数'.format(raw_time, conf[0]))


def _scan_files():
    '''
        @name 扫描数据库文件
        @author Zhj<2022-09-22>
        @return void
    '''
    # public.print_log('|--正在扫描数据库文件')
    print('|--正在扫描数据库文件')

    # 查询主机id并构建 主机ID MD5 => 主机ID 的映射字典
    with db_mgr() as db:
        sid_list = db.query() \
            .name('servers') \
            .column('sid')

    d = {}

    for sid in sid_list:
        d[public.md5(str(sid))] = sid

    # files = glob('{}/data/monitor_servers/**'.format(public.get_panel_path()), recursive=True)

    files = []

    for sid_md5 in d.keys():
        files.extend(glob('{}/data/monitor_servers/{}/**'.format(public.get_panel_path(), sid_md5), recursive=True))

    db_name_set = set()

    archived_db = set()

    # 匹配数据库名的正则表达式
    pattern = re.compile(r'monitor_servers\/[0-9a-fA-F]{32}\/\d{6,8}\/\w+(?=\.(?:db|7z))')

    for filename in files:
        # 非db文件或归档文件 跳过
        if filename[-3:] not in ['.db', '.7z']:
            continue

        m = pattern.search(filename)

        if m is None:
            continue

        db_name_set.add(m.group(0))

        # 已归档的需要标记归档
        if filename[-3:] == '.7z':
            archived_db.add(m.group(0))

    # exists_db_list = []
    #
    # with db_mgr('server_databases') as db:
    #     exists_db_list = db.query() \
    #         .name('server_databases') \
    #         .where('delete_time=0') \
    #         .where_in('db_name', list(db_name_set)) \
    #         .column('db_name')
    #
    # lost_db = db_name_set.difference(set(exists_db_list))
    # lost_archived_db = archived_db.difference(set(exists_db_list))
    # lost_db = lost_db.difference(lost_archived_db)
    #
    # # 没有可以新增的数据
    # if len(lost_archived_db) == 0 and len(lost_db) == 0:
    #     public.print_log('|--扫描完成，无新增数据库')
    #     # print('|--扫描完成，无新增数据库')
    #     return

    # 构建插入数据
    insert_data = []

    for db_name in db_name_set:
        # 数据库已归档
        if db_name in archived_db:
            archive_path = '{}/data/{}.7z'.format(public.get_panel_path(), db_name)
            archive_time = os.path.getctime(archive_path)
            insert_data.append({
                'sid': d.get(db_name[16:48], 0),
                'db_name': db_name,
                'table_name': os.path.basename(db_name),
                'db_path': '{}/data/{}.db'.format(public.get_panel_path(), db_name),
                'db_date': int(os.path.dirname(db_name)[49:]),
                'archive_time': int(archive_time),
                'archive_path': archive_path,
            })
            print('|--正在新增数据库 {} >>> 完成'.format(db_name))
            continue

        insert_data.append({
            'sid': d.get(db_name[16:48], 0),
            'db_name': db_name,
            'table_name': os.path.basename(db_name),
            'db_path': '{}/data/{}.db'.format(public.get_panel_path(), db_name),
            'db_date': int(os.path.dirname(db_name)[49:]),
            'archive_time': 0,
            'archive_path': '',
        })
        # public.print_log('|--正在新增数据库 {} >>> 完成'.format(db_name))
        print('|--正在新增数据库 {} >>> 完成'.format(db_name))

    # with db_mgr('server_databases') as db:
    #     db.query() \
    #         .name('server_databases') \
    #         .insert_all(insert_data)

    # public.print_log('|--扫描完成，新增{}个数据库'.format(len(archived_db) + len(db_name_set)))
    print('|--扫描完成，新增{}个数据库 已归档{}个 未归档{}个'.format(len(db_name_set), len(archived_db),
                                                                    len(db_name_set) - len(archived_db)))

    return insert_data


class MonitorDbManager:
    __LOCK = Lock()  # 线程锁对象

    # 数据库存放根目录
    __ROOT_PATH = '{}/data/monitor_servers'.format(public.get_panel_path())

    # 主数据库名称
    __DB_MGR = _DB_MGR

    # 子数据库建表语句列表
    __SUB_DB_SQL_LIST = _SUB_DB_SQL_LIST

    # 独立数据库建表语句
    __SINGLE_DB_SQL_LIST = _SINGLE_DB_SQL_LIST

    '''
        @name 云监控数据库管理类
        @param sid<integer>         服务器ID
        @param cur_time<?integer>   指定时间[可选]
        @author Zhj<2022-08-10>
    '''

    def __init__(self, sid, cur_time=None):
        self.__PROCESS_DATABASES = tuple(map(lambda x: x[0], _PROCESS_DB_LIST))
        self.__SID = sid
        self.__SID_MD5 = public.md5(str(sid))

        # 获取时间元组
        self.__NOW_TIME = time.localtime(int(cur_time) if cur_time is not None else None)

        # 当前日期 yyyymm 整数形式
        self.__CUR_DATE = int(time.strftime('%Y%m', self.__NOW_TIME))

        # 当前日期 yyyymmdd 整数形式
        self.__TODAY = int(time.strftime('%Y%m%d', self.__NOW_TIME))

        # 初始化主数据库
        # self.__init_mgr()

        # 初始化数据库
        self.__init_databases()

        # 初始化进程数据库
        self.__init_process_databases()

        # 初始化独立数据库
        self.__init_single_databases()

    def __init_mgr(self):
        '''
            @name 初始化主数据库
            @author Zhj<2022-08-12>
            @return void
        '''
        _init_mgr_db()
        _init_single_db()

    def __init_process_databases(self):
        """初始化进程相关数据库

        进程相关数据库按天存储数据（测试中）

        @author lx<2022-09-14>
        """
        # with Locker.acquire(self.__LOCK):
        day = self.__TODAY

        # 检查是否需要初始化数据库
        if not self.__need_init_database(day, 'process'):
            return

        # 开始初始化数据库
        with self.__initializing_database(day, 'process'):
            # cache_key = "PROCESS_DB_INIT_"+day
            # if public.cache_get(cache_key):
            #     return True

            # 确保目录已存在
            self.__ensure_directory_exists(day)

            insert_data = []
            remove_list = []

            # 获取当前时间
            cur_time = int(time.time())

            for item in _PROCESS_DB_LIST:
                table_name = item[0]

                db_name = self.__build_db_name(table_name, day)
                db_path = '{}/data/{}.db'.format(public.get_panel_path(), db_name)
                with public.sqlite_easy(db_name) as db:
                    db.query().execute_script(item[1])
                insert_data.append({
                    'sid': self.__SID,
                    'db_name': db_name,
                    'table_name': table_name,
                    'db_path': db_path,
                    'db_date': int(day),
                })

                # 记录需要标记删除的表名
                remove_list.append(item[0])

            # 批量插入
            with self.db_mgr('server_databases') as db:
                # 关闭自动提交事务
                db.autocommit(False)

                # 标记删除
                db.query() \
                    .name('server_databases') \
                    .where('sid=?', self.__SID) \
                    .where('delete_time=0') \
                    .where('db_date=?', int(day)) \
                    .where_in('table_name', remove_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 新增记录
                db.query() \
                    .name('server_databases') \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()
                # public.cache_set(cache_key, True, 86500)

    def __init_databases(self):
        '''
            @name 初始化数据库
            @author Zhj<2022-08-10>
            @return void
        '''
        # 上锁
        # with Locker.acquire(self.__LOCK):
        # 检查是否需要初始化本月数据库
        if not self.__need_init_database(self.__CUR_DATE):
            return

        # 开始初始化数据库
        with self.__initializing_database(self.__CUR_DATE):
            # 确保目录已存在
            self.__ensure_directory_exists(self.__CUR_DATE)

            # 主机数据库记录
            insert_data = []
            remove_list = []

            # 获取当前时间
            cur_time = int(time.time())

            for item in self.__SUB_DB_SQL_LIST:
                # 数据库名称tmp
                db_name_tmp = self.__build_db_name(item[0], self.__CUR_DATE)

                # 执行sql语句
                with public.sqlite_easy(db_name_tmp) as db:
                    db.query().execute_script(item[1])

                insert_data.append({
                    'sid': self.__SID,
                    'db_name': db_name_tmp,
                    'table_name': item[0],
                    'db_path': '{}/data/{}.db'.format(public.get_panel_path(), db_name_tmp),
                    'db_date': self.__CUR_DATE,
                })

                # 记录需要标记删除的表名
                remove_list.append(item[0])

            # 批量插入
            with self.db_mgr('server_databases') as db:
                # 关闭自动提交事务
                db.autocommit(False)

                # 标记删除
                db.query() \
                    .name('server_databases') \
                    .where('sid=?', self.__SID) \
                    .where('delete_time=0') \
                    .where('db_date=?', self.__CUR_DATE) \
                    .where_in('table_name', remove_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 新增记录
                db.query() \
                    .name('server_databases') \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

    # 初始化独立数据库
    def __init_single_databases(self):
        cache_key = 'MONITOR_DATABASE_INITIALIZED_FLAG_SINGLE_{}'.format(self.__SID)

        if public.cache_get(cache_key):
            return

        for tbl_name, sql in _SUB_SINGLE_DB_SQL_LIST.items():
            with self.db_mgr(self.__build_sgl_db_name(tbl_name)) as db:
                # 执行语句
                db.query().execute_script(sql)

        public.cache_set(cache_key, 1, 86400)

    def __need_init_database(self, cur_date, check_type='sub'):
        '''
            @name 检查是否需要初始化数据库
            @author Zhj<2022-08-12>
            @param  cur_date<integer|string> 当前日期
            @param  check_type<?string>      检查类型[可选 默认'sub'] sub 通用分库、process 进程分库
            @return bool
        '''
        d = {
            'sub': len(_SUB_DB_SQL_LIST),
            'process': len(_PROCESS_DB_LIST),
        }

        if check_type not in d:
            raise RuntimeError('无效的参数check_type: {}'.format(check_type))

        # 存在缓存，无需继续检测
        if public.cache_get('MONITOR_DATABASE_INITIALIZED_FLAG__{}_{}_{}'.format(check_type, self.__SID, cur_date)):
            return False

        # 检查当前日期的数据库文件数量是否正常
        with self.db_mgr('server_databases') as db:
            db_list = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('delete_time=0') \
                .where('db_date=?', int(cur_date)) \
                .field('id', 'db_path') \
                .select()

            if len(db_list) < d[check_type]:
                return True

            # 已删除的数据库文件 ID列表
            removed_list = []

            # 检查数据库文件是否存在
            for item in db_list:
                if not os.path.exists(item['db_path']):
                    removed_list.append(item['id'])

            # 没有数据库文件缺失 无需重新初始化数据库
            if len(removed_list) == 0:
                return False

            # 获取当前时间
            cur_time = int(time.time())

            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 更新已删除的数据
                db.query() \
                    .name('server_databases') \
                    .where_in('id', removed_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

        return True

    @contextmanager
    def __initializing_database(self, cur_date, check_type='sub'):
        '''
            @name 数据库初始化上下文
            @author Zhj<2022-09-23>
            @param  cur_date<integer|string> 当前日期
            @param  check_type<?string>      检查类型[可选 默认'sub'] sub 通用分库、process 进程分库
            @return generator
        '''
        try:
            yield

            # 缓存初始化标志
            public.cache_set('MONITOR_DATABASE_INITIALIZED_FLAG__{}_{}_{}'.format(check_type, self.__SID, cur_date), 1,
                             2678400)
        except BaseException as e:
            # 记录异常堆栈信息
            public.print_exc_stack(e)

    def __ensure_directory_exists(self, db_date):
        '''
            @name 确保目录已创建
            @author Zhj<2022-08-12>
            @param  db_date<integer|string> 数据库日期
            @return void
        '''
        db_path = '{}/{}/{}'.format(self.__ROOT_PATH, self.__SID_MD5, db_date)

        # 目录不存在则创建
        if not os.path.isdir(db_path):
            os.makedirs(db_path, 0o755)

    def __ensure_db_date(self, raw_time, precision='month'):
        '''
            @name 确保输出yyyymm格式的日期整数
            @author Zhj<2022-08-15>
            @param raw_time<integer|string> 输入时间
            @param precision<?string> 精确到xx[可选 默认'month'] year 年、month 月、day 天
            @return integer
        '''
        return _ensure_db_date(raw_time, precision)

    def __build_db_name(self, table_name, db_date):
        '''
            @name 获取数据库名称
            @author Zhj<2022-08-11>
            @param  table_name<string>      数据表名
            @param  db_date<integer|string> 数据库日期
            @return string
        '''
        return 'monitor_servers/{}/{}/{}'.format(self.__SID_MD5, db_date, table_name)

    def __build_sgl_db_name(self, table_name):
        '''
            @name 获取独立数据库名称
            @param table_name<string> 表名
            @return string
        '''
        return 'monitor_servers/{}/{}'.format(self.__SID_MD5, table_name)

    def __get_databases(self, table_name, begin_time=None, end_time=None):
        '''
            @name 获取数据库列表
            @author Zhj<2022-08-15>
            @param table_name<string>   表名
            @param begin_time<?integer> 起始时间[可选]
            @param end_time<?integer>   结束时间[可选]
            @return (db_name<string>, table_name<string>)[]
        '''
        # 返归档
        self.unarchive(table_name, begin_time, end_time)

        # 数据库信息列表
        databases = []

        # 数据库日期精度
        db_date_precision = 'month'

        if table_name.startswith('process_'):
            db_date_precision = 'day'

        with self.db_mgr('server_databases') as db:
            query = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('table_name=?', table_name) \
                .where('delete_time=0') \
                .order('db_date', 'asc') \
                .field('id', 'db_path', 'db_name', 'table_name')

            if begin_time is not None:
                query.where('db_date >= ?', self.__ensure_db_date(begin_time, db_date_precision))

            if end_time is not None:
                # 起始时间不能大于结束时间
                if begin_time is not None and begin_time > end_time:
                    raise Exception('起始时间不能大于结束时间')

                query.where('db_date <= ?', self.__ensure_db_date(end_time, db_date_precision))

            # 查询结果
            databases = query.select()

        # 结果为空时
        # 直接返回空列表
        if len(databases) == 0:
            return databases

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 真实可用的数据库列表
        ret = []

        # 遍历列表 获取真实存在的数据库文件
        for item in databases:
            # 数据库文件不存在
            # 说明已被删除 标记已删除
            if not os.path.exists(item['db_path']):
                # removed_list.append(item['id'])
                continue

            ret.append((item['db_name'], item['table_name']))

        # 更新主数据库数据
        if len(removed_list) > 0:
            with self.db_mgr('server_databases') as db:
                try:
                    # 关闭自动提交事务
                    db.autocommit(False)

                    # 获取当前时间
                    cur_time = int(time.time())

                    # 标记数据库文件已被删除
                    db.query() \
                        .name('server_databases') \
                        .where_in('id', removed_list) \
                        .update({
                        'delete_time': cur_time
                    })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

        return ret

    def db_mgr(self, db_name=_DB_MGR):
        '''
            @name 获取主数据库连接对象
            @author Zhj<2022-08-15>
            @param db_name<?string> 数据库名称[可选]
            @return Db
        '''
        # 独立数据库
        if db_name in _SUB_SINGLE_DB_SQL_LIST:
            return self.db_sgl(db_name)

        # 通用数据库
        return db_mgr(db_name)

    def db_cur_date(self, table_name):
        '''
            @name 获取本月数据库连接对象
            @author Zhj<2022-08-20>
            @param table_name<string> 表名
            @return Db
        '''
        if table_name.startswith("process_"):
            db_date = int(self.__TODAY)
        else:
            db_date = int(self.__CUR_DATE)
        db_name = self.__build_db_name(table_name, db_date)
        return Db(db_name)

    # 独立数据库连接对象
    def db_sgl(self, db_name, brandnew=True):
        if db_name not in _SUB_SINGLE_DB_SQL_LIST:
            raise RuntimeError('no database {} in server-{}'.format(db_name, self.__SID))

        return Db(self.__build_sgl_db_name(db_name), brandnew)

    def archive(self, table_name=None, begin_time=None, end_time=None, archive_type=None):
        '''
            @name 数据库归档(压缩)
            @author Zhj<2022-08-16>
            @param table_name<?string>   表名[可选]
            @param begin_time<?integer>  起始时间[可选]
            @param end_time<?integer>    结束时间[可选]
            @param archive_type<?string> 归档类型[可选] process 进程数据
            @return void
        '''
        # 数据库路径信息列表
        ret = None

        # 获取当前时间
        cur_time = int(time.time())
        today = int(time.strftime('%Y%m%d'))

        # 时间格式精度
        precision = 'month'

        with self.db_mgr('server_databases') as db:
            query1 = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('delete_time = 0') \
                .where('archive_time = 0') \
                .field('id', 'db_date', 'table_name', 'db_path', 'archive_path', '0 AS `is_archived`')

            query2 = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('delete_time = 0') \
                .where('archive_time > 0') \
                .where('unarchive_time > ?', cur_time - 86400) \
                .field('id', 'db_date', 'table_name', 'db_path', 'archive_path', '1 AS `is_archived`')

            if archive_type is not None and archive_type == 'process':
                query1.where('table_name like ?', 'process_%')
                query2.where('table_name like ?', 'process_%')
                precision = 'day'

            if table_name is not None:
                query1.where('table_name=?', table_name)
                query2.where('table_name=?', table_name)

            if begin_time is not None:
                begin_date = self.__ensure_db_date(begin_time, precision)

                # 起始时间不能大于等于今天
                if begin_date >= today:
                    return

                query1.where('db_date >= ?', begin_date)
                query2.where('db_date >= ?', begin_date)

            if end_time is not None:
                end_date = self.__ensure_db_date(end_time, precision)

                if end_date >= today:
                    end_date = today - 1

                # 起始时间不能大于结束时间
                if begin_time is not None and self.__ensure_db_date(begin_time, precision) > end_date:
                    return

                query1.where('db_date <= ?', end_date)
                query2.where('db_date <= ?', end_date)

            # 获取查询结果
            ret = query1.select() + query2.select()

        # 结果为空时 停止处理
        if ret is None or len(ret) == 0:
            return

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 压缩成功的压缩文件 ID列表
        archived_list = []
        archive_path_map = {}

        # 开始归档
        for item in ret:
            # 首次归档的数据库文件
            # 数据库文件不存在时 标记为删除
            # 跳过
            if not item['is_archived'] and not os.path.exists(item['db_path']):
                removed_list.append(item['id'])
                continue

            # 重复归档的数据库文件
            if item['is_archived']:
                # 情况a：压缩包与数据库文件同时存在 -> 删除数据库文件（释放数据库连接）
                # 情况b：压缩包存在、数据库文件不存在 -> 跳过
                if os.path.exists(item['archive_path']):
                    # 存在数据库文件 删除
                    if os.path.exists(item['db_path']):
                        os.remove(item['db_path'])
                    continue

                # 情况c：压缩包不存在、数据库文件存在 -> 创建压缩包、删除数据库文件（释放数据库连接）
                # 情况d：压缩包与数据库文件同时不存在 -> 标记删除、跳过
                elif not os.path.exists(item['db_path']):
                    removed_list.append(item['id'])
                    continue

            shm_file = '{}.db-shm'.format(item['db_path'][:-3])
            wal_file = '{}.db-wal'.format(item['db_path'][:-3])

            # 待归档的文件
            archive_files = [item['db_path']]
            if os.path.exists(shm_file):
                archive_files.append(shm_file)

            if os.path.exists(wal_file):
                archive_files.append(wal_file)

            print('|--正在归档数据库文件 {}'.format(item['db_path']), end='')

            # 开始压缩文件
            root_dir = os.path.dirname(item['db_path'])
            archive_path = os.path.join(root_dir, '{}.7z'.format(item['table_name']))
            with py7zr.SevenZipFile(archive_path, 'w') as archive:
                for archive_file in archive_files:
                    archive.write(archive_file, os.path.basename(archive_file))

            # 删除数据库文件
            for archive_file in archive_files:
                if os.path.exists(archive_file):
                    os.remove(archive_file)

            # 归档成功
            archive_path_map[item['id']] = archive_path
            # archived_list.append(item['id'])

            print(' >>> 完成')

        # 更新主数据库数据
        with self.db_mgr('server_databases') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 标记已删除的数据
                db.query() \
                    .name('server_databases') \
                    .where_in('id', removed_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 标记归档成功的数据
                for archive_id, archive_path in archive_path_map.items():
                    db.query() \
                        .name('server_databases') \
                        .where('id', archive_id) \
                        .update({
                        'archive_time': cur_time,
                        'archive_path': archive_path,
                    })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

    def unarchive(self, table_name=None, begin_time=None, end_time=None, force_remove_archive_file=False):
        '''
            @name 数据库返归档(解压缩)
            @author Zhj<2022-08-15>
            @param table_name<?string>                  表名[可选]
            @param begin_time<?integer>                 起始时间[可选]
            @param end_time<?integer>                   结束时间[可选]
            @param force_remove_archive_file<?boolean>  是否强制删除压缩包[可选]
            @return void
        '''
        # 数据库路径信息列表
        ret = None

        # 获取当前时间
        today = int(time.strftime('%Y%m%d'))

        # 时间格式精度
        precision = 'day' if table_name in self.__PROCESS_DATABASES else 'month'

        with self.db_mgr('server_databases') as db:
            query = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('delete_time = 0') \
                .where('archive_time > 0') \
                .field('id', 'db_path', 'archive_path')

            if table_name is not None:
                query.where('table_name=?', table_name)

            if begin_time is not None:
                begin_date = self.__ensure_db_date(begin_time, precision)

                # 起始时间不能大于等于今天
                if begin_date >= today:
                    # public.print_log('>>> 起始时间大于等于本月：{} {}'.format(begin_time, today))
                    return

                query.where('db_date >= ?', begin_date)

            if end_time is not None:
                end_date = self.__ensure_db_date(end_time, precision)

                if end_date >= today:
                    end_date = today - 1

                # 起始时间不能大于结束时间
                if begin_time is not None and self.__ensure_db_date(begin_time, precision) > end_date:
                    # public.print_log('>>> 起始时间大于结束时间：{} ~ {}'.format(begin_time, end_date))
                    return

                query.where('db_date <= ?', end_date)

            # 获取结果
            ret = query.select()

        # 结果为空时 停止处理
        if ret is None or len(ret) == 0:
            return

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 解压缩成功的压缩文件 ID列表
        unarchived_list = []

        # 开始返归档
        for item in ret:
            # 已存在数据库文件时 跳过
            if os.path.exists(item['db_path']):
                continue

            # 压缩文件不存在时 跳过
            if not os.path.exists(item['archive_path']):
                # 既不存在压缩包 也不存在数据库文件
                # 说明数据库文件遭到删除
                # 标记该数据已被删除
                if not os.path.exists(item['db_path']):
                    removed_list.append(item['id'])
                continue

            # 开始解压缩文件
            with py7zr.SevenZipFile(item['archive_path'], 'r') as archive:
                archive.extractall(os.path.dirname(item['archive_path']))

            # 解压缩成功
            unarchived_list.append(item['id'])

            # 删除压缩包
            if force_remove_archive_file:
                os.remove(item['archive_path'])

        # 更新主数据库记录信息
        if len(removed_list) > 0 or len(unarchived_list) > 0:
            with self.db_mgr('server_databases') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 获取当前时间
                    cur_time = int(time.time())

                    # 标记已删除的数据
                    if len(removed_list) > 0:
                        db.query() \
                            .name('server_databases') \
                            .where_in('id', removed_list) \
                            .update({
                            'delete_time': cur_time,
                        })

                    # 标记返归档成功的数据
                    if len(unarchived_list) > 0:
                        db.query() \
                            .name('server_databases') \
                            .where_in('id', unarchived_list) \
                            .update({
                            'unarchive_time': cur_time,
                        })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

    def add(self, table_name, dataset, option=None):
        '''
            @name 添加数据
            @author Zhj<2022-08-16>
            @param  table_name<string>   表名
            @param  dataset<list|dict>   插入数据 批量插入时为list、单条插入时为dict
            @param  option<?string>      额外选项[可选]
            @return bool
        '''
        ret = True

        # 打开数据库
        with self.db_cur_date(table_name) as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                query = db.query().name(table_name)

                # 批量插入
                if isinstance(dataset, list):
                    # 每次最多批量插入5000条数据
                    data_size = len(dataset)
                    e = int(data_size / 5000) + int(data_size % 5000 > 0)
                    for i in range(e):
                        query.insert_all(dataset[i * 5000:(i + 1) * 5000], option=option)

                # 插入单条数据
                else:
                    query.insert(dataset, option=option)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                ret = False

        return ret

    def remove(self, table_name=None, query_handler=None, begin_time=None, end_time=None):
        '''
            @name 删除数据
            @author Zhj<2022-08-17>
            @param table_name<?string>      表名[可选]
            @param query_handler<?function> 查询构造器处理函数[可选]
            @param begin_time<?integer>     起始时间[可选]
            @param end_time<?integer>       结束时间[可选]
            @return bool
        '''
        # 当query_handler不为None时
        # 情况a：query_handler不是一个函数 -> 抛出异常
        # 情况b：query_handler是一个函数 -> 进行返归档
        if query_handler is not None:
            from inspect import isfunction

            # 检查query_handler是否是函数类型
            if not isfunction(query_handler):
                raise Exception('参数 query_handler 必须是一个函数')

            # 返归档
            self.unarchive(table_name, begin_time, end_time)

        # 查询结果
        ret = None

        # 数据库日期精度
        db_date_precision = 'month'

        # 查询数据库信息
        with self.db_mgr('server_databases') as db:
            query = db.query() \
                .name('server_databases') \
                .where('sid=?', self.__SID) \
                .where('delete_time=0') \
                .order('db_date', 'asc') \
                .field('id', 'db_path', 'archive_path', 'db_name', 'table_name')

            if table_name is not None:
                if table_name.startswith('process_'):
                    db_date_precision = 'day'
                query.where('table_name=?', table_name)

            if begin_time is not None:
                query.where('db_date >= ?', self.__ensure_db_date(begin_time, db_date_precision))

            if end_time is not None:
                # 起始时间不能大于结束时间
                if begin_time is not None and begin_time > end_time:
                    raise Exception('起始时间不能大于结束时间')

                query.where('db_date <= ?', self.__ensure_db_date(end_time, db_date_precision))

            # 获取查询结果
            ret = query.select()

        # 查询结果为空时
        # 返回True
        if ret is None or len(ret) == 0:
            return True

        # 当query_hander为None时
        # 删除所有匹配到的数据库文件以及归档文件
        if query_handler is None:
            # 记录已被删除的数据库 ID列表
            removed_list = []

            for item in ret:
                # 删除数据库文件
                if os.path.exists(item['db_path']):
                    os.remove(item['db_path'])

                # 删除归档文件
                if os.path.exists(item['archive_path']):
                    os.remove(item['archive_path'])

                # 标记删除
                removed_list.append(item['id'])

            # 更新主数据库记录信息
            with self.db_mgr('server_databases') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 获取当前时间
                    cur_time = int(time.time())

                    # 标记已删除的数据
                    db.query() \
                        .name('server_databases') \
                        .where_in('id', removed_list) \
                        .update({
                        'delete_time': cur_time,
                    })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

            # 删除目录以及目录下所有文件
            try:
                import shutil
                shutil.rmtree('{}/{}'.format(self.__ROOT_PATH, self.__SID_MD5))
            except BaseException as e:
                # 记录异常堆栈
                public.print_exc_stack(e)

            return True

        # 当query_handler不为None时
        # 删除特定数据
        for item in ret:
            # 打开数据库
            with public.sqlite_easy(item['db_name']) as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 开启自动释放空间
                    db.auto_vacuum()

                    # 构建查询构造器对象
                    query = db.query().name(item['table_name'])

                    # 处理查询构造器
                    query_handler(query)

                    # 执行删除操作
                    query.delete()

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

        return True

    def query(self, table_name, query_handler, begin_time=None, end_time=None, order_field='create_time',
              reverse=False):
        '''
            @name 数据库查询
            @author Zhj<2022-08-16>
            @param  table_name<strnig>       表名
            @param  query_handler<function>  查询构造器处理函数
            @param  begin_time<?integer>     起始时间[可选]
            @param  end_time<?integer>       结束时间[可选]
            @param  order_field<?string>     排序字段[可选]
            @param  reverse<?bool>           倒序[可选]
            @return list
        '''
        # 检查query_handler是否是函数类型
        if not isfunction(query_handler):
            raise Exception('参数 query_handler 必须是一个函数')

        # 获取数据库列表
        databases = self.__get_databases(table_name, begin_time, end_time)

        # 倒序
        if reverse:
            databases.reverse()

        # 结果集
        ret = []

        for database in databases:
            # 打开数据库
            with public.sqlite_easy(database[0]) as db:
                # 构建查询构造器对象
                query = db.query().name(database[1])

                # 起始时间
                if begin_time is not None:
                    query.where('create_time >= ?', int(begin_time))

                # 结束时间
                if end_time is not None:
                    query.where('create_time <= ?', int(end_time))

                # 排序
                query.order(order_field, 'desc' if reverse else 'asc')

                # 处理查询构造器
                query_handler(query)

                # 查询数据
                result = query.select()

                if isinstance(result, list):
                    # 获取查询数据
                    ret += result

        return ret


# # memoryDb事务提交线程
# def memory_db_commit_thread():
#     while True:
#         # 每隔1秒钟提交一次事务
#         time.sleep(1)
#
#         try:
#             if MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW:
#                 # public.print_log('------db_memory commit------')
#                 MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW.commit()
#         except BaseException as e:
#             public.print_exc_stack(e)
#
#
# Thread(target=memory_db_commit_thread, daemon=True).start()


class MonitorDbMemory:
    '''
        @name In-Memory模式连接数据库
        @author Zhj<2022-08-18>
    '''
    __RESET_INTERVAL = 86400 * 30
    __RESET_LOCK = Lock()
    __LAST_CONNECT_TIME = 0
    __DB_BRANDNEW = None

    def __init__(self, brandnew=False):
        # 存储在内存中monitor数据库连接对象
        self.__DB_MONITOR_MEMORY = None
        self.__BRANDNEW = brandnew
        self.connect()

    def __del__(self):
        self.close()

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.__BRANDNEW:
            self.close()

    def connect(self):
        '''
            @name 连接数据库
            @author Zhj<2022-08-18>
            @return Db
        '''
        self.__attempt_reset_connection()
        if not self.__BRANDNEW:
            if not isinstance(self.__DB_MONITOR_MEMORY, Db):
                self.__DB_MONITOR_MEMORY = Db('/dev/shm/monitor_tmp', False).synchronous_off_wal()

            return self.__DB_MONITOR_MEMORY

        return MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW.set_blocking(False).autocommit(True)

    def close(self):
        '''
            @name 将数据库连接放回连接池
            @author Zhj<2022-08-18>
            @return void
        '''
        if isinstance(self.__DB_MONITOR_MEMORY, Db):
            self.__DB_MONITOR_MEMORY.close()
            self.__DB_MONITOR_MEMORY = None
            return

        # if self.__BRANDNEW:
        #     cur_time = int(time.time())
        #     if cur_time > MonitorDbMemory._MonitorDbMemory__LAST_CONNECT_TIME + self.__RESET_INTERVAL:
        #         if isinstance(MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW, Db)\
        #                 and MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW.queries() == 0:
        #             MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW = None

    # 尝试重置连接
    def __attempt_reset_connection(self):
        if self.__BRANDNEW:
            cur_time = int(time.time())
            if cur_time > MonitorDbMemory._MonitorDbMemory__LAST_CONNECT_TIME + self.__RESET_INTERVAL:
                with acquire(self.__RESET_LOCK, timeout=15):
                    if MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW is None \
                            or cur_time > MonitorDbMemory._MonitorDbMemory__LAST_CONNECT_TIME + self.__RESET_INTERVAL:
                        # public.print_log('==============reset connection {} {}'.format(self.__LAST_CONNECT_TIME, cur_time))
                        MonitorDbMemory._MonitorDbMemory__LAST_CONNECT_TIME = cur_time
                        MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW = Db('/dev/shm/monitor_tmp')
                        MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW.synchronous_off_wal()
                        MonitorDbMemory._MonitorDbMemory__DB_BRANDNEW.set_blocking(False)


# SSH登录日志类
class SshLoginLog:
    '''
        @name SSH登录日志类
        @author Zhj<2022-12-29>
    '''
    # 锁
    __LOCK = Lock()

    def __init__(self):
        # 获取当天时间元组
        loc_time = time.localtime()

        # 昨天日期 yyyy_mm_dd
        self.__YESTERDAY = time.strftime('%Y_%m_%d',
                                         (loc_time.tm_year, loc_time.tm_mon, loc_time.tm_mday - 1, 0, 0, 0, 0, 0, 0))

        # 当天日期 yyyy_mm_dd
        self.__TODAY = time.strftime('%Y_%m_%d', loc_time)

        # 初始化当天临时数据库
        self.__init_temp_db()

    # 初始化当天临时数据库
    def __init_temp_db(self):
        with self.__LOCK:
            if os.path.exists('{}/ssh_login_logs_{}.db'.format(_SINGLE_BASE_DIR, self.__TODAY)):
                return

            # 初始化数据库
            with Db('{}/ssh_login_logs_{}'.format(_SINGLE_BASE_DIR, self.__TODAY)) as db:
                db.query().execute_script(_SINGLE_DB_SQL_LIST['ssh_login_logs'])

    # 获取当天临时数据库
    def db_today(self):
        return Db('{}/ssh_login_logs_{}'.format(_SINGLE_BASE_DIR, self.__TODAY))

    # 写入数据
    def add(self, dataset):
        with Db('{}/ssh_login_logs_{}'.format(_SINGLE_BASE_DIR, self.__TODAY)) as db:
            db.query() \
                .name('ssh_login_logs') \
                .insert_all(dataset)

    # 分页查询
    def simple_page(self, query_handler, args):
        if not isfunction(query_handler):
            raise Exception('参数query_handler必须是一个函数')

        # 获取分页页码与分页大小
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))

        # 数据总数(最小)
        total = p * p_size

        # 分页结果
        ret = {
            'total': 0,
            'list': [],
        }

        # 首先使用当天临时数据库查询
        with Db('{}/ssh_login_logs_{}'.format(_SINGLE_BASE_DIR, self.__TODAY)) as db:
            query = db.query()
            query_handler(query)
            ret_tmp = public.simple_page(query, {
                'p': p,
                'p_size': p_size,
            })

        # 累加总数
        ret['total'] += ret_tmp['total']
        ret['list'].extend(ret['list'])

        # 当临时数据库中的数据不足以完成分页时，从主库中分页查询
        if len(ret['list']) < p_size:
            # 计算切换到新数据库时的分页页码
            # 计算偏移量
            offset = (total - ret['total']) % p_size
            new_p = (total - ret['total']) / p_size
            new_p_size = p_size

            # 当新分页小于1时，取余数作为分页大小，分页页码取1
            if new_p < 1:
                new_p = 1
                new_p_size = offset
                offset = 0

            with db_mgr('ssh_login_logs') as db:
                query = db.query()
                query_handler(query)
                ret_tmp = public.simple_page(query, {
                    'p': new_p,
                    'p_size': new_p_size,
                }, offset)

        # 累计总数
        ret['total'] += ret_tmp['total']
        ret['list'].extend(ret_tmp['list'])

        return ret

    # 同步数据
    def sync(self):
        with self.__LOCK:
            if not os.path.exists('{}/ssh_login_logs_{}.db'.format(_SINGLE_BASE_DIR, self.__YESTERDAY)):
                return

            insert_data = []

            with Db('{}/ssh_login_logs_{}'.format(_SINGLE_BASE_DIR, self.__YESTERDAY)) as db:
                # 查询所有主机登录成功的记录
                insert_data.extend(db.query() \
                                   .name('ssh_login_logs') \
                                   .where('success', 1) \
                                   .field('sid', 'ip', 'port', 'ip_place', 'user', 'success', 'login_time') \
                                   .select())

                # 查询各主机前20条登录失败的记录
                sid_list = db.query() \
                    .name('ssh_login_logs') \
                    .where('success', 0) \
                    .field('sid') \
                    .group('sid') \
                    .column('sid')

                for sid in sid_list:
                    insert_data.extend(db.query()
                                       .name('ssh_login_logs')
                                       .where('sid', sid)
                                       .where('success', 0)
                                       .order('login_time', 'desc')
                                       .limit(20)
                                       .field('sid', 'ip', 'port', 'ip_place', 'user', 'success', 'login_time')
                                       .select())

            # 批量插入数据
            insert_data_len = len(insert_data)
            if insert_data_len > 0:
                e = (insert_data_len / 5000) + int(insert_data_len % 5000 > 0)
                with db_mgr('ssh_login_logs') as db:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 每次批量插入5000条
                    for i in range(e):
                        db.query().name('ssh_login_logs') \
                            .insert_all(insert_data[i * 5000:(i + 1) * 5000])

                    # 提交事务
                    db.commit()

            # 删除临时数据库
            db_file = '/www/server/bt-monitor/{}/ssh_login_logs_{}.db'.format(_SINGLE_BASE_DIR, self.__YESTERDAY)
            shm_file = '/www/server/bt-monitor/{}/ssh_login_logs_{}.db-shm'.format(_SINGLE_BASE_DIR, self.__YESTERDAY)
            wal_file = '/www/server/bt-monitor/{}/ssh_login_logs_{}.db-wal'.format(_SINGLE_BASE_DIR, self.__YESTERDAY)

            os.remove(db_file)

            # 删除临时shm文件
            if os.path.exists(shm_file):
                os.remove(shm_file)

            # 删除wal文件
            if os.path.exists(wal_file):
                os.remove(wal_file)


# TODO 系统日志类
class SystemLog:
    '''
        @name 系统日志类
        @author Zhj<2022-09-20>
    '''
    __LOCK = Lock()  # 线程锁对象

    __ROOT_DIR = '{}/data/system_logs/'.format(public.get_panel_path())  # 系统日志存储文件夹
    __INDEX_DB = 'system_log_index'  # 索引数据库

    def __init__(self):
        self.__TODAY = int(time.strftime('%Y%m%d'))

    def __init_index_database(self):
        '''
            @name 初始化索引数据库
            @author Zhj<2022-09-19>
            @return bool
        '''
        with Db(self.__INDEX_DB) as db:
            try:
                db.query().execute_script('''
                    -- 开启wal模式
                    PRAGMA journal_mode = wal;

                    -- 关闭同步
                    PRAGMA synchronous = 0;

                    -- 开启事务
                    begin;

                    -- 系统日志索引表
                    CREATE TABLE IF NOT EXISTS `bt_system_log_index` (
                        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                        `db_date` INTEGER NOT NULL DEFAULT 0,
                        `records` INTEGER NOT NULL DEFAULT 0,
                        `delete_time` INTEGER NOT NULL DEFAULT 0,
                        `archive_time` INTEGER NOT NULL DEFAULT 0,
                        `unarchive_time` INTEGER NOT NULL DEFAULT 0
                    );

                    CREATE INDEX IF NOT EXISTS `systemLogIndex_deleteTime_dbDate_records`
                        ON `bt_system_log_index` (`delete_time`, `db_date`, `records`);

                    CREATE INDEX IF NOT EXISTS `systemLogIndex_deleteTime_dbDate_archiveTime_unarchiveTime`
                        ON `bt_system_log_index` (`delete_time`, `db_date`, `archive_time`, `unarchive_time`);

                    -- 提交事务
                    commit;
                ''')
            except BaseException as e:
                # 记录异常信息
                return False

        return True

    def __init_database(self):
        '''
            @name 初始化数据库
            @author Zhj<2022-09-19>
            @return bool
        '''
        with Db(self.__build_db_name()) as db:
            db.query().execute_script('''
                -- 开启wal模式
                PRAGMA journal_mode = wal;

                -- 关闭同步
                PRAGMA synchronous = 0;

                -- 开启事务
                begin;

                -- 系统日志表
                CREATE TABLE IF NOT EXISTS `bt_logs` (
                    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
                    `uid`         INTEGER NOT NULL DEFAULT 0,
                    `username`    TEXT NOT NULL DEFAULT '',
                    `type`        TEXT NOT NULL DEFAULT '',
                    `log`         TEXT NOT NULL DEFAULT '',
                    `addtime`     INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now')),
                    `status_code` INTEGER NOT NULL DEFAULT 1,
                    `error_info`  TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS `logs_uid`
                    on `bt_logs` (`uid`);

                CREATE INDEX IF NOT EXISTS `logs_statusCode`
                    on `bt_logs` (`status_code`);

                CREATE INDEX IF NOT EXISTS `logs_addtime`
                    on `bt_logs` (`addtime`);

                -- 提交事务
                commit;
            ''')
        pass

    def __build_db_name(self, db_date=None):
        '''
            @name 构造数据库名
            @author Zhj<2022-09-19>
            @param  db_date<?string> 数据库日期
            @return string
        '''
        # 未指定数据库日期时
        # 获取当天的日期
        if db_date is None:
            db_date = time.strftime('%Y%m%d')
        return 'system_logs/{}'.format(db_date)

    def __get_databases(self, begin_time=None, end_time=None):
        '''
            @name 获取数据列表
            @author Zhj<2022-09-20>
            @param  begin_time<?integer>    起始时间[可选]
            @param  end_time<?integer>      结束时间[可选]
            @return [(db_name, table_name), ...]
        '''
        # 返归档
        self.unarchive(begin_time, end_time)

        # 数据库信息列表
        databases = []

        with Db(self.__INDEX_DB) as db:
            query = db.query() \
                .name('system_log_index') \
                .where('delete_time=0') \
                .order('db_date', 'asc') \
                .field('id', 'db_date')

            if begin_time is not None:
                query.where('db_date >= ?', _ensure_db_date(begin_time, 'day'))

            if end_time is not None:
                # 起始时间不能大于结束时间
                if begin_time is not None and begin_time > end_time:
                    raise Exception('起始时间不能大于结束时间')

                query.where('db_date <= ?', _ensure_db_date(end_time, 'day'))

            # 查询结果
            databases = query.select()

        # 结果为空时
        # 直接返回空列表
        if len(databases) == 0:
            return databases

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 真实可用的数据库列表
        ret = []

        # 遍历列表 获取真实存在的数据库文件
        for item in databases:
            # 数据库文件路径
            db_path = '{}/{}.db'.format(self.__ROOT_DIR, item['db_date'])

            # 数据库文件不存在
            # 说明已被删除 标记已删除
            if not os.path.exists(db_path):
                removed_list.append(item['id'])
                continue

            ret.append((self.__build_db_name(item['db_date']), 'logs'))

        # 更新主数据库数据
        with Db(self.__INDEX_DB) as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 获取当前时间
                cur_time = int(time.time())

                # 标记数据库文件已被删除
                db.query() \
                    .name('system_log_index') \
                    .where_in('id', removed_list) \
                    .update({
                    'delete_time': cur_time
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)

        return ret

    # TODO 写日志
    def write(self, log_type, log_content, status_code=1, error_info=''):
        pass

    # TODO 删除日志
    def remove(self, begin_time=None, end_time=None):
        pass

    # TODO 查询日志
    def query(self, query_handler, begin_time=None, end_time=None, order_field='addtime', reverse=True, page=None,
              page_size=None):
        from inspect import isfunction

        # 检查query_handler是否是函数类型
        if not isfunction(query_handler):
            raise Exception('参数 query_handler 必须是一个函数')

        # 获取数据库列表
        databases = self.__get_databases(begin_time, end_time)

        # 倒序
        if reverse:
            databases.reverse()

        # TODO 分页时 统计总页数

        # 结果集
        ret = []

        for database in databases:
            # 打开数据库
            with Db(database[0]) as db:
                # 构建查询构造器对象
                query = db.query().name(database[1])

                # 起始时间
                if begin_time is not None:
                    query.where('addtime >= ?', int(begin_time))

                # 结束时间
                if end_time is not None:
                    query.where('addtime <= ?', int(end_time))

                # 排序
                query.order(order_field, 'desc' if reverse else 'asc')

                # 处理查询构造器
                query_handler(query)

                # 查询数据
                result = query.select()

                if isinstance(result, list):
                    # 获取查询数据
                    ret += result

        return ret

    def archive(self, begin_time=None, end_time=None):
        '''
            @name 归档
            @author Zhj<2022-09-20>
            @param  begin_time<?integer>    起始时间[可选]
            @param  end_time<?integer>      结束时间[可选]
            @return void
        '''
        # 数据库路径信息列表
        ret = None

        # 获取当前时间
        cur_time = int(time.time())

        with Db(self.__INDEX_DB) as db:
            query1 = db.query() \
                .name('system_log_index') \
                .where('delete_time = 0') \
                .where('archive_time = 0') \
                .field('id', 'db_date', '0 AS `is_archived`')

            query2 = db.query() \
                .name('system_log_index') \
                .where('delete_time = 0') \
                .where('archive_time > 0') \
                .where('unarchive_time > ?', cur_time - 86400) \
                .field('id', 'db_date', '1 AS `is_archived`')

            # if table_name is not None:
            #     query1.where('table_name=?', table_name)
            #     query2.where('table_name=?', table_name)

            if begin_time is not None:
                begin_date = _ensure_db_date(begin_time, 'day')

                # 起始时间不能大于等于今天
                if begin_date >= self.__TODAY:
                    return

                query1.where('db_date >= ?', begin_date)
                query2.where('db_date >= ?', begin_date)

            if end_time is not None:
                end_date = _ensure_db_date(end_time, 'day')

                if end_date >= self.__CUR_DATE:
                    end_date = self.__CUR_DATE - 1

                # 起始时间不能大于结束时间
                if begin_time is not None and _ensure_db_date(begin_time, 'day') > end_date:
                    return

                query1.where('db_date <= ?', end_date)
                query2.where('db_date <= ?', end_date)

            # 获取查询结果
            ret = query1.select() + query2.select()

        # 结果为空时 停止处理
        if ret is None or len(ret) == 0:
            return

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 压缩成功的压缩文件 ID列表
        archived_list = []

        # 开始归档
        for item in ret:
            # 数据库文件路径
            db_path = '{}/{}.db'.format(self.__ROOT_DIR, item['db_date'])

            # 归档文件路径
            archive_path = '{}/{}.7z'.format(self.__ROOT_DIR, item['db_date'])

            # 首次归档的数据库文件
            # 数据库文件不存在时 标记为删除
            # 跳过
            if not item['is_archived'] and not os.path.exists(db_path):
                removed_list.append(item['id'])
                continue

            # 重复归档的数据库文件
            if item['is_archived']:
                # 情况a：压缩包与数据库文件同时存在 -> 删除数据库文件（释放数据库连接）
                # 情况b：压缩包存在、数据库文件不存在 -> 跳过
                if os.path.exists(archive_path):
                    # 存在数据库文件 删除
                    if os.path.exists(db_path):
                        os.remove(db_path)
                    continue

                # 情况c：压缩包不存在、数据库文件存在 -> 创建压缩包、删除数据库文件（释放数据库连接）
                # 情况d：压缩包与数据库文件同时不存在 -> 标记删除、跳过
                elif not os.path.exists(db_path):
                    removed_list.append(item['id'])
                    continue

            shm_file = '{}/{}.db-shm'.format(self.__ROOT_DIR, item['db_date'])
            wal_file = '{}/{}.db-wal'.format(self.__ROOT_DIR, item['db_date'])

            # 待归档的文件
            archive_files = [db_path]
            if os.path.exists(shm_file):
                archive_files.append(shm_file)

            if os.path.exists(wal_file):
                archive_files.append(wal_file)

            # 开始压缩文件
            with py7zr.SevenZipFile(archive_path, 'w') as archive:
                for archive_file in archive_files:
                    archive.write(archive_file, os.path.basename(archive_file))

            # 删除数据库文件
            for archive_file in archive_files:
                if os.path.exists(archive_file):
                    os.remove(archive_file)

            # 归档成功
            archived_list.append(item['id'])

        # 更新索引数据库数据
        with Db(self.__INDEX_DB) as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 标记已删除的数据
                db.query() \
                    .name('system_log_index') \
                    .where_in('id', removed_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 标记归档成功的数据
                db.query() \
                    .name('system_log_index') \
                    .where_in('id', archived_list) \
                    .update({
                    'archive_time': cur_time,
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

    def unarchive(self, begin_time=None, end_time=None, force_remove_archive_file=False):
        '''
            @name 返归档
            @author Zhj<2022-09-20>
            @param  begin_time<?integer>                起始时间[可选]
            @param  end_time<?integer>                  结束时间[可选]
            @param  force_remove_archive_file<?bool>    是否强制删除压缩文件[可选]
            @return void
        '''
        # 数据库路径信息列表
        ret = None

        with Db(self.__INDEX_DB) as db:
            query = db.query() \
                .name('system_log_index') \
                .where('delete_time = 0') \
                .where('archive_time > 0') \
                .field('id', 'db_date')

            if begin_time is not None:
                begin_date = _ensure_db_date(begin_time, 'day')

                # 起始时间不能大于等于今天
                if begin_date >= self.__TODAY:
                    return

                query.where('db_date >= ?', begin_date)

            if end_time is not None:
                end_date = _ensure_db_date(end_time, 'day')

                if end_date >= self.__TODAY:
                    end_date = self.__TODAY - 1

                # 起始时间不能大于结束时间
                if begin_time is not None and _ensure_db_date(begin_time, 'day') > end_date:
                    return

                query.where('db_date <= ?', end_date)

            # 获取结果
            ret = query.select()

        # 结果为空时 停止处理
        if ret is None or len(ret) == 0:
            return

        # 已被删除的数据库文件 ID列表
        removed_list = []

        # 解压缩成功的压缩文件 ID列表
        unarchived_list = []

        # 开始返归档
        for item in ret:
            # 数据库文件路径
            db_path = '{}/{}.db'.format(self.__ROOT_DIR, item['db_date'])

            # 归档文件路径
            archive_path = '{}/{}.7z'.format(self.__ROOT_DIR, item['db_date'])

            # 已存在数据库文件时 跳过
            if os.path.exists(db_path):
                continue

            # 压缩文件不存在时 跳过
            if not os.path.exists(archive_path):
                # 既不存在压缩包 也不存在数据库文件
                # 说明数据库文件遭到删除
                # 标记该数据已被删除
                if not os.path.exists(db_path):
                    removed_list.append(item['id'])
                continue

            # 开始解压缩文件
            with py7zr.SevenZipFile(archive_path, 'r') as archive:
                archive.extractall(self.__ROOT_DIR)

            # 解压缩成功
            unarchived_list.append(item['id'])

            # 删除压缩包
            if force_remove_archive_file:
                os.remove(archive_path)

        # 更新索引数据库记录信息
        with Db(self.__INDEX_DB) as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 获取当前时间
                cur_time = int(time.time())

                # 标记已删除的数据
                db.query() \
                    .name('system_log_index') \
                    .where_in('id', removed_list) \
                    .update({
                    'delete_time': cur_time,
                })

                # 标记返归档成功的数据
                db.query() \
                    .name('system_log_index') \
                    .where_in('id', unarchived_list) \
                    .update({
                    'unarchive_time': cur_time,
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)


class SshLoginLogsLatest:
    """
        @name ssh登录日志数据库 [最近3个月汇总库]
    """

    __LOCK = threading.Lock()

    def __init__(self):

        self.PATH = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())
        self.CUR_TIME = int(time.time())
        self.LAST_3_MONTHS = self.CUR_TIME - (90 * 86400)  # 最近90天

        today = datetime.date.today()
        two_months_ago = datetime.date(today.year, today.month - 2, 1)
        # 最近三月 第一天的时间戳
        self.MONTH3_AGO = int(time.mktime(two_months_ago.timetuple()))

    # 创建数据库
    def init_ssh_login_logs_db(self):
        ret = True
        try:
            with Db(self.PATH) as db:
                db.query().execute_script('''
                    -- 开启wal模式
                    PRAGMA journal_mode=wal;

                    -- 关闭同步
                    PRAGMA synchronous=0;

                    -- 开启事务
                    begin;

                 -- SSH登录信息收集表  
                 CREATE TABLE IF NOT EXISTS `bt_ssh_login_logs_latest` (
                     `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                     `sid` TEXT NOT NULL DEFAULT 0,
                     `ip` TEXT NOT NULL DEFAULT '',
                     `port` INTEGER NOT NULL DEFAULT 0,
                     `ip_place` TEXT NOT NULL DEFAULT '',
                     `user` TEXT NOT NULL DEFAULT '',
                     `success` INTEGER NOT NULL DEFAULT 0,
                     `login_time` INTEGER NOT NULL DEFAULT 0
                 );

                 CREATE INDEX IF NOT EXISTS `sshLoginLogsLatest_loginTime`
                     ON `bt_ssh_login_logs_latest` (`login_time`);

                -- 提交事务
                 commit;

                ''')

        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            ret = False

        return ret

    # # 同步数据
    # def sync_ssh_login_logs_database(self, all=False):
    #     """
    #     @name 同步数据
    #     @param all: 是否同步所有数据  默认False   True时,同步所有(3月)数据  False时,同步20min内的数据
    #     """
    #     return self.sync_ssh_login_logs_database_v2(all)
    #
    #     from core.include.monitor_helpers import warning_obj
    #
    #     path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
    #     server_maxid = json.loads(public.readFile(path))
    #
    #     if all or not server_maxid:  # 三个月内的数据
    #         last_sync_time = self.MONTH3_AGO
    #         self.sync_ssh_login_logs_by_time(last_sync_time)
    #     else:  # 20min内的数据
    #         # 从配置文件中读取
    #         # 如果不存在 则创建配置文件  用时间戳同步
    #         # 存在 则用配置文件中的数据
    #         # path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
    #         # server_maxid = json.loads(public.readFile(path))
    #         # if not server_maxid:  # 不存在配置文件 用上次同步时间戳
    #         #     # 创建配置文件 更新最大id
    #         #     self.update_ssh_login_logs_latest_config()
    #         #     # 获取上次同步时间戳
    #         #     last_sync_time = self.record_sync_time()
    #         #     # 用时间戳同步
    #         #     self.sync_ssh_login_logs_by_time(last_sync_time)
    #         #
    #         # else:  # 存在配置文件 用配置文件中的数据
    #
    #         with Db(self.PATH).synchronous_off_wal() as db:
    #             # 关闭自动提交事务
    #             db.autocommit(False)
    #
    #             insert_data = []  # 20min内数据
    #
    #             for sid, maxid in server_maxid.items():
    #                 # 实例化云监控数据库管理对象
    #                 db_mgr2 = MonitorDbManager(sid)
    #
    #                 with db_mgr2.db_sgl('ssh_login_logs') as db2:
    #                     p = 0
    #                     while True:
    #                         #  查询出最近的登录数据
    #                         query = db2.query().name('ssh_login_logs') \
    #                             .where('id > ?', int(maxid)) \
    #                             .order('id', 'asc') \
    #                             .limit(100000, 100000 * p) \
    #                             .select()
    #
    #                         # 给数据添加sid
    #                         for item in query:
    #                             del (item['id'],)
    #                             item['sid'] = sid
    #
    #                         insert_data.extend(query)
    #
    #                         if len(query) < 100000:
    #                             break
    #
    #                         db.query() \
    #                             .name('ssh_login_logs_latest') \
    #                             .insert_all(insert_data)
    #
    #                         db.commit()
    #
    #                         insert_data = []
    #
    #                         p += 1
    #
    #             if len(insert_data) > 0:
    #                 db.query() \
    #                     .name('ssh_login_logs_latest') \
    #                     .insert_all(insert_data)
    #
    #                 # 提交事务
    #                 db.commit()
    #
    #     # 更新同步最大id
    #     self.update_ssh_login_logs_latest_config()

    # 同步数据V2
    def sync_ssh_login_logs_database(self, all=False):
        # 使用非阻塞式获取锁
        if not self.__LOCK.acquire(False):
            return

        try:
            path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
            server_maxid = None
            if os.path.exists(path):
                # public.print_log('------存在配置------')
                server_maxid = json.loads(public.readFile(path))

            if all or not server_maxid:  # 三个月内的数据
                # public.print_log('------进入三月数据同步------')
                os.remove(self.PATH)
                self.init_ssh_login_logs_db()
                return self.sync_ssh_login_logs_by_time(self.MONTH3_AGO)
            # public.print_log('------去同步数据 根据最大id------')
            return self.sync_ssh_login_logs_by_maxid(server_maxid)
        finally:
            # 释放锁
            self.__LOCK.release()

    # 记录同步时间
    def record_sync_time(self, save=False):
        '''
            @name 记录/获取 同步时间
            @param save bool 是否记录时间 默认False 获取时间, True 记录同步时间
            @return void
        '''
        p = '{}/data/ssh_login_logs_latest_sync_time.txt'.format(public.get_panel_path())

        if save:
            with open(p, 'w') as fp:
                fp.write(str(self.CUR_TIME))
                return self.CUR_TIME

        if os.path.exists(p):
            with open('{}/data/ssh_login_logs_latest_sync_time.txt'.format(public.get_panel_path()), 'r') as fp:
                return int(fp.read())

        return self.LAST_3_MONTHS

    # # 创建配置文件 sid => max(id)
    # def create_ssh_login_logs_latest_config(self):
    #
    #     path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
    #     # 判断配置文件是否存在
    #     # if not os.path.exists(path):
    #     #     # 创建配置文件
    #     #     ...
    #
    #     data = self.query_ssh_login_logs_maxid()
    #     public.writeFile(path, json.dumps(data))
    #     os.chmod(path, 384)

    # 更新配置文件 max(id)
    def update_ssh_login_logs_latest_config(self):

        path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
        data = self.query_ssh_login_logs_maxid()
        public.writeFile(path, json.dumps(data))
        os.chmod(path, 384)


    # 查询数据 sid的最大id ssh登录日志表
    def query_ssh_login_logs_maxid(self):
        from core.include.monitor_helpers import warning_obj
        insert_data = {}  # sid登录 当前最新的id [{sid, maxid}, {sid, maxid}]
        # sid列表
        sids = warning_obj.db_easy('servers') \
            .field('sid') \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')

        # 批量插入 本月数据
        with Db(self.PATH).synchronous_off_wal() as db:
            # 关闭自动提交事务
            db.autocommit(False)
            for sid in sids:
                # 实例化云监控数据库管理对象
                db_mgr1 = MonitorDbManager(sid)
                with db_mgr1.db_sgl('ssh_login_logs') as db2:
                    #  查询当前最新的id
                    insert_data[sid] = db2.query().name('ssh_login_logs').value('max(`id`)')

                    # 给数据添加sid
                    # insert_data.append({sid: mid})
                    # insert_data[sid] = mid

            db.commit()

        return insert_data

    # 同步辅助函数
    # judge_type: timestamp/max_id
    def __sync_log_help(self, judge_value, judge_type='timestamp'):
        from core.include.monitor_helpers import warning_obj
        path = '{}/data/ssh_login_logs_latest_config.json'.format(public.get_panel_path())
        if os.path.exists(path):
            # public.print_log('------存在配置------')
            max_dict_latest = json.loads(public.readFile(path))
        else:
            max_dict_latest = {}

        # sid列表
        sids = warning_obj.db_easy('servers') \
            .field('sid') \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')

        # 批量插入 本月数据
        with Db(self.PATH).synchronous_off_wal() as db:

            # 关闭自动提交事务
            db.autocommit(False)

            insert_data = []  # 20min内数据

            for sid in sids:
                # 实例化云监控数据库管理对象
                db_mgr = MonitorDbManager(sid)

                with db_mgr.db_sgl('ssh_login_logs') as db2:
                    p = 0
                    cur_max_id = None
                    while True:
                        #  查询出最近的登录数据
                        query_obj = db2.query().name('ssh_login_logs') \
                            .order('id', 'asc') \
                            .limit(100000, 100000 * p) \

                        if judge_type == 'timestamp':
                            query_obj.where('login_time > ?', judge_value)

                        elif judge_type == 'max_id':
                            maxid = judge_value.get(str(sid), None)
                            if maxid is None:
                                break
                            query_obj.where('id > ?', int(maxid))

                        else:
                            raise RuntimeError('无效的参数：judge_type {}'.format(judge_type))

                        # query = db2.query().name('ssh_login_logs') \
                        #     .where('login_time > ?', last_sync_time) \
                        #     .order('id', 'asc') \
                        #     .limit(100000, 100000 * p) \
                        #     .select()

                        query = query_obj.select()

                        # 给数据添加sid
                        for item in query:
                            cur_max_id = item['id']
                            item.pop('id', None)
                            item['sid'] = sid
                            # print(item)

                        insert_data.extend(query)

                        if len(query) < 100000:
                            break

                        db.query() \
                            .name('ssh_login_logs_latest') \
                            .insert_all(insert_data)

                        db.commit()

                        insert_data = []

                        p += 1

                    # 最大ID => query[-1]['id']
                    if cur_max_id is not None:
                        max_dict_latest[str(sid)] = cur_max_id

            if len(insert_data) > 0:
                db.query() \
                    .name('ssh_login_logs_latest') \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()
        # 数据有变化了 去更新配置文件
        if len(max_dict_latest) > 0:
            # public.print_log('------更新配置文件------{}'.format(max_dict_latest))
            public.writeFile(path, json.dumps(max_dict_latest))

    # # 根据时间戳同步数据
    # def sync_ssh_login_logs_by_time(self, last_sync_time):
    #     return self.sync_ssh_login_logs_by_time_v2(last_sync_time)
    #
    #     from core.include.monitor_helpers import warning_obj
    #     # sid列表
    #     sids = warning_obj.db_easy('servers') \
    #         .field('sid') \
    #         .where('is_authorized', 1) \
    #         .where('type', 0) \
    #         .column('sid')
    #
    #     # 批量插入 本月数据
    #     with Db(self.PATH).synchronous_off_wal() as db:
    #         # 关闭自动提交事务
    #         db.autocommit(False)
    #
    #         insert_data = []  # 20min内数据
    #
    #         for sid in sids:
    #             # 实例化云监控数据库管理对象
    #             db_mgr = MonitorDbManager(sid)
    #
    #             with db_mgr.db_sgl('ssh_login_logs') as db2:
    #                 p = 0
    #                 while True:
    #                     #  查询出最近的登录数据
    #                     query = db2.query().name('ssh_login_logs') \
    #                         .where('login_time > ?', last_sync_time) \
    #                         .order('id', 'asc') \
    #                         .limit(100000, 100000 * p) \
    #                         .select()
    #
    #                     # 给数据添加sid
    #                     for item in query:
    #                         del (item['id'],)
    #                         item['sid'] = sid
    #
    #                     insert_data.extend(query)
    #
    #                     if len(query) < 100000:
    #                         break
    #
    #                     db.query() \
    #                         .name('ssh_login_logs_latest') \
    #                         .insert_all(insert_data)
    #
    #                     db.commit()
    #
    #                     insert_data = []
    #
    #                     p += 1
    #
    #                 # 最大ID => query[-1]['id']
    #
    #         if len(insert_data) > 0:
    #             db.query() \
    #                 .name('ssh_login_logs_latest') \
    #                 .insert_all(insert_data)
    #
    #             # 提交事务
    #             db.commit()

    # 根据时间戳同步数据V2
    def sync_ssh_login_logs_by_time(self, last_sync_time):
        return self.__sync_log_help(last_sync_time)

    # 根据最大ID同步数据
    def sync_ssh_login_logs_by_maxid(self, server_maxids):
        return self.__sync_log_help(server_maxids, 'max_id')


# # 每月ssh登录记录表
# def ssh_login_logs_month_database():
#     '''
#         @name 初始化ssh登录日志数据库
#         @author Zhj<2022-08-10>
#         @return void
#     '''
#     cur_time = int(time.time())
#     now_time = time.localtime(int(cur_time))
#     # 当前日期 yyyymm 整数形式
#     cur_month = int(time.strftime('%Y%m', now_time))
#     last_month = int(time.strftime('%Y%m', (now_time.tm_year, now_time.tm_mon - 1, 1, 0, 0, 0, 0, 0, 0)))
#
#     # 上锁
#     # with Locker.acquire(self.__LOCK):
#
#     # 创建标记
#     create_key = 'SSH_LOGIN_LOGS_DB_CREATE_{}'.format(cur_month)
#     create_key_last = 'SSH_LOGIN_LOGS_DB_CREATE_{}'.format(last_month)
#
#     # 检查本月数据库是否已存在
#     path = '{}/data/monitor_databases/ssh_login_logs_{}.db'.format(public.get_panel_path(), cur_month)
#     if not public.cache_get(create_key) and not os.path.exists(path):
#         # 不存在时 创建数据库
#         _init_ssh_login_logs_db(path, cur_month, create_key)
#
#     # 检查上月数据库是否已存在
#     last_month_path = '{}/data/monitor_databases/ssh_login_logs_{}.db'.format(public.get_panel_path(), last_month)
#     if not public.cache_get(create_key_last) and not os.path.exists(path):
#         # 不存在时 创建数据库
#         _init_ssh_login_logs_db(last_month_path, last_month, create_key_last)


# # 每月ssh登录记录表
# def ssh_login_logs_month_database():
#     '''
#         @name 初始化ssh登录日志数据库
#         @author Zhj<2022-08-10>
#         @return void
#     '''
#     cur_time = int(time.time())
#     now_time = time.localtime(int(cur_time))
#     # 当前日期 yyyymm 整数形式
#     cur_month = int(time.strftime('%Y%m', now_time))
#     last_month = int(time.strftime('%Y%m', (now_time.tm_year, now_time.tm_mon - 1, 1, 0, 0, 0, 0, 0, 0)))
#
#     # 上锁
#     # with Locker.acquire(self.__LOCK):
#
#     # 创建标记
#     create_key = 'SSH_LOGIN_LOGS_DB_CREATE_{}'.format(cur_month)
#     create_key_last = 'SSH_LOGIN_LOGS_DB_CREATE_{}'.format(last_month)
#
#     # 检查本月数据库是否已存在
#     path = '{}/data/monitor_databases/ssh_login_logs_{}.db'.format(public.get_panel_path(), cur_month)
#     if not public.cache_get(create_key) and not os.path.exists(path):
#         # 不存在时 创建数据库
#         _init_ssh_login_logs_db(path, cur_month, create_key)
#
#     # 检查上月数据库是否已存在
#     last_month_path = '{}/data/monitor_databases/ssh_login_logs_{}.db'.format(public.get_panel_path(), last_month)
#     if not public.cache_get(create_key_last) and not os.path.exists(path):
#         # 不存在时 创建数据库
#         _init_ssh_login_logs_db(last_month_path, last_month, create_key_last)
#
#
#
# from core.include.monitor_helpers import basic_monitor_obj, warning_obj
#
#
# # 同步数据(只执行一次)
# def sync_ssh_login_logs_database():
#     cur_time = int(time.time())
#     now_time = time.localtime(int(cur_time))
#     cur_month = int(time.strftime('%Y%m', now_time))
#     last_month = int(time.strftime('%Y%m', (now_time.tm_year, now_time.tm_mon - 1, 1, 0, 0, 0, 0, 0, 0)))
#     db_name_tmp_last = 'ssh_login_logs_{}'.format(last_month)  # 上月数据库
#     db_name_tmp = 'ssh_login_logs_{}'.format(cur_month)     # 本月数据库
#     today, next_, last = _get_day_of_month()
#     insert_data_last = []   # 上月数据
#     insert_data_ = []       # 本月数据
#     insert_data = []        # 本月和上月数据
#     # sid列表
#     sids = warning_obj.db_easy('servers') \
#         .field('sid', ) \
#         .where('is_authorized', 1) \
#         .where('type', 0) \
#         .column('sid')
#     for sid in sids:
#         db_mgr1 = MonitorDbManager(sid)
#
#         with db_mgr1.db_sgl('ssh_login_logs') as db:
#             #  查询出最近两个月的登录数据
#             query = db.query().name('ssh_login_logs') \
#                 .where('login_time', '>=', last) \
#                 .where('login_time', '<', next_) \
#                 .select()
#             # 给数据添加sid
#             for item in query:
#                 item['sid'] = sid
#             insert_data.extend(query)
#
#     # 拆分出上下两个月的数据
#     for item in insert_data:
#         if item['login_time'] < today:
#             insert_data_last.append(item)
#         else:
#             insert_data_.append(item)
#
#     # 批量插入 本月数据
#     with db_mgr('{}/{}'.format(_SINGLE_BASE_DIR, db_name_tmp)) as db:
#         # 关闭自动提交事务
#         db.autocommit(False)
#
#         db.query() \
#             .name(db_name_tmp) \
#             .insert_all(insert_data_)
#
#         # 提交事务
#         db.commit()
#
#     # 批量插入  上月数据
#     with db_mgr('{}/{}'.format(_SINGLE_BASE_DIR, db_name_tmp_last)) as db:
#         # 关闭自动提交事务
#         db.autocommit(False)
#
#         db.query() \
#             .name(db_name_tmp_last) \
#             .insert_all(insert_data_last)
#
#         # 提交事务
#         db.commit()
#
#
#
# @contextmanager
# def __initializing_database_ssh(cur_date):
#     '''
#         @name 数据库初始化上下文
#         @author Zhj<2022-09-23>
#         @param  cur_date<integer|string> 当前日期
#         @return generator
#     '''
#     try:
#         yield
#
#         # 缓存初始化标志
#         public.cache_set('SSH_LOGIN_LOGS_DB_INITIALIZED_{}'.format(cur_date), 1, 2678400)
#     except BaseException as e:
#         # 记录异常堆栈信息
#         public.print_exc_stack(e)
#
# def _init_ssh_login_logs_db(path,month, cache_key, force=False):
#     ret = True
#     # 表名
#     db_name = 'bt_ssh_login_logs_{}'.format(month)   # 本月数据库
#     try:
#         with Db(path) as db:
#             db.query().execute_script('''
#                 -- 开启wal模式
#                 PRAGMA journal_mode=wal;
#
#                 -- 关闭同步
#                 PRAGMA synchronous=0;
#
#                 -- 开启事务
#                 begin;
#
#              -- SSH登录信息收集表
#              CREATE TABLE IF NOT EXISTS `bt_ssh_login_logs_all` (
#                  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
#                  `sid` TEXT NOT NULL DEFAULT 0,
#                  `ip` TEXT NOT NULL DEFAULT '',
#                  `port` INTEGER NOT NULL DEFAULT 0,
#                  `ip_place` TEXT NOT NULL DEFAULT '',
#                  `user` TEXT NOT NULL DEFAULT '',
#                  `success` INTEGER NOT NULL DEFAULT 0,
#                  `login_time` INTEGER NOT NULL DEFAULT 0
#              );
#
#              CREATE INDEX IF NOT EXISTS `sshLoginLogsAll_loginTime`
#                  ON `bt_ssh_login_logs_all` (`login_time`);
#
#             -- 提交事务
#              commit;
#
#             ''')
#
#         # 标记初始化成功
#         public.cache_set(cache_key, 1, 2678400)
#     except BaseException as e:
#         # 记录异常堆栈
#         public.print_exc_stack(e)
#
#         ret = False
#
#     return ret
#
# # 当月第一天时间戳 下月第一天时间戳  上月第一天时间戳
# def _get_day_of_month():
#     """
#     return:当月第一天时间戳 下月第一天时间戳
#     """
#
#     today = datetime.date.today()
#     first_day = datetime.date(today.year, today.month, 1)
#     # 当月第一天
#     timestamp = int(time.mktime(first_day.timetuple()))
#     # 下月
#     if today.month == 12:
#         next_month = datetime.date(today.year + 1, 1, 1)
#     else:
#         next_month = datetime.date(today.year, today.month + 1, 1)
#     # 下月第一天时间戳
#     next_timestamp = int(time.mktime(next_month.timetuple()))
#
#     # 上月
#     last_month = first_day - datetime.timedelta(days=1)
#     last_month_first_day = datetime.date(last_month.year, last_month.month, 1)
#     last_timestamp = int(time.mktime(last_month_first_day.timetuple()))
#
#     return timestamp, next_timestamp, last_timestamp
