# encoding: utf-8
#
# Web Socket 各类型数据处理函数
# Author Zhj<2022-06-25>

import json,time, core.include.public as public,re
from core.include.monitor_helpers import basic_monitor_obj, monitor_task_queue, counters

# basic_monitor_obj = plugin_loader.get_module('{}/core/include/monitor_helpers.py'.format(public.get_panel_path())).basic_monitor_obj
monitor_db_manager = public.import_via_loader(
    '{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))


def recv_Heartbeat(ret):
    '''
        @name 主机心跳包
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    public.print_log('recv Heartbeat:' + json.dumps(ret))
    # public.print_log('recv Heartbeat: {}'.format(ret['remote_addr']))
    # public.cache_set('SERVER_CONNECTION_'+str(ret['sid']), 1, 600)
    # basic_monitor_obj.update_servers(ret['sid'], True, ret['remote_addr'])
    monitor_task_queue.add_task_easy(basic_monitor_obj.update_servers, ret['sid'], True, ret['remote_addr'])


def recv_firewall_info(ret):
    '''
        @name 系统防火墙规则信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    try:
        if ret['sid'] == 62:
            public.print_log(f">>>>>>recv_systeminfo:{ret}")
        # public.print_log('recv firewall_info:'+json.dumps(ret))
        basic_monitor_obj.store_firewall_info(ret['sid'], ret['data']['body'])
    finally:
        # counters['firewall_info'].pop()
        pass


def recv_systeminfo(ret):
    '''
        @name 主机资源信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv systeminfo: {}'.format(ret))


    # 缓存在线登录用户
    try:
        if isinstance(ret['data']['body'], str):
            try:
                ret['data']['body'] = json.loads(ret['data']['body'])
            except:
                return

        # 缓存在线登录用户
        admin_info = ret['data']['body'].get("admin_info")
        if admin_info is not None:
            admin_info_list = [admin_info]
            basic_monitor_obj.cache_server_ssh_users(ret['sid'], admin_info_list)

        basic_monitor_obj.store_systeminfo(ret['sid'], ret['data']['body'])

        # 更新时间间隔缓存
        public.cache_set(basic_monitor_obj.build_send_message_to_agent_cache_name(ret['sid'], 'systeminfo', 'GetSystemInfoByServer'), basic_monitor_obj.get_min_agent_request_interval())
    finally:
        # counters['systeminfo'].pop()
        pass

    # 缓存SSH在线用户
    # if 'ssh_info' in ret['data']['body']:
    #     basic_monitor_obj.cache_server_ssh_users(ret['sid'], ret['data']['body']['ssh_info'])


def recv_serverport(ret):
    '''
        @name 主机端口信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    try:
        # public.print_log('recv serverport:'+json.dumps(ret))
        basic_monitor_obj.store_port_info(ret['sid'], ret['data']['body'])
    finally:
        # counters['serverport'].pop()
        pass


def recv_loganalysis(ret):
    '''
        @name 主机SSH登录日志
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    try:
        # public.print_log('recv loganalysis:'+json.dumps(ret))
        '''
        try:
            ssh_logs = json.loads(ret['data']['body'])
        except:
            ssh_logs = []
        '''
        # SSH登录日志
        if 'ssh_login_info' in ret['data']['body']:
            # public.print_log('recv loganalysis: {} {}'.format(ret['remote_addr'], ret['data']['body']['ssh_login_info']))
            basic_monitor_obj.store_ssh_login_logs(
                ret['sid'], ret['data']['body']['ssh_login_info'])

        # 系统日志路径列表
        if 'sys_log' in ret['data']['body']:
            basic_monitor_obj.cache_server_syslog_paths(
                ret['sid'], ret['data']['body']['sys_log'])
    finally:
        # counters['loganalysis'].pop()
        pass


def recv_networktraffic(ret):
    '''
        @name   进程流量
        @author Zhj<2022-07-04>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # body_dict = ret["data"]["body"]
    # # public.print_log(f'recv networktraffic:{body_dict}')
    # if isinstance(body_dict, str):
    #     try:
    #         body_dict = json.loads(body_dict)
    #     except:
    #         pass
    # if isinstance(body_dict, dict):
    #     network_io = {"sent_bytes_per_second": 0, "recv_bytes_per_second": 0}
    #     for k, v in body_dict.items():
    #         if str(k).startswith("nginx"):
    #             network_io["sent_bytes_per_second"] = v.get("total_up")
    #             network_io["recv_bytes_per_second"] = v.get("total_down")
    #     else:
    #         public.cache_set("NGINX_NETWORK_IO_" + str(ret["sid"]),
    #                          network_io)  # 网络io
    try:
        basic_monitor_obj.update_process_network_io_info(ret['sid'], ret['data']['body'])

        # 更新时间间隔缓存
        public.cache_set(
            basic_monitor_obj.build_send_message_to_agent_cache_name(ret['sid'], 'networktraffic', 'GetProcess2'),
            basic_monitor_obj.get_min_agent_request_interval())
    finally:
        # counters['networktraffic'].pop()
        pass


def recv_process(ret):
    '''
        @name 进程信息
        @author Zhj<2022-07-04>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    try:
        # if ret['sid'] == 58:
        #     public.print_log(f">>>>>>192.168.66.192    info:{ret['data']['body']}")
        # if int(ret['sid']) == 62:
            # public.print_log(f"!!!!!!!!!!!!!!!!!!!recv_process: {ret['data']['body']}")
            # public.print_log('>>>>>>>>>>recv process:' + json.dumps(ret))

        if isinstance(ret["data"]["body"], dict):
            for k, v in ret["data"]["body"].items():
                if str(k).startswith("nginx"):
                    public.cache_set("NGINX_CPU_" + str(ret["sid"]),
                                     round(v.get('cpu_percent'), 2))
                    public.cache_set("NGINX_MEM_" + str(ret["sid"]),
                                     round(int(v.get('memory_used')), 2))

        # if int(ret['sid']) in (191,183):
            # public.print_log('>>>> recv_process: {} {}'.format(ret['sid'], ret['remote_addr']), _level='error')

        basic_monitor_obj.store_process_info(ret['sid'], ret['data']['body'])

        # 更新时间间隔缓存
        public.cache_set(
            basic_monitor_obj.build_send_message_to_agent_cache_name(ret['sid'], 'process', 'GetProcessByServer'),
            basic_monitor_obj.get_min_agent_request_interval())
    finally:
        # counters['process'].pop()
        pass


def recv_sshandsoft(ret):
    '''
        @name 命令执行日志、SSH在线用户、软件安装列表
        @author Zhj<2022-07-12>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv sshandsoft:' + json.dumps(ret))

    # 缓存命令执行日志
    try:
        if 'history' in ret['data']['body']:
            basic_monitor_obj.cache_server_command_history(
                ret['sid'], ret['data']['body']['history'])

        # 缓存SSH在线用户
        if 'ssh_info' in ret['data']['body']:
            basic_monitor_obj.cache_server_ssh_users(
                ret['sid'], ret['data']['body']['ssh_info'])

        # 缓存软件安装列表
        if 'soft_info' in ret['data']['body']:
            basic_monitor_obj.cache_server_installed_softs(
                ret['sid'], ret['data']['body']['soft_info'])

        # 存储命令执行记录
        if 'history_realtime' in ret['data']['body']:
            # public.print_log('recv history_realtime: {} {}'.format(ret['remote_addr'], ret['data']['body']['history_realtime']))
            basic_monitor_obj.store_command_history(
                ret['sid'], ret['data']['body']['history_realtime'])
    finally:
        # counters['sshandsoft'].pop()
        pass


# Linux软件列表
def recv_softlist(ret):
    basic_monitor_obj.store_command_history(ret['sid'], ret['data']['body'])


def recv_raidcheck(ret):
    """接收磁盘阵列检测信息

    Args:
        ret (dict):
        checkResult: OK或NO, 磁盘都在线为OK，否则为NO
        checkOutput: 空或者perccli/storcli命令的输出结果
        controllerCount: 阵列卡控制器数量
        checkDetail: 阵列卡0;磁盘数量,在线数|阵列卡1;磁盘数量,在线数...
        checkdell:是否是dell品牌

    """
    # if int(ret['sid']) ==  8:
    #     public.print_log('**************************{}'.format(ret),_level='error')
    # if int(ret['sid']) ==  168:
    #     public.print_log('***********正常*****************{}'.format(ret))

    # public.print_log('++++++{}'.format(ret), _level='error')

    # public.print_log("raid check info:")
    # public.print_log(ret)
    try:
        if "data" in ret and "body" in ret["data"]:
            check_res = ret["data"]["body"]


            if "checkResult" in check_res:
                import time
                public.cache_set("RAID_INFO_UPDATE_{}".format(ret["sid"]),
                                 time.time())
                r = check_res["checkResult"]
                to_update = False
                if r.strip() == "OK":
                    output = ""
                    if "checkOutput" in check_res:
                        output = check_res["checkOutput"]
                        if output:
                            to_update = True
                else:
                    to_update = True

                    check_dell = ""
                    if "checkdell" in check_res:
                        check_dell = check_res["checkdell"]

                    detail = ""
                    if "checkDetail" in check_res:
                        detail = check_res["checkDetail"]

                    if detail:
                        from core.include.monitor_helpers import warning_obj
                        warning_rules = warning_obj.get_warning_rules(
                            ret["sid"], "resource", 'disk_[all]', 'raid_check')
                        # public.print_log("raid check rule:")
                        # public.print_log("-------------------------{}-{}".format(ret["sid"],warning_rules),_level='error')
                        check_detail = check_res["checkDetail"]
                        try:
                            for warning_rule in warning_rules:
                                # public.print_log("warning res: {}".format(warning_obj.warn(warning_rule, check_detail)))
                                warning_obj.warn(warning_rule, check_res)
                        except BaseException as e:
                            public.print_exc_stack(e)

                if to_update:
                    basic_monitor_obj.store_raidinfo(ret["sid"], check_res)
    finally:
        # counters['raidcheck'].pop()
        pass


def recv_agentinfo(ret):
    if "data" in ret and "body" in ret["data"]:
        sid = ret["sid"]
        data = ret['data']['body']
        if "agentVersion" in data:
            agent_version = data["agentVersion"]
            agent_version_file = '{}/data/monitor_servers/{}/{}'.format(
                public.get_panel_path(), public.md5(str(sid)),
                "agentversion.pl")
            # public.print_log("local agent version file:", agent_version_file)
            public.writeFile(agent_version_file, agent_version)
            public.cache_set(f"AGENT_VERSION_{sid}", agent_version)
            # public.print_log("agent version:"+agent_version)
        # if ret['sid'] == 65:
        #     public.print_log(f">>>>>>recv_systeminfo:{ret['data']['body']}")
        # if ret['sid'] == 59:
        #     public.print_log(f">>>>>>sid{ret['sid']} ===========:{ret['data']['body']}")
        # if ret['sid'] == 65:
        #     public.print_log(f">>>>>>sid{ret['sid']} ===========:{ret['data']['body']}")
        # if ret['sid'] == 68:
        #     public.print_log(f">>>>>>sid{ret['sid']} ===========:{ret['data']['body']}")

    # public.print_log("===================================================================Agent info:", str(ret))


def recv_nginxstats(ret):
    data = ret['data']['body']
    sid = ret["sid"]
    if not isinstance(data, dict):
        return
    create_time = int(time.time())
    now_requests = public.get_item_as_number(data, 'requests', True)
    now_accepts = public.get_item_as_number(data, 'accepts', True)

    requests_last_key = "NGINX_REQUESTS_LAST_" + str(ret["sid"])
    requests_key = "NGINX_REQUESTS_" + str(ret["sid"])
    accepts_last_key = "NGINX_ACCEPTSS_LAST_" + str(ret["sid"])
    accepts_key = "NGINX_ACCEPTSS_" + str(ret["sid"])

    # 计算每秒数据
    requests = 0
    requests_last = public.cache_get(requests_last_key)  # 请求数
    if requests_last is not None:
        last_requests = int(str(requests_last).split("/")[0])
        last_requests_time = int(str(requests_last).split("/")[1])

        requests = now_requests - last_requests if last_requests != 0 and last_requests is not None else 0
        requests = int(round(requests / max(1, (create_time - last_requests_time)), 0))
    public.cache_set(requests_last_key, f"{now_requests}/{create_time}")
    public.cache_set(requests_key, requests)

    accepts = 0
    accepts_last = public.cache_get(accepts_last_key)  # 连接数
    if accepts_last is not None:
        last_accepts = int(str(accepts_last).split("/")[0])
        last_accepts_time = int(str(accepts_last).split("/")[1])

        accepts = now_accepts - last_accepts if last_accepts != 0 and last_accepts is not None else 0
        accepts = int(round(accepts / max(1, (create_time - last_accepts_time)), 0))
    public.cache_set(accepts_last_key, f"{now_accepts}/{create_time}")

    public.cache_set(accepts_key, data.get("active_connections")) # 连接数

    # public.print_log(f">>>>>>>>>>>>>>>>>>>>>>sid:{sid},requests_last：{requests_last}，now_requests:{now_requests},requests:{requests}")
    # public.print_log(f">>>>>>>>>>>>>>>>>>>>>>sid:{sid}")
    # public.print_log(f">>>>>>>>>>>>>>>>>>>>>>data:{data}")
    virtual_host_info = data.get("virtual_host_info")
    port_list = []
    website_list = []
    for website in virtual_host_info.values():
        info = str(website).split("|")
        port = info[0]
        domain_list = info[1].split()
        config_url = info[2]
        log_url = info[3]

        temp = port.split("#")
        for i in temp:
            if i not in port_list:
                port_list.append(i)

        temp = {
            "port": ",".join(port.split("#")),
            "domain_list": domain_list,
            "config_url": config_url,
            "log_url": log_url,
        }
        website_list.append(temp)

    data["gzip_min_length"] = public.get_item_as_number(data, 'gzip_min_length', True) * 1024
    data["client_max_body_size"] = public.get_item_as_number(data, 'client_max_body_size', True) * 1024 * 1024
    data["client_header_buffer_size"] = public.get_item_as_number(data, 'client_header_buffer_size', True) * 1024
    data["client_body_buffer_size"] = public.get_item_as_number(data, 'client_body_buffer_size', True) * 1024

    nginx_stats_info = {
        "id": 1,
        "version": data.get("version",""), # 属性-版本号
        "start_cmd": data.get("start_cmd",""), # 属性-启动命令
        "conf_path": data.get("conf_path",""), # 属性-主配置文件
        "ports": ",".join(port_list), # 属性-监听端口
        "modules": data.get("configure_arguments",""), # 属性-编译模块
        "worker_processes": data.get("worker_processes",""), # 参数-处理进程数
        "worker_connections": public.get_item_as_number(data, "worker_connections", True), # 参数-最大并发连接数
        "keepalive_timeout": public.get_item_as_number(data, "keepalive_timeout", True), # 参数-连接超时时间
        "gzip": data.get("gzip",""), # 参数-压缩传输
        "gzip_min_length": public.get_item_as_number(data, "gzip_min_length", True), # 参数-最小压缩文件
        "gzip_comp_level": public.get_item_as_number(data, "gzip_complevel", True), # 参数-压缩率
        "client_max_body_size": public.get_item_as_number(data, "client_max_body_size", True), # 参数-最大上传文件
        "server_names_hash_bucket_size": public.get_item_as_number(data, "server_names_hash_bucket_size", True), # 参数-服务器名字的hash表大小
        "client_header_buffer_size": public.get_item_as_number(data, "client_header_buffer_size", True), # 参数-客户端请求头buffer大小
        "client_body_buffer_size": public.get_item_as_number(data, "client_body_buffer_size", True), # 参数-请求主体缓冲区
        "process": public.get_item_as_number(data, "workers", True) + public.get_item_as_number(data, "writing", True), # 进程数
        "website": len(virtual_host_info.values()), # 网站数量
        "website_list": json.dumps(website_list), # 网站详情
        "create_time": create_time,
    }


    # public.print_log(f">>>>>>>>>>>>>>>>>>>>>>>>nginx_stats_info:{nginx_stats_info}")
    with monitor_db_manager.MonitorDbManager(sid).db_mgr('nginx_stats_info') as db:
        # 关闭事务自动提交
        db.autocommit(False)
        try:
            query = db.query().name('nginx_stats_info')
            query.insert(nginx_stats_info, option="replace")

            # 提交事务
            db.commit()
        except BaseException as e:
            # 回滚事务
            db.rollback()
            # 打印异常堆栈
            public.print_exc_stack(e)
            raise e

    nginx_stats = {
        "requests": requests,
        "accepts": accepts,
        "waiting": data.get("waiting"),
        "active_connections": data.get("active_connections"),
        "create_time": create_time,
    }
    # public.print_log(f">>>>>>>>>>>>>>>>>>>>>>>>nginx_stats:{nginx_stats}")
    db_mgr = monitor_db_manager.MonitorDbManager(sid)
    db_mgr.add('process_nginx_stats_list', nginx_stats)


def recv_vul_scan(ret):
    '''
        @name 主机漏洞扫描
        @author Zhj<2023-03-22>
        @param  ret<dict> 主机ID与消息体
        @return void
    '''
    # public.print_log('recv vul scan: {}'.format(ret))
    basic_monitor_obj.update_server_bugs(ret['sid'], ret['data']['body'])


def recv_detect_mining(ret):
    '''
        @name 接收挖矿木马扫描列表
        @author Zhj<2023-03-28>
        @param  ret<dict> 主机ID与消息体
        @return void
    '''
    # public.print_log('recv detect mining: {}'.format(ret))
    basic_monitor_obj.update_server_minings(ret['sid'], ret['data']['body'])


# 病毒扫描
def recv_scanning(ret):
    # public.print_log('recv scanning: {}'.format(ret))
    pass


def recv_vocationalwork(ret):
    pass


# 文件监听
def recv_filelisten(ret):
    pass


# 远程执行shell脚本
def recv_exec_shell(ret):
    pass


# 入侵检测
def recv_intrusion_detection(ret):
    """
    接收入侵扫描消息
    """
    try:
        hids = ret['data']['body']
        if isinstance(hids, str):
            # public.print_log('字符串匹配'.format(hids), _level='error')
            try:
                hids = json.loads(hids)
            except:
                # public.print_log('无数据退出111--{}'.format(hids), _level='error')
                return False

        if not isinstance(hids, dict) or len(hids) < 1:
            # public.print_log('空字典退出222'.format(), _level='error')
            return False

        if all(value is None for key, value in hids.items() if key != 'status'):
            # public.print_log('全None值退出 sid--{}退出333--{}'.format(ret['sid'], hids), _level='error')
            return False

        with monitor_db_manager.db_mgr('hids') as db:
            query = db.query().name('hids_setting').where('sid', ret['sid']).field('open').find()
            if not query:
                # public.print_log('未设置退出444'.format(), _level='error')
                return
            if query['open'] == 0:
                # public.print_log('未开启退出555'.format(), _level='error')
                return
            # 主机设置开启 但被控没有开启
            if isinstance(hids.get('status', None), str):
                if query['open'] == 1 and hids.get('status', None) == 'stop':
                    # public.print_log('主机设置开启 但被控没有开启666'.format(), _level='error')
                    # 调用被控开启
                    public.send_agent_msg(
                        public.get_serverid_bysid(ret['sid']),
                        'intrusion_detection',
                        'SetStartStop',
                        pdata=public.g_pdata({
                            'action': 'start',
                        }))
        del hids['status']
        basic_monitor_obj.update_server_hids(ret['sid'], hids)
    finally:
        # counters['intrusion_detection'].pop()
        pass
