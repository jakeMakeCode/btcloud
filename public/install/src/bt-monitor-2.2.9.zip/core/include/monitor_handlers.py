# encoding: utf-8
#
# 监听器模块
# Author Zhj<2023-03-23>

import json
import copy
import core.include.public as public
from core.include.monitor_helpers import monitor_db_manager, basic_monitor_obj, warning_obj


# 监听器基类
class BaseHandler:
    '''
        @name 监听器基类
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        raise RuntimeError('method handle() must be implements.')


# 提交统计数据
class SubmitStatistics(BaseHandler):
    '''
        @name 提交统计数据
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        from core.include.monitor_helpers import basic_monitor_obj, monitor_task_queue, MonitorTask
        # 提交至任务队列执行
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj.submit_statistics, args=(True,)))


# 更新首页监控大屏主机位置信息
class UpdateServerPosition(BaseHandler):
    '''
        @name 更新首页监控大屏主机位置信息
        @author Zhj<2023-04-11>
    '''
    def handle(self, event):
        server_position = None
        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'r') as fp:
            try:
                server_position = json.loads(fp.read())
            except:
                server_position = {}

        server_position.pop(str(event.server_info['sid']), None)

        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'w') as fp:
            fp.write(json.dumps(server_position))


# 删除进程监控数据
class DeleteProcessMonitoring(BaseHandler):
    """
        @name 删除进程监控数据
        @author Zhj<2023-05-18>
    """
    def handle(self, event):
        sid = event.server_info['sid']
        with monitor_db_manager.db_mgr('custom_process') as db, monitor_db_manager.db_mgr() as db_mgr:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 进程监控
                ids = db.query() \
                    .name('custom_process') \
                    .where('sid', int(sid)) \
                    .column('id')

                # 删除进程监控
                db.query() \
                    .name('custom_process') \
                    .where('sid', int(sid)) \
                    .delete()

                if len(ids) == 0:
                    return

                # 删除中间表
                query = db.query().name('custom_process_rule_script').where_in('pro_id', ids)
                rule_ids = query.fork().column('rule_id')

                query.delete()

                # 删除结果表
                db.query() \
                    .name('custom_process_script_result') \
                    .where_in('pro_id', ids) \
                    .delete()

                if len(rule_ids) > 0:
                    db_mgr.query().name('warning_configurations')\
                        .where_in('id', rule_ids)\
                        .delete()

                db.commit()
                db_mgr.commit()
            except BaseException as e:
                db.rollback()
                db_mgr.rollback()

                public.print_exc_stack(e)


# 删除主机漏洞统计
class DeleteServerBugs(BaseHandler):
    """
        @name 删除主机漏洞统计
        @author Zhj<2023-05-19>
    """
    def handle(self, event):
        basic_monitor_obj.db_easy('server_bug_total')\
            .where('sid', int(event.server_info['sid']))\
            .delete()


# 删除主机挖矿木马统计
class DeleteServerMinings(BaseHandler):
    """
        @name 删除主机挖矿木马统计
        @author Zhj<2023-05-19>
    """
    def handle(self, event):
        basic_monitor_obj.db_easy('server_mining_total') \
            .where('sid', int(event.server_info['sid'])) \
            .delete()


# 删除主机病毒扫描任务
class DeleteServerMaliciousRecords(BaseHandler):
    """
        @name 删除主机病毒扫描任务
        @author Zhj<2023-05-20>
    """
    def handle(self, event):
        sid = int(event.server_info['sid'])
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.autocommit(False)

            try:
                # 删除扫描任务
                db.query().name('server_malicious_scan_task')\
                    .where('sid', sid)\
                    .delete()

                # 删除扫描结果
                db.query().name('malicious_scan_results') \
                    .where('sid', sid) \
                    .delete()

                db.commit()
            except BaseException as e:
                db.rollback()
                public.print_exc_stack(e)


# 更新主机分组关联的主机告警规则
class UpdateServerWarningRulesWhenGroupSetting(BaseHandler):
    """
        @name 更新主机分组关联的主机告警规则
        @author Zhj<2023-07-05>
    """
    def handle(self, event):
        # 获取主机分组关联的所有告警规则
        template_rules = basic_monitor_obj.db_easy('warning_templates')\
            .where('"," || `linked_server_groups` || "," LIKE ?', '%,{},%'.format(event.group_id))\
            .select()

        # 获取已关联的主机告警规则
        linked_keys = basic_monitor_obj.db_easy('warning_configurations')\
            .where_in('template_id', tuple(map(lambda x: x['id'], template_rules)))\
            .column('template_id || "_" || sid as xxx')

        # 新建对应的主机告警规则
        insert_data = []
        for template_rule in template_rules:
            for sid in event.sid:
                if '{}_{}'.format(template_rule['id'], sid) in linked_keys:
                    continue
                tmp = copy.deepcopy(template_rule)
                tmp['template_id'] = tmp['id']
                tmp['sid'] = sid
                tmp.pop('linked_server_groups', None)
                tmp.pop('linked_all_server', None)
                tmp.pop('remark', None)
                tmp.pop('id', None)
                tmp.pop('package_id', None)
                insert_data.append(tmp)

        if len(insert_data) > 0:
            basic_monitor_obj.db_easy('warning_configurations').insert_all(insert_data)


# 删除主机分组关联的告警规则
class DeleteWarningRulesWhenGroupRemoved(BaseHandler):
    """
        @name 删除主机分组关联的告警规则
        @author Zhj<2023-07-05>
    """
    def handle(self, event):
        # 获取主机分组关联的所有告警规则
        template_rules = basic_monitor_obj.db_easy('warning_templates') \
            .where('"," || `linked_server_groups` || "," LIKE ?', '%{}%'.format('%'.join(map(lambda x: ',{},'.format(x), event.group_id)))) \
            .field('id', 'linked_server_groups')\
            .select()

        # 获取主机分组对应的所有主机ID
        sid = basic_monitor_obj.db_easy('servers')\
            .where_in('group_id', event.group_id)\
            .column('sid')

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 删除主机ID对应的主机告警规则
                db.query()\
                    .name('warning_configurations')\
                    .where_in('template_id', tuple(map(lambda x: int(x['id']), template_rules)))\
                    .where_in('sid', sid)\
                    .delete()

                # 去除告警规则中关联的分组ID
                for template_rule in template_rules:
                    db.query().name('warning_templates')\
                        .where('id', template_rule['id'])\
                        .update({'linked_server_groups': ','.join(map(lambda x: str(x), sorted(set(map(lambda x: int(x), template_rule['linked_server_groups'])).difference(set(event.group_id)))))})

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()
                public.print_exc_stack(e)


# 新增主机告警规则
class CreateServerWarningRules(BaseHandler):
    """
        @name 新增主机告警规则
        @author Zhj<2023-07-05>
    """
    def handle(self, event):
        if event.status != 1:
            return

        # 获取关联所有主机的告警规则
        template_rules = basic_monitor_obj.db_easy('warning_templates')\
            .where('linked_all_server', 1)\
            .select()

        # 获取已关联的主机告警规则
        linked_keys = basic_monitor_obj.db_easy('warning_configurations') \
            .where_in('template_id', tuple(map(lambda x: x['id'], template_rules))) \
            .where_in('sid', event.sid)\
            .column('template_id || "_" || sid as xxx')

        # 新建主机告警规则
        insert_data = []
        for template_rule in template_rules:
            for sid in event.sid:
                if '{}_{}'.format(template_rule['id'], sid) in linked_keys:
                    continue
                tmp = copy.deepcopy(template_rule)
                tmp['template_id'] = tmp['id']
                tmp['sid'] = sid
                tmp.pop('linked_server_groups', None)
                tmp.pop('linked_all_server', None)
                tmp.pop('remark', None)
                tmp.pop('id', None)
                tmp.pop('package_id', None)
                insert_data.append(tmp)

        if len(insert_data) > 0:
            basic_monitor_obj.db_easy('warning_configurations').insert_all(insert_data)


# 删除关联的主机告警规则
class DeleteServerWarningRules(BaseHandler):
    def handle(self, event):
        basic_monitor_obj.db_easy('warning_configurations')\
            .where('sid', event.server_info['sid'])\
            .delete()


# 应用默认告警模板到主机
class ApplyServerDefaultTemplateRules(BaseHandler):
    def handle(self, event):
        if event.status != 1:
            return

        sid_list = list(event.sid)

        # 查询主机是否配置过告警规则
        with monitor_db_manager.db_mgr() as db:
            rule = db.query().name('warning_configurations') \
                .where_in('sid', sid_list) \
                .field('sid', 'count(*) as cnt') \
                .group('sid') \
                .column('cnt', 'sid')

        for rule_sid, rule_cnt in rule.items():
            if int(rule_cnt) > 0:
                sid_list.remove(rule_sid)

        if len(sid_list) == 0:
            return

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)
                #  获取默认模板包
                default = db.query() \
                    .name('warning_templates') \
                    .order('id') \
                    .limit(1) \
                    .find()

                # 获取模板包下所有模板
                templates = db.query() \
                    .name('warning_templates') \
                    .where('package_id=?', int(default['package_id'])) \
                    .field(
                    'id', 'title', 'content', 'type', 'sub_type', 'watch_target', 'watch_type',
                    'watch_value', 'is_push', 'scores', 'push_methods', 'duration'
                ).select()

                if warning_obj.is_empty_result(templates):
                    return

                # 清空主机所有告警规则
                db.query().name('warning_configurations').where_in('sid', sid_list).where('add_source', 0).delete()

                # 删除主机模板关联记录
                db.query().name('server_warning_template_package_merge').where_in('sid', sid_list).delete()

                # 批量插入数据
                insert_data = []

                for item in templates:
                    ok, _ = warning_obj.check_rule(item)

                    if not ok:
                        continue

                    for sid in sid_list:
                        tmp = copy.deepcopy(item)
                        tmp.update({
                            'sid': int(sid),
                            'template_id': int(item['id']),
                        })
                        tmp.pop('id', None)
                        insert_data.append(tmp)

                # 批量插入告警规则
                if len(insert_data) > 0:
                    db.query() \
                        .name('warning_configurations') \
                        .insert_all(insert_data)

                # 添加主机告警模板包关联记录
                db.query() \
                    .name('server_warning_template_package_merge') \
                    .insert_all([{
                        'sid': int(sid),
                        'package_id': int(default['package_id']),
                    } for sid in sid_list])

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)
