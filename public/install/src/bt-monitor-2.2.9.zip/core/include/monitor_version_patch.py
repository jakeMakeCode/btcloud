#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, time, json
from contextlib import contextmanager

os.chdir('/www/server/bt-monitor')
import sys

sys.path.insert(0, "/www/server/bt-monitor")
import core.include.public as public
# import core.include.c_loader.PluginLoader as plugin_loader
# import core.include.monitor_db_manager as monitor_db_manager
from core.include.cron_task import main as CronTask
from core.include.monitor_helpers import monitor_task_queue, basic_monitor_obj, warning_obj, MonitorTaskQueue, \
    MonitorTask, monitor_db_manager
import core.include.monitor_enums as monitor_enums
import core.include.aes as aes

Availability = public.import_via_loader('{}/modules/availabilityModule/main.py'.format(public.get_panel_path())).main
Custom = public.import_via_loader('{}/modules/customModule/main.py'.format(public.get_panel_path())).main
SafetyMonitor = public.import_via_loader('{}/modules/safetymonitorModule/main.py'.format(public.get_panel_path())).main
Server_ = public.import_via_loader('{}/modules/serverModule/main.py'.format(public.get_panel_path())).main

class MonitorVersionPatch:
    '''
        @name 版本补丁类
        @author Zhj<2022-08-26>
    '''
    # 版本补丁链
    __PATCH_VERSIONS = [
        (1, 0, 4),
        (1, 0, 6),
        (1, 0, 10),
        (1, 0, 11),
        (1, 0, 12),
        (2, 0, 0),
        (2, 0, 1),
        (2, 0, 3),
        (2, 0, 5),
        (2, 0, 7),
        (2, 0, 9),
        (2, 1, 1),
        (2, 1, 5),
        (2, 1, 9),
        (2, 2, 1),
        (2, 2, 2),
        (2, 2, 4),
        (2, 2, 5),
        (2, 2, 6),
    ]

    def __init__(self):
        # 云监控未完成初始化时，尝试初始化
        if not basic_monitor_obj.the_project_is_initialized():
            # 初始化云监控
            basic_monitor_obj.init_cloud_monitor()

        self.__CUR_VERSION = public.ReadFile('{}/version.pl'.format(public.get_panel_path()))

        public.print_log('|-database initialize...', _level='error')

        # 删除/dev/shm/下的临时数据库
        # os.system('rm -f /dev/shm/monitor_tmp.*')

        # 初始化数据库
        monitor_db_manager._init_memory_db()
        monitor_db_manager._vacuum_memory_db()
        monitor_db_manager._init_safety_db()
        monitor_db_manager._init_mgr_db()
        monitor_db_manager._init_single_db()

        public.print_log('|-database initialize ok', _level='error')

        public.print_log('|-update database struct...', _level='error')

        self.check_database_schema()

        public.print_log('|-update database struct ok', _level='error')

        # 初始化权限树
        self.update_authorization_tree()

        public.print_log('|-patching...', _level='error')

        # 尝试安装版本补丁
        self.attempt_install_patches()

        public.print_log('|-patch ok', _level='error')

        # 初始化默认模板
        warning_obj.init_default_template()

        # self.adjust_process_db()
        # self.migrate_process_db()

        # 删除被控面板缓存文件
        self.clear_cache_file()

        public.print_log('|-init tasks...', _level='error')

        # 初始化任务
        self.init_monitor_tasks()

        public.print_log('|-init tasks ok', _level='error')

        public.print_log('|-loading sampling options...', _level='error')

        # 初始化加载 采样信息
        self.loader_sampling_tasks()

        public.print_log('|-loading sampling options ok', _level='error')

    def clear_cache_file(self):
        # if os.path.exists("/www/server/bt-monitor/static/panel/static/js/term.js"):
        #     os.remove("/www/server/bt-monitor/static/panel/static/js/term.js")
        # public.ExecShell("cd /www/server/bt-monitor/static/panel && rm -rf `ls | grep -v static`")

        # 清空被控面板缓存
        os.system('rm -rf {}/static/panel/*'.format(public.get_panel_path()))

    def init_monitor_tasks(self):
        '''
            @name 初始化任务
            @author Zhj<2022-09-20>
            @return void
        '''
        # 删除计划任务
        cron_task_obj = CronTask()

        # 删除更新服务器列表状态计划任务
        cron_task_obj.delete_task('update_servers')

        # 删除扫描告警规则计划任务
        cron_task_obj.delete_task('warn_task')

        # 删除端口测试计划任务
        cron_task_obj.delete_task('port_test_task')

        # 每天00:30:00提交统计信息
        cron_task_obj.delete_task('report_task')
        # cron_task_obj.create_task('report_task', {
        #     'type': 'day-n',
        #     'hour': 0,
        #     'minute': 30,
        #     'where1': 1,
        # })

        # 每天02:00:00归档数据库文件
        cron_task_obj.delete_task('database_archive')
        cron_task_obj.create_task('database_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档请求日志
        cron_task_obj.delete_task('request_log_archive')
        cron_task_obj.create_task('request_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档错误日志
        cron_task_obj.delete_task('debug_log_archive')
        cron_task_obj.create_task('debug_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天01:00:00重启数据库
        cron_task_obj.delete_task('reboot_bss')
        # cron_task_obj.create_task('reboot_bss', {
        #     'type': 'day-n',
        #     'hour': 1,
        #     'minute': 0,
        #     'where1': 1,
        # })

        # 每3小时重启一次云监控服务
        cron_task_obj.delete_task('reboot_btm')
        # cron_task_obj.create_task('reboot_btm', {
        #     'type': 'hour-n',
        #     'minute': 0,
        #     'where1': 3,
        # })

        # 每2小时备份一次数据库 monitor_mgr/safety
        cron_task_obj.delete_task('database_bak')
        cron_task_obj.create_task('database_bak', {
            'type': 'hour-n',
            'minute': 0,
            'where1': 2,
        })

        # # 每20分分钟 同步一次ssh登录  'monitor_databases', 'ssh_login_logs_latest'
        # cron_task_obj.delete_task('update_ssh_login_logs_latest_db')
        # cron_task_obj.create_task('update_ssh_login_logs_latest_db', {
        #     'type': 'minute-n',
        #     'where1': 20,
        # })
        #
        # # 每月 删除一次ssh登录 重新同步 'monitor_databases', 'ssh_login_logs_latest'
        # cron_task_obj.delete_task('create_ssh_login_logs_latest_db')
        # cron_task_obj.create_task('create_ssh_login_logs_latest_db', {
        #     'type': 'day-n',
        #     'minute': 0,
        #     'hour': 3,
        #     'where1': 1,
        # })

        # 更新主机状态任务
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj, 'update_servers').delay(300).set_interval())

        # 主机告警任务
        # monitor_task_queue.add_task(MonitorTask(warning_obj, 'warn_all').delay(1).set_interval(periodic=10))
        monitor_task_queue.add_task(MonitorTask(warning_obj, 'warn_all').delay(300).set_interval(periodic=60))

        # 统计信息提交任务
        monitor_task_queue.add_task(
            MonitorTask(basic_monitor_obj, 'submit_statistics', args=(True,)).delay(1).set_interval(periodic=3600))

        # 更新进程名称与启动路径
        monitor_task_queue.add_task(
            MonitorTask(basic_monitor_obj, 'update_process_name_exe').delay(1).set_interval(periodic=15))

        availability_obj = Availability()
        # port 执行任务
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_port_task').delay(60).set_interval(periodic=1))
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_port_task_controlled').delay(60).set_interval(periodic=1))

        # ping 执行任务
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_ping_task').delay(60).set_interval(periodic=1))
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_ping_task_controlled').delay(60).set_interval(periodic=1))

        # https 执行任务
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_http_task').delay(60).set_interval(periodic=1))
        MonitorTaskQueue().run().add_task(
            MonitorTask(availability_obj, 'execute_http_task_controlled').delay(60).set_interval(periodic=1))

        # 病毒扫描进度更新队列
        MonitorTaskQueue().run().add_task(
            MonitorTask(SafetyMonitor(), 'update_scan_task_progress').delay(60).set_interval(periodic=3))

        # 病毒扫描自动扫描队列
        MonitorTaskQueue().run().add_task(
            MonitorTask(SafetyMonitor(), 'automatic_scan').per_day('03:00:00'))

        # 同步ssh登录信息 20min
        MonitorTaskQueue().run().add_task(
            MonitorTask(SafetyMonitor(), 'ssh_login_logs_latest_sync').delay(120).set_interval(periodic=60 * 20))
        # 更新ssh登录信息 0.5day
        MonitorTaskQueue().run().add_task(
            MonitorTask(SafetyMonitor(), 'ssh_login_logs_latest_database').delay(120).set_interval(periodic=86400 / 2))

        # 自定义监控任务
        custom_obj = Custom()
        # 脚本执行
        MonitorTaskQueue().run().add_task(
            MonitorTask(custom_obj, 'execute_script_task').delay(60).set_interval(periodic=1))

        # # 拿告警消息队列的数据 处理
        # MonitorTaskQueue().run().add_task(
        #     MonitorTask(warning_obj, 'get_warning_info').delay(15).set_interval(periodic=15))

        # 聚合好的分组数据进行处理
        # MonitorTaskQueue().run().add_task(
        #     MonitorTask(warning_obj, 'warning_set_list').delay(15).set_interval(periodic=15))

        # 同步基础数据对应的进程top信息
        MonitorTaskQueue().run().add_task(
            MonitorTask(Server_(), 'sync_process_top').delay(120).set_interval(periodic=1200))

        # 同步基础数据与进程基础信息
        MonitorTaskQueue().run().add_task(
            MonitorTask(basic_monitor_obj, 'sync_insert_base_and_process_data').delay(450).set_interval(periodic=450))

    def loader_sampling_tasks(self):
        '''
            @name 初始化 加载采样信息
            @author Zhj<2022-09-20>
            @return void
        '''
        from core import sampling_global, sampling_closed

        sampling_global.clear()
        sampling_closed.clear()

        # 查询全局数据采样设置
        sampling_global_temp = basic_monitor_obj.db_easy('servers') \
            .field('sid', 'sampling') \
            .column('sampling', 'sid')

        sampling_global.update(sampling_global_temp)

        # public.print_log(f">>>>>>>>>>>>>sampling:{sampling_global}")
        # public.print_log(f">>>>>>>>>>>>>sampling_closed:{sampling_closed}")

        # # 监控数据类型映射表
        sampling_types = {
            'global': monitor_enums.SAMPLING_TYPE__GLOBAL,  # 全局
            # 'cpu': monitor_enums.SAMPLING_TYPE__CPU,  # CPU占用率
            # 'mem': monitor_enums.SAMPLING_TYPE__MEM,  # CPU占用率
            # 'swap': monitor_enums.SAMPLING_TYPE__SWAP,  # SWAP占用(主机)
            # 'load_avg': monitor_enums.SAMPLING_TYPE__LOAD_AVG,  # 平均负载(主机)
            # 'disk_io': monitor_enums.SAMPLING_TYPE__DISK_IO,  # 磁盘IO(进程)
            # 'net_io': monitor_enums.SAMPLING_TYPE__NET_IO,  # 网络IO
            # 'disk': monitor_enums.SAMPLING_TYPE__DISK,  # 磁盘占用(主机)
            # 'opened_threads': monitor_enums.SAMPLING_TYPE__OPENED_THREADS,  # 打开线程数(进程)
            # 'opened_files': monitor_enums.SAMPLING_TYPE__OPENED_FILES,  # 打开文件数(进程)
        }

        sid_list = list(sampling_global_temp.keys())
        process_id_list = basic_monitor_obj.db_easy('processes') \
            .field('id') \
            .where_in('sid', sid_list) \
            .where('update_time > ?', int(time.time()) - 600) \
            .column('id')

        ks = []

        # 初始化采样设置
        for sampling_type in sampling_types.values():
            # 初始化主机采样设置
            for sid in sid_list:
                ks.append(public.mmh3_hash64('server|{}|{}'.format(sid, sampling_type)))

            # 初始化进程采样设置
            for process_id in process_id_list:
                ks.append(public.mmh3_hash64('process|{}|{}'.format(process_id, sampling_type)))

        # 查询出已设置的选项
        sampling_settings = basic_monitor_obj.db_easy('sampling_settings') \
            .where_in('id', ks) \
            .field('id', 'status') \
            .column('status', 'id')

        sampling_closed.update(sampling_settings)
        # public.print_log(f">>>>>>>>>>>>>sampling_closed>{sampling_closed}")

    def v_1_0_4(self):
        '''
            @name 1.0.4版本补丁
            @author Zhj<2022-08-26>
            @return void
        '''
        # 初始化独立数据库
        monitor_db_manager._init_single_db()

        if self.__is_patched('1.0.4'):
            return

        # 打补丁
        with self.__patching('1.0.4'):
            old_db_file = '{}/data/monitor.db'.format(public.get_panel_path())

            if os.path.exists(old_db_file) and os.path.getsize(old_db_file) > 100:
                # 迁移基础数据
                public.print_log('--正在进行数据库迁移')

                with public.sqlite_easy('monitor') as db_old, monitor_db_manager.db_mgr() as db_new:
                    try:
                        # 关闭事务自动提交
                        db_new.autocommit(False)

                        # 迁移主机列表
                        if not db_new.query().name('servers').where('sid>0').exists():
                            public.print_log('--正在迁移服务器列表')

                            # 迁移数据
                            db_new.query().name('servers').insert_all(
                                db_old.query().name('servers').select())

                            public.print_log('--服务器列表迁移成功')

                        # 迁移告警模板规则
                        if not db_new.query().name('warning_templates').where('id>0').exists():
                            public.print_log('--正在迁移告警模板规则')

                            # 迁移数据
                            db_new.query().name('warning_templates').insert_all(
                                db_old.query().name('warning_templates').select())

                            public.print_log('--告警模板规则迁移成功')

                        # 迁移告警模板
                        if not db_new.query().name('warning_template_packages').where('id>0').exists():
                            public.print_log('--正在迁移告警模板')

                            # 迁移数据
                            db_new.query().name('warning_template_packages').insert_all(
                                db_old.query().name('warning_template_packages').select())

                            public.print_log('--告警模板迁移成功')

                        # 迁移告警模板与主机关联信息
                        if not db_new.query().name('server_warning_template_package_merge').where('id>0').exists():
                            public.print_log('--正在迁移告警模板与主机关联信息')

                            # 迁移数据
                            db_new.query().name('server_warning_template_package_merge').insert_all(
                                db_old.query().name('server_warning_template_package_merge').select())

                            public.print_log('--告警模板与主机关联信息迁移成功')

                        # 迁移主机告警规则
                        if not db_new.query().name('warning_configurations').where('id>0').exists():
                            public.print_log('--正在迁移主机告警规则')

                            # 迁移数据
                            db_new.query().name('warning_configurations').insert_all(
                                db_old.query().name('warning_configurations').select())

                            public.print_log('--主机告警规则迁移成功')

                        # 提交事务
                        db_new.commit()

                        public.print_log('--数据库迁移成功')

                    except BaseException as e:
                        # 回滚事务
                        db_new.rollback()

                        # 记录异常堆栈
                        public.print_exc_stack(e)

                        return

                # 删除monitor.db
                if os.path.exists(old_db_file):
                    os.remove(old_db_file)

    def v_1_0_6(self):
        '''
            @name 1.0.6版本补丁
            @author Zhj<2022-09-17>
            @return void
        '''
        if self.__is_patched('1.0.6'):
            return

        # 打补丁
        with self.__patching('1.0.6'):
            # 删除计划任务
            cron_task_obj = CronTask()

            # 删除更新服务器列表状态计划任务
            cron_task_obj.delete_task('update_servers')

            # 删除扫描告警规则计划任务
            cron_task_obj.delete_task('warn_task')

            # 删除端口测试计划任务
            cron_task_obj.delete_task('port_test_task')

            # 扫描数据库
            # monitor_db_manager._scan_files()

    def v_1_0_10(self):
        '''
            @name 1.0.10版本补丁
            @author Zhj<2022-11-12>
            @return void
        '''
        if self.__is_patched('1.0.10'):
            return

        # 打补丁
        with self.__patching('1.0.10'):
            # 修复默认模板异常
            with public.sqlite_easy('monitor_mgr') as db:
                package_id = db.query() \
                    .name('warning_template_packages') \
                    .order('id', 'asc') \
                    .value('id')

                if package_id is None:
                    return

                db.query() \
                    .name('warning_templates') \
                    .where('package_id=?', package_id) \
                    .where('type=?', 'log') \
                    .where('sub_type=?', 'ssh_login_logs') \
                    .where('watch_target=?', 'place_other') \
                    .where('watch_type=5') \
                    .where('is_push=1') \
                    .where('watch_value=?', 'on_off') \
                    .update({
                    'watch_value': 'on',
                })

    def v_1_0_11(self):
        '''
            @name 1.0.11版本补丁
            @author Zhj<2022-12-09>
            @return void
        '''
        if self.__is_patched('1.0.11'):
            return

        with self.__patching('1.0.11'):
            # 更新敏感命令
            with monitor_db_manager.db_mgr('command_execute_logs') as db:
                commands = db.query() \
                    .name('command_execute_logs') \
                    .where('is_sensitive', 0) \
                    .field('id', 'command') \
                    .select()

                update_ids = []

                for command_info in commands:
                    if basic_monitor_obj.is_sensitive_command(command_info['command']):
                        update_ids.append(str(command_info['id']))

                # 关闭事务自动提交
                db.autocommit(False)

                # 批量更新
                if len(update_ids) > 0:
                    db.query() \
                        .name('command_execute_logs') \
                        .where('`id` IN ({})'.format(','.join(update_ids))) \
                        .update({
                        'is_sensitive': 1,
                    })

                # 提交事务
                db.commit()

    # 1.0.12版本升级补丁
    def v_1_0_12(self):
        if self.__is_patched('1.0.12'):
            return

        with self.__patching('1.0.12'):
            # 更改主机端口列表存储结构
            servers = basic_monitor_obj.db_easy('server_details') \
                .field('sid', 'port_info') \
                .select()

            # 收集进程基本信息
            pne_insert_data = {}

            cur_time = int(time.time())

            for server in servers:
                port_list = json.loads(server['port_info'])

                if isinstance(port_list, list):
                    new_port_list = {}

                    for port_info in port_list:
                        k = public.mmh3_hash64('{}|{}|{}|{}'.format(
                            server['sid'],
                            port_info['listen_address'],
                            port_info['listen_port'],
                            port_info['protocol']
                        ))

                        pne_id = basic_monitor_obj.get_pne_id(port_info.get('process_name', ''),
                                                              port_info.get('process_path', ''))

                        pne_insert_data[pne_id] = {
                            'id': pne_id,
                            'name': port_info.get('process_name', ''),
                            'exe': port_info.get('process_path', ''),
                        }

                        new_port_list[k] = {
                            'ip': port_info['listen_address'],
                            'port': port_info['listen_port'],
                            'protocol': port_info['protocol'],
                            'pne_id': pne_id,
                        }

                    with monitor_db_manager.db_mgr() as db:
                        db.query() \
                            .name('server_details') \
                            .where('sid', server['sid']) \
                            .update({
                            'port_info': json.dumps(new_port_list),
                        })

                # 调整SSH登录日志存储方式
                # SSH登录日志按天统计
                # SSH登录IP按天统计
                # SSH登录用户按天统计
                ssh_login_logs_insert_data = []
                ssh_login_total_daily_insert_data = []
                ssh_login_ip_total_daily_insert_data = []
                ssh_login_user_total_daily_insert_data = []
                with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                    ssh_login_total_daily_insert_data = db.query() \
                        .name('ssh_login_logs') \
                        .where('sid', server['sid']) \
                        .field('sid',
                               'sum(case success when 1 then 1 else 0 end) as `success`',
                               'sum(case success when 0 then 1 else 0 end) as `fail`',
                               "strftime('%s', strftime('%Y-%m-%d', `login_time`, 'unixepoch', 'localtime'), 'utc') as `day_time`") \
                        .group('sid, day_time') \
                        .select()

                    ssh_login_ip_total_daily_insert_data = db.query() \
                        .name('ssh_login_logs') \
                        .where('sid', server['sid']) \
                        .field('sid',
                               'ip',
                               'ip_place',
                               'group_concat(`port`) as `ports`',
                               'sum(case success when 1 then 1 else 0 end) as `success`',
                               'sum(case success when 0 then 1 else 0 end) as `fail`',
                               "strftime('%s', strftime('%Y-%m-%d', `login_time`, 'unixepoch', 'localtime'), 'utc') as `day_time`") \
                        .group('sid, ip, day_time') \
                        .select()

                    ssh_login_user_total_daily_insert_data = db.query() \
                        .name('ssh_login_logs') \
                        .where('sid', server['sid']) \
                        .field('sid',
                               'user',
                               'sum(case success when 1 then 1 else 0 end) as `success`',
                               'sum(case success when 0 then 1 else 0 end) as `fail`',
                               "strftime('%s', strftime('%Y-%m-%d', `login_time`, 'unixepoch', 'localtime'), 'utc') as `day_time`") \
                        .group('sid, user, day_time') \
                        .select()

                    # 登录成功记录每天全量保存
                    ssh_login_logs_insert_data = db.query() \
                        .name('ssh_login_logs') \
                        .where('sid', server['sid']) \
                        .where('success', 1) \
                        .field('ip', 'port', 'ip_place', 'user', 'success', 'login_time') \
                        .select()

                    # 登录失败记录每天最多记录20条(最近5天)
                    ssh_login_fail_daily = db.query() \
                        .name('ssh_login_logs') \
                        .where('sid', server['sid']) \
                        .where('success', 0) \
                        .where('login_time > ?', cur_time - (5 * 86400)) \
                        .field('sid',
                               "strftime('%s', strftime('%Y-%m-%d', `login_time`, 'unixepoch', 'localtime'), 'utc') as `day_time`") \
                        .group('sid, day_time') \
                        .select()

                    for item in ssh_login_fail_daily:
                        today_start, today_end = public.get_timestamp_interval(time.localtime(int(item['day_time'])))
                        ssh_login_logs_insert_data.extend(db.query() \
                                                          .name('ssh_login_logs') \
                                                          .where('sid', item['sid']) \
                                                          .where('success', 0) \
                                                          .where('`login_time` >= ?', today_start) \
                                                          .where('`login_time` <= ?', today_end) \
                                                          .field('ip', 'port', 'ip_place', 'user', 'success',
                                                                 'login_time') \
                                                          .order('login_time', 'desc') \
                                                          .limit(20) \
                                                          .select())

                # 批量插入SSH登录日志统计(每天)
                with monitor_db_manager.db_mgr('ssh_login_total_daily') as db:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 清空数据
                    db.query() \
                        .name('ssh_login_total_daily') \
                        .where('sid', server['sid']) \
                        .delete()

                    # 插入数据
                    db.query() \
                        .name('ssh_login_total_daily') \
                        .insert_all(ssh_login_total_daily_insert_data)

                    # 提交事务
                    db.commit()

                # 端口号去重
                for item in ssh_login_ip_total_daily_insert_data:
                    item['ports'] = json.dumps(list(set(str(item['ports']).split(','))))

                # 批量插入SSH登录IP统计(每天)
                with monitor_db_manager.db_mgr('ssh_login_ip_total_daily') as db:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 清空数据
                    db.query() \
                        .name('ssh_login_ip_total_daily') \
                        .where('sid', server['sid']) \
                        .delete()

                    # 插入数据
                    db.query() \
                        .name('ssh_login_ip_total_daily') \
                        .insert_all(ssh_login_ip_total_daily_insert_data)

                    # 提交事务
                    db.commit()

                # 批量插入SSH登录用户统计(每天)
                with monitor_db_manager.db_mgr('ssh_login_user_total_daily') as db:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 清空数据
                    db.query() \
                        .name('ssh_login_user_total_daily') \
                        .where('sid', server['sid']) \
                        .delete()

                    # 插入数据
                    db.query() \
                        .name('ssh_login_user_total_daily') \
                        .insert_all(ssh_login_user_total_daily_insert_data)

                    # 提交事务
                    db.commit()

                # 批量插入SSH登录日志
                db_mgr = monitor_db_manager.MonitorDbManager(server['sid'])

                with db_mgr.db_sgl('ssh_login_logs') as db:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 清空数据
                    db.query().name('ssh_login_logs').delete()

                    # 插入数据
                    db.query() \
                        .name('ssh_login_logs') \
                        .insert_all(ssh_login_logs_insert_data)

                    # 提交事务
                    db.commit()

            try:
                with monitor_db_manager.db_mgr('processes') as db:
                    public.print_log('connected process database')
                    processes = db.query() \
                        .name('processes') \
                        .field('id', 'name', 'boot_command') \
                        .where('update_time > ?', cur_time - 600) \
                        .select()

                    # 关闭事务自动提交
                    db.autocommit(False)

                    try:
                        for item in processes:
                            pne_id = basic_monitor_obj.get_pne_id(item['name'], item['boot_command'])
                            pne_insert_data[pne_id] = {
                                'id': pne_id,
                                'name': item['name'],
                                'exe': item['boot_command'],
                            }

                            # 更新pne_id
                            db.query() \
                                .name('processes') \
                                .where('id', item['id']) \
                                .update({
                                'pne_id': pne_id,
                            })

                        # 提交事务
                        db.commit()
                    except:
                        # 回滚事务
                        db.rollback()
            except:
                pass

            if len(pne_insert_data) > 0:
                # 更新进程基本信息
                with monitor_db_manager.db_mgr('process_name_exe') as db:
                    db.query() \
                        .name('process_name_exe') \
                        .insert_all(list(pne_insert_data.values()), option='replace')

    # 2.0.0版本升级补丁
    def v_2_0_0(self):
        if self.__is_patched('2.0.0'):
            return

        with self.__patching('2.0.0'):
            # 更新rbac配置文件
            public.set_config_value('rbac', 'NOT_AUTH_MODULE', ["user", "auth", "test", "plugin", "api"])

            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                # 初始化权限节点
                db.query().name('node').execute_script('''
                    BEGIN;
                    DROP TABLE IF EXISTS `bt_node`;
                    CREATE TABLE bt_node (
                        node_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name VARCHAR (128),
                        title VARCHAR (128),
                        ps VARCHAR (128),
                        pid INTEGER,
                        level INTEGER DEFAULT (0)
                    );
                    INSERT INTO bt_node VALUES(1,'/home','首页概览','菜单',0,1);
                    INSERT INTO bt_node VALUES(2,'/server','服务器列表','菜单',0,1);
                    INSERT INTO bt_node VALUES(3,'添加服务器','添加服务器','模块',2,2);
                    INSERT INTO bt_node VALUES(4,'server/get_server_ip','获取服务端IP信息','方法',3,3);
                    INSERT INTO bt_node VALUES(5,'server/add_server','获取安装脚本','方法',3,3);
                    INSERT INTO bt_node VALUES(6,'分组','分组','模块',2,2);
                    INSERT INTO bt_node VALUES(7,'server/get_server_groups','查看组列表','方法',6,3);
                    INSERT INTO bt_node VALUES(8,'server/add_server_group','添加分组','方法',6,3);
                    INSERT INTO bt_node VALUES(9,'server/edit_server_group','编辑分组','方法',6,3);
                    INSERT INTO bt_node VALUES(10,'server/remove_server_group','删除分组','方法',6,3);
                    INSERT INTO bt_node VALUES(11,'/alarm','警告设置','菜单',0,1);
                    INSERT INTO bt_node VALUES(12,'告警通知方式','告警通知方式','模块',11,2);
                    INSERT INTO bt_node VALUES(13,'msg/get_msg_config','消息通道配置信息','方法',12,3);
                    INSERT INTO bt_node VALUES(14,'msg/set_msg_config','设置消息通道','方法',12,3);
                    INSERT INTO bt_node VALUES(15,'msg/send_test_msg','发送一条测试信息','方法',12,3);
                    INSERT INTO bt_node VALUES(16,'告警模板','告警模板','模块',11,2);
                    INSERT INTO bt_node VALUES(17,'warning/get_template_packages','查看告警模板列表','方法',16,3);
                    INSERT INTO bt_node VALUES(18,'warning/modify_template_package','修改告警模板名称','方法',16,3);
                    INSERT INTO bt_node VALUES(19,'warning/remove_template_packages','删除告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(20,'warning/apply_template_package','应用告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(21,'warning/get_templates','查看告警模板详情','方法',16,3);
                    INSERT INTO bt_node VALUES(22,'warning/add_template','添加告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(23,'warning/modify_template','修改告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(24,'warning/remove_templates','删除告警模板规则','方法',16,3);
                    INSERT INTO bt_node VALUES(25,'warning/import_templates','导入告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(26,'warning/export_templates','导出告警模板','方法',16,3);
                    INSERT INTO bt_node VALUES(27,'设置告警规则','设置告警规则','模块',11,2);
                    INSERT INTO bt_node VALUES(28,'warning/get_rules','查看告警规则','方法',27,3);
                    INSERT INTO bt_node VALUES(29,'warning/add_rule','添加告警规则','方法',27,3);
                    INSERT INTO bt_node VALUES(30,'warning/modify_rule','修改告警规则','方法',27,3);
                    INSERT INTO bt_node VALUES(31,'warning/remove_rules','删除告警规则','方法',27,3);
                    INSERT INTO bt_node VALUES(32,'warning/save_rules_to_template','保存主机规则为告警模板','方法',27,3);
                    INSERT INTO bt_node VALUES(33,'warning/export_sqllates','导出告警模板','方法',27,3);
                    INSERT INTO bt_node VALUES(34,'warning/import_sqllates','导入告警模板','方法',27,3);
                    INSERT INTO bt_node VALUES(35,'/rbac','用户设置','菜单',0,1);
                    INSERT INTO bt_node VALUES(36,'用户管理','用户管理','模块',35,2);
                    INSERT INTO bt_node VALUES(37,'rbac/get_user_list','查看用户列表','方法',36,3);
                    INSERT INTO bt_node VALUES(38,'rbac/set_user_status','设置用户状态','方法',36,3);
                    INSERT INTO bt_node VALUES(39,'rbac/create_user','创建用户','方法',36,3);
                    INSERT INTO bt_node VALUES(40,'rbac/modify_user','修改用户','方法',36,3);
                    INSERT INTO bt_node VALUES(41,'rbac/remove_user','删除用户','方法',36,3);
                    INSERT INTO bt_node VALUES(42,'rbac/get_role_list','查看所有角色','方法',36,3);
                    INSERT INTO bt_node VALUES(43,'角色管理','角色管理','模块',35,2);
                    INSERT INTO bt_node VALUES(44,'rbac/get_role_list','查看所有角色','方法',43,3);
                    INSERT INTO bt_node VALUES(45,'rbac/create_role','创建角色','方法',43,3);
                    INSERT INTO bt_node VALUES(46,'rbac/modify_role','修改角色','方法',43,3);
                    INSERT INTO bt_node VALUES(47,'rbac/remove_role','删除角色','方法',43,3);
                    INSERT INTO bt_node VALUES(48,'rbac/set_role_status','设置角色状态','方法',43,3);
                    INSERT INTO bt_node VALUES(49,'rbac/set_role_access','设置角色权限','方法',43,3);
                    INSERT INTO bt_node VALUES(50,'权限管理','权限管理','模块',35,2);
                    INSERT INTO bt_node VALUES(51,'rbac/get_node_list_by_all','获取节点列表','方法',50,3);
                    INSERT INTO bt_node VALUES(52,'/logs','系统日志','菜单',0,1);
                    INSERT INTO bt_node VALUES(53,'全部日志','全部日志','模块',52,2);
                    INSERT INTO bt_node VALUES(54,'logs/get_log_list','获取日志列表','方法',53,3);
                    INSERT INTO bt_node VALUES(55,'错误日志','错误日志','模块',52,2);
                    INSERT INTO bt_node VALUES(56,'logs/get_error_log','获取错误日志信息','方法',55,3);
                    INSERT INTO bt_node VALUES(57,'/config','系统设置','菜单',0,1);
                    INSERT INTO bt_node VALUES(58,'全部设置','全部设置','模块',57,2);
                    INSERT INTO bt_node VALUES(59,'config/get_config','获取SSL证书信息','方法',58,3);
                    INSERT INTO bt_node VALUES(60,'config/get_ssl_cert','获取系统配置','方法',58,3);
                    INSERT INTO bt_node VALUES(61,'config/set_ssl_cert','设置ssl证书','方法',58,3);
                    INSERT INTO bt_node VALUES(62,'config/modify_basic_auth','设置BASIC认证','方法',58,3);
                    INSERT INTO bt_node VALUES(63,'config/modify_password_complexity','设置密码复杂度','方法',58,3);
                    INSERT INTO bt_node VALUES(64,'config/modify_session_timeout','设置会话超时时间','方法',58,3);
                    INSERT INTO bt_node VALUES(65,'config/modify_accept_domain','设置授权域名','方法',58,3);
                    INSERT INTO bt_node VALUES(66,'config/modify_accept_ip','设置授权IP','方法',58,3);
                    INSERT INTO bt_node VALUES(67,'config/modify_admin_path','设置安全入口','方法',58,3);
                    INSERT INTO bt_node VALUES(68,'config/modify_port','设置端口','方法',58,3);
                    INSERT INTO bt_node VALUES(69,'config/modify_password_expire','设置密码过期时间','方法',58,3);
                    INSERT INTO bt_node VALUES(70,'config/modify_login_place_other','设置异地登录提醒','方法',58,3);
                    INSERT INTO bt_node VALUES(71,'public','公共模块','模块',0,2);
                    INSERT INTO bt_node VALUES(72,'config/update','更新云监控','方法',71,3);
                    INSERT INTO bt_node VALUES(73,'warning/get_settings','告警设置规则','方法',71,3);
                    INSERT INTO bt_node VALUES(74,'read','查看','模块',0,4);
                    INSERT INTO bt_node VALUES(75,'dashboard/server_statistics','主机统计','方法',74,3);
                    INSERT INTO bt_node VALUES(76,'dashboard/get_server_detail','主机监控信息','方法',74,3);
                    INSERT INTO bt_node VALUES(77,'dashboard/get_warning_tasks','告警事件列表','方法',74,3);
                    INSERT INTO bt_node VALUES(78,'dashboard/get_ssh_login_logs','获取SSH登录日志列表','方法',74,3);
                    INSERT INTO bt_node VALUES(79,'dashboard/sensitive_execute_records','危险命令执行','方法',74,3);
                    INSERT INTO bt_node VALUES(80,'dashboard/danger_port_apperence','危险端口暴露','方法',74,3);
                    INSERT INTO bt_node VALUES(81,'dashboard/server_realtime_net_rank','主机实时信息排行(CPU/内存/流量)','方法',74,3);
                    INSERT INTO bt_node VALUES(82,'dashboard/ssh_login_statistics_v2','所有服务器SSH登录次数','方法',74,3);
                    INSERT INTO bt_node VALUES(83,'dashboard/sensitive_execute_statistics','所有服务器危险命令执行次数','方法',74,3);
                    INSERT INTO bt_node VALUES(84,'dashboard/disk_health','硬盘状态','方法',74,3);
                    INSERT INTO bt_node VALUES(85,'dashboard/rank_title','SSH登录最多次','方法',74,3);
                    INSERT INTO bt_node VALUES(86,'server/get_server_list_simple','获取主机列表(简易数据)','方法',74,3);
                    INSERT INTO bt_node VALUES(87,'dashboard/get_server_list','主机列表','方法',74,3);
                    INSERT INTO bt_node VALUES(88,'warning/get_server_list','查看主机列表','方法',74,3);
                    INSERT INTO bt_node VALUES(89,'dashboard/get_raid_info','主机概览-获取主机磁盘RAID信息','方法',74,3);
                    INSERT INTO bt_node VALUES(90,'dashboard/get_proc_top','主机概览-获取主机进程TOP10','方法',74,3);
                    INSERT INTO bt_node VALUES(91,'dashboard/get_ssh_users_info','主机概览-获取当前SSH在线用户','方法',74,3);
                    INSERT INTO bt_node VALUES(92,'dashboard/get_warning_tasks','主机概览-获取告警任务列表','方法',74,3);
                    INSERT INTO bt_node VALUES(93,'dashboard/get_server_detail','主机概览-获取主机监控信息','方法',74,3);
                    INSERT INTO bt_node VALUES(94,'dashboard/repair_agent','主机概览-修复被控版本','方法',74,3);
                    INSERT INTO bt_node VALUES(95,'dashboard/get_agent_info','主机概览-插件列表','方法',74,3);
                    INSERT INTO bt_node VALUES(96,'dashboard/get_process_cpu_info_list','主机概览-历史记录-cpu','方法',74,3);
                    INSERT INTO bt_node VALUES(97,'dashboard/get_process_mem_info_list','主机概览-历史记录-内存','方法',74,3);
                    INSERT INTO bt_node VALUES(98,'dashboard/get_process_disk_info_list','主机概览-历史记录-磁盘IO','方法',74,3);
                    INSERT INTO bt_node VALUES(99,'dashboard/get_process_network_io_info_list','主机概览-历史记录-网络IO','方法',74,3);
                    INSERT INTO bt_node VALUES(100,'dashboard/get_process_opened_threads_info_list','主机概览-历史记录-打开线程数','方法',74,3);
                    INSERT INTO bt_node VALUES(101,'dashboard/get_process_opened_files_info_list','主机概览-历史记录-打开文件数','方法',74,3);
                    INSERT INTO bt_node VALUES(102,'server/cpu_info_statistics','CPU占用率统计','方法',74,3);
                    INSERT INTO bt_node VALUES(103,'server/loadavg_info_statistics','主机负载统计','方法',74,3);
                    INSERT INTO bt_node VALUES(104,'server/mem_info_statistics','内存占用率统计','方法',74,3);
                    INSERT INTO bt_node VALUES(105,'server/swap_info_statistics','swap占用率统计','方法',74,3);
                    INSERT INTO bt_node VALUES(106,'server/disk_info_statistics','磁盘统计信息','方法',74,3);
                    INSERT INTO bt_node VALUES(107,'server/disk_io_info_statistics','磁盘IO统计信息','方法',74,3);
                    INSERT INTO bt_node VALUES(108,'server/net_info_statistics','网络IO统计信息','方法',74,3);
                    INSERT INTO bt_node VALUES(109,'dashboard/get_processes_list','进程监控列表','方法',74,3);
                    INSERT INTO bt_node VALUES(110,'dashboard/get_host_port_info','获取主机端口信息','方法',74,3);
                    INSERT INTO bt_node VALUES(111,'dashboard/get_logs_path_list','获取日志路径列表','方法',74,3);
                    INSERT INTO bt_node VALUES(112,'dashboard/get_log_content','获取日志内容','方法',74,3);
                    INSERT INTO bt_node VALUES(113,'dashboard/get_host_firewall_info','获取主机系统防火墙信息','方法',74,3);
                    INSERT INTO bt_node VALUES(114,'dashboard/get_ssh_login_logs','SSH登录日志列表','方法',74,3);
                    INSERT INTO bt_node VALUES(115,'server/get_command_execute_logs','SSH命令执行记录','方法',74,3);
                    INSERT INTO bt_node VALUES(116,'dashboard/get_installed_soft_info','软件列表','方法',74,3);
                    INSERT INTO bt_node VALUES(117,'dashboard/get_command_history','获取SSH命令执行记录','方法',74,3);
                    INSERT INTO bt_node VALUES(118,'server/get_server_raid_info','获取主机磁盘阵列信息','方法',74,3);
                    INSERT INTO bt_node VALUES(119,'server/get_panel_info','查看被控面板信息','方法',74,3);
                    INSERT INTO bt_node VALUES(120,'server/get_ssh_info','查看面板SSH终端信息','方法',74,3);
                    INSERT INTO bt_node VALUES(121,'terminal/player','查看终端历史记录','方法',74,3);
                    INSERT INTO bt_node VALUES(122,'records','查看终端历史记录视频权限','方法',74,3);
                    INSERT INTO bt_node VALUES(123,'dashboard/get_login_logs','获取服务端登录日志','方法',74,3);
                    INSERT INTO bt_node VALUES(124,'dashboard/get_servers_overview','获取主机概览','方法',74,3);
                    INSERT INTO bt_node VALUES(125,'server/get_server_sampling_settings','获取主机基础监控数据采样设置','方法',74,3);
                    INSERT INTO bt_node VALUES(126,'server/get_process_sampling_settings','获取主机基础监控数据采样设置','方法',74,3);
                    INSERT INTO bt_node VALUES(127,'write','编辑','模块',74,5);
                    INSERT INTO bt_node VALUES(128,'dashboard/edit_server_auth_status','修改服务器授权状态','方法',127,3);
                    INSERT INTO bt_node VALUES(129,'server/set_remark','修改服务器备注','方法',127,3);
                    INSERT INTO bt_node VALUES(130,'server/set_status','取消主机维护状态(取消告警通知)','方法',127,3);
                    INSERT INTO bt_node VALUES(131,'server/cancel_maintence','取消主机维护状态(启用告警通知)','方法',127,3);
                    INSERT INTO bt_node VALUES(132,'server/remove_server','删除服务器','方法',127,3);
                    INSERT INTO bt_node VALUES(133,'server/set_server_group','设置分组','方法',127,3);
                    INSERT INTO bt_node VALUES(134,'warning/update_rules_by_templates','同步模板配置','方法',127,3);
                    INSERT INTO bt_node VALUES(135,'warning/remove_apply_template_packages','取消应用模板','方法',127,3);
                    INSERT INTO bt_node VALUES(136,'warning/handled_task','一键处理-告警任务','方法',127,3);
                    INSERT INTO bt_node VALUES(137,'warning/clear_tasks','清除告警任务','方法',127,3);
                    INSERT INTO bt_node VALUES(138,'server/get_sampling_global','获取全局监控数据采样设置','方法',127,3);
                    INSERT INTO bt_node VALUES(139,'server/set_sampling','监控数据采样设置','方法',127,3);
                    INSERT INTO bt_node VALUES(140,'server/set_sampling_global','全局监控数据采样设置','方法',127,3);
                    INSERT INTO bt_node VALUES(141, 'cmproxy/proxy','登录宝塔面板','服务器权限', 127, 3);
                    INSERT INTO bt_node VALUES(142, 'server/add_panel_info','添加被控面板信息','服务器权限', 127, 3);
                    INSERT INTO bt_node VALUES(143,'server/modify_panel_info','编辑被控面板信息','方法',127,3);
                    INSERT INTO bt_node VALUES(144,'server/delete_panel_info','删除被控宝塔面板','方法',127,3);
                    INSERT INTO bt_node VALUES(145,'terminal/run','登录被控面板SSH终端','方法',127,3);
                    INSERT INTO bt_node VALUES(146,'server/add_ssh_info','添加被控SSH登录信息','方法',127,3);
                    INSERT INTO bt_node VALUES(147,'server/modify_ssh_info','编辑被控面板SSH终端信息','方法',127,3);
                    INSERT INTO bt_node VALUES(148,'server/delete_ssh_info','删除被控面板SSH终端','方法',127,3);
                    COMMIT;
                ''')

    # 2.0.1版本升级补丁
    def v_2_0_1(self):
        if self.__is_patched('2.0.1'):
            return

        with self.__patching('2.0.1'):
            # 删除已创建的终端录像数据库文件
            os.system('rm -f {}/data/monitor_servers/*/playrecords.*'.format(public.get_panel_path()))

            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .name('node') \
                    .where('node_id', 138) \
                    .update({
                    'pid': 74,
                })

    # 2.0.3版本升级补丁
    def v_2_0_3(self):
        if self.__is_patched('2.0.3'):
            return

        with self.__patching('2.0.3'):
            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .execute_script('''
                        BEGIN;
                        -- 2.0.2
                        REPLACE INTO bt_node VALUES(149,'config/modify_two_step_auth','设置动态口令状态','方法',58,3);
                        REPLACE INTO bt_node VALUES(150,'config/get_two_step_auth_status','获取动态口令状态','方法',71,3);
                        REPLACE INTO bt_node VALUES(151,'config/check_two_step_auth','认证动态口令','方法',71,3);
                        REPLACE INTO bt_node VALUES(152,'server/get_nginx_stats_info','nginx监控信息','方法',74,3);
                        REPLACE INTO bt_node VALUES(153,'server/get_nginx_stats_connect','nginx监控连接信息','方法',74,3);
                        REPLACE INTO bt_node VALUES(154,'server/get_stats_list','nginx监控信息列表','方法',74,3);

                        -- 2.0.3
                        REPLACE INTO bt_node VALUES(155,'/monitor','业务监控','菜单',0,1);
                        REPLACE INTO bt_node VALUES(156,'业务监控','业务监控','模块', 155,2);
                        REPLACE INTO bt_node VALUES(157, 'availability/get_port_task', '获取port监控任务列表', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(158, 'availability/get_port_task_id', '获取端口任务详情', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(159, 'availability/get_port_result', '获取port监控任务结果', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(160, 'availability/execute_port_task', '执行port监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(161, 'availability/add_port_task', '添加port监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(162, 'availability/remove_port_task', '删除port监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(163, 'availability/update_port_task', '编辑/修改端口监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(164, 'availability/get_ping_task', '获取ping监控任务列表', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(165, 'availability/get_ping_result', '获取ping监控任务结果', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(166, 'availability/execute_ping_task', '执行ping监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(167, 'availability/add_ping_task', '添加ping监控', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(168, 'availability/remove_ping_task', '删除ping监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(169, 'availability/update_ping_task', '编辑/修改ping监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(170, 'availability/get_http_task', '获取http/https监控任务列表', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(171, 'availability/get_http_result', '获取http/https监控任务结果', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(172, 'availability/execute_http_task', '执行http/https监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(173, 'availability/add_http_task', '添加监控http/https任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(174, 'availability/remove_http_task', '删除http/https监控任务', '方法', 156, 3);
                        REPLACE INTO bt_node VALUES(175, 'availability/update_http_task', '编辑/修改http/https监控任务', '方法', 156, 3);
                        COMMIT;
                    ''')

            # 删除已创建的业务监控数据库文件
            os.system('rm -f {}/data/monitor_databases/availability*'.format(public.get_panel_path()))

            # 重新执行建表语句
            monitor_db_manager._init_single_db(True)

    # 2.0.5版本升级补丁
    def v_2_0_5(self):
        if self.__is_patched('2.0.5'):
            return

        with self.__patching('2.0.5'):
            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .execute_script('''
                        BEGIN;
                        -- 2.0.5
                        REPLACE INTO bt_node VALUES(176,'安全监控','安全监控','模块', 2,2);
                        REPLACE INTO bt_node VALUES(177, 'safetymonitor/get_bug_list', '获取主机漏洞列表', '方法', 176, 3);
                        REPLACE INTO bt_node VALUES(178, 'safetymonitor/ignore_bug', '忽略漏洞', '方法', 176, 3);
                        REPLACE INTO bt_node VALUES(179, 'safetymonitor/handle_bug', '处理漏洞', '方法', 176, 3);
                        REPLACE INTO bt_node VALUES(180, 'safetymonitor/re_scan_bug', '重新扫描漏洞', '方法', 176, 3);
                        REPLACE INTO bt_node VALUES(181, 'safetymonitor/re_scan_bug_all', '重新扫描漏洞(全部)', '方法', 176, 3);
                        COMMIT;
                    ''')

    # 2.0.7版本升级补丁
    def v_2_0_7(self):
        if self.__is_patched('2.0.7'):
            return

        with self.__patching('2.0.7'):
            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .execute_script('''
                        BEGIN;
                        REPLACE INTO `bt_node` VALUES(182, 'safetymonitor/get_mining_list', '获取挖矿木马列表', '方法', 176, 3);
                        REPLACE INTO `bt_node` VALUES(183, 'safetymonitor/ignore_mining', '忽略挖矿木马', '方法', 176, 3);
                        REPLACE INTO `bt_node` VALUES(184, 'safetymonitor/handle_mining', '处理挖矿木马', '方法', 176, 3);
                        REPLACE INTO `bt_node` VALUES(185, 'safetymonitor/re_scan_mining_all', '重新扫描挖矿木马(全部)', '方法', 176, 3);
                        REPLACE INTO `bt_node` VALUES(186, 'server/add_server_both', '获取安装脚本Linux/Windows', '方法', 3, 3);
                        COMMIT;
                    ''')

    # 2.0.9版本升级补丁
    def v_2_0_9(self):
        if self.__is_patched('2.0.9'):
            return

        with self.__patching('2.0.9'):
            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .execute_script('''
                        BEGIN;
                        REPLACE INTO `bt_node` VALUES(187, '/safe', '安全监控', '菜单', 0, 1);
                        REPLACE INTO `bt_node` VALUES(188, '病毒扫描', '病毒扫描', '模块', 187, 2);
                        REPLACE INTO `bt_node` VALUES(189, 'safetymonitor/add_scan_task', '添加扫描任务', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(190, 'safetymonitor/get_scan_task_list', '获取扫描任务列表', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(191, 'safetymonitor/get_server_scan_task_list', '获取扫描任务下的主机列表', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(192, 'safetymonitor/get_scan_task_result', '获取扫描结果', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(193, 'safetymonitor/stop_scan_task', '结束扫描任务', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(194, 'safetymonitor/handle_scan_task_result', '处理扫描结果', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(195, 'safetymonitor/add_white_list', '目录/文件 加入白名单', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(196, 'safetymonitor/remove_white_list', '删除白名单', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(197, 'safetymonitor/get_white_list', '获取白名单列表', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(198, 'safetymonitor/get_scan_dashboard', '统计面板', '方法', 188, 3);
                        COMMIT;
                    ''')

    # 2.1.1版本升级补丁
    def v_2_1_1(self):
        if self.__is_patched('2.1.1'):
            return

        with self.__patching('2.1.1'):
            public.print_log('|--installing pandas...', _level='error')

            # 更新safety.node表结构
            with public.sqlite_easy('safety') as db:
                db.query() \
                    .execute_script('''
                        BEGIN;
                        REPLACE INTO `bt_node` VALUES(199, 'safetymonitor/get_isolators_list', '获取隔离箱列表', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(200, 'safetymonitor/join_isolatore', '拉入隔离箱', '方法', 188, 3);
                        REPLACE INTO `bt_node` VALUES(201, 'safetymonitor/restore_files', '移出隔离箱', '方法', 188, 3);
                        COMMIT;
                    ''')

            try:
                # 检查pandas是否安装，没有安装则尝试安装
                import pandas
            except ImportError:
                # 安装pandas
                os.system('{}/pyenv/bin/pip install pandas'.format(public.get_panel_path()))

            public.print_log('|--pandas installed...', _level='error')

    # 2.1.5版本升级补丁
    def v_2_1_5(self):
        if self.__is_patched('2.1.5'):
            return

        with self.__patching('2.1.5'):
            from core import app, not_login_uri

            # 修改配置文件
            if '/user/check_two_auth_login' not in not_login_uri:
                not_login_uri.append('/user/check_two_auth_login')

            public.set_config_value('config', 'not_login_uri', not_login_uri)

            app.config['NOT_LOGIN_URI'] = not_login_uri

            public.print_log('|--installing msgpack...', _level='error')

            try:
                # 检查msgpack是否安装，没有安装则尝试安装
                import msgpack
            except ImportError:
                # 安装pandas
                os.system('{}/pyenv/bin/pip install msgpack'.format(public.get_panel_path()))

            public.print_log('|--msgpack installed...', _level='error')

    # 2.1.9版本升级补丁
    def v_2_1_9(self):
        if self.__is_patched('2.1.9'):
            return

        with self.__patching('2.1.9'):
            # 更新终端录像数据库结构
            with monitor_db_manager.db_mgr('fortress_player') as db:
                db.query().execute_script('''
                       begin;
                       drop table `bt_fortress_player`;
                       CREATE TABLE IF NOT EXISTS `bt_fortress_player` (
                            `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                            `ssh_id` INTEGER NOT NULL DEFAULT 0,
                            `host` TEXT NOT NULL DEFAULT '',
                            `playback` TEXT NOT NULL DEFAULT '',
                            `username` TEXT NOT NULL DEFAULT '',
                            `uid` INTEGER NOT NULL DEFAULT 0,
                            `port` INTEGER NOT NULL DEFAULT 0,
                            `login_mode` TEXT NOT NULL DEFAULT '',
                            `count_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                            `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
                        );

                        CREATE INDEX IF NOT EXISTS `btFortress_Player_createTime`
                            ON `bt_fortress_player` (`create_time`);
                       commit;
                    ''')

            # 终端录像数据库迁移
            with monitor_db_manager.db_mgr() as db:
                # 返回sid列表
                sid_list = db.query().name('servers').column('sid')

            # 遍历每台主机下的录像回放数据库
            for sid in sid_list:
                with monitor_db_manager.MonitorDbManager(sid).db_mgr('playrecords') as db1, \
                        monitor_db_manager.db_mgr('fortress_player') as db2:
                    try:
                        source_data = db1.query() \
                            .name('playrecords') \
                            .field(
                            "`host`, `playback`, `username`, `uid`, `port`,`login_mode`,`count_time`,`create_time`") \
                            .select()

                        db2.query() \
                            .name('fortress_player') \
                            .insert_all(source_data)

                    except Exception as e:
                        public.print_log("数据库结构调整失败: {}".format(e))

                        # 记录异常堆栈
                        public.print_exc_stack(e)

            # 删除进程监控弃用数据库
            with monitor_db_manager.db_mgr('custom_script') as db2:
                db2.query().execute_script('''
                       begin;
                       drop table `bt_custom_script`;
                       drop table `bt_custom_script_result`;

                       commit;
                    ''')

            # 重新执行建表语句
            monitor_db_manager._init_single_db(True)

    # 2.2.1版本升级补丁
    def v_2_2_1(self):
        if self.__is_patched('2.2.1'):
            return

        with self.__patching('2.2.1'):
            all_servers = basic_monitor_obj.db_easy('servers') \
                .where('is_authorized=1') \
                .where('type=0') \
                .column('sid')

            for sid in all_servers:
                with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
                    level_num = db.query().name('server_bugs') \
                        .where('usable', 1) \
                        .where_not_in('status', [1]) \
                        .field(
                        'SUM(`level`=0) AS `level_0`',
                        'SUM(`level`=1) AS `level_1`',
                        'SUM(`level`=2) AS `level_2`',
                        'SUM(`level`=3) AS `level_3`', ) \
                        .find()

                    basic_monitor_obj.db_easy('server_bug_total') \
                        .name('server_bug_total') \
                        .where('sid', sid) \
                        .update({
                        'bugs': db.query().name('server_bugs').count(),
                        'ignored': db.query().name('server_bugs').where('status', 1).count(),
                        'handled': db.query().name('server_bugs').where('status', 2).count(),
                        'fixed': db.query().name('server_bugs').where_not_in('status', [1]).where('usable', 0).count(),
                        'level_0': level_num['level_0'],
                        'level_1': level_num['level_1'],
                        'level_2': level_num['level_2'],
                        'level_3': level_num['level_3'],
                    })

    # 2.2.2版本升级补丁
    def v_2_2_2(self):
        if self.__is_patched('2.2.2'):
            return

        with self.__patching('2.2.2'):
            # from core.include.monitor_db_manager import SshLoginLogsLatest
            SshLoginLogsLatest = monitor_db_manager.SshLoginLogsLatest
            path = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())

            if not os.path.exists(path):
                # 不存在时 创建数据库
                SshLoginLogsLatest().init_ssh_login_logs_db()
            else:
                # 存在时 删除数据库
                os.remove(path)
                # 创建数据库
                SshLoginLogsLatest().init_ssh_login_logs_db()

            # 同步三月内的数据
            SshLoginLogsLatest().sync_ssh_login_logs_database(True)
            # 记录同步时间
            SshLoginLogsLatest().record_sync_time(True)

    # 2.2.4版本升级补丁 设置入侵检测开关 默认开启
    def v_2_2_4(self):
        self.v_2_2_2()

        if self.__is_patched('2.2.4'):
            return

        with self.__patching('2.2.4'):

            sids = warning_obj.db_easy('servers') \
                .field('sid', ) \
                .where('is_authorized', 1) \
                .where('type', 0) \
                .column('sid')

            insert_data = []
            warning_insert_data = []
            for i in sids:
                insert_data.append({
                    'sid': i,
                    'open': 1,
                })

                warning_insert_data.append({
                    'sid': i,
                    'open': 1,
                    'count': 1,
                })

            with monitor_db_manager.db_mgr('hids') as db:
                # 开启事务
                db.autocommit(False)
                db.query().name('hids_setting').insert_all(insert_data, option='replace')
                db.query().name('hids_warning').insert_all(insert_data, option='replace')

                db.commit()

            # 推消息队列执行被控开关的方法
            from core.include.monitor_helpers import message_push_queue

            def hids_automatic_switch_help(sids):
                # start 开启 stop停止
                # title = {0: 'stop', 1: 'start'}
                for sid in sids:
                    public.send_agent_msg(
                        public.get_serverid_bysid(sid),
                        'intrusion_detection',
                        'SetStartStop',
                        pdata=public.g_pdata({
                            'action': 'start',
                        }))

            message_push_queue.add_task_easy(hids_automatic_switch_help, sids)

    # 2.2.5版本升级补丁
    def v_2_2_5(self):
        self.v_2_2_2()

        if self.__is_patched('2.2.5'):
            return

        with self.__patching('2.2.5'):
            public.print_log('|-正在更新数据库')

            # 更新数据库索引表
            with monitor_db_manager.db_mgr('server_databases') as db:
                # 创建临时表
                db.query().execute_script('''
            CREATE TABLE IF NOT EXISTS `bt_server_databases_2` (
                `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                `sid` INTEGER NOT NULL DEFAULT 0,
                `db_name` TEXT NOT NULL DEFAULT '',
                `table_name` TEXT NOT NULL DEFAULT '',
                `db_path` TEXT NOT NULL DEFAULT '',
                `db_date` INTEGER NOT NULL DEFAULT 202208,
                `create_time` INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                `archive_time` INTEGER NOT NULL DEFAULT 0,
                `unarchive_time` INTEGER NOT NULL DEFAULT 0,
                `archive_path` TEXT NOT NULL DEFAULT '',
                `delete_time` INTEGER NOT NULL DEFAULT 0
            );
            ''')

                # 扫描数据文件
                insert_data = monitor_db_manager._scan_files()

                # 写入数据
                db.query().name('server_databases_2').insert_all(insert_data)

                # 迁移数据表
                db.query().execute_script('''
            begin;
            DROP TABLE IF EXISTS `bt_server_databases`;
            ALTER TABLE `bt_server_databases_2` RENAME TO `bt_server_databases`;
            CREATE INDEX IF NOT EXISTS `serverDatabases_sid_deleteTime_dbDate_tableName_archiveTime_unarchiveTime`
                ON `bt_server_databases` (`sid`, `delete_time`, `db_date`, `table_name`, `archive_time`, `unarchive_time`);
            commit;
            ''')

            public.print_log('|-正在更新数据库 >> 成功')
            public.print_log('|-正在同步V2告警规则')

            # 同步V2告警规则
            with monitor_db_manager.db_mgr() as db:
                try:
                    # 取消事务自动提交
                    db.autocommit(False)

                    # 查询所有主机模板包关联记录
                    template_package_merge = db.query() \
                        .name('server_warning_template_package_merge') \
                        .column('package_id', 'sid')

                    # print(template_package_merge)

                    # 获取所有模板包对应的模板规则
                    template_rules = db.query() \
                        .name('warning_templates') \
                        .where_in('package_id', tuple(template_package_merge.values())) \
                        .field('id', 'package_id', 'type', 'sub_type', 'watch_target', 'watch_value') \
                        .select()

                    # print(template_rules)

                    # 查询所有template_id为0的主机告警规则
                    rules = db.query() \
                        .name('warning_configurations') \
                        .where_in('sid', tuple(template_package_merge.keys())) \
                        .where('template_id', 0) \
                        .field('id', 'sid', 'type', 'sub_type', 'watch_target', 'watch_value') \
                        .select()

                    # print(rules)

                    template_rule_dict = {}
                    for template_rule in template_rules:
                        if template_rule['package_id'] not in template_rule_dict:
                            template_rule_dict[template_rule['package_id']] = {}
                        k = '{}||{}||{}||{}'.format(template_rule['type'], template_rule['sub_type'],
                                                    template_rule['watch_target'], template_rule['watch_value'])
                        template_rule_dict[template_rule['package_id']][k] = template_rule

                    # print(template_rule_dict)

                    # updated = set()

                    # 更新主机告警规则的template_id
                    for rule in rules:
                        package_id = template_package_merge.get(rule['sid'])

                        if package_id is None:
                            continue

                        # print(package_id)

                        k = '{}||{}||{}||{}'.format(rule['type'], rule['sub_type'], rule['watch_target'],
                                                    rule['watch_value'])
                        d = template_rule_dict.get(package_id, {})

                        # print(k)

                        if k not in d:
                            continue

                        db.query() \
                            .name('warning_configurations') \
                            .where('id', rule['id']) \
                            .update({'template_id': d[k]['id']})

                        # print('>> {}'.format(template_rule))

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()
                    raise

            public.print_log('|-正在同步V2告警规则 >> 成功')

    # 2.2.6版本升级补丁  迁移病毒扫描结果表
    def v_2_2_6(self):
        if self.__is_patched('2.2.6'):
            return

        try:
            with self.__patching('2.2.6'):
                public.print_log('|-正在更新数据库')
                with monitor_db_manager.db_mgr('malicious_scan') as db:
                    # 创建临时表
                    db.query().execute_script('''
                            begin;
                            drop table if exists `bt_malicious_scan_results_2`;
                             -- 安全监控-病毒扫描结果表(新)
                             CREATE TABLE IF NOT EXISTS `bt_malicious_scan_results_2` (
                                 `id` INTEGER PRIMARY KEY AUTOINCREMENT, -- 主键ID
                                 `sid` INTEGER NOT NULL DEFAULT 0, -- 主机ID    
                                 `task_id` INTEGER NOT NULL DEFAULT 0, -- 扫描任务ID
                                 `isolate_id` INTEGER NOT NULL DEFAULT 0, -- 隔离箱ID(0表示没有拉入隔离箱)
                                 `status` INTEGER NOT NULL DEFAULT 0, -- 状态 0-未处理 1-已处理 2-已忽略(误报)
                                 `level` INTEGER NOT NULL DEFAULT 0, -- 风险级别 0-低风险 1-中风险 2-高风险 3-严重
                                 `white_list_id` INTEGER NOT NULL DEFAULT 0, -- 白名单ID(0表示没有加入白名单)
                                 `handle_operator` INTEGER NOT NULL DEFAULT 0, -- 处理人UID
                                 `handled_time` INTEGER NOT NULL DEFAULT 0, -- 处理时间
                                 `ignore_operator` INTEGER NOT NULL DEFAULT 0, -- 忽略人UID
                                 `ignore_time` INTEGER NOT NULL DEFAULT 0, -- 忽略时间
                                 `create_time` INTEGER NOT NULL DEFAULT 0, -- 扫描时间
                                 `file_path` TEXT NOT NULL DEFAULT '', -- 文件路径
                                 `idx` TEXT GENERATED ALWAYS AS (`sid` || '|' || `file_path`) VIRTUAL, -- 扫描结果唯一索引
                                 `fix_remark` TEXT NOT NULL DEFAULT '' -- 处理人备注
                             );
    
                             CREATE INDEX IF NOT EXISTS `maliciousScanResults2_sid_taskId_status_createTime`
                                 ON `bt_malicious_scan_results_2` (`sid`, `task_id`, `status`, `create_time`);
                             CREATE INDEX IF NOT EXISTS `maliciousScanResults2_status_level`
                                 ON `bt_malicious_scan_results_2` (`status`, `level`);
                             CREATE INDEX IF NOT EXISTS `maliciousScanResults2_whiteListId`
                                 ON `bt_malicious_scan_results_2` (`white_list_id`);  
    
                             CREATE UNIQUE INDEX IF NOT EXISTS `maliciousScanResults2_idx`
                                 ON `bt_malicious_scan_results_2` (`idx`);
    
                    commit;
                    ''')

                    # 扫描数据文件
                    # insert_data = monitor_db_manager._scan_files()

                    insert_data = db.query().name('malicious_scan_results') \
                        .field('sid', 'task_id', 'status', 'level', 'white_list_id', 'isolate_id', 'handle_operator',
                               'handled_time', 'ignore_operator', 'ignore_time', 'file_path', 'fix_remark',
                               'create_time') \
                        .select()

                    # 写入数据
                    db.query().name('malicious_scan_results_2').insert_all(insert_data, option='replace')

                    # 迁移数据表
                    db.query().execute_script('''
                    begin;
                    DROP TABLE IF EXISTS `bt_malicious_scan_results`;
                    ALTER TABLE `bt_malicious_scan_results_2` RENAME TO `bt_malicious_scan_results`;
    
                    commit;
                    ''')
        except BaseException as e:
            public.print_exc_stack(e)

    def check_database_schema(self):
        '''
            @name 更新表结构
            @return void
        '''
        try:
            # 更新servers表结构
            # 需要确保存在的字段列表
            keep_columns = {
                "ssh_info": "INTEGER DEFAULT 0",
                "panel_info": "INTEGER DEFAULT 0",
                "group_id": "INTEGER NOT NULL DEFAULT 0",
            }

            # 更新主数据库
            with monitor_db_manager.db_mgr() as db:
                # 更新servers表结构
                query = db.query().name('servers')

                for (col_name, col_prop) in keep_columns.items():
                    query.add_column(col_name, col_prop)

                # 新增字段 是否开启数据采样(全局设置)
                query.add_column('sampling', 'INTEGER NOT NULL DEFAULT 3')
                query.add_column('type', 'INTEGER NOT NULL DEFAULT 0')
                # 新增上次授权时间
                query.add_column('last_authorized_time', 'INTEGER NOT NULL DEFAULT 0')


                # 更新表结构
                query.alter_table()

                # 新增索引
                query.add_index('servers_sampling', ['sampling'])

                # 更新warning_templates表结构
                query = db.query().name('warning_templates')

                # 新增字段
                query.add_column('scores', 'INTEGER NOT NULL DEFAULT 0')

                # 新增字段
                query.add_column('duration', 'INTEGER NOT NULL DEFAULT 60')

                # 新增字段
                query.add_column('linked_all_server', 'INTEGER NOT NULL DEFAULT 0')

                # 新增字段
                query.add_column('linked_server_groups', 'TEXT NOT NULL DEFAULT ""')

                # 新增字段
                query.add_column('remark', 'TEXT NOT NULL DEFAULT ""')

                query.alter_table()

                # 更新warning_configurations表结构
                query = db.query().name('warning_configurations')

                # 新增字段
                query.add_column('scores', 'INTEGER NOT NULL DEFAULT 0')
                # 新增字段
                query.add_column('duration', 'INTEGER NOT NULL DEFAULT 60')
                query.add_column('add_source', 'INTEGER DEFAULT 0')
                query.add_column('template_id', 'INTEGER DEFAULT 0')

                query.alter_table()

                # 调整ssh_info表结构
                try:
                    db.query().name('ssh_info').field('id', 'uid').exists()
                except:
                    db.query().execute_script('''
                    begin;
                    drop table if exists `bt_ssh_info_2`;
                    create table `bt_ssh_info_2` (
                        `id` integer primary key autoincrement,
                        `uid` integer not null default 0,
                        `sid` integer not null default 0,
                        `port` integer not null default 22,
                        `addtime` integer not null default (strftime('%s', 'now')),
                        `last_login_time` integer not null default (strftime('%s', 'now')),
                        `host` text not null default '',
                        `remark` text not null default '',
                        `username` text not null default '',
                        `password` text not null default '',
                        `pkey` text not null default ''
                    );

                    insert into `bt_ssh_info_2` (`sid`, `port`, `host`, `addtime`, `last_login_time`, `username`, `password`, `pkey`)
                    select `sid`, `port`, `host`, `addtime`, `addtime` as `last_login_time`, `username`, ifnull(`password`, '') as `password`, ifnull(`pkey`, '') as `pkey`
                    from `bt_ssh_info`;

                    drop table `bt_ssh_info`;

                    alter table `bt_ssh_info_2` rename to `bt_ssh_info`;

                    create index if not exists `sshInfo_addtime_host_remark` on `bt_ssh_info` (`addtime`, `host`, `remark`);
                    
                    commit;
                    ''')

            # 更新ssh_login_logs表结构
            with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                query = db.query().name('ssh_login_logs')

                # 新增字段
                query.add_column('ip_place', "TEXT NOT NULL DEFAULT ''")

                # 更新表结构
                query.alter_table()

                # 新增索引
                query.add_index('sshLoginLogs_loginTime_ipPlace', ['login_time', 'ip_place'])

            # 更新safety.logs表结构
            with public.sqlite_easy('safety') as db:
                query = db.query().name('logs')

                # 新增索引
                query.add_index('logs_addtime_type', ['addtime', 'type'])

                # 更新access表结构
                query = db.query().name('access')

                # 新增sid字段
                query.add_column('sid', "INTEGER NOT NULL DEFAULT 0")

                query.alter_table()

            # 更新command_execute_logs表结构
            with monitor_db_manager.db_mgr('command_execute_logs') as db:
                query = db.query().name('command_execute_logs')

                # 新增字段
                query.add_column('is_sensitive', 'INTEGER NOT NULL DEFAULT 0')

                # 更新表结构
                query.alter_table()

                # 新增索引
                query.add_index('commandExecuteLogs_isSensitive_createTime', ['is_sensitive', 'create_time'])

            # 更新processes表结构
            with monitor_db_manager.db_mgr('processes') as db:
                query = db.query().name('processes')

                # 新增字段
                query.add_column('pne_id', 'INTEGER NOT NULL DEFAULT 0')

                query.alter_table()

                # 新增索引
                query.add_index('processes_pneId_sid', ['pne_id', 'sid'])

            #  更新业务监控port ping http表结构
            with monitor_db_manager.db_mgr('availability_port') as db:
                query = db.query().name('availability_port')

                # 新增字段
                query.add_column('suspend', 'INTEGER NOT NULL DEFAULT 0')
                query.add_column('nodes', 'TEXT NOT NULL DEFAULT "0"')
                query.add_column('retries', 'INTEGER NOT NULL DEFAULT 0')

                query.alter_table()

            with monitor_db_manager.db_mgr('availability_ping') as db:
                query = db.query().name('availability_ping')

                # 新增字段
                query.add_column('suspend', 'INTEGER NOT NULL DEFAULT 0')
                query.add_column('nodes', 'TEXT NOT NULL DEFAULT "0"')
                query.add_column('retries', 'INTEGER NOT NULL DEFAULT 0')

                query.alter_table()

            with monitor_db_manager.db_mgr('availability_http') as db:
                query = db.query().name('availability_http')

                # 新增字段
                query.add_column('suspend', 'INTEGER NOT NULL DEFAULT 0')
                query.add_column('is_basic', 'INTEGER NOT NULL DEFAULT 0')
                query.add_column('bs_user', 'TEXT NOT NULL DEFAULT ""')
                query.add_column('bs_pwd', 'TEXT NOT NULL DEFAULT ""')
                query.add_column('nodes', 'TEXT NOT NULL DEFAULT "0"')
                query.add_column('retries', 'INTEGER NOT NULL DEFAULT 0')

                query.alter_table()

            with monitor_db_manager.db_mgr('availability_port_info') as db:
                query = db.query().name('availability_port_info')

                # 新增字段
                query.add_column('delay', 'INTEGER DEFAULT 0')
                query.alter_table()

            # 更新server_raid_info表结构
            with monitor_db_manager.db_mgr('server_raid_info') as db:
                query = db.query().name('server_raid_info')

                # 新增字段
                query.add_column('check_dell', 'INTEGER DEFAULT 1')

                query.alter_table()

            # 更新 malicious_scan_results 表结构
            with monitor_db_manager.db_mgr('malicious_scan') as db:
                query = db.query().name('malicious_scan_results')
                query2 = db.query().name('malicious_scan_tasks')

                # 新增字段
                query.add_column('isolate_id', 'INTEGER DEFAULT 0')
                query2.add_column('is_automatic', 'INTEGER DEFAULT 0')

                query.alter_table()
                query2.alter_table()

            # 更新 server_bug_total表结构 上次扫描时间 危险等级漏洞数量
            with monitor_db_manager.db_mgr('server_bug_total') as db:
                query = db.query().name('server_bug_total')

                # 新增字段
                query.add_column('last_scan_time', 'INTEGER DEFAULT 0')
                query.add_column('level_0', 'INTEGER DEFAULT 0')
                query.add_column('level_1', 'INTEGER DEFAULT 0')
                query.add_column('level_2', 'INTEGER DEFAULT 0')
                query.add_column('level_3', 'INTEGER DEFAULT 0')

                query.alter_table()

            # 更新 server_mining_total 表结构 上次扫描时间
            with monitor_db_manager.db_mgr('server_mining_total') as db:
                query = db.query().name('server_mining_total')

                # 新增字段
                query.add_column('last_scan_time', 'INTEGER DEFAULT 0')

                query.alter_table()


        except BaseException as e:
            public.print_log("数据库结构调整失败: {}".format(e))

            # 记录异常堆栈
            public.print_exc_stack(e)

    def adjust_process_db(self):
        """调整进程数据库适合按天存储"""
        with monitor_db_manager.db_mgr() as db:
            servers = db.query() \
                .name('servers') \
                .where_in('status', [0, 1]) \
                .column('sid')

        import time, shutil
        ori_date = time.strftime('%Y%m')
        day = time.strftime('%Y%m%d')
        root_path = '{}/data/monitor_servers'.format(public.get_panel_path())
        for sid in servers:
            sid_md5 = public.md5(str(sid))
            target_db_path = '{}/{}/{}'.format(root_path, sid_md5, ori_date)
            if not os.path.isdir(target_db_path):
                continue
            new_path = '{}/{}/{}'.format(root_path, sid_md5, day)
            if not os.path.exists(new_path):
                os.makedirs(new_path)
            for sfile in os.listdir(target_db_path):
                if not sfile.startswith("process_"): continue
                source_db = os.path.join(target_db_path, sfile)
                if not os.path.isfile(source_db): continue
                new_db = os.path.join(new_path, sfile)
                shutil.move(source_db, new_db)
                public.print_log("移动{} --> {} 完成。".format(sfile, new_db))
                # print("移动{} 完成。".format(sfile))

    def migrate_process_db(self):
        '''
            @name 删减并迁移进程数据库(调整为按天存储)
            @author Zhj<2022-09-21>
            @return void
        '''
        # 获取当前时间的时间元组
        now_time = time.localtime()

        # 获取本月日期
        cur_month = int(time.strftime('%Y%m', now_time))

        # 获取今天日期
        today = time.strftime('%Y%m%d', now_time)

        # 获取今天00:00:00时间戳
        today_time = int(time.mktime((now_time.tm_year, now_time.tm_mon, now_time.tm_mday, 0, 0, 0, 0, 0, 0)))

        # 获取昨天日期
        yesterday = time.strftime('%Y%m%d', time.localtime(today_time - 86400))

        # 获取前天日期
        before_yesterday = time.strftime('%Y%m%d', time.localtime(today_time - 172800))

        with monitor_db_manager.db_mgr('server_databases') as db:
            process_db_list = db.query() \
                .name('server_databases') \
                .where('sid>0') \
                .where('delete_time=0') \
                .where('db_date>=?', 202207) \
                .where('db_date<=?', 999999) \
                .where('table_name like ?', 'process_%') \
                .field('id', 'sid', 'db_name', 'table_name', 'db_date', 'db_path', 'archive_path', 'archive_time') \
                .select()

        if len(process_db_list) == 0:
            return

        public.print_log('|--开始迁移主机进程数据库')

        # 标记删除的ID列表
        remove_list = []

        # 即将删除的文件列表
        remove_files = []

        for process_db_info in process_db_list:
            db_file_exists = False
            shm_file = '{}.db-shm'.format(process_db_info['db_path'][:-3])
            wal_file = '{}.db-wal'.format(process_db_info['db_path'][:-3])

            # 删除db文件
            if os.path.exists(process_db_info['db_path']):
                remove_files.append(process_db_info['db_path'])
                db_file_exists = True

            # 删除shm文件
            if os.path.exists(shm_file):
                remove_files.append(shm_file)

            # 删除wal文件
            if os.path.exists(wal_file):
                remove_files.append(wal_file)

            # 删除归档文件
            if process_db_info['archive_time'] > 0 and os.path.exists(process_db_info['archive_path']):
                remove_files.append(process_db_info['archive_path'])

            # 标记删除
            remove_list.append(process_db_info['id'])

            # 不是本月数据或db文件不存在时 跳过
            if process_db_info['db_date'] < cur_month or not db_file_exists:
                continue

            log_content = '|--正在迁移数据库 {}'.format(process_db_info['db_name'])

            today_data = None
            yestoday_data = None
            before_yesterday_data = None

            # 迁移今天、昨天、前天数据
            with public.sqlite_easy(process_db_info['db_name']) as db:
                today_data = db.query() \
                    .name(process_db_info['table_name']) \
                    .where('create_time >= ?', today_time) \
                    .select()

                yesterday_data = db.query() \
                    .name(process_db_info['table_name']) \
                    .where('create_time >= ?', today_time - 86400) \
                    .where('create_time < ?', today_time) \
                    .select()

                before_yesterday_data = db.query() \
                    .name(process_db_info['table_name']) \
                    .where('create_time >= ?', today_time - 172800) \
                    .where('create_time < ?', today_time - 86400) \
                    .select()

            # 初始化数据库(今天)
            today_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(today))

            # 迁移今天数据
            if len(today_data) > 0:
                today_mgr.add(process_db_info['table_name'], today_data, option='ignore')

            # 释放内存
            today_data = None

            # 初始化数据库(昨天)
            yesterday_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(yesterday))

            # 迁移昨天数据
            if len(yesterday_data) > 0:
                yesterday_mgr.add(process_db_info['table_name'], yesterday_data, option='ignore')

            # 释放内存
            yesterday_data = None

            # 初始化数据库(前天)
            before_yesterday_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(before_yesterday))

            # 迁移昨天数据
            if len(before_yesterday_data) > 0:
                before_yesterday_mgr.add(process_db_info['table_name'], before_yesterday_data, option='ignore')

            # 释放内存
            before_yesterday_data = None

            public.print_log('{} >>> 完成'.format(log_content))

        # 删除文件
        for filename in remove_files:
            if os.path.exists(filename):
                os.remove(filename)

        # 获取当前时间戳
        cur_time = int(time.mktime(now_time))

        # 更新主数据
        with monitor_db_manager.db_mgr('server_databases') as db:
            db.query() \
                .name('server_databases') \
                .where_in('id', remove_list) \
                .update({
                'delete_time': cur_time,
            })

        public.print_log('|--主机进程数据库迁移成功')

    def update_authorization_tree(self):
        '''
            @name 更新权限树
            @author Zhj<2023-04-28>
            @return None
        '''
        public.print_log('|-updating authorization tree...', _level='error')

        # 更新权限树
        sql = aes.aescrypt_py3('ce0c478b42f4882b', 'CBC', b'83314d2122d4896e').aesdecrypt(
            public.readFile('{}/update/node.sqlx'.format(public.get_panel_path())))
        with public.sqlite_easy('safety') as db:
            db.query().execute_script(sql)

        public.print_log('|-updating authorization tree ok', _level='error')

    def attempt_install_patches(self):
        '''
            @name 尝试安装版本补丁
            @author Zhj<2022-11-12>
            @return void
        '''
        # 获取当前已安装的最新补丁版本
        with monitor_db_manager.db_mgr('version_patches') as db:
            last_installed_patch = db.query() \
                .name('version_patches') \
                .where('create_time > 0') \
                .order('create_time', 'desc') \
                .value('version')

        if last_installed_patch is None:
            last_installed_patch = self.__CUR_VERSION

        last_installed_patch = tuple(map(lambda x: int(x), str(last_installed_patch).split('.')))

        for version in self.__PATCH_VERSIONS:
            # 小于最新安装的补丁版本的无需尝试安装补丁
            if version < last_installed_patch:
                continue

            # 获取方法名称
            func_name = 'v_{}'.format('_'.join(map(lambda x: str(x), version)))

            # 调用方法
            if hasattr(self, func_name):
                getattr(self, func_name)()

    def __is_patched(self, version=None):
        '''
            @name 检查是否已经打过补丁
            @author Zhj<2022-08-26>
            @param  version<?string> 版本号[可选]
            @return bool
        '''
        version = version or self.__CUR_VERSION
        try:
            with monitor_db_manager.db_mgr('version_patches') as db:
                return db.query() \
                    .name('version_patches') \
                    .where('version = ?', version) \
                    .where('create_time > 0') \
                    .field('id') \
                    .exists()
        except:
            return True

    def __patch_end(self, version=None):
        '''
            @name 补丁完成记录
            @author Zhj<2022-08-26>
            @param version<?string> 版本号[可选]
            @return void
        '''
        version = version or self.__CUR_VERSION
        with monitor_db_manager.db_mgr('version_patches') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('version_patches') \
                    .insert({
                    'version': version,
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

    @contextmanager
    def __patching(self, version=None):
        '''
            @name 基于上下文管理器的补丁程序
            @author Zhj<2022-09-08>
            @param  version<?string> 版本号[可选]
            @return generator
        '''
        yield
        self.__patch_end(version)

# if __name__ == "__main__":
#     mvp = MonitorVersionPatch()
#     mvp.check_database_schema()
# mvp.adjust_process_db()
