import time
import queue, threading
import core.include.public as public
# from multiprocessing import Process


class MonitorTaskQueue:
    '''
        @name 云监控任务队列类
        @author Zhj<2022-09-17>
        @param name<str>        任务队列名称
        @param max_tasks<int>   最大任务数
    '''
    def __init__(self, name='default', max_tasks=5000):
        self.__NAME = name
        self.__TASK_QUEUE = queue.Queue(maxsize=max_tasks)
        # self.__TASK_QUEUE = JoinableQueue()
        self.__IS_RUNNING = False
        # self.__THREAD_OBJS = []
        self.__BLOCKING = False
        self.__MAX_TASKS = max_tasks
        self.__PRINT_THRESHOLD = int(max_tasks * 0.95)

    # 析构函数
    def __del__(self):
        self.__IS_RUNNING = False
        # self.__THREAD_OBJS = None

    def blocking(self, blocking=True):
        '''
            @name 设置获取队列元素时是否阻塞
            @author Zhj<2022-09-19>
            @param  blocking<?bool> 是否阻塞[可选]
            @return self
        '''
        self.__BLOCKING = blocking
        return self

    # 任务队列处理函数
    def __task_queue_handler(self):
        while self.__IS_RUNNING:
            # 每次休眠1秒钟后开始调度
            time.sleep(1)

            # 当任务数超过阈值，打印数量
            if self.__TASK_QUEUE.qsize() > self.__PRINT_THRESHOLD:
                public.print_log('>>>> MonitorTaskQueue exceed：{} {}'.format(self.__NAME, self.__TASK_QUEUE.qsize()), _level='error')

            # 获取当前时间
            cur_time = int(time.time())
            task_list = []
            while True:
                try:
                    task = self.__TASK_QUEUE.get(self.__BLOCKING)

                    if not isinstance(task, MonitorTask):
                        continue

                    # 执行任务
                    task.handle(cur_time)

                    self.__TASK_QUEUE.task_done()

                    # 循环执行的任务或未完成的任务
                    # 需要在本次调度完成后重新放回队列
                    if task.is_interval() or not task.is_finished():
                        task_list.append(task)

                    # 主动释放内存
                    del (task,)
                except queue.Empty:
                    break

            for task in task_list:
                self.__TASK_QUEUE.put(task)

            # 主动释放内存
            del(task_list, cur_time)

    def run(self, threads = 1):
        if self.__IS_RUNNING:
            raise RuntimeError('任务队列已启动')

        self.__IS_RUNNING = True

        # 开启线程
        for i in range(threads):
            t = threading.Thread(target=self.__task_queue_handler, daemon=True)
            # t = Process(target=self.__task_queue_handler, daemon=True)
            t.start()
            # self.__THREAD_OBJS.append(t)

        return self

    def add_task(self, task):
        '''
            @name 添加任务
            @author Zhj<2022-09-17>
            @param  task<MonitorTask> 任务对象
            @return self
        '''
        self.__TASK_QUEUE.put(task)
        return self

    def add_task_easy(self, fn, *args, **kwargs):
        """
            @name 提供更为简便的添加任务方法
            @author Zhj<2023-05-16>
            @param  fn<function>    函数对象
            @return self
        """
        return self.add_task(MonitorTask(fn, args=args, kwargs=kwargs))

    # 获取当前任务数
    def current_tasks(self):
        return self.__TASK_QUEUE.qsize()


class MonitorTask:
    '''
        @name 任务类
        @author Zhj<2022-09-17>
    '''
    def __init__(self, obj, func_name=None, args=(), kwargs=None):
        self.__OBJ = obj
        self.__FUNC_NAME = func_name
        self.__ARGS = args
        self.__KWARGS = kwargs or {}
        self.__IS_INTERVAL = False   # 是否循环执行
        self.__IS_FINISHED = False   # 任务是否完成
        self.__HANDLE_PERIODIC = 60  # 任务循环执行间隔/秒
        self.__LAST_HANDLED_TIME = 0  # 上一次执行任务时间
        self.__FIRST_CALL_TIME = 0  # 首次执行时间

        self.__IS_INTERVAL_DATETIME = False  # 时间型周期任务
        self.__DATETIME = None  # 时间型周期任务 目标时间
        self.__NEXT_CALL_TIME = 0  # 时间型周期任务执行时间(时间戳)

    def __del__(self):
        self.__OBJ = None
        self.__ARGS = None
        self.__KWARGS = None

        del (self.__OBJ, self.__ARGS, self.__KWARGS,)

    def set_interval(self, interval=True, periodic=60):
        '''
            @name 设置任务循环执行状态
            @author Zhj<2022-09-17>
            @param  interval<?bool> 是否循环执行[可选 默认True]
            @param  periodic<?integer> 任务循环执行间隔/秒[可选 默认60]
            @return self
        '''
        self.__IS_INTERVAL = interval
        self.__HANDLE_PERIODIC = periodic
        return self

    def delay(self, delay):
        '''
            @name 设置首次执行延迟时间
            @author Zhj<2022-02-11>
            @param delay<int> 延迟秒数
            @return self
        '''
        self.__FIRST_CALL_TIME = int(time.time()) + delay
        return self

    # 计算下一次执行时间
    def __calculate_next_call_time(self):
        now_time = time.localtime()
        cur_time = int(time.mktime(now_time))
        t = str(self.__DATETIME).split(':')
        # 判断时间是否已经在今天已经过去了
        # 获取目标时间在今天的时间戳
        except_time_in_today = int(time.mktime((now_time.tm_year, now_time.tm_mon, now_time.tm_mday, int(t[0]), int(t[1]), int(t[2]), 0, 0, 0)))
        if cur_time >= except_time_in_today:
            # 计算出下一天的时间戳
            return int(time.mktime((now_time.tm_year, now_time.tm_mon, now_time.tm_mday + 1, int(t[0]), int(t[1]), int(t[2]), 0, 0, 0)))

        return except_time_in_today

    # 补全时间字符串
    def __ensure_datetime_regular(self, except_datetime):
        t = str(except_datetime).split(':')
        if len(t) < 3:
            for _ in range(3 - len(t)):
                t.append('00')

        return ':'.join(t)

    # 在每天指定的时刻执行任务(循环)
    def per_day(self, except_datetime):
        self.__IS_INTERVAL_DATETIME = True  # 设置循环执行
        self.__DATETIME = self.__ensure_datetime_regular(except_datetime)  # 时间型周期任务 目标时间
        # 通过时间日期计算出下一次的执行时间(时间戳)
        # 每次执行后，再次计算出下一次的执行时间(时间戳)
        self.__FIRST_CALL_TIME = self.__calculate_next_call_time()
        return self

    # 在一个指定的时刻执行任务(单次)
    def datetime(self, except_datetime):
        # 计算出时间日期对应的时间戳
        self.__DATETIME = self.__ensure_datetime_regular(except_datetime)  # 时间型周期任务 目标时间
        self.__FIRST_CALL_TIME = self.__calculate_next_call_time()
        return self

    def is_interval(self):
        '''
            @name 检查任务是否需要循环执行
            @author Zhj<2022-09-17>
            @return bool
        '''
        return self.__IS_INTERVAL or self.__IS_INTERVAL_DATETIME

    def is_finished(self):
        '''
            @name 检查任务是否完成
            @author Zhj<2022-09-17>
            @return bool
        '''
        return self.__IS_FINISHED

    def periodic(self, periodic=60):
        '''
            @name 设置循环执行间隔
            @author Zhj<2022-09-17>
            @param  periodic<?integer> 任务循环执行间隔/秒[可选 默认60]
            @return self
        '''
        self.__HANDLE_PERIODIC = periodic
        return self

    def handle(self, cur_time=None):
        '''
            @name 执行任务
            @author Zhj<2022-09-17>
            @param cur_time<?integer> 当前时间[可选]
            @return void
        '''
        cur_time = cur_time or int(time.time())
        # 周期型任务
        if self.__LAST_HANDLED_TIME > 0:
            # 时间间隔型任务
            if self.__IS_INTERVAL and self.__LAST_HANDLED_TIME > cur_time - self.__HANDLE_PERIODIC:
                return

            # 指定时间型任务
            if self.__IS_INTERVAL_DATETIME and self.__NEXT_CALL_TIME > 0 and cur_time < self.__NEXT_CALL_TIME:
                return

        # 首次执行任务延时
        if self.__FIRST_CALL_TIME > cur_time:
            return

        try:
            fn = None
            # from inspect import isfunction
            if self.__FUNC_NAME is None:
                # if isfunction(self.__OBJ):
                fn = self.__OBJ
            elif hasattr(self.__OBJ, self.__FUNC_NAME):
                fn = getattr(self.__OBJ, self.__FUNC_NAME)

            # 执行任务
            if fn is not None:
                # 在主线程中执行
                fn(*self.__ARGS, **self.__KWARGS)
        except BaseException as e:
            public.print_exc_stack(e)
        finally:
            # 一次性任务执行完后标记已完成
            if not self.is_interval():
                self.__IS_FINISHED = True

            # 记录本次任务执行时间
            self.__LAST_HANDLED_TIME = cur_time

            # 标记首次已执行
            self.__FIRST_CALL_TIME = 0

            # 指定时间型任务 计算下一次执行时间
            if self.__IS_INTERVAL_DATETIME:
                self.__NEXT_CALL_TIME = self.__calculate_next_call_time()

