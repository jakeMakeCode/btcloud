#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-
import sys, os, base64, time, datetime, json

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
# from sqlite_server import Db
# from core.include.monitor_helpers import basic_monitor_obj, warning_obj, monitor_db_manager
# 每月创建一次最新的数据库   删除旧的数据库文件 创建新的数据库文件 同步三月内的数据

# 导入 SshLoginLogsLatest
from core.include.monitor_db_manager import SshLoginLogsLatest

class create_ssh_login_logs():
    def __init__(self):
        self.PATH = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())
        # today = datetime.date.today()
        # two_months_ago = datetime.date(today.year, today.month - 2, 1)
        # # 最近三月 第一天的时间戳
        # self.MONTH3_AGO = int(time.mktime(two_months_ago.timetuple()))
        # self.CUR_TIME = int(time.time())

        # cur_time = int(time.time())
        # now_time = time.localtime(int(cur_time))
        # # 当前日期 yyyymm 整数形式
        # self.cur_month = int(time.strftime('%Y%m', now_time))
        # # 上月日期 yyyymm 整数形式
        # self.last_month = int(time.strftime('%Y%m', (now_time.tm_year, now_time.tm_mon - 1, 1, 0, 0, 0, 0, 0, 0)))

    # 每月ssh登录记录表
    def ssh_login_logs_latest_database(self):
        '''
            @name 初始化ssh登录日志数据库
            @return void
        '''

        if not os.path.exists(self.PATH):
            # 不存在时 创建数据库
            # self.__init_ssh_login_logs_db(self.PATH)
            SshLoginLogsLatest().init_ssh_login_logs_db()

        else:
            # 存在时 删除数据库
            os.remove(self.PATH)
            # 创建数据库
            # self.__init_ssh_login_logs_db(self.PATH)
            SshLoginLogsLatest().init_ssh_login_logs_db()

        # 同步三月内的数据
        # self.__sync_ssh_login_logs_database()
        SshLoginLogsLatest().sync_ssh_login_logs_database(True)
        # 记录同步时间
        # self.__record_sync_time()
        SshLoginLogsLatest().record_sync_time(True)



if __name__ == '__main__':

    s_time = time.time()
    print('ssh登录日志数据库 开始同步时间:{}'.format(time.strftime('%Y-%m-%d-%H:%M:%S')))
    # 实例化对象
    obj = create_ssh_login_logs()
    # 创建数据库
    obj.ssh_login_logs_latest_database()

    os.system('btm 1')
    print('ssh登录日志(三月)更新成功!!!!!')



