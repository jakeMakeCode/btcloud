#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core.include.monitor_helpers import basic_monitor_obj

if __name__ == '__main__':
    try:
        basic_monitor_obj.report_module_logs()
    except: pass

    try:
        basic_monitor_obj.report_daily_active()
    except: pass