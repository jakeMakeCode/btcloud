#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-
import json
import sys, os, base64, time, datetime

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
# from sqlite_server import Db
# from core.include.monitor_helpers import basic_monitor_obj, warning_obj, monitor_db_manager
# 导入 SshLoginLogsLatest
from core.include.monitor_db_manager import SshLoginLogsLatest
# 同步最新的ssh登录日志到数据库 20min一次 记录同步的时间
class update_ssh_login_logs():
    def __init__(self):

        self.PATH = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())
        # self.CUR_TIME = int(time.time())
        # self.LAST_3_MONTHS = self.CUR_TIME - (90 * 86400)

    def ssh_login_logs_latest_database(self):
        '''
            @name 初始化ssh登录日志数据库
            @return void
        '''
        # 上锁
        # with Locker.acquire(self.__LOCK):

        if not os.path.exists(self.PATH):
            # 不存在时 创建数据库
            # self.__init_ssh_login_logs_db(self.PATH)
            SshLoginLogsLatest().init_ssh_login_logs_db()

        # 存在时 更新20min内的数据
        # self.__sync_ssh_login_logs_database()
        SshLoginLogsLatest().sync_ssh_login_logs_database(False)

        # 记录同步时间
        # self.__record_sync_time(True)
        SshLoginLogsLatest().record_sync_time(True)


if __name__ == '__main__':
    s_time = time.time()
    print('ssh登录日志数据库 开始备份时间:{}'.format(time.strftime('%Y-%m-%d-%H:%M:%S')))
    # 实例化对象
    obj = update_ssh_login_logs()
    # 创建数据库
    obj.ssh_login_logs_latest_database()
    print('同步成功!!!!!')
















