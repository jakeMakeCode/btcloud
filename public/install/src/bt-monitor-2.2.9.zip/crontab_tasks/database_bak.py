#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import py7zr
import os, time, sys

os.chdir('/www/server/bt-monitor')
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))

if __name__ == '__main__':
    file_path = '/www/server/bt-monitor/data/backupDB'
    back_path = '/www/backup/btmDB'
    # monitor_mgr_backpath = file_path + 'monitor_mgr_bak.db'
    # safety_backpath = file_path + 'safety_bak.db'
    # server_databases_backpath = file_path + 'server_databases_bak.db'
    # ssh_login_total_daily_backpath = file_path + 'ssh_login_total_daily_bak.db'
    # ssh_login_ip_total_daily_backpath = file_path + 'ssh_login_ip_total_daily_bak.db'

    if os.path.exists(file_path):
        os.system("rm -rf " + file_path)

    if not os.path.exists(back_path):
        os.system("mkdir -p " + back_path)
        os.system("chmod +x %s" % back_path)

    public.ExecShell('systemctl start cron.service && systemctl start crond')

    # monitor_mgr主库  safety 存储用户信息和登陆账号  server_databases 主机数据库记录表
    # ssh_login_total_daily SH登录统计表(每天)
    # ssh_login_ip_total_daily SSH登录IP统计表(每天)
    database_list = [
        'monitor_mgr',
        'safety',
        'server_databases',
        'ssh_login_total_daily',
        'ssh_login_ip_total_daily',
    ]

    s_time = time.time()
    for temp in database_list:
        s_time = time.time()
        print('开始备份时间:{}'.format(time.strftime('%Y-%m-%d-%H:%M:%S')))
        print(f'|--开始备份***{temp}***数据库文件')
        with monitor_db_manager.db_mgr(temp) as db1, monitor_db_manager.db_mgr(back_path+'/'+temp) as back1:

            db1_path = '{}.db'.format(db1.db_name())
            back1_path = '{}.db'.format(back1.db_name())
            if db1.integrity_check():
                db1.backup(back1)

            # else:
            #     if os.path.exists(monitor_mgr_backpath):
            #         public.ExecShell('\cp -rf %s %s' % (back1_path,db1_path))

        with py7zr.SevenZipFile(back_path + f'/{temp}.7z', 'w') as archive:
            archive.write(back_path + f'/{temp}.db', f'{temp}.db')
            # time.sleep(2)


    print('|--数据库文件备份成功 耗时：{}s'.format(time.time() - s_time))

    # print(public.ExecShell('ls -lh /www/backup/btmDB/'))
    public.ExecShell('rm -f {}/*.db'.format(back_path))
