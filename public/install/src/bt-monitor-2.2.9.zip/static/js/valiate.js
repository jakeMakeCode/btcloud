import{M as r}from"./windi.js";const o=o=>(s,i)=>!r(i)||new Error(o);export{o as v};
