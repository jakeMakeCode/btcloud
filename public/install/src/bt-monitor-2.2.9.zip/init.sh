#!/bin/bash
# chkconfig: 2345 55 25
# description: bt-monitor Service

### BEGIN INIT INFO
# Provides:          bt-monitor
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: starts bt-monitor
# Description:       starts the bt-monitor
### END INIT INFO

setup_path="/www"
python_bin=$setup_path/server/bt-monitor/pyenv/bin/python3.7
install_path=/www/server/bt-monitor
run_bin=/www/server/bt-monitor/BT-MONITOR
sqlite_server_sh=/www/server/bt-monitor/sqlite-server.sh
monitor_version="1.0.0"
cd $install_path

get_pids(){
    monitor_pid=$(ps aux|grep BT-MONITOR|grep -v grep|awk '{print $2}')
}

get_monitor_version() {
  monitor_version=$(cat ${install_path}/version.pl)
}

update_monitor() {
  if [[ ! $update_version =~ ^(1\.0\.([4-9]|[1-9][0-9]+)|1\.[1-9][0-9]*\.[0-9]+|([2-9]|[1-9][0-9]+)\.[0-9]+\.[0-9]+)$ ]]; then
    return
  fi

  if [[ -f "${install_path}/data/patch-1.0.4" ]]; then
    return
  fi

  if [[ -f "${install_path}/update/update_btmonitor.sh" ]]; then
      bash ${install_path}/update/update_btmonitor.sh update_py
      touch ${install_path}/data/patch-1.0.4
  fi
}

monitor_start()
{
    get_pids
    get_monitor_version
    update_monitor
    if [ -f "$sqlite_server_sh" ]; then
        chmod +x $sqlite_server_sh
        $sqlite_server_sh start_ex
    fi
    #ls -l $install_path/logs/
    #如果"$sqlite_server_sh"存在，"$install_path/logs/sqlite_server.sock"文件不存在时执行$sqlite_server_sh restart
    if [ -f "$sqlite_server_sh" ] && [ ! -e "$install_path/logs/sqlite_server.sock" ]; then
        echo "$install_path/logs/sqlite_server.sock does not exist. restarting btm_sqlite_server"
        chmod +x $sqlite_server_sh
        $sqlite_server_sh restart
    fi
    if [ "$monitor_pid" != "" ]; then
        echo -e "Starting Bt-Monitor... Bt-Monitor (pid $monitor_pid) already running"
    else
        echo -e "Starting Bt-Monitor...\c"
        chmod 700 $run_bin
        if [ ! -d "$install_path/logs" ]; then
            mkdir -p $install_path/logs
            touch $install_path/logs/error.log
        fi
        nohup $python_bin $run_bin >> $install_path/logs/error.log 2>&1 &
        sleep 1
        get_pids
        if [ "$monitor_pid" == "" ]; then
            echo -e "   \033[31mfailed\033[0m"
            exit 1
        else
            echo -e "	\033[32mdone\033[0m"
        fi
    fi
}

monitor_stop()
{
        echo -e "Stopping Bt-Monitor...\c";
        get_pids
        if [ "$monitor_pid" != "" ]; then
            kill -9 $monitor_pid
        fi
        echo -e "	\033[32mdone\033[0m"
        # echo "Waiting Stop BT-SQLITE-SERVER in 30 seconds..."
        # sleep 30
        # chmod +x $sqlite_server_sh
        # $sqlite_server_sh stop
}

monitor_status()
{
    get_pids
    $sqlite_server_sh status
    if [ "$monitor_pid" != "" ]; then
        echo -e "\033[32mBt-Monitor (pid "$monitor_pid") is running\033[0m"
    else
        echo -e "\033[31mBt-Monitor is not running\033[0m"
    fi
}

monitor_reload()
{
    monitor_stop
    monitor_start
}

monitor_resetpass(){
    chmod +x $install_path/tools.py
    echo "正在重置随机密码..."
    $install_path/tools.py reset_pwd
}

monitor_resetpass_static(){
    chmod +x $install_path/tools.py
    echo ""
    echo "=================================="
    read -p "请输入新管理员密码(最少8位):" n_input
    $install_path/tools.py reset_pwd $n_input
}

monitor_reset_adminpath(){
    chmod +x $install_path/tools.py
    echo ""
    echo "=================================="
    read -p "请输入新安全入口(最少8位):" n_input
    $install_path/tools.py adminpath $n_input
}

monitor_resetserver_port(){
    chmod +x $install_path/tools.py
    echo ""
    echo "=================================="
    read -p "请输入新云监控端口(建议9000-65535):" n_input
    $install_path/tools.py server_port $n_input
}

monitor_basic_auth_0(){
    echo "正在关闭basic_auth..."
    chmod +x $install_path/tools.py
    $install_path/tools.py basic_auth 0
}

monitor_accept_ip_0(){
    echo "正在取消IP绑定限制..."
    chmod +x $install_path/tools.py
    $install_path/tools.py accept_ip 0
}

monitor_accept_domain_0(){
    echo "正在取消域名绑定..."
    chmod +x $install_path/tools.py
    $install_path/tools.py accept_domain 0
}

monitor_two_step_auth_0(){
    echo "正在关闭动态口令认证..."
    chmod +x $install_path/tools.py
    $install_path/tools.py two_step_auth 0
}

monitor_fix(){
    echo "正在修复并升级云监控到最新版本..."
    sleep 1
    curl http://www.example.com/install/update_btmonitor.sh|bash
}

monitor_fixplus(){
    curl http://www.example.com/tools/btm_check.sh|bash
}

Get_Ip_Address(){
	getIpAddress=""
	getIpAddress=$(curl -sS --connect-timeout 10 -m 60 http://www.example.com/api/getIpAddress)
	if [ -z "${getIpAddress}" ] || [ "${getIpAddress}" = "0.0.0.0" ]; then
		isHosts=$(cat /etc/hosts|grep 'www.bt.cn')
		if [ -z "${isHosts}" ];then
			echo "" >> /etc/hosts
			echo "116.213.43.206 www.bt.cn" >> /etc/hosts
			getIpAddress=$(curl -sS --connect-timeout 10 -m 60 http://www.example.com/api/getIpAddress)
			if [ -z "${getIpAddress}" ];then
				sed -i "/bt.cn/d" /etc/hosts
			fi
		fi
	fi

	ipv4Check=$($python_bin -c "import re; print(re.match('^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$','${getIpAddress}'))")
	if [ "${ipv4Check}" == "None" ];then
		ipv6Address=$(echo ${getIpAddress}|tr -d "[]")
		ipv6Check=$($python_bin -c "import re; print(re.match('^([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}$','${ipv6Address}'))")
		if [ "${ipv6Check}" == "None" ]; then
			getIpAddress="SERVER_IP"
		else
			echo "True" > ${setup_path}/server/bt-monitor/data/ipv6.pl
		fi
	fi

	if [ "${getIpAddress}" != "SERVER_IP" ];then
		echo "${getIpAddress}" > ${setup_path}/server/bt-monitor/data/iplist.txt
	fi
	LOCAL_IP=$(ip addr | grep -E -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -E -v "^127\.|^255\.|^0\." | head -n 1)
}

cat_errlog(){
    tail -n 100 $install_path/logs/error.log
}

btm_default(){
    getIpAddress=""
    accept_domain=$(cat $install_path/config/config.json |awk -F '\"accept_domain\"' '{print $2}'|awk -F ":" '{print $2}'|awk -F '"' '{print $2}')
    if [ ! -z $accept_domain ]; then
        getIpAddress=$accept_domain
    else
        Get_Ip_Address
    fi
    c_path=$(cat $install_path/config/config.json |awk -F '\"admin_path\"' '{print $2}'|awk -F ":" '{print $2}'|awk -F '"' '{print $2}')
    adminpath=$(echo $c_path|awk -F ',' '{print $1}')
    c_port=$(cat $install_path/config/config.json |awk -F '\"port\"' '{print $2}'|awk -F ":" '{print $2}'|awk -F '"' '{print $1}')
    panelPort=$(echo $c_port|awk -F ',' '{print $1}')

echo -e "=================================================================="
echo -e "\033[33m以下是云安全监控登录地址!\033[0m"
echo -e "=================================================================="
echo  "外网访问地址: https://${getIpAddress}:${panelPort}${adminpath}"
echo  "内网访问地址: https://${LOCAL_IP}:${panelPort}${adminpath}"
#echo -e "username: admin"
echo -e "username: `$python_bin $install_path/tools.py admin_username`"
echo -e "password: ***********************"
echo -e "\033[33m如果您忘记了密码，请执行btm 6重置随机密码或btm 8手动重置密码\033[0m"
echo -e "\033[33m若无法访问云安全监控，请检查防火墙/安全组是否有放行[${panelPort}]端口\033[0m"
echo -e "=================================================================="
}

case "$1" in
    start)
        monitor_start
        ;;
    stop | 3)
        monitor_stop
        ;;
    restart | 1)
        monitor_stop
        sleep 1
        monitor_start
        ;;
    status | 4)
        monitor_status
        ;;
    reload)
        monitor_reload
        ;;
    resetpass | 6)
        monitor_resetpass
        ;;
    default | 2)
        Get_Ip_Address
        btm_default
        ;;
    logs | 5)
        cat_errlog
        ;;
    7)
        monitor_basic_auth_0
        monitor_reload
        ;;
    8 )
        monitor_resetpass_static
        ;;

    9)
        monitor_accept_domain_0
        monitor_reload
        ;;
    10)
        monitor_reset_adminpath
        ;;
    11)
        monitor_accept_ip_0
        monitor_reload
        ;;

    12 )
        monitor_resetserver_port
        ;;
    13 )
        monitor_fix
        ;;
    14 )
        monitor_fixplus
        ;;
    15 )
        monitor_two_step_auth_0
        ;;
    *)
        echo "==================云安全监控命令行======================"
        echo "1) 重启主控服务       2) 查看登录地址及安全入口"
        echo "3) 停止主控服务       4) 查看运行状态"
        echo "5) 查看错误日志       6) 修改管理员密码(自动生成随机密码)"
        echo "7) 关闭basic_auth     8) 修改管理员密码(手动输入密码)"
        echo "9) 取消域名绑定       10) 修改安全入口(手动输入)"
        echo "11) 取消IP绑定限制    12) 修改端口(手动输入)"
        echo "13) 修复主控(检查错误并更新云安全监控到最新版)"
        echo "14) 无法访问?(云安全监控故障检测自动修复程序-超强力版)"
        echo "15) 关闭动态口令认证"
        echo "0) 退出或按组合键[ctrl+c]"
        echo "====================================================== "
        read -p "请输入对应数字进行命令行操作[0-15]:" input
        case ${input} in
        1)
            monitor_stop
            sleep 1
            monitor_start
            ;;
        2)
            Get_Ip_Address
            btm_default
            ;;
        3)
            monitor_stop
            ;;
        4)
            monitor_status
            ;;
        5)
            cat_errlog
            ;;
        6)
            monitor_resetpass
            ;;
        7)
            monitor_basic_auth_0
            monitor_reload
            ;;
        8)
            monitor_resetpass_static
            ;;
        9)
            monitor_accept_domain_0
            monitor_reload
            ;;
        10)
            monitor_reset_adminpath
            ;;
        11)
            monitor_accept_ip_0
            monitor_reload
            ;;
        12)
            monitor_resetserver_port
            ;;
        13)
            monitor_fix
            ;;
        14)
            monitor_fixplus
            ;;
        15)
            monitor_two_step_auth_0
            ;;
        0)
            exit
            ;;
        *)
            echo "未正确选择选项，请重新输入!"
            exit
            ;;
        esac
        ;;
esac
