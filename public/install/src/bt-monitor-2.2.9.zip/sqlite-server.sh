#!/bin/bash

install_path=/www/server/bt-monitor
run_bin=$install_path/BT-SQLITE-SERVER
cd $install_path

get_pid() {
  sqlite_server_pid=$(ps aux |grep BT-SQLITE-SERVER |grep -v grep |awk '{print $2}')
}

start_sqlite_server() {
  get_pid
  if [ "$sqlite_server_pid" != "" ]; then
    echo -e "Starting BT-SQLITE-SERVER... BT-SQLITE-SERVER (pid $sqlite_server_pid) already running"
  else
    echo -e "Starting BT-SQLITE-SERVER...\c"
    chmod +x $run_bin
    if [[ ! -f "${install_path}/logs/sqlite_server.log" ]]; then
        mkdir -p ${install_path}/logs
        touch $install_path/logs/sqlite_server.log
    fi
    nohup $run_bin >> $install_path/logs/sqlite_server.log 2>&1 &
    sleep 3
    get_pid
    if [ "$sqlite_server_pid" == "" ]; then
        echo -e "   \033[31mfailed\033[0m"
    else
        echo -e "	\033[32mdone\033[0m"
    fi
  fi
}

stop_sqlite_server() {
  echo -e "Stopping BT-SQLITE-SERVER...\c"
  get_pid
  if [ "$sqlite_server_pid" != "" ]; then
      kill -9 $sqlite_server_pid
      pkill -9 BT-SQLITE-SERVER
  fi
  rm -f $install_path/logs/sqlite_server*.sock
  echo -e "	\033[32mdone\033[0m"
}

restart_sqlite_server() {
  stop_sqlite_server
  sleep 1
  start_sqlite_server
}

sqlite_server_status() {
  get_pid
  if [ "$sqlite_server_pid" != "" ]; then
      echo -e "\033[32mBT-SQLITE-SERVER... BT-SQLITE-SERVER (pid $sqlite_server_pid) is running\033[0m"
  else
      echo -e "\033[31mBT-SQLITE-SERVER is not running\033[0m"
  fi
}

case "$1" in
  start)
    start_sqlite_server
    ;;
  stop)
    stop_sqlite_server
    ;;
  restart | reload)
    restart_sqlite_server
    ;;
  status)
    sqlite_server_status
    ;;
  start_ex)
    get_pid
    if [ "$sqlite_server_pid" != "" ]; then
      echo -e "BT-SQLITE-SERVER(pid $sqlite_server_pid) already running"
    else
        start_sqlite_server
    fi
    ;;
esac