import json,time,re,os
import core.include.public as public
from flask import abort, send_file


class main:

    plugin_path = '{}/plugin'.format(public.get_panel_path())

    def get_plugin_list(self,args):
        '''
            @name 获取插件列表
            @author hwliang
            @param args <dict> 参数
            @return list
        '''
        plugin_list = []
        for plugin_name in os.listdir(self.plugin_path):
            if plugin_name.startswith('.'):
                continue

            _info_file = '{}/{}/info.json'.format(self.plugin_path,plugin_name)
            if not os.path.exists(_info_file): continue
            _main_file = '{}/{}/main.py'.format(self.plugin_path,plugin_name)
            try:
                _info = json.loads(public.readFile(_info_file))
            except:
                continue
            _index_file = '{}/{}/index.html'.format(self.plugin_path,plugin_name)
            _info['is_main'] = os.path.exists(_main_file)
            _info['is_html'] = os.path.exists(_index_file)

            plugin_list.append(_info)

        return public.return_data(True,plugin_list)

    def get_plugin_info(self,args):
        '''
            @name 获取插件信息
            @author hwliang
            @param name <str> 插件名称
            @return dict
        '''
        plugin_name = args.get('name/xss','')
        if not plugin_name:
            return public.return_data(False,'插件名称不能为空!')

        _info_file = '{}/{}/info.json'.format(self.plugin_path,plugin_name)
        if not os.path.exists(_info_file):
            return public.return_data(False,'插件不存在!')
        try:
            _info = json.loads(public.readFile(_info_file))
        except:
            return public.return_data(False,'插件信息错误!')
        _main_file = '{}/{}/main.py'.format(self.plugin_path,plugin_name)
        _index_file = '{}/{}/index.html'.format(self.plugin_path,plugin_name)
        _info['is_main'] = os.path.exists(_main_file)
        _info['is_html'] = os.path.exists(_index_file)
        return public.return_data(True,_info)



    def get_plugin_html(self,args):
        '''
            @name 获取插件页面
            @author hwliang
            @param name <str> 插件名称
            @return str
        '''
        plugin_name = args.get('name/xss','')
        if not plugin_name:
            return public.return_data(False,'插件名称不能为空!')

        _index_file = '{}/{}/index.html'.format(self.plugin_path,plugin_name)
        if not os.path.exists(_index_file):
            return public.return_data(False,'指定插件没有HTML模板!')
        cache_time = 0 if public.is_debug() else 86400
        return send_file(_index_file,
                    add_etags = True,
                    conditional = True,
                    cache_timeout = cache_time)


    def static(self,args):
        '''
            @name 获取插件静态资源
            @author hwliang
            @param name <str> 插件名称
            @param file <str> 静态资源路径 如：js/index.js
            @return str
        '''
        plugin_name = args.get('name/xss','')
        static_file = args.get('file/s','')
        if not public.path_safe_check(static_file) or not public.path_safe_check(plugin_name):
            return public.return_data(False,'错误的参数格式!')

        if not plugin_name:
            return public.return_data(False,'插件名称不能为空!')

        _index_file = '{}/{}/static/{}'.format(self.plugin_path,plugin_name,static_file)
        if not os.path.exists(_index_file):
            return abort(404)

        cache_time = 0 if public.is_debug() else 86400
        return send_file(_index_file,
                    add_etags = True,
                    conditional = True,
                    cache_timeout = cache_time)

