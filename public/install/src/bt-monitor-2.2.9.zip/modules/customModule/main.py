# encoding: utf-8
import json, os, sys, re, time, random, copy
from core import g
import core.include.public as public
import core.include.Locker as Locker
from core.include.monitor_helpers import basic_monitor_obj, warning_obj
from core.include.monitor_exceptions import BtMonitorException
import core.include.monitor_enums as monitor_enums
import core.include.pymmh3 as mmh3
from concurrent.futures import ThreadPoolExecutor

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))


class main():
    '''
        @name 云监控自定义监控模块
        @author lt<2023-05-06>
    '''

    # 服务器列表 去掉未授权 离线
    def get_server_list(self, args):
        '''
            @name 获取主机列表(简易数据)
            @author Zhj<2023-01-10>
            @param args<dict> 请求参数列表
            @return dict
        '''
        server_authorized = g.get("server_list", [])

        if not server_authorized:
            return public.success({
                'total': 0,
                'list': [],
            })

        group_id = args.get('group_id', None)

        query = basic_monitor_obj.db_easy('servers s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .left_join('server_warning_template_package_merge m', 's.sid=m.sid') \
            .left_join('warning_template_packages p', 'm.package_id=p.id') \
            .left_join('server_details sys', 's.sid = sys.sid') \
            .where_in('s.sid', server_authorized) \
            .where('s.is_authorized', 1) \
            .where('s.status', 1) \
            .where('s.type', 0) \
            .order('s.sid', 'desc') \
            .field('s.sid', 'sg.name as group_name', 's.ip', 's.remark', 's.is_authorized', 's.status',
                   'ifnull(p.name, \'\') as cur_template', 's.type', 'sys.host_info')

        # query['host_info'] = json.loads(query['host_info'])

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        def query_hander(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('s.remark like ? OR s.ip like ?', (k, k,))

        public.add_retrieve_keyword_query(query, args, query_hander)

        ret = public.simple_page(query, args)

        for item in ret['list']:
            # 更新主机状态
            _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
            item['host_info'] = json.loads(item['host_info'])
            item['agent_version'] = basic_monitor_obj.get_agent_version_with_sid(item['sid'])

        return public.success(ret)

    def add_process(self, args):
        '''
            @name 添加进程监控
            @author lt<2023-05-10>
            @arg    json_data<list>         json_data
            @arg    sid<str>                sid
            @arg    sub_type<str>           proc_[进程名称|启动命令]
            @arg    push_methods<str>       推送配置: 钉钉 飞书
            @arg    scores<str>             规则参数 告警级别
            @arg    watch_target<str>      规则参数
            @arg    watch_type<str>        规则参数

            @return dict
        '''

        # public.print_log('添加', _level='error')
        try:
            json_data = args.get('json_data/json', None)
            sid = args.get('sid', None)
            sub_type = args.get('sub_type', None)
            push_methods = args.get('push_methods', None)
            scores = args.get('scores', None)
            watch_target = args.get('watch_target', None)
            watch_type = args.get('watch_type', None)

        except Exception as e:
            return public.return_error(str(e))
        if sid is None or sub_type is None:
            return public.return_error('缺少参数：sid or sub_type')

        proc_name, boot_command = sub_type.split('[')[1].split(']')[0].split('|')
        # public.print_log('proc_name::{}   boot_command::{}'.format(proc_name, boot_command), _level='error')

        pne_id = warning_obj.get_pne_id(proc_name, boot_command)

        # 任务重复性检测
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 存在 不添加
            if db.query().name('custom_process').where('pne_id', pne_id).where('sid', sid).exists():
                return public.return_error('进程任务已存在')

        # 主机信息
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', sid) \
            .find()

        servers = server_info['remark'] if server_info['remark'] else server_info['ip']
        title = '自定义进程监控-{}-{}'.format(servers, proc_name)
        # scripts = []
        rule_lst = []
        center_add = []

        # 固定数据
        rule_data_ = {
            "type": "service",
            "content": "",
            "duration": 0,
            'add_source': 1,  # 添加来源
        }

        # 进程信息
        rule_data_.update(
            {
                "sid": int(sid),
                "sub_type": sub_type,
                "push_methods": push_methods,
                "scores": int(scores),
                "watch_type": int(watch_type),
                "title": title,
                "watch_target": watch_target,
            }
        )

        watch_value_ = {0: 'deactive', 1: 'active'}
        is_push = 0
        for i in json_data:
            # 是否推送
            push_ = i['is_push']
            if push_ == 1:
                is_push = 1

            script = i['script']
            # 脚本合法性
            if script != '':
                if basic_monitor_obj.is_sensitive_command(script):
                    return public.return_error('脚本包含危险命令')
                    # public.print_log('脚本非法', _level='error')

            # 规则
            rule = {
                'is_push': i['is_push'],
                'watch_value': watch_value_[i['push_condition']],
            }
            # 中间表
            center = {
                'is_push': i['is_push'],
                'push_condition': i['push_condition'],
                'script': script,
                # pro_id  rule_id
            }

            center_add.append(copy.deepcopy(center))

            # 拷贝固定数据
            d = copy.deepcopy(rule_data_)
            rule.update(d)
            rule_lst.append(rule)
        # public.print_log('~~~~~~~~~~~~~center_add:{}'.format(center_add),_level='error')

        # 验证告警规则是否合法
        rule_add = []
        rule_err = []
        for rule in rule_lst:
            ok, err_msg = warning_obj.check_rule(rule)
            if ok:
                rule_add.append(rule)
            else:
                rule_err.append(err_msg)
                # public.print_log('!!!!!!!!!!!!!!!rule_err: {}'.format(err_msg), _level='error')
        # public.print_log('!!!!!!!!!!!!!!!rule_add: {}'.format(rule_add), _level='error')
        if len(rule_add) > 0:
            # 添加告警规则
            with monitor_db_manager.db_mgr() as db:
                # 告警规则重复性检测  有重复多个的情况 去掉重复的

                try:
                    # 关闭事务自动提交
                    db.autocommit(False)
                    for i, j in enumerate(rule_add):
                        rule_id = db.query() \
                            .name('warning_configurations') \
                            .insert(j)

                        center_add[i]['rule_id'] = rule_id

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()
                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    return public.error('规则添加失败')

        with monitor_db_manager.db_mgr('custom_process') as db:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 添加进程监控
                pro_id = db.query() \
                    .name('custom_process') \
                    .insert({
                    'pne_id': pne_id,
                    'sid': sid,
                    'is_push': is_push,
                    'push_methods': push_methods,
                    'create_time': int(time.time()),
                })
                # 中间表数据
                if len(center_add) > 0:
                    for i in center_add:
                        i['pro_id'] = pro_id

                    # 添加中间表
                    db.query() \
                        .name('custom_process_rule_script') \
                        .insert_all(center_add)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        # 记录日志
        public.WriteLog('自定义监控进程',
                        '监控【%s（%s）】下的进程【%s】' % (server_info['ip'], server_info['remark'], proc_name))
        return public.success('操作成功')

    # 获取进程信息
    def get_processes_list(self, args):
        """进程监控列表
        @author lt<2023-05-10>
        Args:
            args (dict_obj): 查询参数对象
                p<?integer>             分页页码[可选 默认1]
                p_size<?integer>        分页大小[可选 默认20]
        """
        # sid = args.get('sid', None)
        # query_date = args.get('query_date', None)
        process_name = args.get('process_name', None)

        with monitor_db_manager.db_mgr('custom_process') as db:
            process = db.query().name('custom_process').select()
            pro_isd = [i['id'] for i in process]
            # 中间表信息   .field('sum(`script`!="") AS `num_script`', 'sum(`rule_id`>0) AS `num_rule_id`', 'is_push', 'pro_id') \

            center_info = db.query().name('custom_process_rule_script') \
                .where_in('pro_id', pro_isd) \
                .field('sum(`script`!="") AS `num_script`', 'pro_id', 'script') \
                .group('pro_id') \
                .column(None, 'pro_id')
        for i in process:
            i['info'] = center_info[i['id']]
            # public.print_log('======进程监控列表======{}'.format(process), _level='error')

        if len(process) == 0:
            return public.return_data(True, {'total': 0, 'data': []})
        pne_ids_ = [i['pne_id'] for i in process]
        sids = list(set([i['sid'] for i in process]))

        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        procs_raw = basic_monitor_obj.db_memory('processes') \
            .field(
            'id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user',
            'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes',
            'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes', 'create_time',
            'update_time', 'boot_time',
        ) \
            .where_in('pne_id', pne_ids_) \
            .select()

        procs = {}
        for item in procs_raw:
            procs['{}_{}'.format(item['sid'], item['pne_id'])] = item

        # public.print_log('======进程数据 ====={}::{}'.format(query, len(query)), _level='error')

        # 查询进程基本信息
        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', pne_ids_) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        # 重组进程监控数据
        proc_info = {}
        for item in process:
            p_item = procs.get('{}_{}'.format(item['sid'], item['pne_id']), None)

            if not p_item:
                continue

            p_item.update(
                basic_monitor_obj.cache_realtime_proc_info(p_item['id']))

            pne = pnes.get(int(p_item['pne_id']), {})
            p_item['name'] = pne.get('name', '')
            p_item['boot_command'] = pne.get('exe', '')

            # 进程监控信息
            p_item['pro_id'] = item.get('info', {}).get('pro_id', None)
            p_item['run_time'] = int(time.time()) - p_item['boot_time']
            p_item['proc_status'] = 1 if p_item.get('update_time', 0) > int(time.time()) - 300 else 0

            proc_info[p_item['pro_id']] = p_item

        # public.print_log('======进程数据33 ====={}::{}'.format(proc_info, len(proc_info)), _level='error')
        # public.print_log('======进程数据22 ====={}::{}'.format(query, len(query)), _level='error')

        for p in process:
            # public.print_log('======当前sid======{}'.format(p['sid']), _level='error')
            server_ = server_info.get(p['sid'], {})
            p['server_info'] = {'ip': server_.get('ip', ''), 'remark': server_.get('remark', '')}
            p['is_script'] = p.get('info', {}).get('num_script', None)
            p['script'] = p.get('info', {}).get('script', None)
            p['is_warning'] = p.get('is_push', 0)
            p['info'] = proc_info.get(p['id'], {})  # 进程监控信息
            p['name'] = p['info'].get('name', '')
            p['boot_command'] = p['info'].get('boot_command', '')
            p['proc_status'] = p['info'].get('proc_status', 0)

        if process_name:
            proc_s = []
            # 不区分大小写
            for i in process:
                if process_name.lower() in i['name'].lower():
                    proc_s.append(i)
            process = proc_s

        # 列表排序
        for sort_key, sort_reverse in public.get_sort_params(args).items():
            process.sort(key=lambda x: x.get('info', {}).get(sort_key, 0), reverse=sort_reverse)

        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(process),
            'list': process[(p - 1) * p_size:p * p_size],
        })

    # 终止进程执行脚本
    # def execute_process_task(self, args=None):
    #     '''
    #         @name 执行进程监控任务
    #         @author Law Lt <2023-02-24>
    #         @arg    p<integer>      分页页码
    #         @arg    p_size<integer> 分页大小
    #         @arg    keyword<string> 关键字
    #         @return dict
    #     '''
    #     insert_data = []
    #
    #     process_all = self.get_processes_list(args)
    #     # 选择proc_status为0 且is_script为1的进程 执行脚本
    #     process_list = [i for i in process_all['list'] if i['proc_status'] == 0 and i['is_script'] == 1]
    #
    #
    #
    #     with ThreadPoolExecutor(max_workers=100) as t:
    #         ts = []
    #
    #         for temp in script_list:
    #             f = t.submit(self.__script_task_help, temp)
    #             ts.append(f)
    #
    #         for f in ts:
    #             res = f.result()
    #
    #             if not res:
    #                 continue
    #
    #             if 'insert_data' in res:
    #                 insert_data.append(res['insert_data'])
    #             # else:
    #             #     insert_data.extend(res)
    #
    #     # public.print_log('??? insert_data:{} count:{} '.format(insert_data, len(insert_data)), _level='error')
    #     # 记录http监控结果  写入信息表
    #     if len(insert_data) > 0:
    #         with monitor_db_manager.db_mgr('custom_script') as db:
    #             # 关闭事务自动提交
    #             db.autocommit(False)
    #
    #             db.query() \
    #                 .name("custom_script_result") \
    #                 .insert_all(insert_data)
    #
    #             # 提交事务
    #             db.commit()
    #
    #     return True

    # 获取关联表 列表
    def get_custom_process(self, args):
        '''
            @name   获取进程监控 关联表
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
        '''

        pro_id = args.get('pro_id', None)
        if not pro_id:
            return public.return_error('缺少参数 pro_id')

        center_data = []
        script = None
        rule_ids = []
        scores = None
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 进程监控
            cusproc_info = db.query() \
                .name('custom_process') \
                .where('id=?', int(pro_id)) \
                .find()

            # 中间表
            center = db.query() \
                .name('custom_process_rule_script') \
                .where('pro_id=?', int(pro_id)) \
                .select()
        if not cusproc_info:
            data = {
            }

            return public.success(data)
        if center:
            # 拿中间表 数据 规则id 执行条件
            d = {0: '终止时通知', 1: '恢复时通知'}
            for item in center:
                center_data.append({
                    'push_condition': d[item['push_condition']],
                    'center_id': item['id'],
                    'is_push': item['is_push'],
                })

                if item['rule_id']:
                    rule_ids.append(item['rule_id'])
                if item['script'] != '':
                    # if item['push_condition'] == 0:
                    script = item['script']
                    # public.print_log('YYYYYYYYYYYYYYYYYscript::{}'.format(script), _level='error')
        if rule_ids:
            with monitor_db_manager.db_mgr() as db:
                rule_infos = db.query() \
                    .name('warning_configurations') \
                    .field('scores') \
                    .where_in('id', rule_ids) \
                    .select()

            scores = rule_infos[0]['scores'] if rule_infos else None
        # public.print_log('进程监控获取::{}'.format(cusproc_info), _level='error')
        proc_info = basic_monitor_obj.db_easy('process_name_exe') \
            .where('id', cusproc_info['pne_id']) \
            .field('id', 'name', 'exe') \
            .find()

        proc_name = proc_info['name'] + '|' + proc_info['exe']
        data = {
            'sid': cusproc_info['sid'],
            'pro_id': cusproc_info['id'],
            'proc_name': proc_name,
            'script_deactive': script,
            'center_data': center_data,
            'is_push': cusproc_info['is_push'],
            'push_methods': cusproc_info['push_methods'],
            'scores': scores,
        }

        return public.success(data)

    # 修改监控配置 脚本 规则
    def update_custom_process(self, args):
        '''
            @name 修改进程监控
            @author lt<2023-05-10>
            @arg    json_data<list>         json_data
            @arg    pro_id<list>           监控任务id
            @arg    push_methods<list>     推送通道
            @arg    scores<list>           告警级别
            @arg    is_push<list>          是否推送

            @return dict
        '''
        # public.print_log('修改', _level='error')
        try:
            json_data = args.get('json_data/json', None)
            pro_id = args.get('pro_id', None)
            push_methods = args.get('push_methods', None)
            scores = args.get('scores', None)
            is_push = args.get('is_push', None)
        except Exception as e:
            return public.return_error(str(e))
        if pro_id is None or push_methods is None or scores is None or is_push is None or json_data is None:
            return public.return_error('缺少参数')
        # 进程监控
        custom_proc = {
            'is_push': is_push,
            'push_methods': push_methods
        }
        # public.print_log('进程监控修改::{}'.format(custom_proc), _level='error')

        with monitor_db_manager.db_mgr('custom_process') as db, monitor_db_manager.db_mgr() as dbr:

            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 添加进程监控
                db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .update(custom_proc)

                pro_info = db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .find()

                # 中间表
                for item in json_data:
                    # 脚本合法性
                    if item['script'] != '' and item['script'] is not None:
                        if basic_monitor_obj.is_sensitive_command(item['script']):
                            return public.return_error('脚本存在危险命令')

                    db.query() \
                        .name('custom_process_rule_script') \
                        .where('id=?', int(item['center_id'])) \
                        .update({
                        'is_push': item['is_push'],
                        'push_condition': item['push_condition'],
                        'script': item['script'],
                    })

                    # 规则id
                    rule_id = db.query() \
                        .name('custom_process_rule_script') \
                        .where('id=?', item['center_id']) \
                        .value('rule_id')

                    try:
                        # 关闭事务自动提交
                        dbr.autocommit(False)
                        # 添加告警规则
                        dbr.query() \
                            .name('warning_configurations') \
                            .where('id=?', rule_id) \
                            .update({
                            'is_push': item['is_push'],
                            'push_methods': push_methods,
                            'scores': scores,
                        })

                        # 提交事务
                        dbr.commit()
                    except BaseException as e:
                        # 回滚事务
                        dbr.rollback()
                        # 记录异常堆栈
                        public.print_exc_stack(e)

                        return public.error('修改规则失败')
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        # 记录日志

        # 主机信息
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', pro_info['sid']) \
            .find()
        # 查询进程基本信息
        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where('id', pro_info['pne_id']) \
            .field('id', 'name',) \
            .find()
        public.WriteLog('自定义监控进程',
                        '修改【%s（%s）】下的进程监控任务【%s】' % (server_info['ip'], server_info['remark'], pnes['name']))
        return public.success('修改成功')

    # 删除
    def delete_custom_process(self, args):
        '''
            @name   删除进程监控
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
            删除监控表 pro_id  中间表center_id  规则表rule_id  结果表pro_id
        '''
        pro_id = args.get('pro_id', None)
        if not pro_id:
            return public.return_error('缺少参数 pro_id')

        with monitor_db_manager.db_mgr('custom_process') as db:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 进程监控
                pro_info = db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .find()

                # 删除进程监控
                db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .delete()

                # 删除中间表
                query = db.query().name('custom_process_rule_script').where('pro_id=?', int(pro_id))
                rule_ids = query.fork().field('rule_id').column('rule_id')
                query.fork().delete()

                # 删除结果表
                db.query() \
                    .name('custom_process_script_result') \
                    .where('pro_id=?', int(pro_id)) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        # 删除规则表

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 获取告警规则
                warning_rules = db.query() \
                    .name('warning_configurations') \
                    .where_in('id', rule_ids) \
                    .field('id', 'sid', 'title', 'content', 'type', 'sub_type', 'watch_target',
                           'watch_type', 'watch_value', 'is_push', 'scores', 'push_methods', 'duration'
                           ) \
                    .select()

                # 删除告警规则
                db.query() \
                    .name('warning_configurations') \
                    .where_in('id', rule_ids) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)

        # 记录日志
        # 主机信息
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', pro_info['sid']) \
            .find()
        # 查询进程基本信息
        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where('id', pro_info['pne_id']) \
            .field('id', 'name',) \
            .find()
        public.WriteLog('自定义监控进程',
                        '删除【%s（%s）】下的进程监控任务【%s】' % (server_info['ip'], server_info['remark'], pnes['name']))

        return public.success('删除成功')


    # # 脚本执行结果
    # def get_process_script_result(self, args):
    #     '''
    #         @name   脚本执行结果
    #         @author lt<2023-05-10>
    #         @arg    pro_id<int>     进程监控表id 必填
    #         @return dict
    #     '''
    #     pro_id = args.get('pro_id', None)
    #     with monitor_db_manager.db_mgr('custom_process') as db:
    #         result = db.query() \
    #             .name('custom_process_script_result') \
    #             .where('pro_id=?', int(pro_id)) \
    #             .select()
    #
    #     return public.success(result)

    # 脚本执行结果
    def get_process_script_result(self, args):
        '''
            @name   脚本执行结果
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
        '''
        pro_id = args.get('pro_id', None)
        with monitor_db_manager.db_mgr('custom_process') as db:
            query = db.query() \
                .name('custom_process_script_result') \
                .where('pro_id=?', int(pro_id)) \
                .order('create_time', 'desc') \
                .limit(100)\
                .select()

        # 分页
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(query),
            'list': query[(p - 1) * p_size:p * p_size],
        })


    def get_rule_info(self, args):
        pro_id = args.get('pro_id', None)
        rule_ids = []
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 进程监控
            cusproc_info = db.query() \
                .name('custom_process') \
                .where('id=?', int(pro_id)) \
                .order('create_time', 'desc') \
                .find()

            # query = db.query() \
            #     .name('custom_process_rule_script') \
            #     .alias('center') \
            #     .join('custom_process_script_result as res', 'center.id=res.center_id', 'left') \
            #     .field('center.script as script','res.create_time as create_time',
            #            'result', 'err_msg', 'status') \
            #     .where('center.pro_id=?', int(pro_id)) \
            #     .where('center.script!=?', '') \
            #     .order('res.create_time', 'desc') \
            #     .select()

            # 中间表
            result = db.query() \
                .name('custom_process_rule_script') \
                .where('pro_id=?', int(pro_id)) \
                .select()

        rule_ids = [i['rule_id'] for i in result]
        # public.print_log('$$$$$$$$$${}'.format(rule_ids), _level='error')
        # 添加告警规则
        with monitor_db_manager.db_mgr() as db:
            rule_info = db.query() \
                .name('warning_configurations') \
                .where_in('id', rule_ids) \
                .select()

        dsta = {
            'cusproc_info': cusproc_info,
            'rule_info': rule_info,
            'center': result
        }

        return public.success(dsta)

    #  脚本监控-----------------------------------
    # 添加脚本监控
    def add_custom_script(self, args):
        '''
            @name 添加脚本监控
            @author lt<2023-05-22>
            @arg    sid<str>                sid
            @arg    name<str>               任务名
            @arg    frequency<int>          检测频率  20s
            @arg    script<str>             脚本命令
            @arg    condition<int>          推送条件      0不匹配时推送   1匹配时推送
            @arg    push_methods<str>       推送方式      'dingding,weixin'
            @arg    is_push<int>            是否推送
            @arg    result_type<int>        脚本结果类型判定  1字符串   0 数值
            @arg    result_match<int>       匹配方式   result_match 12345  单选
            @arg    result_key<str>         返回结果关键词  多个,隔开
            @arg    suspend<int>            暂停1   运行中0

            result_match = {
                1: "字符串 包含",
                2: "字符串 不包含",
                3: "数值 大于",
                4: "数值 小于",
                5: "数值 等于"
            }
            @return dict
        '''
        # uid = public.bt_auth('uid')
        frequency = int(args.get('frequency', 20))  # 频率 20s
        alarm_frequency = int(args.get('alarm_frequency', 600))  # 告警频率
        condition = int(args.get('condition', 1))  # 推送条件  0不匹配时推送   1匹配时推送
        is_push = int(args.get('is_push', 1))  # 是否推送 1推送 0不推送
        result_type = int(args.get('result_type', 1))  # 脚本结果类型判定  1字符串   0 数值
        result_match = int(args.get('result_match', 1))  # 匹配方式   result_match 12345  单选
        # suspend = int(args.get('suspend', 1))           # 0执行 1暂停

        sid = args.get('sid', None)  # 服务器
        name = args.get('name', None)  # 脚本监控名
        script = args.get('script', None)  # 脚本命令
        push_methods = args.get('push_methods', None)  # 推送方式
        result_key = args.get('result_key', None)  # 返回结果关键词  多个,隔开

        # 必填项检查    sid 任务名 脚本  推送方式 返回结果关键词
        if sid == '' or not sid or name == '' or not name or script == '' or not script or result_key == '' or not result_key:
            return public.error('必填项不能为空')
        if is_push == 1 and (push_methods == '' or not push_methods):
            return public.error('请选择推送方式')

        # 检查脚本是否合法
        if basic_monitor_obj.is_sensitive_command(script):
            return public.return_error('脚本存在危险命令')

        # 判断匹配方式是否合法
        if result_type == 1 and result_match not in [1, 2]:
            return public.return_error('匹配方式与结果类型不匹配')
        if result_type == 0 and result_match not in [3, 4, 5]:
            return public.return_error('匹配方式与结果类型不匹配')

        # 判断关键词是否合法
        if result_type == 1 and not isinstance(result_key, str):
            return public.return_error('关键词与结果类型不匹配')
        if result_type == 0 and not public.is_number(result_key):
            return public.return_error('关键词与结果类型不匹配')

        # 任务重复性检测
        with monitor_db_manager.db_mgr('custom_script') as db:
            # 存在 不添加
            if db.query().name('custom_script').where('name=?', name).where('sid=?', sid).exists():
                return public.return_error('脚本任务已存在')
            else:
                add_data = {
                    'sid': sid,
                    'name': name,
                    'frequency': frequency,
                    'alarm_frequency': alarm_frequency,
                    'script': script,
                    'condition': condition,
                    'push_methods': push_methods,
                    'is_push': is_push,
                    'result_type': result_type,
                    'result_match': result_match,
                    'result_key': result_key,
                    'suspend': 0,
                    'create_time': int(time.time())
                }
                # 关闭事务自动提交
                db.autocommit(False)
                try:
                    # 添加脚本监控
                    script_id = db.query() \
                        .name('custom_script') \
                        .insert(add_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
        # 记录日志
        # 主机信息
        server_info = self.__get_server_info(sid)
        public.WriteLog('自定义监控脚本',
                        '【%s（%s）】添加脚本监控任务【%s】' % (server_info['ip'], server_info['remark'], name))
        return public.success('操作成功')

    # 删除脚本监控
    def delete_custom_script(self, args):
        '''
            @name   删除脚本监控
            @author lt<2023-05-23>
            @arg    id<int>     脚本监控表id 必填
            @return dict
        '''
        id_ = args.get('id', None)
        if id_ == '' or not id_:
            return public.error('id不能为空')
        with monitor_db_manager.db_mgr('custom_script') as db:
            # 获取脚本监控信息
            script_info = db.query() \
                .name('custom_script') \
                .where('id', id_) \
                .find()

            # 删除脚本监控
            db.query() \
                .name('custom_script') \
                .where('id', id_) \
                .delete()
            # 删除脚本监控结果
            db.query() \
                .name('custom_script_result') \
                .where('script_id', id_) \
                .delete()

        # 记录日志
        server_info = self.__get_server_info(script_info['sid'])
        public.WriteLog('自定义监控脚本',
                        '删除【%s（%s）】下的脚本监控任务【%s】' % (
                        server_info['ip'], server_info['remark'], script_info['name']))

        return public.success('删除成功')

    # 获取脚本监控信息
    def get_custom_script_info(self, args):
        '''
            @name   获取脚本监控信息
            @author lt<2023-05-23>
            @arg    id<int>     脚本监控表id 必填
            @return dict
        '''
        id_ = args.get('id', None)
        if id_ == '' or not id_:
            return public.error('id不能为空')
        with monitor_db_manager.db_mgr('custom_script') as db:
            # 获取脚本监控信息
            script_info = db.query() \
                .name('custom_script') \
                .where('id', id_) \
                .find()
            # 获取服务器信息
            server_info = warning_obj.db_easy('servers') \
                .field('ip', 'remark') \
                .where('sid', script_info['sid']) \
                .find()
            script_info['server_info'] = server_info
            return public.success(script_info)

    # 修改脚本监控
    def update_custom_script(self, args):
        '''
            @name 修改脚本监控
            @author lt<2023-05-22>
            @arg    id<int>                 监控任务id
            @arg    frequency<int>          检测频率  20s
            @arg    script<str>             脚本命令
            @arg    condition<int>          推送条件      0不匹配时推送   1匹配时推送
            @arg    push_methods<str>       推送方式      'dingding,weixin'
            @arg    is_push<int>            是否推送
            @arg    result_type<int>        脚本结果类型判定  1字符串   0 数值
            @arg    result_match<int>       匹配方式   result_match 12345  单选
            @arg    result_key<str>         返回结果关键词  多个,隔开
            @arg    suspend<int>            暂停1   运行中0

            result_match = {
                1: "字符串 包含",
                2: "字符串 不包含",
                3: "数值 大于",
                4: "数值 小于",
                5: "数值 等于"
            }
            @return dict
        '''
        id_ = args.get('id', None)  # 监控任务id
        sid = args.get('sid', None)
        if id_ == '' or not id_:
            return public.error('任务id不能为空')
        if sid == '' or not sid:
            return public.error('sid不能为空')

        new_data = {}
        dicts = {}

        with monitor_db_manager.db_mgr('custom_script') as db:
            # 原数据
            old = db.query().name('custom_script').where('id', id_).find()

        # if "name" in args:
        #     ta_name = args.get('name')
        #     # 修改了任务名
        #     if old['name'] != ta_name:
        #         # 修改后的任务名在当前用户数据库是否有重名
        #         if db.query().name('custom_script') \
        #                 .where("sid=? AND name=?", [sid, ta_name]) \
        #                 .exists():
        #             return public.error('任务名已存在')
        #         new_data["task_name"] = ta_name
        #         dicts['任务名修改为'] = ta_name

        if "script" in args:
            new_data["script"] = args.get('script')
            # 检查脚本是否合法
            if basic_monitor_obj.is_sensitive_command(new_data["script"]):
                return public.return_error('脚本存在危险命令')

            if old['script'] != new_data["script"]:
                dicts['脚本修改为'] = new_data["script"]

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'
        if "is_push" in args:
            new_data["is_push"] = int(args.get('is_push'))

        if 'push_methods' in args:
            new_data["push_methods"] = args.get('push_methods')

        if "result_key" in args:
            new_data["result_key"] = args.get('result_key')
            if old['result_key'] != new_data["result_key"]:
                dicts['结果关键词修改为'] = new_data["result_key"]

        if "result_type" in args:
            new_data["result_type"] = int(args.get('result_type'))

        if "result_match" in args:
            new_data["result_match"] = int(args.get('result_match'))

        # 判断匹配方式是否合法
        if new_data.get('result_type', None) is not None and new_data.get('result_match', None) is not None:
            if new_data["result_type"] == 1 and new_data["result_match"] not in [1, 2]:
                return public.return_error('匹配方式不合法')
            if new_data["result_type"] == 0 and new_data["result_match"] not in [3, 4, 5]:
                return public.return_error('匹配方式不合法')

        # 判断关键词是否合法
        if new_data.get('result_key', None) is not None and new_data.get('result_type', None) is not None:
            if new_data["result_type"] == 1 and not isinstance(new_data["result_key"], str):
                return public.return_error('关键词与结果类型不匹配')
            if new_data["result_type"] == 0 and not public.is_number(new_data["result_key"]):
                return public.return_error('关键词与结果类型不匹配')

        if old['result_type'] != new_data["result_type"] or old['result_match'] != new_data["result_match"]:
            types = {0: '数值', 1: '字符串'}
            match = {1: '包含', 2: '不包含', 3: '大于', 4: '小于', 5: '等于'}
            result_key = new_data["result_key"] if new_data["result_key"] else old['result_key']
            dicts['匹配方式修改为'] = types[new_data["result_type"]] + match[new_data["result_match"]] + result_key

        if "frequency" in args:
            new_data["frequency"] = int(args.get('frequency'))

        if "condition" in args:
            new_data["condition"] = int(args.get('condition'))
            if old['condition'] != new_data["condition"]:
                dicts['推送条件修改为'] = '匹配时推送' if new_data["condition"] == 1 else '不匹配时推送'



        if "alarm_frequency" in args:
            new_data["alarm_frequency"] = int(args.get('alarm_frequency'))

        if len(new_data) > 0:
            new_data["update_time"] = int(time.time())
        with monitor_db_manager.db_mgr('custom_script') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('custom_script') \
                    .where("id=?", id_) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        # 记录日志

        server_info = self.__get_server_info(sid)

        if dicts:
            public.WriteLog('自定义监控脚本', '修改【%s（%s）】下的监控任务【%s】成功!  %s' % (
            server_info['ip'], server_info['remark'], old['name'], dicts))
        else:
            public.WriteLog('自定义监控脚本', '修改【%s（%s）】下的监控任务【%s】成功! ' % (
            server_info['ip'], server_info['remark'], old['name'],))

        return public.success('修改脚本监控任务成功')

    # 批量暂停 暂停
    def suspend_task(self, args):
        '''
        @name 批量暂停监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        # 转换为数字列表
        id_list = [int(i) for i in ids.split(',')]


        with monitor_db_manager.db_mgr('custom_script') as db:
            sup = db.query() \
                .name('custom_script') \
                .where_in("id", id_list) \
                .field('id', 'suspend') \
                .column('suspend', 'id')

            try:
                # 关闭事务自动提交
                db.autocommit(False)
                for i, j in sup.items():
                    db.query() \
                        .name('custom_script') \
                        .where("id=?", i) \
                        .update({"suspend":  1 if j == 0 else 0})
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        return public.success('切换状态成功')

    # 获取脚本监控列表 & 最近一次执行结果  查询参数 搜索 分页
    def get_custom_script_list(self, args):
        '''
            @name   获取脚本监控列表
            @author lt<2023-05-23>
            @arg    id<int>     脚本监控表id 必填
            @return dict
        '''

        keyword = args.get('keyword', None)
        with monitor_db_manager.db_mgr('custom_script') as db:
            # 查询脚本监控列表
            query = db.query() \
                .name('custom_script') \
                .order('update_time', 'desc')

            # 搜索
            if keyword is not None:
                query.where(
                    'name like ? or script like ?or result_type like ?or result_match like ? or result_key like ?',
                    ['%{}%'.format(keyword), '%{}%'.format(keyword), '%{}%'.format(keyword), '%{}%'.format(
                        keyword), '%{}%'.format(keyword)])

            # 组装数据
            data = query.select()

            script_ids = [i['id'] for i in data]
            sids = [i['sid'] for i in data]
            server_info = warning_obj.db_easy('servers') \
                .field('ip', 'remark', 'sid') \
                .where_in('sid', sids) \
                .column(None, 'sid')

            # 当天开始时间
            day = time.strftime('%Y-%m-%d 00:00:00', time.localtime())
            # 转为数字时间戳
            day = int(time.mktime(time.strptime(day, "%Y-%m-%d %H:%M:%S")))

            # 当天告警次数
            res1 = db.query() \
                .name('custom_script_result') \
                .where_in('script_id', script_ids) \
                .where('create_time >= ?', day) \
                .field('sum(`is_warning`=1) AS `num_warning`', 'script_id', 'max(`id`) as `max_id`') \
                .group('script_id') \
                .column(None, 'script_id')

            # public.print_log('$$$$$$$$$$  res1--------   {}'.format(res1), _level='error')
            latest_result_map = db.query() \
                .name('custom_script_result') \
                .where_in('id', list(map(lambda x: x['max_id'], res1.values()))) \
                .field('script_id', 'result')\
                .column('result', 'script_id')

        for i in data:
            server_ = server_info.get(i['sid'], {})
            i['server_info'] = {'ip': server_.get('ip', ''), 'remark': server_.get('remark', '')}
            i['latest_result'] = latest_result_map.get(i['id'], '')
            i['num_warning'] = res1.get(i['id'], {}).get('num_warning', 0)
        # public.print_log('$$$$$$$$$$  data-----   {}'.format(data), _level='error')
        # 分页
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(data),
            'list': data[(p - 1) * p_size:p * p_size],
        })

    # 获取脚本执行结果 全部 分页
    def get_custom_script_result(self, args):
        '''
            @name   获取脚本执行结果
            @author lt<2023-05-23>
            @arg    id<int>     脚本监控表id 必填
            @arg    p<int>     脚本监控表id 必填
            @arg    p_size<int>     脚本监控表id 必填
            @return dict
        '''
        id_ = args.get('id', None)  # 监控任务id
        if id_ == '' or not id_:
            return public.error('任务id不能为空')
        with monitor_db_manager.db_mgr('custom_script') as db:
            query = db.query().name('custom_script_result') \
                .where('script_id', id_) \
                .order('create_time', 'desc')\
                .limit(100)\
                .select()

            # result = public.simple_page(query, args)
            # return public.success(result)
            # 分页
            p = int(args.get('p', 1))
            p_size = int(args.get('p_size', 20))
            return public.success({
                'total': len(query),
                'list': query[(p - 1) * p_size:p * p_size],
            })

    # 执行脚本任务
    def __script_task_help(self, temp):
        cur_time = int(time.time())
        table_name = 'bt_custom_script_result'
        cache_key = 'CUSTOM_SCRIPT_TASK_LATEST_EXECUTE_TIME_{}__{}'.format(table_name, temp['id'])
        # 获取最近一次执行时间
        ret = public.cache_get(cache_key)
        if not ret:  # 缓存不存在 从数据库获取
            with monitor_db_manager.db_mgr('custom_script') as db:
                sub_query = db.query() \
                    .name('custom_script_result') \
                    .where('script_id', temp['id']) \
                    .field('max(id)') \
                    .build_sql(True)
                ret = db.query() \
                          .name('custom_script_result') \
                          .where('`id` = {}'.format(sub_query)) \
                          .value('create_time') or 0

            public.cache_set(cache_key, ret, 600)

        if cur_time <= temp['frequency'] + ret:
            return None

        # 执行脚本
        if temp['script'] == '':
            return None
        else:
            res, err_msg = basic_monitor_obj.exec_shell_with_agent(temp['sid'], temp['script'])
            # public.print_log('HHHHHHHHHHHHHHHHHHHHHHHHHHHH任务:{} 执行脚本:{} res:{} err_msg:{} '.format(temp['name'],
            #                                                                                              temp['script'],
            #                                                                                              res, err_msg),
            #                  _level='error')
            exe_time = int(time.time())

            # res = '' if res is None else res.replace('\n', '')
            # 缓存执行完的时间
            public.cache_set(cache_key, exe_time, 600)
            # 记录执行脚本日志
            status_ = '成功' if err_msg is None else '失败'
            public.WriteLog('自定义监控脚本',
                            '脚本任务【%s】 执行 %s 结果:【%s】  err_msg: %s' % (temp['name'], status_, res, err_msg))
            # 缓存执行完的时间
            public.cache_set(cache_key, exe_time, 600)

            # 脚本执行失败 退出
            if res is None or res == '':
                result_dict = {
                    'script_id': temp['id'],
                    'result': '',
                    'status': 0,
                    'err_msg': '' if err_msg is None else str(err_msg),
                    'is_warning': 0,
                    'create_time': exe_time
                }
                rest = {'insert_data': result_dict}
                return rest

        # 告警推送
        flag = True     # 是否匹配条件
        ok = 0          # 是否满足告警
        is_check = 1    # 数据是否合法
        is_warning = 0  # 告警后标记
        res = res.strip()
        if temp['is_push']:
            warning_type = '脚本监控告警'
            notify_content = ''
            # 告警时间间隔
            if temp['last_warning_time'] == 0 or int(temp['last_warning_time'] + temp['alarm_frequency']) < int(
                    time.time()):

                #  字符串
                if temp['result_type'] == 1:
                    key_list = temp['result_key'].split(',')
                    if temp['result_match'] not in [1, 2]:   # 字符串不在包含和不包含中 校验失败
                        is_check = 0
                        # public.WriteLog('自定义监控脚本', '脚本结果类型匹配失败 应返回字符串 结果返回:【%s】' % (res))
                    # 判断结果是否包含
                    for key in key_list:
                        if str(res).find(key) > -1:  # 包含
                            flag = True if temp['result_match'] == 1 else False
                            break
                        else:  # 不包含
                            flag = True if temp['result_match'] == 2 else False

                else:  # 数值
                    key_int = int(temp['result_key'])
                    if temp['result_match'] not in [3, 4, 5]:
                        # 跳过告警
                        is_check = 0
                    # 判断结果是否是数字  -- 进入判断
                    if public.is_number(res):
                        # 判断结果是否符合条件
                        # 大于
                        if temp['result_match'] == 3:
                            flag = True if float(res) > float(key_int) else False
                        # 小于
                        elif temp['result_match'] == 4:
                            flag = True if float(res) < float(key_int) else False
                        # 等于
                        elif temp['result_match'] == 5:
                            flag = True if float(res) == float(key_int) else False
                    else:  # 不匹配跳过告警
                        # public.WriteLog('自定义监控脚本', '脚本结果类型匹配失败 应返回数值 结果返回:【%s】' % (res))
                        # 跳过告警
                        is_check = 0

                # 判断是否告警 匹配 or 不匹配
                if temp['condition'] == 0:  # 不匹配推送
                    ok = 1 if flag is False else 0
                else:  # 匹配推送
                    ok = 1 if flag is True else 0

                if ok == 1 and is_check == 1:
                    # public.print_log(f'$$$$$$$$$$$$$$$$$-------满足告警条件 进行告警-----$$$$$$$$$$$$$$$$$$$$$$$$')
                    # 服务器信息
                    server_info = self.__get_server_info(temp['sid'])
                    pipw = {0: '不匹配', 1: '匹配'}
                    gvze = {1: '包含', 2: '不包含', 3: '大于', 4: '小于', 5: '等于'}
                    lwxk = {0: '数值', 1: '字符串'}

                    matching_condition = '{}{}【{}】'.format(lwxk[temp['result_type']], gvze[temp['result_match']], temp['result_key'])
                    notify_content = '执行结果与关键字【{}】 {} '.format(temp['result_key'], pipw[temp['condition']])
                    times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))

                    option = {'mail_title': f'自定义监控-脚本告警: {server_info["ip"]},{temp["name"]}'}

                    send_msg = [
                        f'> 告警类型：{warning_type}',
                        f'> 推送时间: {times}',
                        f'> 服务器: {server_info["ip"]}（{server_info["remark"]}）',
                        f'> 告警任务名: {temp["name"]}',
                        f'> 匹配条件: {matching_condition}',
                        '> 告警消息：[{}]:{}'.format(temp["name"], notify_content),
                        '',
                        '请尽快处理',
                    ]

                    warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','),options=option)
                    is_warning = 1
                    # 更新上一次告警时间
                    with monitor_db_manager.db_mgr('custom_script') as db:
                        db.query() \
                            .name('custom_script') \
                            .where('id', temp['id']) \
                            .update({'last_warning_time': cur_time})

        result_dict = {
            'script_id': temp['id'],
            'result': res,
            # 'result': '' if res is None else res.replace('\n', ''),
            'status': 1 if err_msg is None else 0,
            'err_msg': '' if err_msg is None else str(err_msg),
            'is_warning': is_warning,
            'create_time': exe_time
        }
        rest = {'insert_data': result_dict}

        return rest

    # 执行脚本任务
    def execute_script_task(self, args=None):
        '''
            @name 执行脚本监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        with monitor_db_manager.db_mgr('custom_script') as db:
            # 获取检测监控列表          未暂停
            script_list = db.query().name('custom_script') \
                .where('suspend=?', 0) \
                .order('create_time', 'desc') \
                .select()

        insert_data = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in script_list:
                f = t.submit(self.__script_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.append(res['insert_data'])
                # else:
                #     insert_data.extend(res)

        # public.print_log('??? insert_data:{} count:{} '.format(insert_data, len(insert_data)), _level='error')
        # 记录http监控结果  写入信息表
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('custom_script') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("custom_script_result") \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

        return True

    # # 判断对象是否为数值 整形 浮点型
    # def __is_number(self, s):
    #     pattern = re.compile(r'^(-?\d+)(\.\d+)?$')
    #     return pattern.match(str(s)) is not None

    # 获取主机信息
    def __get_server_info(self, sid):
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', sid) \
            .find()
        return server_info

