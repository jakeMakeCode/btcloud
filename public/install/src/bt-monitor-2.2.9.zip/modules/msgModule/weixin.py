
from distutils.log import info
from importlib.resources import path
import json,time,re,os,requests
import core.include.public as public
from flask import Response,request
import core.include.c_loader.PluginLoader as plugin_loader


main = plugin_loader.get_module('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main

# from modules.msgModule.main import main
"""
@name 微信消息通道模块 
@author cjxin@bt.cn
"""

class weixin(main):

    __info = None
    __msg_type = 'weixin'
    
    def __init__(self):               
        self.__info = self.get_config(None)

  
    def get_config(self,get = None):
        """
        @name 获取配置
        @author cjxin
        """                      
        return self._get_base_config(self.__msg_type)

    def set_config(self,get):
        """
        @name 设置配置
        @author cjxin
        """
        if not hasattr(get, 'url') or not hasattr(get, 'atall'): 
            return self._return_data(False, '配置失败，请填写完整信息!')

        import re
        rule = re.compile(r'^https?://')
        if not re.match(rule, get.url):
            return self._return_data(self.__msg_type, False, '未正确配置信息。')

        data = {"weixin_url": get.get('url/s'), "isAtAll": True, "user":1 }

        test_data = {
            "msgtype": "markdown",
            "markdown": {
                "content": '''您正在宝塔云安全监控进行告警通知测试操作，如非您本人操作，请忽略此消息。\n若您收到此消息，证明您的配置正确，且可以正常收发消息。'''
            }
        }

        headers = {'Content-Type': 'application/json'}
        try:
            x = requests.post(url=get.get('url/s'), data=json.dumps(test_data), headers=headers, verify=False, timeout=3)
            if x.json()["errcode"] == 0:
                return self._set_base_config(self.__msg_type, data)
            else:
                return self._return_data(self.__msg_type, False, '未正确配置信息。')
        except:
            return self._return_data(self.__msg_type, False, '未正确配置信息。')


    def resetting_v1(self,get):
        """
        @name 清空企业微信配置
        @author law
        """
        data = {
            "weixin_url": '',
            "user": 0,
            "isAtAll": True,
            "title": '默认',
        }

        return self._set_base_config(self.__msg_type,data)

    def is_configured(self):
        '''
            @name 检查企业微信是否配置
            @author Zhj<2022-08-02>
            @return bool
        '''
        if self.__info is None \
                or not isinstance(self.__info, dict) \
                or 'weixin_url' not in self.__info \
                or self.__info['weixin_url'] is None \
                or self.__info['weixin_url'] == '':
            return False

        return True

    def send_msg(self,minfo):
        """
        @name 发送消息
        @author cjxin
        @minfo dict  {
            msg:string(消息内容),
        }
        """
        if not self.__info :
             return self._return_data(self.__msg_type,False,'未正确配置信息。')

        data = {
            "msgtype": "markdown",
            "markdown": {
                "content": minfo['msg']
            }
        }
        headers = {'Content-Type': 'application/json'}
        try:
            x = requests.post(url = self.__info['weixin_url'], data=json.dumps(data), headers=headers,verify=False)            
            if x.json()["errcode"] == 0:             
                return self._return_data('通知方式:【企业微信】, 收件人:【所有人】',True,'消息发送成功: {}'.format(minfo['msg']))
            else:
                return self._return_data('通知方式:【企业微信】, 收件人:【所有人】',False,'消息发送失败: {}'.format(minfo['msg']),x.json()['errmsg'])
        except:
            return self._return_data('通知方式:【企业微信】, 收件人:【所有人】',False,'消息发送失败: {}'.format(minfo['msg'])+public.get_error_info(),public.get_error_info(), need_write_log=False)


  

