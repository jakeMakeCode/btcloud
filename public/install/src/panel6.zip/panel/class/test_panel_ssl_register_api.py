# coding: utf-8
import ast
import importlib.util
import json
import os
import sys
import types
import unittest


CLASS_DIR = os.path.dirname(os.path.abspath(__file__))
MODULE_PATH = os.path.join(CLASS_DIR, "panelSSL.py")
ROUTE_MODULE_PATH = os.path.join(os.path.dirname(CLASS_DIR), "BTPanel", "__init__.py")


class Args(dict):
    def __getattr__(self, item):
        return self[item]


def load_panel_ssl_module():
    public = types.ModuleType("public")
    public.GetConfigValue = lambda name: "https://www.bt.cn"
    public.returnMsg = lambda status, msg: {"status": status, "msg": msg}
    public.written_files = []
    public.flush_count = 0
    public.writeFile = lambda path, content: public.written_files.append((path, content))

    def flush_plugin_list():
        public.flush_count += 1

    public.flush_plugin_list = flush_plugin_list
    sys.modules["public"] = public

    bt_panel = types.ModuleType("BTPanel")
    bt_panel.cache = None
    bt_panel.session = {}
    sys.modules["BTPanel"] = bt_panel

    panel_auth = types.ModuleType("panelAuth")

    class PanelAuth:
        def get_serverid(self):
            return "test-server-id"

    panel_auth.panelAuth = PanelAuth
    sys.modules["panelAuth"] = panel_auth

    ssl_manage = types.ModuleType("ssl_manage")
    ssl_manage.SSLManger = object
    sys.modules["ssl_manage"] = ssl_manage

    spec = importlib.util.spec_from_file_location("panel_ssl_register_api", MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


panel_ssl_module = load_panel_ssl_module()


class TestPanelSSL(panel_ssl_module.panelSSL):
    def __init__(self):
        self.requests = []
        self.response = {"success": True, "res": "操作成功", "nonce": 1722662400}

    def request_post(self, url, params):
        self.requests.append((url, params))
        return self.response

    def get_suppliers_source(self):
        return "test-source"


class PanelSSLRegisterApiTest(unittest.TestCase):
    def setUp(self):
        self.panel_ssl = TestPanelSSL()
        panel_ssl_module.public.written_files = []
        panel_ssl_module.public.flush_count = 0
        panel_ssl_module.session.clear()

    def assert_forwarded(self, method_name, args, expected_path, expected_params):
        result = getattr(self.panel_ssl, method_name)(Args(args))

        self.assertEqual({"status": True, "msg": "操作成功"}, result)
        self.assertEqual(
            [("http://www.example.com/api/v3" + expected_path, expected_params)],
            self.panel_ssl.requests,
        )

    def test_check_username_forwards_username(self):
        self.assert_forwarded(
            "CheckUsername",
            {"username": "13800138000", "ignored": "value"},
            "/user/check_username",
            {"username": "13800138000"},
        )

    def test_send_register_sms_verification_forwards_username(self):
        self.assert_forwarded(
            "SendRegisterSmsVerification",
            {"username": "13800138000"},
            "/user/register_sms_verification/send",
            {"username": "13800138000"},
        )

    def test_register_panel_user_adds_metadata_and_saves_credentials(self):
        token_info = {
            "uid": 123,
            "username": "13800138000",
            "address": "127.0.0.1",
            "access_key": "access-key",
            "secret_key": "secret-key",
            "ukey": "user-key",
            "serverid": "new-server-id",
        }
        self.panel_ssl.response = {
            "success": True,
            "res": json.dumps(token_info).encode("utf-8").hex(),
            "nonce": 1722662400,
        }

        result = self.panel_ssl.RegisterPanelUser(Args({
            "username": "13800138000",
            "password": "secret",
            "code": "123456",
            "serverid": "untrusted-server-id",
            "o": "untrusted-source",
            "os": "untrusted-os",
        }))

        self.assertEqual({"status": True, "msg": "绑定成功"}, result)
        self.assertEqual([(
            "http://www.example.com/api/v3/user/panel/register",
            {
                "username": "13800138000",
                "password": "secret",
                "code": "123456",
                "serverid": "test-server-id",
                "o": "test-source",
                "os": "Linux",
            },
        )], self.panel_ssl.requests)
        written_files = dict(panel_ssl_module.public.written_files)
        self.assertEqual("new-server-id", written_files["data/sid.pl"])
        self.assertEqual(token_info, json.loads(written_files["data/userInfo.json"]))
        self.assertEqual(1, panel_ssl_module.public.flush_count)
        self.assertTrue(panel_ssl_module.session["focre_cloud"])

    def test_official_api_failure_is_converted_without_saving_credentials(self):
        self.panel_ssl.response = {
            "success": False,
            "res": "验证码错误",
            "nonce": 1722662400,
        }

        result = self.panel_ssl.RegisterPanelUser(Args({
            "username": "13800138000",
            "password": "secret",
            "code": "000000",
        }))

        self.assertEqual({"status": False, "msg": "验证码错误"}, result)
        self.assertEqual([], panel_ssl_module.public.written_files)
        self.assertEqual(0, panel_ssl_module.public.flush_count)

    def test_validate_register_sms_verification_forwards_username_and_code(self):
        self.assert_forwarded(
            "ValidateRegisterSmsVerification",
            {"username": "13800138000", "code": "123456"},
            "/user/register_sms_verification/validate",
            {"username": "13800138000", "code": "123456"},
        )

    def test_required_parameters_are_validated_before_forwarding(self):
        result = self.panel_ssl.RegisterPanelUser(
            Args({"username": "13800138000", "password": "", "code": "123456"})
        )

        self.assertFalse(result["status"])
        self.assertIn("password", result["msg"])
        self.assertEqual([], self.panel_ssl.requests)

    def test_register_apis_are_exposed_by_ssl_route(self):
        with open(ROUTE_MODULE_PATH, "r", encoding="utf-8") as route_file:
            module = ast.parse(route_file.read())

        ssl_route = next(
            node for node in module.body
            if isinstance(node, ast.FunctionDef) and node.name == "ssl"
        )
        defs_assignment = next(
            node for node in ssl_route.body
            if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == "defs" for target in node.targets)
        )
        exposed_methods = {item.value for item in defs_assignment.value.elts}

        self.assertTrue({
            "CheckUsername",
            "SendRegisterSmsVerification",
            "RegisterPanelUser",
            "ValidateRegisterSmsVerification",
        }.issubset(exposed_methods))


if __name__ == "__main__":
    unittest.main()
