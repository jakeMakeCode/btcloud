import os,sys,re,time,subprocess

panelPath = '/www/server/panel/'
os.chdir(panelPath)

sys.path.insert(0, panelPath + "class/")
import public
from datetime import date, datetime, timezone

is_openssl = True
try:
    import OpenSSL
except:
    is_openssl = False

class ssl_info:

    def __init__(self) -> None:
        pass


    def create_key(self,bits=2048):
        """
        @name 创建RSA密钥
        @param bits 密钥长度
        """
        if is_openssl:

            key = OpenSSL.crypto.PKey()
            key.generate_key(OpenSSL.crypto.TYPE_RSA, bits)
            private_key = OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, key)
            return private_key
        else:
            tmp_pk_file = "/tmp/private_key_{}.pem".format(int(time.time()))
            cmd = ["openssl", "genpkey", "-algorithm", "RSA", "-out", tmp_pk_file, "-pkeyopt", f"rsa_keygen_bits:{bits}"]
            subprocess.run(cmd, check=True)
            with open(tmp_pk_file, "r") as f:
                private_key = f.read()
            try:
                os.remove("private_key.pem")
            except:
                pass
            return private_key

    def load_ssl_info_by_data(self, pem_data: str, pwd=None):
        if not isinstance(pem_data, (str, bytes)):
            return None

        if is_openssl:
            return self.__get_cert_info(pem_data, pwd=pwd)
        else:
            result = {}
            pem_file = "/tmp/fullchain_{}.pem".format(int(time.time()))
            public.writeFile(pem_file, pem_data)
            res = public.ExecShell("openssl x509 -in {} -noout -text".format(pem_file))[0]
            issuer_match = re.search(r"Issuer: (.*)", res)
            if issuer_match:
                data = {}
                issuer = issuer_match.group(1)
                for key,val in re.findall(r"(\w+)\s*=([^,]+)", issuer):
                    data[key] = val.strip()

                result["issuer"] = data['CN']
                if "CN" in data:
                    s = data['CN'].encode().decode('unicode_escape')
                    result["issuer"] = bytes(s, 'latin1').decode('utf-8')
                result["issuer_O"] = data['O']
                if "O" in data:
                    s = data['O'].encode().decode('unicode_escape')
                    result["issuer_O"] = bytes(s, 'latin1').decode('utf-8')

            validity_match = re.search(r"Not After\s*:\s*(.*)", res)
            if validity_match:
                not_after = validity_match.group(1)
                dt_after = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                result['notAfter'] = dt_after.strftime("%Y-%m-%d %H:%M:%S")
                result['endtime'] = int((dt_after - datetime.now(timezone.utc)).total_seconds() // 86400)
            else:
                result['endtime'] = 0

            validity_match = re.search(r"Not Before\s*:\s*(.*)", res)
            if validity_match:
                not_befoer = validity_match.group(1)
                dt_befoer = datetime.strptime(not_befoer, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                result['notBefore'] = dt_befoer.strftime("%Y-%m-%d %H:%M:%S")

            subject_match = re.search(r"Subject: (.*)", res)
            if subject_match:
                subject = subject_match.group(1)
                for key,val in re.findall(r"(\w+)\s*=([^,]+)", subject):
                    if key == 'CN':
                        s = val.encode().decode('unicode_escape')
                        result["subject"] = bytes(s, 'latin1').decode('utf-8').strip()
            # 取可选名称
            result['dns'] = []
            dns_match = re.findall(r"DNS:([^\s,]+)", res)
            for dns in dns_match:
                result['dns'].append(dns)
            if os.path.exists(pem_file):
                os.remove(pem_file)
            # 只保留年月日
            result['notAfter'] = result['notAfter'][0:10]
            result['notBefore'] = result['notBefore'][0:10]
            return result

    def load_ssl_info(self,pem_file):
        """
        @name 获取证书详情
        """
        if not os.path.exists(pem_file):
            return None

        pem_data = public.readFile(pem_file)
        if not pem_data:
            return None
        return self.load_ssl_info_by_data(pem_data)

    def __get_cert_info(self, cert_data, pwd=None):
        """
        @name 解析证书信息，兼容 PEM 格式和 PFX/PKCS12 格式
        @param cert_data string/bytes 证书内容 (PEM 字符串或 PFX 二进制数据)
        @param pwd string PFX证书密码 (解析PEM时不需要传)
        """
        from cryptography import x509
        from cryptography.x509.oid import NameOID, ExtensionOID
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives.serialization import pkcs12
        import datetime

        cert = None
        try:
            # ---------------- 兼容性加载逻辑 ----------------
            # 1. 如果传入的已经是 cryptography 的原生证书对象，直接使用
            if isinstance(cert_data, x509.Certificate):
                cert = cert_data
            else:
                # 统一转为 bytes 进行处理
                if isinstance(cert_data, str):
                    # PEM 文本转 bytes
                    data_bytes = cert_data.encode('utf-8')
                else:
                    data_bytes = cert_data

                # 2. 尝试作为 PEM 格式加载
                try:
                    cert = x509.load_pem_x509_certificate(data_bytes, default_backend())
                except Exception:
                    # 3. 如果 PEM 加载失败，尝试作为 PFX/PKCS12 加载 (需要密码)
                    pwd_bytes = pwd.encode('utf-8') if isinstance(pwd, str) else (pwd or b'')

                    # load_pkcs12 返回元组：(private_key, certificate, additional_certificates)
                    key, main_cert, add_certs = pkcs12.load_pkcs12(data_bytes, pwd_bytes)
                    cert = main_cert

            if not cert:
                return None

        except Exception:
            # 密码错误、文件损坏等异常
            return None

        # ---------------- 以下为统一的证书解析逻辑 ----------------
        result = {}

        # 1. 获取签发机构
        issuer = cert.issuer
        result['issuer'] = ''
        cn_list = issuer.get_attributes_for_oid(NameOID.COMMON_NAME)
        if cn_list:
            result['issuer'] = cn_list[0].value

        if not result['issuer']:
            issuer_attrs = list(issuer)
            is_key = ['0', '0']
            if len(issuer_attrs) == 1:
                is_key = ['CN', 'CN']
            for attr in issuer_attrs:
                if attr.oid._name in is_key:
                    result['issuer'] = attr.value
                    break

        o_list = issuer.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)
        if o_list:
            result['issuer_O'] = o_list[0].value

        # 2. 获取时间
        try:
            not_after = cert.not_valid_after_utc
            not_before = cert.not_valid_before_utc
        except AttributeError:
            not_after = cert.not_valid_after
            not_before = cert.not_valid_before
        # 旧版 cryptography 返回无时区的 UTC 时间，统一补上 UTC 时区
        if not_after.tzinfo is None:
            not_after = not_after.replace(tzinfo=datetime.timezone.utc)
        if not_before.tzinfo is None:
            not_before = not_before.replace(tzinfo=datetime.timezone.utc)

        result['notAfter'] = not_after.strftime("%Y-%m-%d")
        result['notBefore'] = not_before.strftime("%Y-%m-%d")

        # 3. 获取可选名称
        result['dns'] = []
        try:
            san = cert.extensions.get_extension_for_oid(
                ExtensionOID.SUBJECT_ALTERNATIVE_NAME
            ).value

            # DNS
            for dns in san.get_values_for_type(x509.DNSName):
                if dns not in result["dns"]:
                    result["dns"].append(dns)

            # IP
            for ip in san.get_values_for_type(x509.IPAddress):
                ip = str(ip)
                if ip not in result["dns"]:
                    result["dns"].append(ip)

        except x509.ExtensionNotFound:
            pass
        except Exception:
            pass

        # 4. 获取主体名称
        subject = cert.subject
        subject_attrs = list(subject)
        subject_cn = ""
        cn_list = subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        if cn_list:
            subject_cn = cn_list[0].value

        if len(subject_attrs) == 1:
            result['subject'] = subject_attrs[0].value
        else:
            if not result['dns']:
                result['subject'] = subject_cn
                if result['subject']:
                    result['dns'].append(result['subject'])
            else:
                result['subject'] = result['dns'][0]

        # 5. 计算到期天数
        result['endtime'] = int((not_after - datetime.datetime.now(datetime.timezone.utc)).total_seconds() // 86400)

        return result

    # 转换时间
    def strf_date(self, sdate):
        # 先按 UTC 解析
        t = time.strptime(sdate, "%Y%m%d%H%M%SZ")
        # 当成 UTC 时间转为时间戳
        timestamp = time.mktime(t) - time.timezone
        # 再转为本地时间
        local_time = time.localtime(timestamp)
        return time.strftime('%Y-%m-%d', local_time)

    #转换时间
    def strfToTime(self,sdate):
        import time
        return time.strftime('%Y-%m-%d',time.strptime(sdate,'%b %d %H:%M:%S %Y %Z'))


    def dump_pkcs12_new(self, key_pem=None, cert_pem=None, ca_pem=None, friendly_name=""):
        try:
            from cryptography.hazmat.backends import default_backend
            from cryptography.hazmat.primitives import serialization
            from cryptography.x509 import load_pem_x509_certificate
            private_key = self.analysis_private_key(key_pem)
            cert = self.analysis_certificate(cert_pem)
            if not private_key or not cert:
                return None
            # 加载CA证书
            cas = None
            if ca_pem:
                cas = [load_pem_x509_certificate(ca_pem.encode(), default_backend())]
            # 将证书和私钥组合成PKCS12格式的文件
            from cryptography.hazmat.primitives.serialization.pkcs12 import serialize_key_and_certificates
            p12 = serialize_key_and_certificates(
                name=friendly_name.encode() if friendly_name else None,
                key=private_key,
                cert=cert,
                encryption_algorithm=serialization.NoEncryption(),
                cas=cas
            )
            return p12
        except:
            return None

    def analysis_private_key(self, key_pem, password=None):
        """
        解析私钥
        :param key_pem: 私钥内容
        :param password: 私钥密码
        :return: 私钥对象
        """
        try:
            from cryptography.hazmat.backends import default_backend
            from cryptography.hazmat.primitives import serialization
            private_key = serialization.load_pem_private_key(
                key_pem.encode(),
                password=password,
                backend=default_backend()
            )
            return private_key
        except:
            return None

    def analysis_certificate(self, cert_pem):
        """
        解析证书
        :param cert_pem: 证书内容
        :return: 有效返回True，无效返回False
        """
        try:
            from cryptography.hazmat.backends import default_backend
            from cryptography.x509 import load_pem_x509_certificate
            cert = load_pem_x509_certificate(cert_pem.encode(), default_backend())
            return cert
        except Exception as e:
            public.print_log(public.get_error_info())
            return None

    def verify_certificate_and_key_match(self, key_pem, cert_pem, password=None):
        """
        验证证书和私钥是否匹配(通过签名验证)
        :param key_pem: 私钥内容
        :param cert_pem: 证书内容
        :param password: 私钥密码
        :return: 验证成功返回True，失败返回False
        """
        try:
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric import padding, ec
            message = b"test message"
            private_key = self.analysis_private_key(key_pem, password)
            cert = self.analysis_certificate(cert_pem)
            if not private_key:
                return False, "密钥错误，请检查是否为正确的PEM格式私钥"
            if not cert:
                return False, "证书错误，请检查是否为正确的PEM格式证书"

            # 使用私钥对消息进行签名
            if isinstance(private_key, ec.EllipticCurvePrivateKey):
                # ECC 私钥使用 ECDSA 签名（2个参数）
                signature = private_key.sign(
                    message,
                    ec.ECDSA(hashes.SHA256())
                )
            else:
                # RSA 私钥使用 PKCS1v15 签名（3个参数）
                signature = private_key.sign(
                    message,
                    padding.PKCS1v15(),
                    hashes.SHA256()
                )

            # 使用证书中的公钥验证签名
            public_key = cert.public_key()

            try:
                if isinstance(public_key, ec.EllipticCurvePublicKey):
                    public_key.verify(
                        signature,
                        message,
                        ec.ECDSA(hashes.SHA256())
                    )
                else:
                    public_key.verify(
                        signature,
                        message,
                        padding.PKCS1v15(),
                        hashes.SHA256()
                    )
                return True, "验证成功"
            except Exception as e:
                return False, "密钥和证书不匹配。"
        except Exception as e:
            public.print_log(public.get_error_info())
            return True, str(e)

    # TODO 待完善,先不检测
    def verify_certificate_chain(self, cert_pem):
        """
        验证证书链是否完整
        :param cert_pem: 证书链内容
        :return: 验证成功返回True，失败返回False
        """
        return True, ""
        try:
            from cryptography.hazmat.primitives.asymmetric import padding, ec
            cert_chain = [(i+"-----END CERTIFICATE-----").strip() for i in cert_pem.strip().split("-----END CERTIFICATE-----") if i]

            for i in range(len(cert_chain) - 1):
                cert = self.analysis_certificate(cert_chain[i])

                issuer_cert = self.analysis_certificate(cert_chain[i + 1])

                # 验证当前证书的签名是否由上一级签发
                try:
                    issuer_public_key = issuer_cert.public_key()
                    # 检查 issuer_public_key 是否为 ECC 公钥或 RSA 公钥
                    if isinstance(issuer_public_key, ec.EllipticCurvePublicKey):
                        # 使用 ECDSA 验证 ECC 证书签名
                        issuer_public_key.verify(
                            cert.signature,
                            cert.tbs_certificate_bytes,
                            ec.ECDSA(cert.signature_hash_algorithm),
                        )
                    else:
                        # 使用 PKCS1v15 验证 RSA 证书签名
                        issuer_public_key.verify(
                            cert.signature,
                            cert.tbs_certificate_bytes,
                            padding.PKCS1v15(),
                            cert.signature_hash_algorithm,
                        )
                except Exception as e:
                    return False, "证书链验证失败，请检查证书链是否完整。"
            return True, "证书链验证成功。"
        except Exception as e:
            public.print_log(public.get_error_info())
            return True, str(e)

#class ssl:








