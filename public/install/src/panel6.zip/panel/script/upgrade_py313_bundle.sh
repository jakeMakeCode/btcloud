#!/bin/bash
#===============================================================================
# 宝塔面板Python 3.13环境升级脚本 - 通用版本
# 功能：将宝塔面板Python环境从3.7升级到3.13
#
# 三条安装路线（自动降级）:
#   Route 1: 完整包（最快，跳过pip）— cpython-*-bundle.tar.gz
#   Route 2: 基础包 + pip 安装      — cpython-*.tar.gz + pip install
#   Route 3: 源码编译（保底）       — 标准 configure，不加 PGO/LTO
#
# 用法:
#   ./deploy-python-bundle.sh                   自动模式（1→2→3）
#   ./deploy-python-bundle.sh --bundle          Route 1 固定
#   ./deploy-python-bundle.sh --basic           Route 2 固定
#   ./deploy-python-bundle.sh --compile         Route 3 固定
#   ./deploy-python-bundle.sh --prepare         仅准备，不替换环境
#   ./deploy-python-bundle.sh --replace         仅替换环境（需已准备）
#===============================================================================

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
LANG=en_US.UTF-8

# =============================================================================
# 常量定义
# =============================================================================

ROUTE_BUNDLE=1
ROUTE_BASIC=2
ROUTE_COMPILE=3

PANEL_PATH="/www/server/panel"
PYTHON_PYENV="$PANEL_PATH/pyenv"
PYTHON_PYENV_NEW="$PANEL_PATH/pyenv313"
PYTHON_VERSION="3.13.14"
PIP_REQUIREMENTS_FILE="pip313.txt"

DOWNLOAD_URL="https://download.bt.cn"
INSTALL_ROUTE=0           # 0=自动, 1=bundle, 2=basic, 3=compile
FORCE_BUNDLE=false
FORCE_BASIC=false
FORCE_COMPILE=false
USE_SOFTLINK=false
PREPARE_ONLY=false
ONLY_REPLACE=false
HAS_OLD_PANEL=true
ARCH=""
PM=""

# 颜色
RED='\033[1;31;40m'
GREEN='\033[1;32;40m'
YELLOW='\033[1;33;40m'
BLUE='\033[1;34;40m'
NC='\033[0m'

# pip 源列表
PIP_NODES=(
    https://mirrors.tencent.com/pypi/simple
    https://mirrors.aliyun.com/pypi/simple
    https://pypi.tuna.tsinghua.edu.cn/simple
    https://pypi.mirrors.ustc.edu.cn/simple
    https://pypi.org/simple
)
FASTEST_PIP_SOURCE=""

# =============================================================================
# 工具函数
# =============================================================================

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $1" >&2; }

print_separator() { echo '============================================================='; }

Red_Error() {
    echo '================================================='
    printf '\033[1;31;40m%b\033[0m\n' "$@"
    GetSysInfo
    exit 1
}

GetSysInfo() {
    if [ -s "/etc/redhat-release" ]; then
        SYS_VERSION=$(cat /etc/redhat-release)
    elif [ -s "/etc/issue" ]; then
        SYS_VERSION=$(cat /etc/issue)
    fi
    SYS_INFO=$(uname -a)
    SYS_BIT=$(getconf LONG_BIT)
    MEM_TOTAL=$(free -m | grep Mem | awk '{print $2}')
    CPU_INFO=$(getconf _NPROCESSORS_ONLN)
    echo -e "${SYS_VERSION}"
    echo -e "Bit:${SYS_BIT} Mem:${MEM_TOTAL}M Core:${CPU_INFO}"
    echo -e "${SYS_INFO}"
    echo -e "请截图以上报错信息发帖至论坛 www.bt.cn/bbs 求助"
}

version_compare() {
    local ver1=$(echo "$1" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
    local ver2=$(echo "$2" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
    [ "$ver1" -ge "$ver2" ]
}

# =============================================================================
# 参数解析
# =============================================================================

show_usage() {
    echo "宝塔面板Python 3.13环境升级脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "路线选择:"
    echo "  (默认)              自动模式：Route 1 完整包 → Route 2 基础包 → Route 3 源码编译"
    echo "  --bundle            Route 1 完整包（最快，跳过 pip，不降级）"
    echo "  --basic             Route 2 基础包 + pip 安装（不降级）"
    echo "  --compile           Route 3 源码编译（不降级）"
    echo ""
    echo "其他选项:"
    echo "  -s, --softlink      使用软链接替换环境"
    echo "  -p, --prepare       仅准备环境，不替换"
    echo "  --replace           仅替换环境（需已准备）"
    echo "  --disable-color     禁用颜色"
    echo "  -h, --help          显示此帮助"
}

parse_arguments() {
    if [ -f '/www/server/panel/data/debug.pl' ]; then
        log_error "请先关闭面板的[开发者模式]，再进行升级操作"
        exit 1
    fi
    while [[ $# -gt 0 ]]; do
        case $1 in
            --bundle)
                FORCE_BUNDLE=true; INSTALL_ROUTE=$ROUTE_BUNDLE; shift ;;
            --basic)
                FORCE_BASIC=true; INSTALL_ROUTE=$ROUTE_BASIC; shift ;;
            --compile)
                FORCE_COMPILE=true; INSTALL_ROUTE=$ROUTE_COMPILE; shift ;;
            -s|--softlink)
                USE_SOFTLINK=true; shift ;;
            -p|--prepare)
                PREPARE_ONLY=true; shift ;;
            --replace)
                ONLY_REPLACE=true; shift ;;
            --disable-color)
                NC=""; RED=""; GREEN=""; YELLOW=""; BLUE=""; shift ;;
            -h|--help)
                show_usage; exit 0 ;;
            *)
                log_error "未知参数: $1"; show_usage; exit 1 ;;
        esac
    done
}

# =============================================================================
# 系统检查
# =============================================================================

check_root() {
    if [ "$(whoami)" != "root" ]; then
        Red_Error "请使用 root 权限执行"
    fi
    log_info "Root 权限检查通过"
}

check_arch() {
    local cpu_arch=$(uname -m)
    case "$cpu_arch" in
        x86_64)     ARCH="x86_64"   ;;
        aarch64|arm64) ARCH="aarch64"   ;;
        loongarch64) ARCH="loongarch64" ;;
        *) Red_Error "不支持的架构: $cpu_arch，仅支持 x86_64 / aarch64 / loongarch64" ;;
    esac
}

check_bt_panel() {
    if [ ! -d "$PANEL_PATH" ]; then
        log_warn "未检测到宝塔面板，创建目录"
        mkdir -p "$PANEL_PATH"
        HAS_OLD_PANEL=false
    fi
    if [ ! -d "$PYTHON_PYENV" ]; then
        log_warn "未找到现有 Python 环境: $PYTHON_PYENV"
        mkdir -p "$PYTHON_PYENV"
        HAS_OLD_PANEL=false
    fi
    if [ ! -f "$PANEL_PATH/init.sh" ] || [ ! -d "$PANEL_PATH/data" ]; then
        HAS_OLD_PANEL=false
    fi
    if [ "$HAS_OLD_PANEL" = true ]; then
        log_info "宝塔面板检查通过"
    fi
}

detect_pm() {
    if [ -z "$PM" ]; then
        command -v yum >/dev/null 2>&1 && PM="yum"
        command -v apt-get >/dev/null 2>&1 && PM="apt-get"
    fi
}

# 龙芯编译器兼容：交叉编译的 Python 可能写死了 loongarch64-linux-gnu-gcc，
# 但系统上实际是 loongarch64-TencentOS-linux-gcc 等，需要创建软链接
setup_loongarch_compiler() {
    [ "$ARCH" != "loongarch64" ] && return 0

    # 如果 loongarch64-linux-gnu-gcc 已存在，无需处理
    command -v loongarch64-linux-gnu-gcc &>/dev/null && return 0

    # Python 交叉编译/构建 C 扩展时可能写死了 loongarch64-linux-gnu-gcc 名称
    # 用系统上的 gcc 创建软链接即可（实际都是同一套编译工具）
    if [ -x /usr/bin/loongarch64-TencentOS-linux-gcc ]; then
        ln -sf /usr/bin/loongarch64-TencentOS-linux-gcc /usr/bin/loongarch64-linux-gnu-gcc
        ln -sf /usr/bin/loongarch64-TencentOS-linux-g++ /usr/bin/loongarch64-linux-gnu-g++
        log_info "创建 loongarch64-linux-gnu-gcc 软链接（→ loongarch64-TencentOS-linux-gcc）"
    elif [ -x /usr/bin/gcc ]; then
        ln -sf /usr/bin/gcc /usr/bin/loongarch64-linux-gnu-gcc
        ln -sf /usr/bin/g++ /usr/bin/loongarch64-linux-gnu-g++
        log_info "创建 loongarch64-linux-gnu-gcc 软链接（→ /usr/bin/gcc）"
    else
        log_warn "未找到可用的 gcc，C 扩展编译可能失败"
        return 1
    fi
}

check_download_tool() {
    detect_pm

    if [ ! -f "/usr/bin/curl" ] && [ -n "$PM" ]; then
        $PM install curl -y
    fi
    if [ ! -f "/usr/bin/wget" ] && [ -n "$PM" ]; then
        $PM install wget -y
    fi
    if [ -f "/usr/bin/curl" ] && [ -f "/usr/bin/wget" ]; then
        log_info "下载工具检查通过"
        return 0
    fi
    Red_Error "请安装 curl 和 wget"
}

# =============================================================================
# CDN 节点选择（来源: upgrade_py313.sh 复制）
# =============================================================================

get_node_url() {
    if [ -f "/www/node.pl" ]; then
        DOWNLOAD_URL=$(cat /www/node.pl)
        log_info "Download node: $DOWNLOAD_URL"
        return 0
    fi

    log_info "选择下载节点..."
    local nodes=(
        https://dg2.bt.cn https://download.bt.cn https://ctcc1-node.bt.cn
        https://cmcc1-node.bt.cn https://ctcc2-node.bt.cn https://hk1-node.bt.cn
        https://na1-node.bt.cn https://jp1-node.bt.cn https://cf1-node.aapanel.com
    )

    local CN_CHECK=$(curl -sS --connect-timeout 10 -m 10 http://www.example.com/api/isCN 2>/dev/null)
    if [ "${CN_CHECK}" == "True" ]; then
        nodes=(https://dg2.bt.cn https://download.bt.cn https://ctcc1-node.bt.cn
               https://cmcc1-node.bt.cn https://ctcc2-node.bt.cn https://hk1-node.bt.cn)
    else
        local PING6_CHECK=$(ping6 -c 2 -W 2 download.bt.cn &>/dev/null && echo "yes" || echo "no")
        if [ "${PING6_CHECK}" == "yes" ]; then
            nodes=(https://dg2.bt.cn https://download.bt.cn https://cf1-node.aapanel.com)
        else
            nodes=(https://cf1-node.aapanel.com https://download.bt.cn https://na1-node.bt.cn
                   https://jp1-node.bt.cn https://dg2.bt.cn)
        fi
    fi

    local tmp1=/dev/shm/net_test1.pl
    local tmp2=/dev/shm/net_test2.pl
    rm -f "$tmp1" "$tmp2"
    touch "$tmp1" "$tmp2"

    for node in "${nodes[@]}"; do
        local check_url="/net_test"
        [[ "$node" == *"aapanel.com"* ]] && check_url="/1net_test"
        local NC=$(curl --connect-timeout 3 -m 3 2>/dev/null \
            -w "%{http_code} %{time_total}" "${node}${check_url}" | xargs)
        local RES=$(echo "$NC" | awk '{print $1}')
        local STATUS=$(echo "$NC" | awk '{print $2}')
        local TIME=$(echo "$NC" | awk '{print int($3 * 1000) - 500}' | cut -d '.' -f 1)

        if [ "$STATUS" == "200" ]; then
            if [ "$TIME" -lt 300 ]; then
                [ "$RES" -ge 1500 ] && echo "$RES $node" >> "$tmp1"
            else
                [ "$RES" -ge 1500 ] && echo "$TIME $node" >> "$tmp2"
            fi
            [ "$TIME" -lt 300 ] && [ "$RES" -ge 2390 ] && break
        fi
    done

    local node_url=$(sort -r -g -t " " -k 1 "$tmp1" 2>/dev/null | head -1 | awk '{print $2}')
    if [ -z "$node_url" ]; then
        node_url=$(sort -g -t " " -k 1 "$tmp2" 2>/dev/null | head -1 | awk '{print $2}')
        [ -z "$node_url" ] && node_url='https://download.bt.cn'
    fi
    rm -f "$tmp1" "$tmp2"
    DOWNLOAD_URL="$node_url"
    log_info "Download node: $DOWNLOAD_URL"
}

# =============================================================================
# 下载和解压 tarball（Route 1/2 共享）
# =============================================================================

download_and_extract_tarball() {
    local package_name="$1"
    local min_size="$2"
    local target_dir="$3"
    local local_path="/tmp/${package_name}"

    log_info "正在下载: $package_name"
    if [ ! -f "$local_path" ]; then
        local url="${DOWNLOAD_URL}/install/pyenv/${package_name}"
        if ! wget -O "$local_path" "$url" -T 30 2>/dev/null; then
            log_warn "下载失败: $url"
            rm -f "$local_path"
            return 1
        fi
    else
        log_info "使用本地缓存: $local_path"
    fi

    local file_size=$(du -b "$local_path" 2>/dev/null | awk '{print $1}')
    if [ "${file_size:-0}" -lt "$min_size" ]; then
        log_warn "文件过小，可能损坏: ${file_size:-0} < $min_size"
        rm -f "$local_path"
        return 1
    fi

    log_info "解压到临时目录..."
    local extract_temp="$(dirname "$target_dir")/extract_temp"
    rm -rf "$extract_temp" "$target_dir"
    mkdir -p "$(dirname "$target_dir")"

    if ! tar -zxf "$local_path" -C "$(dirname "$target_dir")" 2>/dev/null; then
        log_warn "解压失败"
        rm -rf "$extract_temp" "$local_path"
        return 1
    fi

    # 查找 python/ 或 pyenv/ 目录
    if [ -d "$(dirname "$target_dir")/python" ]; then
        mv "$(dirname "$target_dir")/python" "$target_dir"
    elif [ -d "$(dirname "$target_dir")/pyenv" ]; then
        mv "$(dirname "$target_dir")/pyenv" "$target_dir"
    else
        # 可能直接解压到了目标目录
        local top_items=$(ls "$(dirname "$target_dir")" | head -5)
        log_warn "未知的 tarball 结构: $top_items"
        rm -rf "$(dirname "$target_dir")/extract_temp" "$local_path"
        return 1
    fi
    rm -rf "$extract_temp"

    # 验证
    local python_bin="$target_dir/bin/python3.13"
    if [ ! -f "$python_bin" ]; then
        log_warn "未找到 bin/python3.13"
        rm -rf "$target_dir" "$local_path"
        return 1
    fi
    if ! "$python_bin" --version >/dev/null 2>&1; then
        log_warn "Python 二进制无法运行"
        rm -rf "$target_dir" "$local_path"
        return 1
    fi

    chmod -R 600 "$target_dir"
    chmod -R 700 "$target_dir/bin"
    chown -R root:root "$target_dir"
    rm -f "$local_path"
    log_info "Tarball 安装成功"
    return 0
}

# =============================================================================
# Route 1: 完整包安装（最快，跳过 pip）
# =============================================================================

install_full_bundle() {
    log_info "========================================"
    log_info "Route 1: 完整包安装（跳过 pip）"
    log_info "========================================"

    if [ "$ARCH" == "loongarch64" ]; then
        log_warn "LoongArch64 无完整包，Route 1 不可用"
        return 1
    fi

    local package="cpython-${PYTHON_VERSION}-${ARCH}-unknown-linux-gnu-bundle.tar.gz"
    download_and_extract_tarball "$package" 50000000 "$PYTHON_PYENV_NEW" || return 1
    setup_python_environment
    modify_python_shebang

    log_info "Route 1 安装完成（完全跳过 pip 安装）"
    return 0
}

# =============================================================================
# Route 2: 基础包 + pip
# =============================================================================

install_basic_bundle() {
    log_info "========================================"
    log_info "Route 2: 基础包 + pip 安装"
    log_info "========================================"

    # 安装系统编译依赖（libxml2-devel、libxslt-devel 等，龙芯上需从源码编译）
    install_system_dependencies

    local package="cpython-${PYTHON_VERSION}-${ARCH}-unknown-linux-gnu.tar.gz"
    download_and_extract_tarball "$package" 20000000 "$PYTHON_PYENV_NEW" || return 1
    setup_python_environment

    set_pip_source
    install_python_packages
    modify_python_shebang

    log_info "Route 2 安装完成"
    return 0
}

# =============================================================================
# Python 环境设置
# =============================================================================

setup_python_environment() {
    log_info "设置 Python 环境..."

    cd "$PYTHON_PYENV_NEW/bin"
    ln -sf python3.13 python3.7
    ln -sf python3.13 python3
    ln -sf python3.13 python
    ln -sf pip3 pip

    cd "$PYTHON_PYENV_NEW/lib"
    ln -sf python3.13 python3.7
    chmod -R 700 "$PYTHON_PYENV_NEW/bin"
    log_info "Python 环境设置完成"
}

modify_python_shebang() {
    log_info "修改 Python 脚本 shebang 行..."

    for file in "$PYTHON_PYENV_NEW/bin"/*; do
        if [ -f "$file" ] && [ "$(du -b "$file" 2>/dev/null | awk '{print $1}')" -lt 10240 ]; then
            if head -1 "$file" | grep -q "^#!.*python"; then
                local perm=$(stat -c "%a" "$file" 2>/dev/null || echo "755")
                local rest=$(tail -n +2 "$file")
                echo '#!/bin/sh' > "$file.tmp"
                echo "'''exec' \"\$(dirname -- \"\$(realpath -- \"\$0\")\")/python3.13\" \"\$0\" \"\$@\"" >> "$file.tmp"
                echo "' '''" >> "$file.tmp"
                echo "$rest" >> "$file.tmp"
                chmod "$perm" "$file.tmp"
                mv "$file.tmp" "$file"
            fi
        fi
    done
    log_info "Shebang 修改完成"
}

# =============================================================================
# pip 源检测（来源: upgrade_py313.sh 复制）
# =============================================================================

check_tencent_cloud_optimization() {
    if [ -f "/etc/hostname" ]; then
        local tc=$(cat /etc/hostname | grep -E "VM-[0-9]+-[0-9]+")
        if [ -n "$tc" ]; then
            log_info "检测到腾讯云，优先使用腾讯云镜像"
            PIP_NODES=(https://mirrors.tencent.com/pypi/simple https://mirrors.aliyun.com/pypi/simple
                       https://pypi.tuna.tsinghua.edu.cn/simple https://pypi.mirrors.ustc.edu.cn/simple
                       https://pypi.org/simple)
        fi
    fi
}

test_pip_source_speed() {
    curl -sS --connect-timeout 3 -m 10 -I "$1/" >/dev/null 2>&1
}

calculate_response_time() {
    local node=$1
    local start=$(date +%s.%N)
    curl -sS --connect-timeout 3 -m 10 -I "$node/" >/dev/null 2>&1
    local end=$(date +%s.%N)
    local start_s=$(echo "$start" | cut -d '.' -f 1)
    local start_ns=$(echo "$start" | cut -d '.' -f 2)
    local end_s=$(echo "$end" | cut -d '.' -f 1)
    local end_ns=$(echo "$end" | cut -d '.' -f 2)
    current_time=$(( (10#$end_s - 10#$start_s) * 1000000 + (10#$end_ns / 1000 - 10#$start_ns / 1000) ))
    current_time=$((current_time / 1000))
}

get_fastest_pip_source() {
    log_info "检测可用 pip 源..."
    local fastest_url=""
    local shortest_time=5000

    check_tencent_cloud_optimization

    for node in "${PIP_NODES[@]}"; do
        if test_pip_source_speed "$node"; then
            calculate_response_time "$node"
            local rt=$current_time
            log_info "  $node → ${rt}ms"
            if [ "$rt" -lt "$shortest_time" ]; then
                shortest_time=$rt
                fastest_url=$node
            fi
            [ "$shortest_time" -lt 50 ] && break
        else
            log_warn "  $node 超时"
        fi
    done

    if [ -z "$fastest_url" ] || [ "$shortest_time" = 5000 ]; then
        log_error "无可用 pip 源"
        FASTEST_PIP_SOURCE="False"
        return 1
    fi

    FASTEST_PIP_SOURCE="$fastest_url"
    log_info "最快 pip 源: $fastest_url (${shortest_time}ms)"
    return 0
}

get_trusted_host() {
    local url=$1
    [[ "$url" == *"aliyun"* ]]       && echo "mirrors.aliyun.com" && return
    [[ "$url" == *"tencent"* ]]      && echo "mirrors.tencent.com" && return
    [[ "$url" == *"tsinghua"* ]]     && echo "pypi.tuna.tsinghua.edu.cn" && return
    [[ "$url" == *"ustc"* ]]         && echo "pypi.mirrors.ustc.edu.cn" && return
    [[ "$url" == *"pypi.org"* ]]     && echo "pypi.org" && return
    echo "$url" | awk -F/ '{print $3}'
}

set_pip_source() {
    get_fastest_pip_source
    local pip_url="$FASTEST_PIP_SOURCE"
    if [ "$pip_url" = "False" ] || [ -z "$pip_url" ]; then
        log_warn "无法检测到可用 pip 源，跳过配置"
        return 1
    fi
    local host=$(get_trusted_host "$pip_url")

    # 确保 $HOME 可用（cron/systemd 等上下文可能未设置，导致 ~ 落错位置）
    if [ -z "$HOME" ]; then
        export HOME=$(getent passwd "$(id -un)" 2>/dev/null | cut -d: -f6)
        [ -z "$HOME" ] && export HOME=/root
        log_warn "\$HOME 未设置，已回退为: $HOME"
    fi

    # 写入用户级 pip.conf（持久化，供面板后续运行时使用）
    mkdir -p ~/.pip
    cat > ~/.pip/pip.conf << EOF
[global]
index-url = $pip_url

[install]
trusted-host = $host
EOF

    # 导出环境变量（当前会话内优先级高于配置文件，即使配置读取异常也可生效）
    export PIP_INDEX_URL="$pip_url"
    export PIP_TRUSTED_HOST="$host"

    log_info "pip 源已设置: $pip_url (pip.conf: ~/.pip/pip.conf + env: PIP_INDEX_URL/PIP_TRUSTED_HOST)"

    # 验证（pip 已存在时校验；Route 2 于 ensurepip 前调用，pip 不存在则自动跳过）
    if [ -f "$PYTHON_PYENV_NEW/bin/pip3" ]; then
        local resolved=$("$PYTHON_PYENV_NEW/bin/pip3" config get global.index-url 2>/dev/null)
        if [ -n "$resolved" ] && [ "$resolved" != "$pip_url" ]; then
            log_warn "pip 解析的 index-url 与所设不一致: $resolved（以环境变量为准）"
        else
            log_info "pip 配置验证通过: ${resolved:-未解析}"
        fi
    fi
}

# =============================================================================
# Python 包安装
# =============================================================================

install_python_packages() {
    log_info "安装 Python 3.13 所需包..."

    # 前置检查：目录必须存在
    if [ ! -d "$PYTHON_PYENV_NEW" ]; then
        Red_Error "Python 环境目录不存在: $PYTHON_PYENV_NEW"
    fi
    if [ ! -f "$PYTHON_PYENV_NEW/bin/python3.13" ]; then
        Red_Error "Python 二进制不存在: $PYTHON_PYENV_NEW/bin/python3.13"
    fi

    setup_loongarch_compiler

    cd "$PYTHON_PYENV_NEW" || Red_Error "无法进入 $PYTHON_PYENV_NEW"

    bin/python3.13 -m ensurepip || { log_warn "ensurepip 失败"; }
    bin/python3.13 -m pip install --upgrade pip || { log_warn "pip 升级失败"; }
    bin/pip install -U 'setuptools<82.0.0' || { log_warn "setuptools 升级失败"; }

    if [ -f "$PANEL_PATH/script/$PIP_REQUIREMENTS_FILE" ]; then
        log_info "使用本地包列表: $PANEL_PATH/script/$PIP_REQUIREMENTS_FILE"
        cp "$PANEL_PATH/script/$PIP_REQUIREMENTS_FILE" .
    else
        log_info "下载 Python 包列表..."
        local url="${DOWNLOAD_URL}/install/pyenv/${PIP_REQUIREMENTS_FILE}"
        if ! wget -O "$PIP_REQUIREMENTS_FILE" "$url" -T 30; then
            Red_Error "包列表下载失败: $url"
        fi
    fi

    if [ "$(uname -m)" == "loongarch64" ]; then
        bin/pip3 install cryptography cffi \
            -i https://lpypi.loongnix.cn/loongson/pypi/+simple/ --only-binary=cryptography \
            || log_warn "cryptography/cffi 安装失败"
        # Brotli 在龙芯 GCC 上有 model 属性兼容问题，跳过
        # Pillow 需 libjpeg-devel，若未安装跳过（非必需）
        if bin/pip install -r "$PIP_REQUIREMENTS_FILE"; then
            log_info "核心包安装完成"
        else
            log_warn "部分包安装失败，继续安装基础包..."
        fi
        bin/pip install psycopg2-binary 2>/dev/null || true
        bin/pip install psutil gevent flask || log_warn "基础包(psutil/gevent/flask)安装失败"
        log_info "Python 包安装完成"
        return
    fi

    if bin/pip install -r "$PIP_REQUIREMENTS_FILE"; then
        log_info "Python 包安装完成"
    else
        log_warn "部分包安装失败，但不影响基本功能"
    fi
    # psycopg2-binary 可能在部分架构上无 wheel，失败不影响
    bin/pip install psycopg2-binary 2>/dev/null || true
}

# =============================================================================
# Route 3: 源码编译
# =============================================================================

install_system_dependencies() {
    log_info "安装系统编译依赖..."
    setup_loongarch_compiler
    detect_pm

    if [ "$PM" = "yum" ]; then
        yum install -y xz-devel 2>/dev/null || true
        yum install -y gcc gcc-c++ make openssl-devel zlib-devel bzip2-devel \
            libffi-devel readline-devel sqlite-devel wget curl unzip
        # 龙芯架构多数包无预编译 wheel，需从源码编译，安装全部编译依赖
        if [ "$(uname -m)" == "loongarch64" ]; then
            yum install -y libxml2-devel libxslt-devel libcurl-devel \
                libpng-devel freetype-devel \
                postgresql-devel 2>/dev/null || yum install -y libpq-devel 2>/dev/null || true
            # libjpeg-turbo-devel 在不同龙芯发行版可能包名不同
            yum install -y libjpeg-turbo-devel 2>/dev/null || \
                yum install -y libjpeg-devel 2>/dev/null || \
                yum install -y jpeg-devel 2>/dev/null || true
        fi
    elif [ "$PM" = "apt-get" ]; then
        # 修复系统 dpkg 状态（防止因 coreutils 等未配置导致后续包无法安装）
        dpkg --configure -a 2>/dev/null || true

        apt-get update

        # --no-install-recommends：减少依赖级联，避免触发大量非必需包升级
        local _APT_OPTS="--no-install-recommends -y"

        apt-get install $_APT_OPTS liblzma-dev libncurses5-dev 2>/dev/null || true

        # 基础编译依赖（libssl-dev 单独处理，因为龙芯上可能是虚拟包）
        apt-get install $_APT_OPTS build-essential zlib1g-dev libreadline-dev \
            libsqlite3-dev libffi-dev libbz2-dev wget curl unzip

        # libssl-dev：龙芯部分发行版上为虚拟包，需尝试替代包名
        if ! apt-get install -y libssl-dev 2>/dev/null; then
            log_warn "libssl-dev 不可用，尝试替代包名..."
            apt-get install $_APT_OPTS openssl-dev 2>/dev/null || \
            apt-get install $_APT_OPTS openssl-1.1 2>/dev/null || \
            apt-get install $_APT_OPTS openssl 2>/dev/null || \
            log_warn "所有 libssl 开发包均不可用，Route 2/3 的 SSL 支持可能受限"
        fi

        # 龙芯 Debian 系列同样缺少预编译 wheel，逐个安装避免依赖冲突导致整批失败
        if [ "$(uname -m)" == "loongarch64" ]; then
            log_info "龙芯架构：逐个安装编译依赖..."
            apt-get install -f -y 2>/dev/null || true
            for _pkg in libxml2-dev libxslt1-dev libcurl4-openssl-dev; do
                apt-get install $_APT_OPTS "$_pkg" 2>/dev/null && \
                    log_info "  ✓ $_pkg" || log_warn "  ✗ $_pkg 安装失败，跳过"
            done
            for _pkg in libpng-dev libfreetype6-dev; do
                apt-get install $_APT_OPTS "$_pkg" 2>/dev/null && \
                    log_info "  ✓ $_pkg" || log_warn "  ✗ $_pkg 安装失败，跳过"
            done
            apt-get install $_APT_OPTS libjpeg62-turbo-dev 2>/dev/null || \
            apt-get install $_APT_OPTS libjpeg-dev 2>/dev/null || \
            log_warn "  libjpeg-dev 安装失败，跳过"
            apt-get install -f -y 2>/dev/null || true
        fi

        # 检查编译工具链是否可用（即使 -dev 包失败，gcc/make 仍是 Route 3 的前提）
        local _MISSING_TOOLS=""
        command -v gcc   &>/dev/null || _MISSING_TOOLS="gcc"
        command -v g++   &>/dev/null || _MISSING_TOOLS="$_MISSING_TOOLS g++"
        command -v make  &>/dev/null || _MISSING_TOOLS="$_MISSING_TOOLS make"
        if [ -n "$_MISSING_TOOLS" ]; then
            log_warn "编译工具链缺失:$_MISSING_TOOLS，Route 3 可能不可用"
        fi
    else
        log_warn "未识别的包管理器，请手动安装编译依赖"
        return 1
    fi

    log_info "系统依赖安装完成"
    return 0
}

check_dev_packages() {
    local need_openssl=false
    local need_sqlite=false

    log_info "检查系统开发库版本..."

    if command -v rpm >/dev/null 2>&1; then
        if rpm -q openssl-devel >/dev/null 2>&1; then
            local ov=$(rpm -q --queryformat '%{VERSION}' openssl-devel 2>/dev/null)
            log_info "openssl-devel: $ov"
            version_compare "$ov" "1.1.1" || need_openssl=true
        else
            need_openssl=true
        fi
        if rpm -q sqlite-devel >/dev/null 2>&1; then
            local sv=$(rpm -q --queryformat '%{VERSION}' sqlite-devel 2>/dev/null)
            log_info "sqlite-devel: $sv"
            version_compare "$sv" "3.15.2" || need_sqlite=true
        else
            need_sqlite=true
        fi
    elif command -v dpkg >/dev/null 2>&1; then
        if dpkg -l libssl-dev 2>/dev/null | grep -q "^ii"; then
            local ov=$(dpkg -l libssl-dev 2>/dev/null | grep "^ii" | awk '{print $3}' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
            [ -n "$ov" ] && log_info "libssl-dev: $ov" || need_openssl=true
            [ -n "$ov" ] && version_compare "$ov" "1.1.1" || need_openssl=true
        else
            need_openssl=true
        fi
        if dpkg -l libsqlite3-dev 2>/dev/null | grep -q "^ii"; then
            local sv=$(dpkg -l libsqlite3-dev 2>/dev/null | grep "^ii" | awk '{print $3}' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
            [ -n "$sv" ] && log_info "libsqlite3-dev: $sv" || need_sqlite=true
            [ -n "$sv" ] && version_compare "$sv" "3.15.2" || need_sqlite=true
        else
            need_sqlite=true
        fi
    else
        need_openssl=true
        need_sqlite=true
    fi

    if $need_openssl && $need_sqlite; then return 3
    elif $need_openssl; then return 1
    elif $need_sqlite; then return 2
    else return 0; fi
}

Install_Openssl111() {
    log_info "编译 OpenSSL 1.1.1w..."
    local ov="1.1.1w"
    cd /tmp
    wget "${DOWNLOAD_URL}/src/openssl-${ov}.tar.gz" -T 30 || Red_Error "OpenSSL 下载失败"
    tar -zxf "openssl-${ov}.tar.gz"
    rm -f "openssl-${ov}.tar.gz"
    cd "openssl-${ov}" || Red_Error "进入目录失败"
    ./config --prefix="$PYTHON_PYENV_NEW/openssl111w-static" enable-md2 enable-rc5 sctp zlib no-shared
    make -j$(nproc) && make install
    cd /tmp && rm -rf "openssl-${ov}"
    [ -d "$PYTHON_PYENV_NEW/openssl111w-static" ] && log_info "OpenSSL 编译成功" || Red_Error "OpenSSL 编译失败"
}

Install_Sqlite3() {
    log_info "编译 SQLite3 3.50.4..."
    cd /tmp
    wget "${DOWNLOAD_URL}/src/sqlite-src-3500400.zip" -T 30 || Red_Error "SQLite 下载失败"
    unzip -q "sqlite-src-3500400.zip"
    rm -f "sqlite-src-3500400.zip"
    cd "sqlite-src-3500400"
    ./configure --prefix="$PYTHON_PYENV_NEW/sqlite3-static" --disable-shared --enable-static \
        CFLAGS="-fPIC -DSQLITE_ENABLE_TRACE_V2 -DSQLITE_ENABLE_LOAD_EXTENSION" LDFLAGS="-lm -lz"
    make -j$(nproc) && make install
    cd /tmp && rm -rf "sqlite-src-3500400"
    [ -d "$PYTHON_PYENV_NEW/sqlite3-static" ] && log_info "SQLite 编译成功" || Red_Error "SQLite 编译失败"
}

install_from_source() {
    log_info "========================================"
    log_info "Route 3: 源码编译 Python $PYTHON_VERSION"
    log_info "========================================"

    install_system_dependencies

    rm -rf "$PYTHON_PYENV_NEW"
    mkdir -p "$PYTHON_PYENV_NEW"

    log_info "检查系统库版本..."
    check_dev_packages
    local check_result=$?

    [ $((check_result & 1)) -eq 1 ] && Install_Openssl111
    [ $((check_result & 2)) -eq 2 ] && Install_Sqlite3

    local src_path="/tmp/Python-${PYTHON_VERSION}"
    cd /tmp
    if [ ! -f "/tmp/Python-${PYTHON_VERSION}.tar.xz" ]; then
        log_info "下载 Python 源码..."
        local url="https://mirrors.aliyun.com/python-release/source/Python-${PYTHON_VERSION}.tar.xz"
        wget -O "Python-${PYTHON_VERSION}.tar.xz" "$url" -T 30 || Red_Error "源码下载失败"
    fi

    local fsize=$(du -b "Python-${PYTHON_VERSION}.tar.xz" 2>/dev/null | awk '{print $1}')
    if [ "${fsize:-0}" -lt 1000000 ]; then
        rm -f "Python-${PYTHON_VERSION}.tar.xz"
        Red_Error "源码文件损坏"
    fi

    tar -xJf "Python-${PYTHON_VERSION}.tar.xz" || Red_Error "解压失败"
    rm -f "Python-${PYTHON_VERSION}.tar.xz"
    cd "$src_path" || Red_Error "进入源码目录失败"

    log_info "配置 Python 编译环境..."
    local config_opts="--prefix=$PYTHON_PYENV_NEW"

    if [ $check_result -eq 1 ] || [ $check_result -eq 3 ]; then
        config_opts="$config_opts --with-openssl=$PYTHON_PYENV_NEW/openssl111w-static"
    fi
    if [ $check_result -eq 2 ] || [ $check_result -eq 3 ]; then
        CFLAGS="-I$PYTHON_PYENV_NEW/sqlite3-static/include $CFLAGS"
        LDFLAGS="-L$PYTHON_PYENV_NEW/sqlite3-static/lib -lsqlite3 -lz -lm $LDFLAGS"
        export CFLAGS LDFLAGS
        config_opts="$config_opts --enable-loadable-sqlite-extensions"
    fi

    ./configure $config_opts || Red_Error "Python 配置失败"

    local cpu_count=$(getconf _NPROCESSORS_ONLN)
    log_info "编译 Python（${cpu_count} 核，标准模式，无 PGO/LTO）..."
    make -j"$cpu_count" || Red_Error "Python 编译失败"
    make install || Red_Error "Python 安装失败"

    cd /tmp && rm -rf "$src_path"

    [ -f "$PYTHON_PYENV_NEW/bin/python3.13" ] || Red_Error "Python 安装验证失败"
    log_info "Python $PYTHON_VERSION 源码编译成功"
}

# =============================================================================
# 插件第三方库安装（来源: upgrade_py313.sh 复制）
# =============================================================================

declare -A PLUGIN_PACKAGES
PLUGIN_PACKAGES=(
    ["alidns"]="alibabacloud_alidns20150109 alibabacloud_tea_openapi alibabacloud_tea_util alibabacloud_sts20150401 alibabacloud_ecs20140526"
    ["alioss"]="oss2"
    ["aliyun"]="alibabacloud_swas_open20200601 alibabacloud_tea_openapi alibabacloud_tea_util aliyun-python-sdk-sts aliyun-python-sdk-core"
    ["aws_s3"]="boto3"
    ["bos"]="bce-python-sdk"
    ["bt_webhorse"]="pyahocorasick"
    ["cosfs"]="cos-python-sdk-v5"
    ["dnspod"]="tencentcloud-sdk-python"
    ["dogecloud"]="boto3"
    ["frp"]="toml"
    ["gcloud_storage"]="ndg-httpsclient google-cloud-storage"
    ["gdrive"]="google-api-python-client google-auth-httplib2 google-auth-oauthlib httplib2"
    ["gpustat"]="pynvml"
    ["jdcloud"]="'boto3<=1.35.0' 'botocore>=1.27.0'"
    ["linuxsys"]="distro"
    ["mail_sys"]="python-dateutil"
    ["minio"]="minio"
    ["monitor"]="reportlab==4.4.3 matplotlib==3.10.6"
    ["monitor_args"]="--only-binary=contourpy,numpy"
    ["msonedrive"]="requests-oauthlib==1.3.0"
    ["obs"]="esdk-obs-python==3.25.8"
    ["ossfs"]="boto3 esdk-obs-python==3.25.8 ks3sdk oss2 bce-python-sdk"
    ["qiniu"]="qiniu==7.4.1"
    ["supervisor"]="supervisor==4.2.4 pyasynchat "
    ["supervisor_args"]="-I"
    ["sysdisk"]="blkinfo"
    ["tencentcloud"]=""
    ["tencent"]="tencentcloud-sdk-python"
    ["tianyiyun"]="boto3"
    ["total"]="pdfkit user-agents==2.2.0"
    ["txcdn"]="tencentcloud-sdk-python"
    ["txcos"]="cos-python-sdk-v5"
    ["txeo"]="tencentcloud-sdk-python"
    ["webdav"]="webdav4"
)

install_plugin_packages() {
    local python_path=$1
    local pip_path="$python_path/bin/pip3"
    [ -f "$pip_path" ] || { log_error "pip 路径错误"; return 1; }

    ${pip_path} install 'setuptools<82.0.0' 2>/dev/null || true

    local plugins=(
        alidns alioss aliyun aws_s3 bos bt_webhorse cosfs dnspod
        dogecloud frp gcloud_storage gdrive gpustat jdcloud linuxsys
        mail_sys minio monitor msonedrive obs ossfs qiniu supervisor
        sysdisk tencentcloud tencent tianyiyun total txcdn txcos txeo webdav
    )

    for plugin in "${plugins[@]}"; do
        local plugin_path="$PANEL_PATH/plugin/$plugin"
        [ ! -d "$plugin_path" ] && continue

        local packages="${PLUGIN_PACKAGES[$plugin]}"
        [ -z "$packages" ] && continue

        local args="${PLUGIN_PACKAGES[${plugin}_args]}"
        local cmd="$pip_path install $packages"
        [ -n "$args" ] && cmd="$cmd $args"

        log_info "安装插件 [${plugin}] 依赖..."
        if eval "$cmd" 2>/dev/null; then
            log_info "  ✓ $plugin"
        else
            log_warn "  ✗ $plugin 部分依赖安装异常"
        fi
    done

    # fail2ban 特殊处理
    local f2b="$PANEL_PATH/plugin/fail2ban"
    if [ -d "$f2b" ]; then
        log_info "处理插件: fail2ban"
        command -v apt-get >/dev/null 2>&1 && apt-get install libsystemd-dev pkg-config -y 2>/dev/null
        command -v yum >/dev/null 2>&1 && yum install systemd-devel pkgconfig -y 2>/dev/null
        ${pip_path} install systemd-python 2>/dev/null || true
        cp "$f2b/fail2ban.tar.gz" /tmp/fail2ban.tar.gz 2>/dev/null && \
            cd /tmp && tar -vxf fail2ban.tar.gz >/dev/null 2>&1 && \
            cd /tmp/fail2ban 2>/dev/null && \
            rm -f /tmp/fail2ban.tar.gz && \
            ${python_path}/bin/python3 setup.py install >/dev/null 2>&1 || true
    fi
}

# =============================================================================
# 环境验证
# =============================================================================

verify_python_environment() {
    log_info "验证 Python $PYTHON_VERSION 环境..."

    local python_bin="$PYTHON_PYENV_NEW/bin/python3.13"
    local python_version=$("$python_bin" --version 2>&1)
    log_info "Python 版本: $python_version"

    # SSL
    if "$python_bin" -c "import ssl; print('SSL:', ssl.OPENSSL_VERSION)" 2>/dev/null; then
        log_info "SSL 支持正常"
    else
        Red_Error "SSL 支持异常"
    fi

    # SQLite
    if "$python_bin" -c "import sqlite3; print('SQLite:', sqlite3.sqlite_version)" 2>/dev/null; then
        log_info "SQLite 支持正常"
    else
        Red_Error "SQLite 支持异常"
    fi

    # 基础包检查
    for pkg in psutil gevent flask; do
        if "$python_bin" -c "import $pkg" 2>/dev/null; then
            log_info "  ✓ $pkg"
        else
            log_warn "  ✗ $pkg"
        fi
    done

    # Route 1 额外检查完整包关键包
    if [ "$INSTALL_ROUTE" -eq $ROUTE_BUNDLE ]; then
        log_info "完整包额外验证..."
        for pkg in requests yaml redis docker paramiko; do
            if "$python_bin" -c "import ${pkg%%:*}" 2>/dev/null; then
                log_info "  ✓ $pkg"
            else
                log_warn "  ✗ $pkg（模块名可能不同于包名）"
            fi
        done
    fi

    log_info "环境验证完成"
}

# =============================================================================
# 环境替换（备份 → 替换 → 恢复 → 服务检查）
# =============================================================================

get_panel_pids() {
    echo $(ps aux | grep -E 'BT-Panel' | grep -v grep | awk '{print $2}' | xargs)
}

get_task_pids() {
    echo $(ps aux | grep -E '(task.py|BT-Task)' | grep -v grep | awk '{print $2}' | xargs)
}

check_bt_service_status() {
    [ "$HAS_OLD_PANEL" = false ] && { log_info "无面板，跳过服务检查"; return 0; }

    log_info "检查宝塔服务状态..."
    local wait=2
    local retries=0
    local max_retries=3

    while [ "$retries" -lt "$max_retries" ]; do
        sleep "$wait"
        local panel_pids=$(get_panel_pids)
        local task_pids=$(get_task_pids)

        if [ -n "$panel_pids" ] && [ -n "$task_pids" ]; then
            log_info "宝塔服务正常 (面板: $panel_pids, 任务: $task_pids)"
            return 0
        fi
        retries=$((retries + 1))
        wait=$((wait * 2))
        [ "$retries" -lt "$max_retries" ] && log_info "等待服务启动中... (${wait}s)"
    done

    [ -z "$panel_pids" ] && log_warn "面板进程未启动"
    [ -z "$task_pids" ] && log_warn "任务进程未启动"
    return 1
}

backup_and_replace_environment() {
    log_info "备份并替换 Python 环境..."

    # 停止服务
    [ "$HAS_OLD_PANEL" = true ] && /etc/init.d/bt stop

    # 记录当前环境状态
    local original_type="none"
    local original_target=""
    if [ -L "$PYTHON_PYENV" ]; then
        original_type="symlink"
        original_target=$(readlink "$PYTHON_PYENV")
        log_info "原环境为软链接 → $original_target"
    elif [ -d "$PYTHON_PYENV" ]; then
        original_type="directory"
        log_info "原环境为目录"
    fi

    # 备份
    local bak_time=$(date '+%Y%m%d_%H%M%S')
    local bak_path="${PYTHON_PYENV}_backup_${bak_time}"

    if [ "$original_type" = "symlink" ]; then
        mkdir -p "$bak_path"
        echo "$original_target" > "$bak_path/symlink_target"
        log_info "软链接环境已记录备份: $bak_path"
    elif [ "$original_type" = "directory" ]; then
        mv "$PYTHON_PYENV" "$bak_path" || { /etc/init.d/bt start; Red_Error "备份失败"; }
        log_info "原环境已备份: $bak_path"
    else
        mkdir -p "$bak_path"
        log_info "无原环境，创建空备份: $bak_path"
    fi

    # 定义恢复函数
    restore_original_environment() {
        log_warn "正在恢复原环境..."
        /etc/init.d/bt stop
        rm -rf "$PYTHON_PYENV"
        if [ "$original_type" = "symlink" ] && [ -f "$bak_path/symlink_target" ]; then
            ln -sf "$(cat "$bak_path/symlink_target")" "$PYTHON_PYENV"
        elif [ "$original_type" = "directory" ] && [ -d "$bak_path" ]; then
            mv "$bak_path" "$PYTHON_PYENV"
        else
            rm -rf "$bak_path"
        fi
        /etc/init.d/bt start
    }

    # 替换（备份已在前面完成，$PYTHON_PYENV 已不存在或已备份）
    if [ "$USE_SOFTLINK" = true ]; then
        log_info "创建软链接: $PYTHON_PYENV → $PYTHON_PYENV_NEW"
        [ -e "$PYTHON_PYENV" ] && rm -rf "$PYTHON_PYENV"
        ln -sf "$PYTHON_PYENV_NEW" "$PYTHON_PYENV" || {
            restore_original_environment
            Red_Error "软链接创建失败，已恢复"
        }
    else
        log_info "移动新环境: $PYTHON_PYENV_NEW → $PYTHON_PYENV"
        mv "$PYTHON_PYENV_NEW" "$PYTHON_PYENV" || {
            log_warn "移动失败，尝试复制方式..."
            cp -a "$PYTHON_PYENV_NEW" "$PYTHON_PYENV" && rm -rf "$PYTHON_PYENV_NEW" || {
                restore_original_environment
                Red_Error "环境替换失败，已恢复"
            }
        }
    fi

    # 启动服务
    log_info "启动宝塔服务..."
    /etc/init.d/bt start

    # fail2ban
    if [ -d "$PANEL_PATH/plugin/fail2ban" ]; then
        nohup systemctl restart fail2ban &>/dev/null &
    fi

    # 检查服务
    if check_bt_service_status; then
        log_info "Python 环境替换完成！"
        return 0
    else
        log_warn "服务启动失败，执行恢复..."
        restore_original_environment
        if check_bt_service_status; then
            log_info "已恢复原环境"
        else
            log_warn "恢复后服务仍异常，请手动检查"
        fi
        return 1
    fi
}

# =============================================================================
# 主流程
# =============================================================================

main() {
    print_separator
    log_info "宝塔面板 Python $PYTHON_VERSION 环境升级"

    # --replace 模式（直接替换，不走安装流程）
    if [ "$ONLY_REPLACE" = true ]; then
        check_root
        check_arch
        log_info "步骤 1/2: 验证已准备的环境"
        INSTALL_ROUTE=$ROUTE_BUNDLE
        verify_python_environment
        log_info "步骤 2/2: 替换环境"
        if backup_and_replace_environment; then
            print_separator
            log_info "Python 环境替换完成！"
            print_separator
        else
            print_separator
            log_info "环境替换失败，已自动回滚至原环境"
            print_separator
        fi
        exit 0
    fi

    # Step 1: 系统检查
    log_info "步骤 1/4: 系统环境检查"
    check_root
    check_arch
    log_info "架构: $ARCH"
    if [ "$INSTALL_ROUTE" -eq 0 ]; then
        log_info "路线: 自动（完整包 → 基础包 → 源码编译）"
    else
        local routes=("" "完整包(跳过pip)" "基础包+pip" "源码编译")
        log_info "路线: ${routes[$INSTALL_ROUTE]}"
    fi
    check_bt_panel
    check_download_tool
    print_separator

    # Step 2: CDN 节点选择
    log_info "步骤 2/4: 获取下载节点"
    get_node_url

    # Step 3: 安装 Python
    log_info "步骤 3/4: Python 环境安装"

    local install_ok=false

    if [ "$INSTALL_ROUTE" -eq $ROUTE_BUNDLE ] || [ "$INSTALL_ROUTE" -eq 0 ]; then
        if install_full_bundle; then
            INSTALL_ROUTE=$ROUTE_BUNDLE
            install_ok=true
        elif [ "$INSTALL_ROUTE" -eq $ROUTE_BUNDLE ]; then
            Red_Error "Route 1（完整包）失败，且指定了 --bundle 不降级"
        else
            log_warn "Route 1 失败，降级到 Route 2..."
        fi
    fi

    if [ "$install_ok" = false ] && [ "$INSTALL_ROUTE" -eq $ROUTE_BASIC -o "$INSTALL_ROUTE" -eq 0 ]; then
        if install_basic_bundle; then
            INSTALL_ROUTE=$ROUTE_BASIC
            install_ok=true
        elif [ "$INSTALL_ROUTE" -eq $ROUTE_BASIC ]; then
            Red_Error "Route 2（基础包）失败，且指定了 --basic 不降级"
        else
            log_warn "Route 2 失败，降级到 Route 3..."
        fi
    fi

    if [ "$install_ok" = false ] && [ "$INSTALL_ROUTE" -eq $ROUTE_COMPILE -o "$INSTALL_ROUTE" -eq 0 ]; then
        if install_from_source; then
            INSTALL_ROUTE=$ROUTE_COMPILE
            setup_python_environment
            set_pip_source
            install_python_packages
            install_ok=true
        elif [ "$INSTALL_ROUTE" -eq $ROUTE_COMPILE ]; then
            Red_Error "Route 3（源码编译）失败"
        fi
    fi

    if [ "$install_ok" = false ]; then
        Red_Error "所有安装路线均失败，请检查网络和系统环境"
    fi

    # 插件安装 + 环境验证
    log_info "步骤 4/4: 插件安装和验证"
    install_plugin_packages "$PYTHON_PYENV_NEW"
    modify_python_shebang

    # Route 2/3 需要重新 modify shebang（插件可能添加了新脚本）
    verify_python_environment

    if [ "$PREPARE_ONLY" = true ]; then
        print_separator
        log_info "仅准备环境，跳过替换"
        log_info "新环境: $PYTHON_PYENV_NEW"
        print_separator
        return 0
    fi

    # 替换环境
    if backup_and_replace_environment; then
        print_separator
        case $INSTALL_ROUTE in
            $ROUTE_BUNDLE)  log_info "安装路线: Route 1（完整包，跳过 pip）" ;;
            $ROUTE_BASIC)   log_info "安装路线: Route 2（基础包 + pip）" ;;
            $ROUTE_COMPILE) log_info "安装路线: Route 3（源码编译）" ;;
        esac
        log_info "Python 路径: $PYTHON_PYENV/bin/python3.13"
        local latest_bak=$(ls -d "${PYTHON_PYENV}_backup_"* 2>/dev/null | head -1)
        if [ -n "$latest_bak" ]; then
            log_info "备份位置: $(dirname "$latest_bak")/pyenv_backup_*"
        fi
        log_info "请访问宝塔面板确认升级成功"
    else
        print_separator
        log_warn "环境替换失败，已自动回滚至原环境"
        log_warn "新环境保留在: $PYTHON_PYENV_NEW"
    fi
    print_separator
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    parse_arguments "$@"
    main
fi
