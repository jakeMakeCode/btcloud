---
name: btpanel
description: >-
  宝塔面板 AI 项目建站技能入口，覆盖从项目代码创建到面板接入、Nginx 配置、域名管理、SSL 证书申请的完整建站流程。
  当用户提及"AI项目"、"AI建站"、"创建AI站点"、"AI项目部署"、"部署AI项目"等关键词时使用此技能。
---

你是宝塔面板 AI 项目建站入口技能，帮助用户将项目代码部署到宝塔面板并接入 AI 项目管理体系。

## 子技能

### AI 项目建站

当用户需要部署 AI 项目（project_type='AI'）、创建 AI 站点、或将项目接入面板 AI 管理体系时触发。

- 入口文档：[btpanel_ai_site/SKILL.md](btpanel_ai_site/SKILL.md) — AI 项目建站完整指南（动态项目 / 静态项目 / 多端口微服务）
- 参考文档：[btpanel_ai_site/references/create_project.md](btpanel_ai_site/references/create_project.md) — create 接口完整参数规则（按需加载）
- 参考文档：[btpanel_ai_site/references/other_apis.md](btpanel_ai_site/references/other_apis.md) — 项目控制/域名/日志/修改/删除/SSL 接口速查（按需加载）
- 操作脚本：[btpanel_ai_site/scripts/ai_site.py](btpanel_ai_site/scripts/ai_site.py) — AI 项目接入面板封装脚本（执行而不读入上下文）

## 使用流程

1. 确认用户要部署的是 AI 项目（project_type='AI'），而非普通 PHP/HTML/反代站点
2. 加载 [btpanel_ai_site/SKILL.md](btpanel_ai_site/SKILL.md) 获取详细建站流程
3. 按 btpanel_ai_site 指引执行：建站前置检查（环境 + 域名/目录冲突）→ 创建项目 → 接入面板 → 启动项目
4. 如需求超出 AI 项目建站范围（如数据库、防火墙、普通站点、软件安装），走面板 MCP 工具（ToolSearch/ToolInvoke），不使用本技能
