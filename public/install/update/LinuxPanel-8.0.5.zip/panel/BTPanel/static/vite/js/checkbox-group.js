import{a as e}from"./vue-bucket.js";import{A as o}from"./element-ui.js";const s=e(o());export{s as _};
