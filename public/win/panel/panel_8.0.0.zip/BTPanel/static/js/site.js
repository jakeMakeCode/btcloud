var initTab = [];
var site_table = {};

var unidentification = []; //未识别的证书
$('#cutMode .tabs-item').click(function () {
	var type = $(this).data('type');
	var index = $(this).index();
	bt.set_cookie('site_model', type);
	$(this).addClass('active').siblings().removeClass('active');
	$('.site_table_view .tab-con .tab-con-block').eq(index).removeClass('hide').siblings().addClass('hide');
	switch (type) {
		case 'php':
			product_recommend.init(function () {
				site.php_table_view();
			});
			break;
		case 'java':
			if (initTab.indexOf(2) > -1) {
				javaModle.get_project_list();
			} else {
				dynamic.require(['vue.min.js', 'polyfill.min.js', 'vue-components.js', 'java-model.js'], function () {
					initTab.push(index);
				});
			}
			break;
	}
});

var site = {
	php_table_view: function () {
		var _that = this,
			column = [
				{
					type: 'checkbox',
					width: 20,
				},
				{
					fid: 'name',
					title: '网站名',
					sort: true,
					sortValue: 'asc',
					type: 'link',
					event: function (row, index, ev) {
						site.web_edit(row, true);
					},
				},
				{
					fid: 'status',
					title: '状态',
					sort: true,
					width: 98,
					config: {
						icon: true,
						list: [
							['1', '运行中', 'bt_success', 'glyphicon-play'],
							['正常', '运行中', 'bt_success', 'glyphicon-play'],
							['正在运行', '运行中', 'bt_success', 'glyphicon-play'],
							['0', '已停止', 'bt_danger', 'glyphicon-pause'],
						],
					},
					type: 'status',
					event: function (row, index, ev, key, that) {
						bt.site[parseInt(row.status) ? 'stop' : 'start'](row.id, row.name, function (res) {
							if (res.status)
								that.$modify_row_data({
									status: parseInt(row.status) ? '0' : '1',
								});
						});
					},
				},
				{
					fid: 'backup_count',
					title: '备份',
					sort: true,
					width: 90,
					type: 'link',
					template: function (row, index) {
						var backup = '点击备份',
							_class = 'bt_warning';
						if (row.backup_count > 0) (backup = lan.site.backup_yes), (_class = 'bt_success');
						return '<a href="javascript:;" class="btlink  ' + _class + '">' + backup + (row.backup_count > 0 ? '(' + row.backup_count + ')' : '') + '</a>';
					},
					event: function (row, index) {
						site.site_detail(row.id, row.name, 1, $(this).parents('tr').index());
					},
				},
				{
					fid: 'type_version',
					title: 'PHP',
					width: 90,
					type: 'link',
					template: function (row, index) {
						var type = row.type,
							version = row.type_version,
							html = '';
						if (type == 'PHP') {
							if (version == -1) {
								html = '未知版本';
							} else if (version === '00') {
								html = '纯静态';
							} else {
								html = '<a href="javascript:;" class="btlink">' + type + '-' + version + '</a>';
							}
						} else {
							html = '<span>' + type + '</span>';
						}
						return html;
					},
					event: function (row, index) {
						if (row.type == 'PHP' && row.type_version != -1) {
							site.web_edit(row);
							setTimeout(function () {
								$('.site-menu p:eq(11)').click();
							}, 500);
						}
					},
				},
				{
					fid: 'path',
					title: '根目录',
					type: 'link',
					event: function (row, index, ev) {
						openPath(row.path);
					},
				},
				{
					fid: 'edate',
					title: '到期时间',
					width: 85,
					class: 'set_site_edate',
					sort: true,
					type: 'link',
					template: function (row, index) {
						var _endtime = '';
						if (row.edate) _endtime = row.edate;
						if (row.endtime) _endtime = row.endtime;
						_endtime = _endtime === '0000-00-00' ? lan.site.web_end_time : _endtime;
						return _endtime;
					},
					event: function (ev) {
						console.log(ev);
					},
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps(
							{
								id: row.id,
								table: 'sites',
								ps: ev.target.value,
							},
							function (res) {
								layer.msg(
									res.msg,
									res.status
										? {}
										: {
												icon: 2,
										  }
								);
							}
						);
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					},
				},
				{
					fid: 'site_ssl',
					title: 'SSL证书',
					tips: '部署证书',
					sort: true,
					type: 'text',
					template: function (row) {
						if (bt.get_cookie('serverType') != 'iis') {
							var _ssl = row.ssl,
								_info = '',
								_arry = [
									['issuer', '证书品牌'],
									['notAfter', '到期日期'],
									['notBefore', '申请日期'],
									['dns', '可用域名'],
								];

							try {
								if (typeof row.ssl.endtime != 'undefined') {
									if (row.ssl.endtime < 0) {
										return '<a class="btlink bt_danger" href="javascript:;">已过期' + Math.abs(row.ssl.endtime) + '天</a>';
									}
								}
							} catch (error) {}
							for (var i = 0; i < _arry.length; i++) {
								var item = _ssl[_arry[i][0]];
								_info += _arry[i][1] + ':' + item + (_arry.length - 1 != i ? '\n' : '');
							}
							return row.ssl === -1
								? '<a class="btlink bt_warning" href="javascript:;">未部署</a>'
								: '<a class="btlink ' + (row.ssl.endtime < 7 ? 'bt_danger' : '') + '" href="javascript:;" title="' + _info + '">剩余' + row.ssl.endtime + '天</a>';
						} else {
							return "<a class='btlink'>查看</a>";
						}
					},
					event: function (row) {
						site.web_edit(row);
						setTimeout(function () {
							if (bt.get_cookie('serverType') != 'iis') {
								$('.site-menu p:eq(10)').click();
							} else {
								row['ssl_view_type'] = 7;
								$('.site-menu p:eq(10)').addClass('bgw').siblings().removeClass('bgw');
								site.edit.set_ssl(row);
							}
						}, 500);
					},
				},
				{
					title: '操作',
					type: 'group',
					align: 'right',
					group: (function () {
						var setConfig = [
							{
								title: '设置',
								event: function (row, index, ev, key, that) {
									site.web_edit(row, true);
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									site.del_site(row.id, row.name, function (res) {
										if (res.status) that.$refresh_table_list(true);
									});
								},
							},
						];
						try {
							var recomConfig = product_recommend.get_recommend_type(5);
							if (recomConfig) {
								for (var i = 0; i < recomConfig['list'].length; i++) {
									var item = recomConfig['list'][i];
									(function (item) {
										setConfig.unshift({
											title: item.title,
											event: function (row) {
												product_recommend.get_version_event(item, row.name);
											},
										});
									})(item);
								}
							}
						} catch (error) {
							console.log(error);
						}
						return setConfig;
					})(),
				},
			];
		try {
			var recomConfig = product_recommend.get_recommend_type(4);
			if (recomConfig) {
				column.splice(column.length - 1, 0, {
					fid: recomConfig.name,
					title: recomConfig.title,
					type: recomConfig.title,
					template: function (row) {
						return '<a href="javascript:;" class="btlink">设置</a>';
					},
					event: function () {
						product_recommend.get_version_event(item, row.name);
					},
				});
			}
		} catch (error) {
			console.log(error);
		}
		$('#bt_site_table').empty();
		var site_table = bt_tools.table({
			el: '#bt_site_table',
			url: '/data?action=getData',
			cookiePrefix: 'site_table', // cookie前缀，用于状态存储，如果不设置，着所有状态不存储
			height: 480,
			param: {
				table: 'sites',
			}, //参数
			minWidth: '1000px',
			autoHeight: true,
			default: '站点列表为空', // 数据为空时的默认提示
			beforeRequest: function (param) {
				param.type = bt.get_cookie('site_type') || -1;
				return param;
			},
			column: column,
			sortParam: function (data) {
				return {
					order: data.name + ' ' + data.sort,
				};
			},
			// 表格渲染完成后
			success: function (that) {
				$('.event_edate_' + that.random).each(function () {
					var $this = $(this);
					laydate.render({
						elem: $this[0], //指定元素
						min: bt.get_date(1),
						max: '2099-12-31',
						vlue: bt.get_date(365),
						type: 'date',
						format: 'yyyy-MM-dd',
						trigger: 'click',
						btns: ['perpetual', 'confirm'],
						theme: '#20a53a',
						ready: function () {
							$this.click();
						},
						done: function (date) {
							var item = that.event_rows_model.rows;
							bt.site.set_endtime(item.id, date, function (res) {
								if (res.status) {
									layer.msg(res.msg);
									return false;
								}
								bt.msg(res);
							});
						},
					});
				});
			},
			// 渲染完成
			tootls: [
				{
					// 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [
						{
							title: '添加站点',
							active: true,
							event: function (ev) {
								bt.soft.get_soft_find('ftpserver', function (softData) {
									site.add_site(function () {
										site_table.$refresh_table_list(true);
									}, softData.status);
								});
								bt.set_cookie('site_type', '-1');
							},
						},
						{
							title: '修改默认页',
							event: function (ev) {
								site.set_default_page();
							},
						},
						{
							title: '默认站点',
							event: function (ev) {
								site.set_default_site();
							},
						},
						{
							title: 'HTTPS防窜站',
							event: function (ev) {
								site.open_safe_config();
							},
						},
					],
				},
				{
					// 搜索内容
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入域名或备注',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					// 批量操作
					type: 'batch', //batch_btn
					positon: ['left', 'bottom'],
					placeholder: '请选择批量操作',
					buttonValue: '批量操作',
					disabledSelectValue: '请选择需要批量操作的站点!',
					selectList: [
						{
							title: '开启站点',
							url: '/site?action=SiteStart',
							param: {
								status: 1,
							},
							confirmVerify: false, //是否提示验证方式
							paramName: 'id', //列表参数名,可以为空
							paramId: 'id', // 需要传入批量的id
							theadName: '站点名称',
							refresh: true,
						},
						{
							title: '停止站点',
							url: '/site?action=SiteStop',
							param: {
								status: 0,
							},
							confirmVerify: false, //是否提示验证方式
							paramName: 'id', //列表参数名,可以为空
							paramId: 'id',
							load: true,
							theadName: '站点名称',
							refresh: true,
						},
						{
							title: '备份站点',
							url: '/site?action=ToBackup',
							paramId: 'id',
							load: true,
							theadName: '站点名称',
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								bt.confirm(
									{
										title: '批量备份站点',
										msg: '是否备份选中的站点？',
										icon: 2,
									},
									function () {
										that.start_batch({}, function (list) {
											var html = '';
											for (var i = 0; i < list.length; i++) {
												var item = list[i];
												html +=
													'<tr><td>' +
													item.name +
													'</td><td><div style="float:right;"><span style="color:' +
													(item.request.status ? '#20a53a' : 'red') +
													'">' +
													item.request.msg +
													'</span></div></td></tr>';
											}
											site_table.$batch_success_table({
												title: '批量备份',
												th: '站点名称',
												html: html,
											});
											site_table.$refresh_table_list(true);
										});
									}
								);
							},
						},
						{
							title: '设置到期时间',
							url: '/site?action=SetEdate',
							paramName: 'id', //列表参数名,可以为空
							paramId: 'id', // 需要传入批量的id
							theadName: '站点名称',
							refresh: true,
							confirm: {
								title: '批量设置到期时间',
								content:
									'<div class="line"><span class="tname">到期时间</span><div class="info-r "><input name="edate" id="site_edate" class="bt-input-text mr5" placeholder="yyyy-MM-dd" type="text"></div></div>',
								success: function () {
									laydate.render({
										elem: '#site_edate',
										min: bt.format_data(new Date().getTime(), 'yyyy-MM-dd'),
										max: '2099-12-31',
										vlue: bt.get_date(365),
										type: 'date',
										format: 'yyyy-MM-dd',
										trigger: 'click',
										btns: ['perpetual', 'confirm'],
										theme: '#20a53a',
									});
								},
								yes: function (index, layers, request) {
									var site_edate = $('#site_edate'),
										site_edate_val = site_edate.val();
									if (site_edate_val != '') {
										request({
											edate: site_edate_val === '永久' ? '0000-00-00' : site_edate_val,
										});
									} else {
										layer.tips('请输入到期时间', '#site_edate', {
											tips: ['1', 'red'],
										});
										$('#site_edate').css('border-color', 'red');
										$('#site_edate').click();
										setTimeout(function () {
											$('#site_edate').removeAttr('style');
										}, 3000);
										return false;
									}
								},
							},
						},
						{
							title: '设置PHP版本',
							url: '/site?action=SetPHPVersion',
							paramName: 'siteName', //列表参数名,可以为空
							paramId: 'name', // 需要传入批量的id
							theadName: '站点名称',
							refresh: true,
							screening: function (index, row) {
								if (row.type.indexOf('Asp') > -1) {
									return false;
								}
							},
							confirm: {
								title: '批量设置PHP版本',
								area: '420px',
								content:
									'<div class="line"><span class="tname">PHP版本</span><div class="info-r"><select class="bt-input-text mr5 versions" name="versions" style="width:150px"></select></span></div><ul class="help-info-text c7" style="font-size:11px"><li>请根据您的程序需求选择版本</li><li>若非必要,请尽量不要使用PHP5.2,这会降低您的服务器安全性；</li><li>PHP7不支持mysql扩展，默认安装mysqli以及mysql-pdo。</li><li style="color:red;">Aspx和Asp程序无法切换，请须知</li></ul></div>',
								success: function () {
									bt.site.get_all_phpversion(function (res) {
										var html = '';
										$.each(res, function (index, item) {
											html += '<option value="' + item.version + '">' + item.name + '</option>';
										});
										$('[name="versions"]').html(html);
									});
								},
								yes: function (index, layers, request) {
									request({
										version: $('[name="versions"]').val(),
									});
								},
							},
						},
						{
							title: '设置分类',
							url: '/site?action=set_site_type',
							paramName: 'site_ids', //列表参数名,可以为空
							paramId: 'id', // 需要传入批量的id
							refresh: true,
							beforeRequest: function (list) {
								var arry = [];
								$.each(list, function (index, item) {
									arry.push(item.id);
								});
								return JSON.stringify(arry);
							},
							confirm: {
								title: '批量设置分类',
								content:
									'<div class="line"><span class="tname">站点分类</span><div class="info-r"><select class="bt-input-text mr5 site_types" name="site_types" style="width:150px"></select></span></div></div>',
								success: function () {
									bt.site.get_type(function (res) {
										var html = '';
										$.each(res, function (index, item) {
											html += '<option value="' + item.id + '">' + item.name + '</option>';
										});
										$('[name="site_types"]').html(html);
									});
								},
								yes: function (index, layers, request) {
									request({
										id: $('[name="site_types"]').val(),
									});
								},
							},
							tips: false,
							success: function (res, list, that) {
								var html = '';
								$.each(list, function (index, item) {
									html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
								});
								that.$batch_success_table({
									title: '批量设置分类',
									th: '站点名称',
									html: html,
								});
								site_table.$refresh_table_list(true);
							},
						},
						{
							title: '恢复网站到IIS',
							url: '/site?action=sync_iis_site',
							paramName: 'ids', //列表参数名,可以为空
							paramId: 'id', // 需要传入批量的id
							refresh: true,
							beforeRequest: function (list) {
								var arry = [];
								$.each(list, function (index, item) {
									arry.push(item.id);
								});
								return JSON.stringify(arry);
							},
							confirmVerify: true,
							tableName: '站点名称',
						},
						{
							title: '删除站点',
							url: '/site?action=DeleteSite',
							load: true,
							param: function (row) {
								return {
									id: row.id,
									webname: row.name,
								};
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								var ids = [];
								for (var i = 0; i < that.check_list.length; i++) {
									ids.push(that.check_list[i].id);
								}
								site.del_site(ids, function (param) {
									that.start_batch(param, function (list) {
										layer.closeAll();
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										site_table.$batch_success_table({
											title: '批量删除',
											th: '站点名称',
											html: html,
										});
										site_table.$refresh_table_list(true);
									});
								});
							},
						},
					],
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
		});

		this.site_table = site_table;
		this.init_site_type();
	},

	/**
	 * @description PHP类型视图
	 */
	init_site_type: function () {
		$('#php_cate_select').remove();
		$('#bt_site_table .tootls_group.tootls_top .pull-left').append(
			'<div id="php_cate_select" class="bt_select_updown site_class_type" style="vertical-align: bottom;"><div class="bt_select_value"><span class="bt_select_content">分类:</span><span class="glyphicon glyphicon-triangle-bottom ml5"></span></span></div><ul class="bt_select_list"></ul></div>'
		);
		bt.site.get_type(function (res) {
			site.reader_site_type(res);
		});
	},
	reader_site_type: function (res) {
		var html = '',
			active = bt.get_cookie('site_type') || -1,
			select = $('#php_cate_select');
		config = this.site_table;
		if (select.find('.bt_select_list li').length > 1) return false;
		res.unshift({
			id: -1,
			name: '全部分类',
		});
		$.each(res, function (index, item) {
			html += '<li class="item ' + (parseInt(active) == item.id ? 'active' : '') + '" data-id="' + item.id + '">' + item.name + '</li>';
		});
		html += '<li role="separator" class="divider"></li><li class="item" data-id="type_sets">分类设置</li>';
		select.find('.bt_select_value').on('click', function (ev) {
			var $this = this;
			$(this).next().show();
			$(document).one('click', function () {
				$($this).next().hide();
			});
			ev.stopPropagation();
		});

		select
			.find('.bt_select_list')
			.unbind('click')
			.on('click', 'li', function () {
				var id = $(this).data('id');
				if (id == 'type_sets') {
					site.set_class_type();
				} else {
					bt.set_cookie('site_type', id);
					config.$refresh_table_list(true, function (data) {
						if (parseInt($('#bt_site_table .page .Pcurrent').text()) !== 1) $('.Pstart').click();
					});
					$(this).addClass('active').siblings().removeClass('active');
					select.find('.bt_select_value .bt_select_content').text('分类: ' + $(this).text());
				}
			})
			.empty()
			.html(html);
		if (!select.find('.bt_select_list li.active').length) {
			select.find('.bt_select_list li:eq(0)').addClass('active');
			select.find('.bt_select_value .bt_select_content').text('分类: 默认分类');
		} else {
			select.find('.bt_select_value .bt_select_content').text('分类: ' + select.find('.bt_select_list li.active').text());
		}
	},
	get_list: function (page, search, type) {
		if (page == undefined) page = 1;
		if (type == '-1' || type == undefined) {
			type = $('.site_type select').val();
		}
		search = search || $('#SearchValue').val();
		bt.site.get_list(page, search, type, function (rdata) {
			$('.dataTables_paginate').html(rdata.page);
			var _tab = bt.render({
				table: '#webBody',
				columns: [
					{
						field: 'id',
						type: 'checkbox',
						width: 30,
					},
					{
						field: 'name',
						title: '网站名',
						width: 150,
						templet: function (item) {
							return '<a class="btlink webtips" onclick="site.web_edit(this)" href="javascript:;">' + item.name + '</a>';
						},
						sort: function () {
							site.get_list();
						},
					},

					{
						field: 'status',
						title: '状态',
						width: 98,
						templet: function (item) {
							var _status = '<a href="javascript:;" ';
							if (item.status == '1' || item.status == '正常' || item.status == '正在运行') {
								_status += ' onclick="bt.site.stop(' + item.id + ",'" + item.name + '\') " >';
								_status += '<span style="color:#5CB85C">运行中 </span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span>';
							} else {
								_status += ' onclick="bt.site.start(' + item.id + ",'" + item.name + '\')"';
								_status += '<span style="color:red">已停止  </span><span style="color:red" class="glyphicon glyphicon-pause"></span>';
							}
							return _status;
						},
						sort: function () {
							site.get_list();
						},
					},
					{
						field: 'backup',
						title: '备份',
						width: 90,
						templet: function (item) {
							var backup = '<span style="color:#e5804e">点击备份</span>';
							if (item.backup_count > 0) backup = '有备份(' + item.backup_count + ')';
							return '<a href="javascript:;" class="btlink" onclick="site.site_detail(' + item.id + ",'" + item.name + '\')">' + backup + '</a>';
						},
					},
					{
						field: 'type_version',
						title: '程序类型',
						width: 90,
						templet: function (item) {
							var ver = item.type;
							if (ver == 'PHP') {
								if (item.type_version == -1) {
									ver = '未知版本';
								} else {
									ver = '<a href="javascript:;" class="btlink" onclick="site.open_site_program_type(this)">' + ver + '-' + item.type_version + '</a>';
								}
							}

							return ver;
						},
					},
					{
						field: 'path',
						title: '根目录',
						width: '26%',
						templet: function (item) {
							var _path = bt.format_path(item.path);
							return '<a class="btlink" title="打开目录" href="javascript:openPath(\'' + _path + '\');">' + _path + '</a>';
						},
					},
					{
						field: 'edate',
						title: '到期时间',
						width: 86,
						templet: function (item) {
							var _endtime = '';
							if (item.edate) _endtime = item.edate;
							if (item.endtime) _endtime = item.endtime;
							_endtime = _endtime == '0000-00-00' ? lan.site.web_end_time : _endtime;
							return '<a class="btlink setTimes" id="site_endtime_' + item.id + '" >' + _endtime + '</a>';
						},
						sort: function () {
							site.get_list();
						},
					},
					{
						field: 'ps',
						title: '备注',
						templet: function (item) {
							return "<span class='c9 input-edit'  onclick=\"bt.pub.set_data_by_key('sites','ps',this)\">" + item.ps + '</span>';
						},
					},
					bt.os == 'Linux'
						? {
								field: 'id',
								title: '防火墙',
								templet: function (item) {
									var _check = ' onclick="site.no_firewall(this)"';
									if (item.waf_setup) _check = ' onclick="set_site_obj_state(\'' + item.name + "','open')\"";
									var _waf = '<input class="btswitch btswitch-ios " ' + _check + ' id="closewaf_' + item.name + '" ' + (item.firewall ? 'checked' : '') + ' type="checkbox">';
									_waf += '<label class="btswitch-btn bt-waf-firewall" for="closewaf_' + item.name + '" title="' + bt.get_cookie('serverType') + '防火墙开关"></label>';
									return _waf;
								},
						  }
						: '',
					{
						field: 'opt',
						width: 260,
						title: '操作',
						align: 'right',
						templet: function (item) {
							var opt = '';
							var _check = ' onclick="site.site_waf(\'' + item.name + '\')"';

							if (bt.os == 'Linux') opt += '<a href="javascript:;" ' + _check + ' class="btlink ">防火墙</a> | ';
							opt += '<a href="javascript:;" class="btlink" onclick="site.web_edit(this)">设置 </a> | ';
							opt += '<a href="javascript:;" class="btlink" onclick="site.del_site(' + item.id + ",'" + item.name + '\')" title="删除站点">删除</a>';
							return opt;
						},
					},
				],
				data: rdata.data,
			});

			if (bt.get_cookie('serverType') == 'iis') {
				$('.btn-sync_iis').show();
			}

			//设置到期时间
			$('a.setTimes').each(function () {
				var _this = $(this);
				var _tr = _this.parents('tr');
				var id = _this.attr('id');
				laydate.render({
					elem: '#' + id, //指定元素
					min: bt.get_date(1),
					max: '2099-12-31',
					vlue: bt.get_date(365),
					type: 'date',
					format: 'yyyy-MM-dd',
					trigger: 'click',
					btns: ['perpetual', 'confirm'],
					theme: '#20a53a',
					done: function (dates) {
						var item = _tr.data('item');
						bt.site.set_endtime(item.id, dates, function () {});
					},
				});
			});
		});
	},
	open_site_program_type: function (that) {
		site.web_edit(that);
		setTimeout(function () {
			site.reload(11);
		}, 500);
	},
	html_encode: function (html) {
		var temp = document.createElement('div');
		//2.然后将要转换的字符串设置为这个元素的innerText(ie支持)或者textContent(火狐，google支持)
		temp.textContent != undefined ? (temp.textContent = html) : (temp.innerText = html);
		//3.最后返回这个元素的innerHTML，即得到经过HTML编码转换的字符串了
		var output = temp.innerHTML;
		temp = null;
		return output;
	},
	get_types: function (callback) {
		bt.site.get_type(function (rdata) {
			var optionList = '';
			for (var i = 0; i < rdata.length; i++) {
				optionList += '<option value="' + rdata[i].id + '">' + rdata[i].name + '</option>';
			}
			if ($('.dataTables_paginate').next().hasClass('site_type')) $('.site_type').remove();
			$('.dataTables_paginate').after(
				'<div class="site_type"><span>站点分类:</span><select class="bt-input-text mr5"  style="width:100px"><option value="-1">全部分类</option>' + optionList + '</select></div>'
			);
			$('.site_type select').change(function () {
				var val = $(this).val();
				site.get_list(0, '', val);
				bt.set_cookie('site_type', val);
			});
			if (callback) callback(rdata);
		});
	},
	no_firewall: function (obj) {
		var typename = bt.get_cookie('serverType');
		layer.confirm(
			typename + '防火墙暂未开通，<br>请到&quot;<a href="/soft" class="btlink">软件管理>付费插件>' + typename + '防火墙</a>&quot;<br>开通安装使用。',
			{
				title: typename + '防火墙未开通',
				icon: 7,
				closeBtn: 2,
				cancel: function () {
					if (obj) $(obj).prop('checked', false);
				},
			},
			function () {
				window.location.href = '/soft';
			},
			function () {
				if (obj) $(obj).prop('checked', false);
			}
		);
	},
	site_detail: function (id, siteName, page) {
		if (page == undefined) page = '1';
		var that = this;
		if ($('#SiteBackupList').length <= 0) {
			bt.open({
				type: 1,
				skin: 'demo-class',
				area: '700px',
				title: lan.site.backup_title + '【' + siteName + '】',
				closeBtn: 2,
				shift: 5,
				shadeClose: false,
				content:
					"<div class='divtable pd15' style='padding-bottom: 30px;'>\
                    <button id='btn_data_backup' class='btn btn-success btn-sm' type='button' style='margin-bottom:10px'>" +
					lan.database.backup +
					"</button>\
                    <div id='SiteBackupList'></div></div>",
			});
		}
		setTimeout(function () {
			var _page = '';
			$('#SiteBackupList').empty();
			var backTable = bt_tools.table({
				el: '#SiteBackupList',
				url: '/data?action=getData&table=backup&search=' + id + '&limit=5&type=0&tojs=site.site_detail&p=' + page,
				default: '备份列表为空',
				dataFilter: function (res) {
					_page = res.page.replace(/'/g, '"').replace(/site.site_detail\(/g, 'site.site_detail(' + id + ",'" + siteName + "',");
					return { data: res.data };
				},
				column: [
					{
						type: 'checkbox',
						class: '',
						width: 20,
					},
					{
						fid: 'name',
						title: '文件名称',
					},
					{
						fid: 'size',
						title: '文件大小',
						template: function (item) {
							return bt.format_size(item.size);
						},
					},
					{
						fid: 'addtime',
						title: '备份时间',
					},
					{
						title: '操作',
						type: 'group',
						align: 'right',
						group: [
							{
								title: '下载',
								event: function (row, index, ev, key, that) {
									window.location.href = '/download?filename=' + row.filename + '&amp;name=' + row.name;
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									bt.site.del_backup(row.id, id, siteName, row.addtime);
								},
							},
						],
					},
				],
				tootls: [
					{
						type: 'batch',
						positon: ['left', 'bottom'],
						config: {
							title: '删除',
							url: 'site?action=DelBackup',
							param: function (row) {
								return { id: row.id };
							},
							load: true,
							callback: function (that) {
								bt.confirm({ title: '批量删除备份文件', msg: '批量删除选中的站点备份文件，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
									layer.close(index);
									that.start_batch({}, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td><span class="text-overflow" title="' +
												item.name +
												'">' +
												item.name +
												'</span></td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										backTable.$batch_success_table({ title: '批量删除备份文件', th: '键', html: html });
										site.site_detail(id, siteName);
									});
								});
							},
						},
					},
				],
				success: function () {
					$('#SiteBackupList .page').remove();
					$('#SiteBackupList .tootls_bottom .pull-right').html($(_page).addClass('page'));
					$('#btn_data_backup')
						.unbind('click')
						.click(function () {
							bt.site.backup_data(id, function (rdata) {
								if (rdata.status) {
									site.site_detail(id, siteName);
									that.site_table.$refresh_table_list(true);
								}
							});
						});
				},
			});
		}, 100);
	},
	/**
	 * @description 添加站点
	 * @param {object} config  配置参数
	 * @param {function} callback  回调函数
	 */
	add_site: function (callback, ftpStatus) {
		var typeId = bt.get_cookie('site_type');
		var add_web = bt_tools.form({
			data: {}, //用于存储初始值和编辑时的赋值内容
			class: '',
			form: [
				{
					label: '域名',
					must: '*',
					group: {
						type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
						name: 'webname', //当前表单的name
						style: { width: '440px', height: '100px', 'line-height': '22px' },
						tips: {
							//使用hover的方式显示提示
							text: '如需填写多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法 *.domain.com<br>如另加端口格式为 www.domain.com:88',
							style: { top: '15px', left: '15px' },
						},
						input: function (value, form, that, config, ev) {
							//键盘事件
							var array = value.webname.split('\n'),
								ress = array[0].split(':')[0],
								oneVal = bt.strim(ress.replace(new RegExp(/([-.])/g), '_')),
								defaultPath = $('#defaultPath').text(),
								is_oneVal = ress.length > 0;
							that.$set_find_value(
								is_oneVal
									? {
											ftp_username: oneVal,
											ftp_password: bt.get_random(16),
											datauser: is_oneVal ? oneVal.substr(0, 16) : '',
											datapassword: bt.get_random(16),
											ps: ress,
											path: bt.rtrim(defaultPath, '/') + '/' + ress,
									  }
									: { ftp_username: '', ftp_password: '', datauser: '', datapassword: '', ps: '', path: bt.rtrim(defaultPath, '/') }
							);
						},
					},
				},
				{
					label: '备注',
					group: {
						type: 'text',
						name: 'ps',
						width: '400px',
						placeholder: '网站备注，可为空', //默认标准备注提示
					},
				},
				{
					label: '根目录',
					must: '*',
					group: {
						type: 'text',
						width: '400px',
						name: 'path',
						icon: {
							type: 'glyphicon-folder-open',
							event: function (ev) {},
						},
						value: bt.get_cookie('sites_path') ? bt.get_cookie('sites_path') : '/www/wwwroot',
						placeholder: '请选择文件目录',
					},
				},
				{
					label: 'FTP',
					group: [
						{
							type: 'select',
							name: 'ftp',
							width: '120px',
							disabled: !ftpStatus,
							list: [
								{ title: '不创建', value: false },
								{ title: '创建', value: true },
							],
							change: function (value, form, that, config, ev) {
								if (value['ftp'] === 'true') {
									form['ftp_username'].parents('.line').removeClass('hide');
								} else {
									form['ftp_username'].parents('.line').addClass('hide');
								}
							},
						},
						(function () {
							if (ftpStatus) return {};
							return {
								type: 'link',
								title: '未安装FTP，点击安装',
								name: 'installed_ftp',
								event: function (ev) {
									bt.soft.install('pureftpd');
								},
							};
						})(),
					],
				},
				{
					label: 'FTP账号',
					hide: true,
					group: [
						{ type: 'text', name: 'ftp_username', placeholder: '创建FTP账号', width: '175px', style: { 'margin-right': '15px' } },
						{ label: '密码', type: 'text', placeholder: 'FTP密码', name: 'ftp_password', width: '175px' },
					],
					help: {
						list: ['创建站点的同时，为站点创建一个对应FTP帐户，并且FTP目录指向站点所在目录。'],
					},
				},
				{
					label: '数据库',
					group: [
						{
							type: 'select',
							name: 'sql',
							width: '120px',
							disabled: (function () {
								if (bt.config['mysql']) return !bt.config['mysql'].setup;
								return true;
							})(),
							list: [
								{ title: '不创建', value: false },
								{ title: 'MySQL', value: 'MySQL' },
								{ title: 'SQLServer', value: 'SQLServer' },
							],
							change: function (value, form, that, config, ev) {
								if (value['sql'] === 'MySQL') {
									form['datauser'].parents('.line').removeClass('hide');
									form['codeing'].parents('.bt_select_updown').parent().removeClass('hide');
								} else if (value['sql'] === 'SQLServer') {
									bt.soft.get_soft_find('sqlserver', function (softData) {
										if (!softData.status) {
											bt.msg({ msg: 'sqlserver' + '未安装或者未启动!', icon: 2 });
											value['sql'] = false;
											form['datauser'].parents('.line').addClass('hide');
											form['codeing'].parents('.bt_select_updown').parent().addClass('hide');
											return;
										} else {
											form['datauser'].parents('.line').removeClass('hide');
											form['codeing'].parents('.bt_select_updown').parent().removeClass('hide');
										}
									});
								} else {
									form['datauser'].parents('.line').addClass('hide');
									form['codeing'].parents('.bt_select_updown').parent().addClass('hide');
								}
							},
						},
						(function () {
							if (bt.config.mysql.setup) return {};
							return {
								type: 'link',
								title: '未安装数据库，点击安装',
								name: 'installed_database',
								event: function () {
									bt.soft.install('mysql');
								},
							};
						})(),
						{
							type: 'select',
							name: 'codeing',
							hide: true,
							width: '120px',
							list: [
								{ title: 'utf8', value: 'utf8' },
								{ title: 'utf8mb4', value: 'utf8mb4' },
								{ title: 'gbk', value: 'gbk' },
								{ title: 'big5', value: 'big5' },
							],
						},
					],
				},
				{
					label: '数据库账号',
					hide: true,
					group: [
						{ type: 'text', name: 'datauser', placeholder: '创建数据库账号', width: '175px', style: { 'margin-right': '15px' } },
						{ label: '密码', type: 'text', placeholder: '数据库密码', name: 'datapassword', width: '175px' },
					],
					help: {
						class: '',
						style: '',
						list: ['创建站点的同时，为站点创建一个对应的数据库帐户，方便不同站点使用不同数据库。'],
					},
				},
				{
					label: '程序类型',
					group: [
						{
							type: 'select',
							name: 'type',
							width: '120px',
							list: [
								{ title: 'PHP', value: 'PHP' },
								{ title: 'Asp', value: 'Asp' },
								{ title: 'Aspx', value: 'Aspx' },
							],
							change: function (value, form, that, config, ev) {
								if (value['type'] !== 'PHP') {
									form['version'].parents('.line').addClass('hide');
								} else {
									form['version'].parents('.line').removeClass('hide');
								}
							},
						},
					],
				},
				{
					label: 'PHP版本',
					group: [
						{
							type: 'select',
							name: 'version',
							width: '120px',
							// disabled: (bt.contains(bt.get_cookie('serverType'), 'iis') ? false : true),
							list: {
								url: '/site?action=GetPHPVersion',
								dataFilter: function (res) {
									var arry = [];
									for (var i = res.length - 1; i >= 0; i--) {
										var item = res[i];
										arry.push({ title: item.name, value: item.version });
									}
									return arry;
								},
							},
						},
					],
				},
				{
					label: '网站分类',
					group: [
						{
							type: 'select',
							name: 'type_id',
							width: '120px',
							list: {
								url: '/site?action=get_site_types',
								dataFilter: function (res) {
									var arry = [];
									$.each(res, function (index, item) {
										arry.push({ title: item.name, value: item.id });
									});
									return arry;
								},
								success: function (res, formObj) {
									setTimeout(function () {
										var index = -1;
										for (var i = 0; i < res.length; i++) {
											if (res[i].id == typeId) {
												index = i;
												break;
											}
										}
										if (index != -1) formObj.element.find('.bt_select_updown[data-name="type_id"]').find('.bt_select_list li').eq(index).click();
									}, 100);
								},
							},
						},
					],
				},
			],
		});
		//其他配置
		var other_config = {
			dataname: 'MySQL',
			codeing: 'utf8mb4',
			datauser: '',
			datapassword: '',
			php: '',
		};
		var keydept_web = bt_tools.form({
			data: {}, //用于存储初始值和编辑时的赋值内容
			class: 'keydept',
			form: [
				{
					label: '域名',
					must: '*',
					group: {
						type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
						name: 'webname', //当前表单的name
						style: { width: '440px', height: '100px', 'line-height': '22px' },
						tips: {
							//使用hover的方式显示提示
							text: '如需填写多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法 *.domain.com<br>如另加端口格式为 www.domain.com:88',
							style: { top: '15px', left: '15px' },
						},
						input: function (value, form, that, config, ev) {
							//键盘事件
							var array = value.webname.split('\n'),
								ress = array[0].split(':')[0],
								oneVal = bt.strim(ress.replace(new RegExp(/([-.])/g), '_')),
								defaultPath = $('#defaultPath').text(),
								is_oneVal = ress.length > 0;
							other_config.datauser = is_oneVal ? oneVal.substr(0, 16) : '';
							that.$set_find_value(
								is_oneVal
									? {
											ps: ress,
											path: bt.rtrim(defaultPath, '/') + '/' + ress,
									  }
									: { ps: '', path: bt.rtrim(defaultPath, '/') }
							);
						},
					},
				},
				{
					label: '备注',
					group: {
						type: 'text',
						name: 'ps',
						width: '400px',
						placeholder: '网站备注，可为空', //默认标准备注提示
					},
				},
				{
					label: '根目录',
					must: '*',
					group: {
						type: 'text',
						width: '400px',
						name: 'path',
						icon: {
							type: 'glyphicon-folder-open',
							event: function (ev) {},
						},
						value: bt.get_cookie('sites_path') ? bt.get_cookie('sites_path') : '/www/wwwroot',
						placeholder: '请选择文件目录',
					},
				},
			],
		});
		var bath_web = bt_tools.form({
			class: 'plr10',
			form: [
				{
					line_style: { position: 'relative' },
					group: {
						type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
						name: 'bath_code', //当前表单的name
						style: { width: '560px', height: '180px', 'line-height': '22px', 'font-size': '13px' },
						value: '域名|1|0|0|0\n域名|1|0|0|0\n域名|1|0|0|0',
					},
				},
				{
					group: {
						type: 'help',
						style: { 'margin-top': '0' },
						class: 'none-list-style',
						list: [
							'批量格式：域名|根目录|FTP|数据库|PHP版本',
							'<span style="padding-top:5px;display:inline-block;">域名参数：多个域名用&nbsp;,&nbsp;分割</span>',
							'根目录参数：填写&nbsp;1&nbsp;为自动创建，或输入具体目录',
							'FTP参数：填写&nbsp;1&nbsp;为自动创建，填写&nbsp;0&nbsp;为不创建',
							'数据库参数：填写&nbsp;1&nbsp;为自动创建，填写&nbsp;0&nbsp;为不创建',
							'PHP版本参数：填写&nbsp;0&nbsp;为静态，或输入PHP具体版本号列如：56、71、74',
							'<span style="padding-bottom:5px;display:inline-block;">如需添加多个站点，请换行填写</span>',
							'案例：bt.cn,test.cn:8081|/www/wwwroot/bt.cn|1|1|56',
						],
					},
				},
			],
		});
		var web_tab = bt_tools.tab({
			class: 'pd20',
			type: 0,
			theme: { nav: 'mlr20' },
			active: 1, //激活TAB下标
			list: [
				{
					title: '创建站点',
					name: 'createSite',
					content: add_web.$reader_content(),
					success: function () {
						add_web.$event_bind();
					},
				},
				{
					title: '一键部署',
					name: 'keyDeployment',
					content: keydept_web.$reader_content(),
					success: function () {
						keydept_web.$event_bind();
						$('.keydept').parent().parent().css('padding', '10px 10px 0 10px');
						$.post('/deployment?action=GetSiteList', function (rdata) {
							$.post('/site?action=GetPHPVersion', function (res) {
								var php_version = [],
									php_version_normal = [];
								var n = 0;
								for (var i = res.length - 1; i >= 0; i--) {
									var item = res[i];
									php_version_normal.push({ title: item.name, value: item.version });
								}
								$('.keydept .bt-form').prepend(
									'<div class="line" style="padding: 5px 0 0 0;"><span class="tname"><span class="color-red mr5">*</span>模板部署</span><div class="info-r"><div class="deployment_line"></div></div></div>'
								);
								$('.keydept .bt-form').prepend(
									'<div class="dep_msg">快速的部署网站程序，商城、论坛、博客、框架等程序，<a class="btlink" target="_blank" href="https://www.bt.cn/bbs/thread-33063-1-1.html">免费入驻平台</a></div>'
								);
								$('.keydept .bt-form').append(
									'<div class="line">\
                <span class="tname"><span class="color-red mr5">*</span>其他配置</span>\
                <div class="info-r">\
                  <div class="dep_config"><div class="database_info"></div><hr><div class="php_info"></div></div>\
                  <div class="c9 mt5">其他配置初始状态为默认选择的配置项，如需修改请点击<a class="btlink edit_dep_config">编辑配置</a>。</div>\
                </div>\
              </div>'
								);
								var deployment_line = $('.deployment_line'),
									edit_dep_config = $('.edit_dep_config');
								(database_info = $('.database_info')), (php_info = $('.php_info'));
								//动态修改其他配置
								$('[name="webname"]').keyup(function () {
									otherConfig(other_config);
								});
								render_dep_mode();
								var dep_mode = $('.dep_mode');
								//模板点击事件
								dep_mode.click(function () {
									var index = $(this).index();
									var data = $(this).data();
									if (index === 5 && !data['codename']) {
										//更多模板
										depMoreClick();
										return;
									} else {
										$(this).addClass('active').siblings().removeClass('active');
										is_vespub(data);
									}
								});
								dep_mode.eq(0).click();
								//模板悬浮
								dep_mode.hover(
									function () {
										var i = $(this).index();
										var data = $(this).data();
										if (data['codename']) {
											if (i === 5) if (data.idxs) i = data.idxs;
											var item = rdata.list[i];
											var texts = '名称：' + item.title + '<br>';
											texts += '版本：' + item.version + '<br>';
											texts += '简介：' + item.ps.replace('<a', ',,<a').split(',,')[0] + '<br>';
											texts += '支持PHP版本：' + item.php + '<br>';
											texts += '官网：' + (item.author === '宝塔' ? item.official.replace(/^http[s]?:\/\//, '').split('/')[0] : item.author) + '<br>';
											texts += '评价：' + item.score + '<br>';
											layer.tips(texts, this, { time: 0, tips: [1, '#999'] });
										}
									},
									function () {
										layer.closeAll('tips');
									}
								);
								//编辑配置
								edit_dep_config.click(function () {
									layer.open({
										type: 1,
										title: '编辑配置',
										area: '590px',
										closeBtn: 2,
										shadeClose: false,
										skin: 'edit_dep_form',
										content: '<div id="dep_form"></div>',
										success: function (layers, indexs) {
											bt_tools.form({
												el: '#dep_form',
												class: 'pd15',
												form: [
													{
														label: '数据库',
														group: [
															{
																type: 'select',
																name: 'sql',
																width: '120px',
																disabled: (function () {
																	if (bt.config['mysql']) return !bt.config['mysql'].setup;
																	return true;
																})(),
																placeholder: '未安装数据库',
																list: bt.config.mysql.setup ? [{ title: 'MySQL', value: 'MySQL' }] : [],
															},
															(function () {
																if (bt.config.mysql.setup) return {};
																return {
																	type: 'link',
																	title: '未安装数据库，点击安装',
																	name: 'installed_database',
																	event: function () {
																		bt.soft.install('mysql');
																	},
																};
															})(),
															{
																type: 'select',
																hide: bt.config.mysql.setup ? false : true,
																name: 'codeing',
																width: '120px',
																value: other_config.codeing,
																list: [
																	{ title: 'utf8', value: 'utf8' },
																	{ title: 'utf8mb4', value: 'utf8mb4' },
																	{ title: 'gbk', value: 'gbk' },
																	{ title: 'big5', value: 'big5' },
																],
															},
														],
													},
													{
														label: '数据库账号',
														group: [
															{ type: 'text', value: other_config.datauser, name: 'datauser', placeholder: '创建数据库账号', width: '175px', style: { 'margin-right': '15px' } },
															{ label: '密码', value: other_config.datapassword, type: 'text', placeholder: '数据库密码', name: 'datapassword', width: '175px' },
														],
														help: {
															class: '',
															style: '',
															list: ['创建站点的同时，为站点创建一个对应的数据库帐户，方便不同站点使用不同数据库。'],
														},
													},
													{
														label: 'PHP版本',
														group: [
															{
																type: 'select',
																name: 'version',
																width: '120px',
																placeholder: '无支持版本',
																list: php_version,
															},
															(function () {
																if (php_version.length) return {};
																return {
																	type: 'link',
																	title: '点击安装',
																	name: 'installed_php',
																	event: function () {
																		installPhp($('.dep_mode.active').data('versions'));
																	},
																};
															})(),
														],
													},
													{
														label: '',
														group: {
															type: 'button',
															title: '保存配置',
															name: 'save_dep_config',
															event: function (formData, element, that) {
																if (formData.datauser === '' || $.trim(formData.datauser) === '') return bt_tools.msg('数据库账号不能为空！', 2);
																if (formData.datapassword === '' || $.trim(formData.datapassword) === '') return bt_tools.msg('数据库密码不能为空！', 2);
																other_config.datauser = formData.datauser;
																other_config.datapassword = formData.datapassword;
																other_config.codeing = formData.codeing;
																other_config.php = formData.version === undefined ? '' : formData.version;
																otherConfig(other_config);
																layer.close(indexs);
															},
														},
													},
												],
											});
										},
									});
								});
								//模板点击事件公共
								function is_vespub(data) {
									(php_version = []), (n = 0);
									clear_other_config();
									for (var i = res.length - 1; i >= 0; i--) {
										if (data.versions.toString().indexOf(res[i].version) != -1) {
											php_version.push({ title: res[i].name, value: res[i].version });
											n++;
										}
									}
									var timestamp = new Date().getTime().toString();
									var dtpw = timestamp.substring(7);
									other_config.datauser = 'sql' + dtpw;
									other_config.datapassword = _getRandomString(10);
									other_config.php = php_version.length ? php_version[0].value : '';
									otherConfig(other_config);
									$('.funcReleaseMsg').remove();
									if (data.enable_functions.length > 2) {
										$('.keydept .line:eq(4) .c9.mt5').after('<div class="funcReleaseMsg color-red mt5">注意：部署此项目，以下函数将被解禁：' + data.enable_functions + '</div>');
									}
								}
								//打开更多模板
								function depMoreClick() {
									layer.open({
										type: 1,
										title: '模板',
										area: ['840px', '660px'],
										closeBtn: 2,
										shadeClose: false,
										content:
											'<div id="render_deployment" class="anim-content"><div class="anim-content-left"><p data-type="many">精选推荐</p><p data-type="all">全部</p></div>\
                    <div class="anim-content-right">\
                      <div class="right-top">\
                        <div class="right-top-search">\
                            <input type="text" class="search-input" placeholder="请输入搜索内容" style="flex: 1;">\
                            \
                            <button type="button" class="ser-sub pull-left"></button>\
                        </div>\
                    </div>\
                    <div class="right-bottom"></div>\
                  </div></div>',
										success: function (layers, indexs) {
											var type_html = '',
												left_type = $('.anim-content-left'),
												cont_mode = $('#render_deployment .right-bottom');
											//分类
											$.each(rdata.dep_type, function (i, item) {
												type_html += '<p data-type="' + item.tid + '">' + item.title + '</p>';
											});
											left_type.append(type_html);
											setTimeout(function () {
												left_type.find('p').eq(0).click();
											}, 50);
											left_type.find('p').click(function () {
												$(this).addClass('checked').siblings().removeClass('checked');
												var type = $(this).data('type'),
													con_html = '';
												$.each(rdata.list, function (i, item) {
													var ps = item.ps.replace('<a', ',,<a').split(',,');
													var html =
														'<div class="content-card">\
                          <div class="card-logo"><img src="' +
														item.min_image +
														'" alt="" width="100%"></div>\
                          <div class="card-info">\
                            <div class="card-info-title" title="' +
														item.title +
														'">' +
														item.title +
														'</div>\
                            <div class="card-info-text">\
                              <div>简介：<span class="synopsis" title="' +
														ps[0] +
														'">' +
														ps[0] +
														'</span>' +
														ps[1] +
														'</div>\
                              <div>版本：<span style="margin-right: 17px;">' +
														item.version +
														'</span>评分：<span>' +
														item.score +
														'</span></div>\
                            </div>\
                            <div class="card-bottom">\
                              <div class="gwinfo">官网：<a class="btlink" target="_blank" rel="noreferrer noopener" href="' +
														item.official +
														'">' +
														(item.author === '宝塔' ? item.official.replace(/^http[s]?:\/\//, '').split('/')[0] : item.author) +
														'</a></div>\
                              <div class="btn-click" data-index="' +
														i +
														'">选择模板</div>\
                            </div>\
                          </div>\
                        </div>';
													switch (type) {
														case 'many':
															if (item.is_many === 0) con_html += html;
															break;
														case 'all':
															con_html += html;
															break;
														default:
															if (item.type === type) con_html += html;
															break;
													}
												});
												cont_mode.html(con_html);
												var idxs = $('.dep_mode.active').data().idxs;
												$('.content-card')
													.find('[data-index="' + idxs + '"]')
													.parent()
													.parent()
													.parent()
													.addClass('active')
													.siblings()
													.removeClass('active');
											});
											$('#render_deployment .right-bottom').on('click', '.btn-click', function () {
												var index = $(this).data('index');
												data = rdata.list[index];
												if (index >= 5) {
													index = 5;
													dep_mode
														.eq(index)
														.empty()
														.append(
															'<div><img src="' +
																data.min_image +
																'" />' +
																'<span class="dep_title">' +
																data.title +
																' ' +
																data.version +
																'</span>' +
																'</div><div><a class="dep_more btlink">更多模板>></a></div>'
														);
													dep_mode.eq(index).css({ 'align-items': 'center', 'text-align': 'left', 'line-height': '22px' });
													$('.dep_more').css({ 'line-height': '12px', dispaly: 'inlineBlock' });
													dep_mode
														.eq(index)
														.data('idxs', index)
														.data('codename', data.name)
														.data('version', data.version)
														.data('versions', data.php)
														.data('title', data.title)
														.data('enable_functions', data.enable_functions);
													$('.dep_more').click(function () {
														depMoreClick();
													});
												}
												dep_mode.eq(index).addClass('active').siblings().removeClass('active');
												data['img'] = data.min_image;
												data['codename'] = data.name;
												data['versions'] = data.php;
												is_vespub(data);
												layer.close(indexs);
											});
										},
									});
								}
								//清空其他配置
								function clear_other_config() {
									other_config.php = '';
									other_config.datauser = '';
									other_config.datapassword = '';
								}
								//渲染模板部署
								function render_dep_mode() {
									var deployment_line_info = '';
									for (var i = 0; i < rdata.list.length; i++) {
										var item = rdata.list[i];
										if (i > 5) continue;
										var ps = item.ps.replace('<a', ',,<a').split(',,');
										if (i === 5) {
											deployment_line_info += '<div class="dep_mode dep_mode_more">' + '<a class="dep_more btlink">更多模板>></a>' + '</div>';
										} else {
											deployment_line_info +=
												'<div class="dep_mode" data-idxs="' +
												i +
												'" data-codename="' +
												item.name +
												'" data-version="' +
												item.version +
												'" data-versions="' +
												item.php +
												'" data-title="' +
												item.title +
												'" data-enable_functions="' +
												item.enable_functions +
												'">' +
												// (item.is_many === 0 ? '<span class="recommend-pay-icon"></span>':'')+
												'<img src="' +
												item.min_image +
												'" />' +
												'<span><span class="dep_title">' +
												item.title +
												' ' +
												item.version +
												'</span>' +
												'<div class="dep_ps"><span>' +
												ps[0] +
												'</span></div></span>' +
												'</div>';
										}
									}
									deployment_line.empty().append(deployment_line_info);
								}
								//渲染其他配置
								function otherConfig(database) {
									var db_html = '',
										phpVersions = $('.dep_mode.active').data('versions');
									db_html += '<span class="mr10">数据库：' + (bt.config['mysql'].setup ? database.dataname + '数据库' : '<a class="btlink install_database">未安装数据库，点击安装</a>') + '</span>';
									if (bt.config['mysql'].setup)
										db_html +=
											'<span class="mr10">编码：' +
											database.codeing +
											'</span>\
                  <span class="mr10" title="' +
											database.datauser +
											'">账号：' +
											database.datauser +
											'</span>\
                  <span title="' +
											database.datapassword +
											'">密码：' +
											database.datapassword +
											'</span>';
									database_info.empty().append(db_html);
									php_info
										.empty()
										.append('PHP版本：' + (database.php === '' ? '<span class="bterror">缺少被支持的PHP版本(' + phpVersions + ')<a class="btlink install_php">>>立即安装</a></span>' : database.php));
									$('.install_database').click(function () {
										bt.soft.install('mysql');
									});
									$('.install_php').click(function () {
										installPhp(phpVersions);
									});
								}
								//安装php版本
								function installPhp(phpVersions) {
									var item = phpVersions.toString().split(','),
										versions = [],
										select = '',
										html = '';
									for (var i = 0; i < item.length; i++) {
										var num = (parseInt(item[i]) / 10).toFixed(1);
										versions.push({ m_version: 'php-' + num });
									}
									$.each(versions, function (index, item) {
										select += '<option data-index="' + index + '">' + item.m_version + '</option>';
									});
									html += '<select id="SelectVersion" class="bt-input-text ml10" style="margin-left:10px">' + select + '</select>';
									var loadOpen = bt.open({
										type: 1,
										title: 'php软件安装',
										area: '400px',
										btn: [lan['public'].submit, lan['public'].close],
										content:
											"<div class='bt-form pd20 c6'>\
                    <div class='version line' style='padding-left:15px'>" +
											lan.soft.install_version +
											'：' +
											html +
											"</div>\
                    <div class='fangshi line' style='padding-left:15px;margin-bottom:0px'>" +
											lan.bt.install_type +
											"：<label data-title='" +
											lan.bt.install_src_title +
											"'>" +
											lan.bt.install_src +
											"<input type='checkbox' name='installType' value='0'></label><label data-title='" +
											lan.bt.install_rpm_title +
											"'>" +
											lan.bt.install_rpm +
											"<input type='checkbox' name='installType' value='1' checked></label></div>\
                    <div class='install_modules' style='display: none;'>\
                      <div style='margin-bottom:15px;padding-top:15px;border-top:1px solid #ececec;'><button onclick=\"bt.soft.show_make_args('" +
											name +
											"')\" class='btn btn-success btn-sm'>添加自定义模块</button></div>\
                      <div class='select_modules divtable' style='margin-bottom:20px'>\
                        <table class='table table-hover'>\
                          <thead>\
                            <tr>\
                              <th width='10px'></th>\
                              <th width='80px'>模块名称</th>\
                              <th >模块描述</th>\
                              <th width='80px'>操作</th>\
                            </tr>\
                          </thead>\
                          <tbody class='modules_list'></tbody>\
                        </table>\
                      </div>\
                    </div>\
                  </div>",
										success: function () {
											$('.fangshi input').click(function () {
												$(this).attr('checked', 'checked').parent().siblings().find('input').removeAttr('checked');
												var type = parseInt($('[name="installType"]:checked').val());
												if (type) {
													$('.install_modules').hide();
													return;
												}
												if (bt.soft.check_make_is('php')) {
													$('.install_modules').show();
													bt.soft.get_make_args('php');
												}
											});
										},
										yes: function (indexs, layers) {
											loadOpen.close();
											layer.close(indexs);
											var name = $('#SelectVersion option:selected').val();
											bt.soft.get_soft_find(name, function (rdata) {
												rdata['install_type'] = parseInt($('[name="installType"]:checked').val());
												if (rdata.versions.length > 1) {
													var index = $('#SelectVersion option:selected').attr('data-index');
													rdata['install_version'] = rdata.versions[index];
													bt.soft.install_soft(rdata, this);
												} else {
													rdata['install_version'] = rdata.versions[0];
													bt.soft.install_soft(rdata, this);
												}
											});
										},
									});
								}
								//生成n位随机密码
								function _getRandomString(len) {
									len = len || 32;
									var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'; // 默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1
									var maxPos = $chars.length;
									var pwd = '';
									for (i = 0; i < len; i++) {
										pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
									}
									return pwd;
								}
							});
						});
					},
				},
			],
		});
		bt_tools.open({
			title: '添加网站',
			skin: 'custom_layer',
			area: '700px',
			btn: ['提交', '取消'],
			content: web_tab.$reader_content(),
			success: function (layers) {
				web_tab.$init();
				$(layers)
					.find('.layui-layer-content')
					.css('overflow', window.innerHeight > $(layers).height() ? 'inherit' : 'auto');
			},
			yes: function (indexs) {
				var formValue = !web_tab.active ? add_web.$get_form_value() : web_tab.active === 1 ? keydept_web.$get_form_value() : bath_web.$get_form_value();
				if (!web_tab.active || web_tab.active === 1) {
					// 创建站点 //一键部署
					var loading = bt.load();
					if (!web_tab.active) {
						add_web.$get_form_element(true);
						if (formValue.webname === '') {
							add_web.form_element.webname.focus();
							bt_tools.msg('域名不能为空！', 2);
							return;
						}
					} else {
						keydept_web.$get_form_element(true);
						if (formValue.webname === '') {
							keydept_web.form_element.webname.focus();
							bt_tools.msg('域名不能为空！', 2);
							return;
						}
						if (!bt.config['mysql'].setup) {
							bt_tools.msg('未安装数据库！', 2);
							return;
						}
						if (other_config.php === '') {
							layer.msg('缺少被支持的PHP版本，请安装!', {
								icon: 5,
							});
							return;
						}
						if (other_config.datauser === '') {
							bt_tools.msg('数据库账号不能为空！', 2);
							return;
						}
						if (other_config.datapassword === '') {
							bt_tools.msg('数据库密码不能为空！', 2);
							return;
						}
					}
					var webname = bt.replace_all(formValue.webname, 'http[s]?:\\/\\/', ''),
						web_list = webname.split('\n'),
						param = { webname: { domain: '', domainlist: [], count: 0 }, port: 80 },
						arry = ['ps', ['path', '网站目录'], 'type_id', 'version', 'type', 'ftp', 'sql', 'ftp_username', 'ftp_password', 'datauser', 'datapassword', 'codeing'];
					for (var i = 0; i < web_list.length; i++) {
						var temps = web_list[i].replace(/\r\n/, '').split(':');
						if (i === 0) {
							param['webname']['domain'] = web_list[i].replace(/[\r\n]/g, '');
							if (typeof temps[1] != 'undefined') param['port'] = temps[1];
						} else {
							param['webname']['domainlist'].push(web_list[i]);
						}
					}
					param['webname']['count'] = param['webname']['domainlist'].length;
					param['webname'] = JSON.stringify(param['webname']);
					$.each(arry, function (index, item) {
						if (formValue[item] == '' && Array.isArray(item)) {
							bt_tools.msg(item[1] + '不能为空?', 2);
							return false;
						}
						Array.isArray(item) ? (item = item[0]) : '';
						if (formValue['ftp'] === 'false' && (item === 'ftp_username' || item === 'ftp_password')) return true;
						if (formValue['sql'] === 'false' && (item === 'datauser' || item === 'datapassword')) return true;
						param[item] = formValue[item];
					});
					if (typeof param.ftp === 'undefined') {
						param.ftp = false;
						delete param.ftp_password;
						delete param.ftp_username;
					}
					if (typeof param.sql === 'undefined') {
						param.sql = false;
						delete param.datapassword;
						delete param.datauser;
					}
					if (web_tab.active) {
						param['webname_1'] = webname;
						param['address'] = 'localhost';
						param['sql'] = true;
						param['datauser'] = other_config.datauser.replace(/[\r\n]/g, '');
						param['datapassword'] = other_config.datapassword;
						param['version'] = other_config.php;
						param['codeing'] = other_config.codeing;
						delete param.type;
						delete param.type_id;
					}
					bt.send('AddSite', 'site/AddSite', param, function (rdata) {
						loading.close();
						if (rdata.siteStatus) {
							layer.close(indexs);
							// site_table.$refresh_table_list(true);
							if (callback) callback(rdata, param);
							var html = '',
								ftpData = '',
								sqlData = '';
							if (rdata.ftpStatus) {
								var list = [];
								list.push({ title: lan.site.user, val: rdata.ftpUser });
								list.push({ title: lan.site.password, val: rdata.ftpPass });
								var item = {};
								item.title = lan.site.ftp;
								item.list = list;
								ftpData = bt.render_web(item);
							}
							if (rdata.databaseStatus) {
								var list = [];
								list.push({ title: lan.site.database_name, val: rdata.databaseUser });
								list.push({ title: lan.site.user, val: rdata.databaseUser });
								list.push({ title: lan.site.password, val: rdata.databasePass });
								var item = {};
								item.title = lan.site.database_txt;
								item.list = list;
								sqlData = bt.render_web(item);
							}
							var dep_cont = $('.dep_mode.active').data();
							if (web_tab.active) {
								//一键部署
								if (!rdata.databaseStatus) {
									sqlData =
										"<p class='p1'>数据库账号资料</p>\
                    <p><span>数据库名：</span><strong>数据库创建失败,请检查是否存在同名数据库!</strong></p>\
                    <p><span>用户：</span><strong>数据库创建失败,请检查是否存在同名数据库!</strong></p>\
                                  <p><span>密码：</span><strong>数据库创建失败,请检查是否存在同名数据库!</strong></p>\
                                ";
								}
								var pdata = {
									dname: dep_cont.codename,
									site_name: web_list[0].replace(/[\r\n]/g, '').split(':')[0],
									php_version: param.version,
									source: 1,
								};
								var loadT = layer.msg('<div class="depSpeed">正在提交 <img src="/static/img/ing.gif"></div>', {
									icon: 16,
									time: 0,
									shade: [0.3, '#000'],
								});
								var intervalGetSpeed = setInterval(function () {
									GetSpeed();
								}, 2000);
								bt.send('SetupPackage', 'deployment/SetupPackage', pdata, function (res) {
									layer.close(loadT);
									clearInterval(intervalGetSpeed);
									if (!res.status) {
										layer.msg(res.msg, {
											icon: 5,
											time: 10000,
										});
										return;
									}
									lan.site.success_txt = '已成功部署【' + dep_cont.title + '】';
									if (res.msg.admin_username != '') {
										sqlData =
											"<p class='p1'>已成功部署，无需安装，请登录修改默认账号密码</p>\
                            <p><span>用户：</span><strong>" +
											rdata.msg.admin_username +
											'</strong></p>\
                            <p><span>密码：</span><strong>' +
											rdata.msg.admin_password +
											'</strong></p>\
                            ';
									}
									sqlData +=
										"<p><span>访问站点：</span><a class='btlink' href='http://" +
										(web_list[0] + '/' + res.msg.success_url).replace('//', '/') +
										"' target='_blank' rel='noreferrer noopener'>http://" +
										(web_list[0] + '/' + res.msg.success_url).replace('//', '/') +
										'</a></p>';
									// pub()
									webPub(JSON.parse(param.webname).domain);
								});
							} else {
								if (ftpData == '' && sqlData == '') {
									// bt.msg({ msg: lan.site.success_txt, icon: 1 })
									webPub(JSON.parse(param.webname).domain);
								} else {
									// pub()
									webPub(JSON.parse(param.webname).domain);
								}
							}
							function pub() {
								bt.open({
									type: 1,
									area: ['600px', '560px'],
									title: lan.site.success_txt,
									closeBtn: 2,
									shadeClose: false,
									content: "<div class='success-msg'><div class='pic'><img src='/static/images/svg/success-web.svg'></div><div class='suc-con'>" + ftpData + sqlData + '</div></div>',
								});
								if (web_tab.active) $('.suc-con p').eq(4).remove();
								if ($('.success-msg').height() < 150) {
									$('.success-msg').find('img').css({ width: '150px', 'margin-top': '30px' });
								}
							}
							function webPub(webname) {
								var area1 = ['600px', '560px'];
								var area2 = ['600px', '392px'];
								var creat_info =
									'<div class="creat_info">' +
									'<div class="creat_info_box">' +
									'<div class="ftp_info ' +
									(ftpData ? 'ftp_info_margin' : 'no_info_margin') +
									'">' +
									(ftpData ? ftpData : '<div class="no_craet_info"><span class="ftp_img">未创建FTP</span></div>') +
									'</div>' +
									'<p class="line"></p>' +
									'<div class="database_info  ' +
									(sqlData ? 'database_info_margin' : 'no_info_margin') +
									'"">' +
									(sqlData ? '<div class="spl_box">' + sqlData + '</div>' : '<div class="no_craet_info"><span class="database_img">未创建数据库</span></div>') +
									'</div>' +
									'</div>' +
									'<div class="copy_box"><div class="all_copy" title="一键复制">一键复制<img src="/static/images/svg/allCopy.svg" class="copy_img"></div></div>' +
									'</div>';

								var kong = ftpData || sqlData;
								var content =
									'<div id="creatWebBg">' +
									'<div class="craet_title">' +
									'<img src="/static/img/success-pic.png">' +
									'[' +
									webname +
									']' +
									lan.site.success_txt +
									'</div>' +
									(kong ? creat_info : '') +
									'<div class="host_log_box ' +
									(kong ? 'host_border' : '') +
									'">' +
									'<div class="host_title ' +
									(kong ? 'text-center' : 'text-left') +
									'">如果需要进行本地测试，请添加hosts记录：</div>' +
									(kong ? '' : '<p class="dotted_line"></p>') +
									'<div class="subtitle">使用管理员权限运行cmd，执行下面命令</div>' +
									'<div class="host_log">' +
									'<p class="item_title">云服务器添加hosts记录</p>' +
									'<div class="input_flex web"><input type="text" disabled value="" class="web_host"></input><div class="img_box" title="复制"><img src="/static/images/svg/copyImg.svg" class="copy_img"></div></div>' +
									'</div>' +
									'<div class="host_log">' +
									'<p class="item_title">添加本机hosts记录</p>' +
									'<div class="input_flex local"><input type="text" disabled value="" class="local_host"></input><div class="img_box" title="复制"><img src="/static/images/svg/copyImg.svg" class="copy_img"></div></div>' +
									'</div>' +
									'</div>' +
									'</div>';

								bt.open({
									type: 1,
									area: kong ? area1 : area2,
									title: '',
									closeBtn: 2,
									shadeClose: false,
									content: content,
									success: function () {
										var copyImg =
											'<svg viewBox="0 0 10 11.5862" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M8.65952 9.83289L8.65952 10.4871L10 10.4871L10 0L1.78955 0L1.78955 1.30841L2.45978 1.30841L2.45978 0.654236L9.32977 0.654236L9.32977 9.83289L8.65952 9.83289M0 1.81219L0 11.4489C0 11.5247 0.061676 11.5862 0.138062 11.5862L8.07172 11.5862C8.1488 11.5862 8.21045 11.5254 8.21045 11.4489L8.21045 1.81219C8.21045 1.73627 8.1488 1.6748 8.07239 1.6748L0.138062 1.6748C0.061676 1.6748 0 1.73566 0 1.81219L0 1.81219M0.670227 2.32904L7.54022 2.32904L7.54022 10.932L0.670227 10.932L0.670227 2.32904M1.34048 3.63745L6.86996 3.63745L6.86996 4.29169L1.34048 4.29169L1.34048 3.63745M1.34048 5.6001L6.86996 5.6001L6.86996 6.25433L1.34048 6.25433L1.34048 5.6001M1.34048 7.56274L6.86996 7.56274L6.86996 8.21698L1.34048 8.21698L1.34048 7.56274Z" fill-rule="evenodd" fill="#20A53A"/><defs/></svg>';
										$('.copy_img').html(copyImg);
										var ipAdress = localStorage.getItem('mypcip');
										var webHost = 'echo ' + ipAdress + ' ' + webname + ' >> C:\\Windows\\System32\\drivers\\etc\\hosts';
										var ftpCopy = 'FTP账号资料\n' + lan.site.user + '：' + rdata.ftpUser + '\n' + lan.site.password + '：' + rdata.ftpPass;
										var database =
											'数据库账号资料\n' + lan.site.database_name + '：' + rdata.databaseUser + '\n' + lan.site.user + '：' + rdata.databaseUser + '\n' + lan.site.password + '：' + rdata.databasePass;
										var allCopy = (ftpData ? ftpCopy : '') + (ftpData && sqlData ? '\n\n' : '') + (sqlData ? database : '');
										$('.web_host').val(webHost);
										$('.local_host').val(webHost);
										$('.all_copy').on('click', function () {
											bt.pub.copy_pass(allCopy);
										});
										$('.web .img_box').on('click', function () {
											bt.pub.copy_pass(webHost);
										});
										$('.local .img_box').on('click', function () {
											bt.pub.copy_pass(webHost);
										});
									},
								});
							}
						} else {
							bt.msg(rdata);
						}
					});
				} else {
					//批量创建
					var loading = bt.load();
					if (formValue.bath_code === '') {
						bt_tools.msg('请输入需要批量创建的站点信息!', 2);
						return false;
					} else {
						var arry = formValue.bath_code.split('\n'),
							config = '',
							_list = [];
						for (var i = 0; i < arry.length; i++) {
							var item = arry[i],
								params = item.split('|'),
								_arry = [];
							if (item === '') continue;
							for (var j = 0; j < params.length; j++) {
								var line = i + 1,
									items = bt.strim(params[j]);
								_arry.push(items);
								switch (j) {
									case 0: //参数一:域名
										var domainList = items.split(',');
										for (var z = 0; z < domainList.length; z++) {
											var domain_info = domainList[z].trim(),
												_domain = domain_info.split(':');
											if (!bt.check_domain(_domain[0])) {
												bt_tools.msg('第' + line + '行,域名格式错误【' + domain_info + '】，可用范围：1-65535', 2);
												return false;
											}
											if (typeof _domain[1] !== 'undefined') {
												if (!bt.check_port(_domain[1])) {
													bt_tools.msg('第' + line + '行,域名端口格式错误【' + _domain[1] + '】，可用范围：1-65535', 2);
													return false;
												}
											}
										}
										break;
									case 1: //参数二:站点目录
										if (items !== '1') {
											if (items.indexOf('/') < -1) {
												bt_tools.msg('第' + line + '行,站点目录格式错误【' + items + '】', 2);
												return false;
											}
										}
										break;
								}
							}
							_list.push(_arry.join('|').replace(/\r|\n/, ''));
						}
					}
					bt.send('create_type', 'site/create_website_multiple', { create_type: 'txt', websites_content: JSON.stringify(_list) }, function (rdata) {
						loading.close();
						if (rdata.status) {
							var _html = '';
							layer.close(indexs);
							if (callback) callback(rdata);
							$.each(rdata.error, function (key, item) {
								_html += '<tr><td>' + key + '</td><td>--</td><td>--</td><td style="text-align: right;"><span style="color:red">' + item + '</td></td></tr>';
							});
							$.each(rdata.success, function (key, item) {
								_html +=
									'<tr><td>' +
									key +
									'</td><td>' +
									(item.ftp_status ? '<span style="color:#20a53a">成功</span>' : '<span>未创建</span>') +
									'</td><td>' +
									(item.db_status ? '<span style="color:#20a53a">成功</span>' : '<span>未创建</span>') +
									'</td><td  style="text-align: right;"><span style="color:#20a53a">创建成功</span></td></tr>';
							});
							bt.open({
								type: 1,
								title: '站点批量添加',
								area: ['500px', '450px'],
								shadeClose: false,
								closeBtn: 2,
								content:
									'<div class="fiexd_thead divtable" style="margin: 15px 30px 15px 30px;overflow: auto;height: 360px;"><table class="table table-hover"><thead><tr><th>站点名称</th><th>FTP</th><th >数据库</th><th style="text-align:right;width:150px;">操作结果</th></tr></thead><tbody>' +
									_html +
									'</tbody></table></div>',
								success: function () {
									$('.fiexd_thead').scroll(function () {
										var scrollTop = this.scrollTop;
										this.querySelector('thead').style.transform = 'translateY(' + scrollTop + 'px)';
									});
								},
							});
						} else {
							bt.msg(rdata);
						}
					});
				}
			},
		});
	},
	set_default_page: function () {
		bt.open({
			type: 1,
			area: '460px',
			title: lan.site.change_defalut_page,
			closeBtn: 2,
			shift: 0,
			content:
				'<div class="change-default pd20"><button  class="btn btn-default btn-sm ">' +
				lan.site.default_doc +
				'</button><button  class="btn btn-default btn-sm">' +
				lan.site.err_404 +
				'</button>	<button  class="btn btn-default btn-sm ">' +
				lan.site.empty_page +
				'</button><button  class="btn btn-default btn-sm ">' +
				lan.site.default_page_stop +
				'</button></div>',
		});
		setTimeout(function () {
			$('.change-default button').click(function () {
				bt.site.get_default_path($(this).index(), function (path) {
					bt.pub.on_edit_file(0, path);
				});
			});
		}, 100);
	},
	set_default_site: function () {
		bt.site.get_default_site(function (rdata) {
			var arrs = [
				{
					title: lan.site.default_site_no,
					value: 'off',
				},
			];
			for (var i = 0; i < rdata.sites.length; i++)
				arrs.push({
					title: rdata.sites[i].name,
					value: rdata.sites[i].name,
				});
			var form = {
				title: lan.site.default_site_yes,
				area: ['530px', '230px'],
				list: [
					{
						title: lan.site.default_site,
						name: 'defaultSite',
						width: '300px',
						value: rdata.defaultSite,
						type: 'select',
						items: arrs,
					},
				],
				btns: [
					bt.form.btn.close(),
					bt.form.btn.submit('提交', function (rdata, load) {
						bt.site.set_default_site(rdata.defaultSite, function (rdata) {
							load.close();
							bt.msg(rdata);
						});
					}),
				],
			};
			bt.render_form(form);
			$('.line').after(
				$(bt.render_help([lan.site.default_site_help_1, lan.site.default_site_help_2]))
					.css({
						bottom: '60px',
					})
					.addClass('plr20')
			);
		});
	},
	// 安全设置
	open_safe_config: function () {
		bt.open({
			type: 1,
			title: 'HTTPS防窜站',
			area: '340px',
			closeBtn: 2,
			shift: 0,
			content:
				'\
            <div class="bt-form pd20">\
              <div class="line">\
                <span class="tname" style="width: 120px;">HTTPS防窜站</span>\
                <div class="info-r" style="height: 32px; margin-left: 120px; padding-top: 6px;">\
                  <input class="btswitch btswitch-ios" id="https_mode" type="checkbox" name="https_mode">\
                  <label class="btswitch-btn" for="https_mode" style="margin-bottom: 0;"></label>\
                </div>\
              </div>\
              <ul class="help-info-text c7 plr20">\
                <li>开启后可以解决HTTPS窜站的问题</li>\
                <li>不支持IP证书的防窜，直接使用IP访问的勿开</li>\
              </ul>\
            </div>\
          ',
			success: function ($layer) {
				this.init();
				$('#https_mode').change(function () {
					var loadT = bt.load('正在设置HTTPS防窜站，请稍候...');
					bt.send('set_https_mode', 'site/set_https_mode', {}, function (res) {
						loadT.close();
						bt.msg(res);
						if (!res.status) {
							var checked = $('#https_mode').is(':checked');
							$('#https_mode').prop('checked', !checked);
						}
					});
				});
			},
			init: function () {
				var loadT = bt.load('正在获取网站设置，请稍候...');
				bt.send('get_https_mode', 'site/get_https_mode', {}, function (res) {
					loadT.close();
					if (typeof res == 'boolean') {
						$('#https_mode').prop('checked', res);
					} else {
						bt.msg(res);
					}
				});
			},
		});
	},
	del_site: function (wid, wname, callback) {
		var rendom = bt.get_random_code(),
			num1 = rendom['num1'],
			num2 = rendom['num2'],
			title = '';
		title = typeof wname === 'function' ? '批量删除站点' : '删除站点 [ ' + wname + ' ]';
		recycle_bin_open = JSON.parse(bt.get_cookie('is_recycle')) || bt.get_cookie('is_recycle') == null ? true : false;
		layer.open({
			type: 1,
			title: title,
			icon: 0,
			skin: 'delete_site_layer',
			area: '440px',
			closeBtn: 2,
			shadeClose: true,
			content:
				"<div class='bt-form webDelete pd30' id='site_delete_form'>" +
				'<i class="layui-layer-ico layui-layer-ico0"></i>' +
				"<div class='f13 check_title'>是否要删除关联的FTP、数据库、站点目录！</div>" +
				'<div class="check_type_group">' +
				'<label><input type="checkbox" name="ftp"><span>FTP</span></label>' +
				'<label><input type="checkbox" name="database"><span>数据库</span>' +
				(!recycle_bin_db_open ? '<span class="glyphicon glyphicon-info-sign" style="color: red"></span>' : '') +
				'</label>' +
				'<label><input type="checkbox"  name="path"><span class=\'' +
				!recycle_bin_open +
				"'>站点目录</span>" +
				(!recycle_bin_open ? '<span class="glyphicon glyphicon-info-sign" style="color: red"></span>' : '') +
				'</label>' +
				'</div>' +
				"<div class='vcode'>" +
				lan.bt.cal_msg +
				"<span class='text'>" +
				num1 +
				' + ' +
				num2 +
				"</span>=<input type='number' id='vcodeResult' value=''></div>" +
				'</div>',
			btn: [lan.public.ok, lan.public.cancel],
			success: function (layers, indexs) {
				$(layers)
					.find('.check_type_group label')
					.hover(
						function () {
							var name = $(this).find('input').attr('name');
							if (name === 'database' && !recycle_bin_db_open) {
								layer.tips('风险操作：当前数据库回收站未开启，删除数据库将永久消失！', this, { tips: [1, 'red'], time: 0 });
							} else if (name === 'path' && !recycle_bin_open) {
								layer.tips('风险操作：当前文件回收站未开启，删除站点目录将永久消失！', this, { tips: [1, 'red'], time: 0 });
							}
						},
						function () {
							layer.closeAll('tips');
						}
					);
			},
			yes: function (indexs) {
				var vcodeResult = $('#vcodeResult'),
					data = { id: wid, webname: wname };
				$('#site_delete_form input[type=checkbox]').each(function (index, item) {
					if ($(item).is(':checked')) data[$(item).attr('name')] = 1;
				});
				if (vcodeResult.val() === '') {
					layer.tips('计算结果不能为空', vcodeResult, { tips: [1, 'red'], time: 3000 });
					vcodeResult.focus();
					return false;
				} else if (parseInt(vcodeResult.val()) !== num1 + num2) {
					layer.tips('计算结果不正确', vcodeResult, { tips: [1, 'red'], time: 3000 });
					vcodeResult.focus();
					return false;
				}
				var is_database = data.hasOwnProperty('database'),
					is_path = data.hasOwnProperty('path'),
					is_ftp = data.hasOwnProperty('ftp');
				if (!is_database && !is_path && (!is_ftp || is_ftp)) {
					if (typeof wname === 'function') {
						wname(data);
						return false;
					}
					bt.site.del_site(data, function (rdata) {
						layer.close(indexs);
						if (callback) callback(rdata);
						bt.msg(rdata);
					});
					return false;
				}
				if (typeof wname === 'function') {
					delete data.id;
					delete data.webname;
				}
				layer.close(indexs);
				var arrs = wid instanceof Array ? wid : [wid];
				var ids = JSON.stringify(arrs),
					countDown = 9;
				if (arrs.length == 1) countDown = 4;
				title = typeof wname === 'function' ? '二次验证信息，批量删除站点' : '二次验证信息，删除站点 [ ' + wname + ' ]';
				var loadT = bt.load('正在检测站点数据信息，请稍后...');
				bt.send('check_del_data', 'site/check_del_data', { ids: ids }, function (res) {
					loadT.close();
					layer.open({
						type: 1,
						title: title,
						closeBtn: 2,
						skin: 'verify_site_layer_info active',
						area: '740px',
						content:
							'<div class="check_delete_site_main pd30">' +
							'<i class="layui-layer-ico layui-layer-ico0"></i>' +
							'<div class="check_layer_title">堡塔温馨提示您，请冷静几秒钟，确认以下要删除的数据。</div>' +
							'<div class="check_layer_content">' +
							'<div class="check_layer_item">' +
							'<div class="check_layer_site"></div>' +
							'<div class="check_layer_database"></div>' +
							'</div>' +
							'</div>' +
							'<div class="check_layer_error ' +
							(is_database && data['database'] && !recycle_bin_db_open ? '' : 'hide') +
							'"><span class="glyphicon glyphicon-info-sign"></span>风险事项：当前未开启数据库回收站功能，删除数据库后，数据库将永久消失！</div>' +
							'<div class="check_layer_error ' +
							(is_path && data['path'] && !recycle_bin_open ? '' : 'hide') +
							'"><span class="glyphicon glyphicon-info-sign"></span>风险事项：当前未开启文件回收站功能，删除站点目录后，站点目录将永久消失！</div>' +
							'<div class="check_layer_message">请仔细阅读以上要删除信息，防止网站数据被误删，确认删除还有 <span style="color:red;font-weight: bold;">' +
							countDown +
							'</span> 秒可以操作。</div>' +
							'</div>',
						// recycle_bin_db_open &&
						// recycle_bin_open &&
						btn: ['确认删除(' + countDown + '秒后继续操作)', '取消删除'],
						success: function (layers) {
							var html = '',
								rdata = res.data;
							for (var i = 0; i < rdata.length; i++) {
								var item = rdata[i],
									newTime = parseInt(new Date().getTime() / 1000),
									t_icon = '<span class="glyphicon glyphicon-info-sign" style="color: red;width:15px;height: 15px;;vertical-align: middle;"></span>';

								(site_html = (function (item) {
									if (!is_path) return '';
									var is_time_rule = newTime - item.st_time > 86400 * 30 && item.total > 1024 * 10,
										is_path_rule = res.file_size <= item.total,
										dir_time = bt.format_data(item.st_time, 'yyyy-MM-dd'),
										dir_size = bt.format_size(item.total);

									var f_html = '<i ' + (is_path_rule ? 'class="warning"' : '') + ' style = "vertical-align: middle;" > ' + dir_size + '</i> ' + (is_path_rule ? t_icon : '');
									var f_title = (is_path_rule ? '注意：此目录较大，可能为重要数据，请谨慎操作.\n' : '') + '目录：' + item.path + '(' + (item.limit ? '大于' : '') + dir_size + ')';

									return (
										'<div class="check_layer_site">' +
										'<span title="站点：' +
										item.name +
										'">站点名：' +
										item.name +
										'</span>' +
										'<span title="' +
										f_title +
										'" >目录：<span style="vertical-align: middle;max-width: 160px;width: auto;">' +
										item.path +
										'</span> (' +
										f_html +
										')</span>' +
										'<span title="' +
										(is_time_rule ? '注意：此站点创建时间较早，可能为重要数据，请谨慎操作.\n' : '') +
										'时间：' +
										dir_time +
										'">创建时间：<i ' +
										(is_time_rule ? 'class="warning"' : '') +
										'>' +
										dir_time +
										'</i></span>' +
										'</div>'
									);
								})(item)),
									(database_html = (function (item) {
										if (!is_database || !item.database) return '';
										var is_time_rule = newTime - item.st_time > 86400 * 30 && item.total > 1024 * 10,
											is_database_rule = res.db_size <= item.database.total,
											database_time = bt.format_data(item.database.st_time, 'yyyy-MM-dd'),
											database_size = bt.format_size(item.database.total);

										var f_size = '<i ' + (is_database_rule ? 'class="warning"' : '') + ' style = "vertical-align: middle;" > ' + database_size + '</i> ' + (is_database_rule ? t_icon : '');
										var t_size = '注意：此数据库较大，可能为重要数据，请谨慎操作.\n数据库：' + database_size;

										return (
											'<div class="check_layer_database">' +
											'<span title="数据库：' +
											item.database.name +
											'">数据库：' +
											item.database.name +
											'</span>' +
											'<span title="' +
											t_size +
											'">大小：' +
											f_size +
											'</span>' +
											'<span title="' +
											(is_time_rule && item.database.total != 0 ? '重要：此数据库创建时间较早，可能为重要数据，请谨慎操作.' : '') +
											'时间：' +
											database_time +
											'">创建时间：<i ' +
											(is_time_rule && item.database.total != 0 ? 'class="warning"' : '') +
											'>' +
											database_time +
											'</i></span>' +
											'</div>'
										);
									})(item));
								if (site_html + database_html !== '') html += '<div class="check_layer_item">' + site_html + database_html + '</div>';
							}
							if (html === '') html = '<div style="text-align: center;width: 100%;height: 100%;line-height: 300px;font-size: 15px;">无数据</div>';
							$('.check_layer_content').html(html);
							var interVal = setInterval(function () {
								countDown--;
								$(layers)
									.find('.layui-layer-btn0')
									.text('确认删除(' + countDown + '秒后继续操作)');
								$(layers).find('.check_layer_message span').text(countDown);
							}, 1000);
							setTimeout(function () {
								$(layers).find('.layui-layer-btn0').text('确认删除');
								$(layers).find('.check_layer_message').html('<span style="color:red">注意：请仔细阅读以上要删除信息，防止网站数据被误删</span>');
								$(layers).removeClass('active');
								clearInterval(interVal);
							}, countDown * 1000);
						},
						yes: function (indes, layers) {
							if ($(layers).hasClass('active')) {
								layer.tips('请确认信息，稍后再尝试，还剩' + countDown + '秒', $(layers).find('.layui-layer-btn0'), { tips: [1, 'red'], time: 3000 });
								return;
							}
							if (typeof wname === 'function') {
								wname(data);
							} else {
								bt.site.del_site(data, function (rdata) {
									layer.closeAll();
									if (rdata.status) site.get_list();
									if (callback) callback(rdata);
									bt.msg(rdata);
								});
							}
						},
					});
				});
			},
		});
		if (bt.get_cookie('is_recycle') || bt.get_cookie('is_recycle') == null) {
			$('[name="path"]').attr('checked', true);
		} else {
			$('[name="path"]').removeProp('checked');
		}
	},

	batch_site: function (type, obj, result) {
		if (obj == undefined) {
			obj = {};
			var arr = [];
			result = {
				count: 0,
				error_list: [],
			};
			$('input[type="checkbox"].check:checked').each(function () {
				var _val = $(this).val();
				if (!isNaN(_val)) arr.push($(this).parents('tr').data('item'));
			});
			if (type == 'site_type') {
				bt.site.get_type(function (tdata) {
					var types = [];
					for (var i = 0; i < tdata.length; i++)
						types.push({
							title: tdata[i].name,
							value: tdata[i].id,
						});
					var form = {
						title: '设置站点分类',
						area: '530px',
						list: [
							{
								title: lan.site.default_site,
								name: 'type_id',
								width: '300px',
								type: 'select',
								items: types,
							},
						],
						btns: [
							bt.form.btn.close(),
							bt.form.btn.submit('提交', function (rdata, load) {
								var ids = [];
								for (var x = 0; x < arr.length; x++) ids.push(arr[x].id);
								bt.site.set_site_type(
									{
										id: rdata.type_id,
										site_array: JSON.stringify(ids),
									},
									function (rrdata) {
										if (rrdata.status) {
											load.close();
											site.get_list();
										}
										bt.msg(rrdata);
									}
								);
							}),
						],
					};
					bt.render_form(form);
				});
				return;
			}
			var thtml = "<div class='options'><label style=\"width:100%;\"><input type='checkbox' id='delpath' name='path'><span>" + lan.site.all_del_info + '</span></label></div>';
			bt.show_confirm(
				lan.site.all_del_site,
				"<a style='color:red;'>" + lan.get('del_all_site', [arr.length]) + '</a>',
				function () {
					if ($('#delpath').is(':checked')) obj.path = '1';
					obj.data = arr;
					bt.closeAll();
					site.batch_site(type, obj, result);
				},
				thtml
			);
			return;
		}
		var item = obj.data[0];
		switch (type) {
			case 'del':
				if (obj.data.length < 1) {
					site.get_list();
					bt.msg({
						msg: lan.get('del_all_site_ok', [result.count]),
						icon: 1,
						time: 5000,
					});
					return;
				}
				var data = {
					id: item.id,
					webname: item.name,
					path: obj.path,
				};
				bt.site.del_site(data, function (rdata) {
					if (rdata.status) {
						result.count += 1;
					} else {
						result.error_list.push({
							name: item.item,
							err_msg: rdata.msg,
						});
					}
					obj.data.splice(0, 1);
					site.batch_site(type, obj, result);
				});
				break;
		}
	},
	set_class_type: function () {
		var _form_data = bt.render_form_line({
			title: '',
			items: [
				{
					placeholder: '请填写分类名称',
					name: 'type_name',
					width: '50%',
					type: 'text',
				},
				{
					name: 'btn_submit',
					text: '添加',
					type: 'button',
					callback: function (sdata) {
						bt.site.add_type(sdata.type_name, function (ldata) {
							if (ldata.status) {
								$('[name="type_name"]').val('');
								site.get_class_type();
							}
							bt.msg(ldata);
						});
					},
				},
			],
		});
		bt.open({
			type: 1,
			area: '350px',
			title: '网站分类管理',
			closeBtn: 2,
			shift: 5,
			shadeClose: true,
			content:
				"<div class='bt-form edit_site_type'><div class='divtable mtb15' style='overflow:auto'>" +
				_form_data.html +
				"<table id='type_table' class='table table-hover' width='100%'></table></div></div>",
			success: function () {
				bt.render_clicks(_form_data.clicks);
				site.get_class_type(function (res) {
					$('#type_table').on('click', '.del_type', function () {
						var _this = $(this);
						var item = _this.parents('tr').data('item');
						if (item.id == 0) {
							bt.msg({
								icon: 2,
								msg: '默认分类不可删除/不可编辑!',
							});
							return;
						}
						bt.confirm(
							{
								msg: '是否确定删除分类？',
								title: '删除分类【' + item.name + '】',
							},
							function () {
								bt.site.del_type(item.id, function (ret) {
									if (ret.status) {
										site.get_class_type();
										bt.set_cookie('site_type', '-1');
									}
									bt.msg(ret);
								});
							}
						);
					});
					$('#type_table').on('click', '.edit_type', function () {
						var item = $(this).parents('tr').data('item');
						if (item.id == 0) {
							bt.msg({
								icon: 2,
								msg: '默认分类不可删除/不可编辑!',
							});
							return;
						}
						bt.render_form({
							title: '修改分类管理【' + item.name + '】',
							area: '350px',
							list: [
								{
									title: '分类名称',
									width: '150px',
									name: 'name',
									value: item.name,
								},
							],
							btns: [
								{
									title: '关闭',
									name: 'close',
								},
								{
									title: '提交',
									name: 'submit',
									css: 'btn-success',
									callback: function (rdata, load, callback) {
										bt.site.edit_type(
											{
												id: item.id,
												name: rdata.name,
											},
											function (edata) {
												if (edata.status) {
													load.close();
													site.get_class_type();
												}
												bt.msg(edata);
											}
										);
									},
								},
							],
						});
					});
				});
			},
		});
	},
	get_class_type: function (callback) {
		site.get_types(function (rdata) {
			bt.render({
				table: '#type_table',
				columns: [
					{
						field: 'name',
						title: '名称',
					},
					{
						field: 'opt',
						width: '80px',
						title: '操作',
						templet: function (item) {
							return '<a class="btlink edit_type" href="javascript:;">编辑</a> | <a class="btlink del_type" href="javascript:;">删除</a>';
						},
					},
				],
				data: rdata,
			});
			$('.layui-layer-page').css({
				'margin-top': '-' + $('.layui-layer-page').height() / 2 + 'px',
				top: '50%',
			});
			site.reader_site_type(rdata);
			if (callback) callback(rdata);
		});
	},
	pool: {
		reload: function (index) {
			if (index == undefined) index = 0;
			var _sel = $('#pool_tabs .on');
			if (_sel.length == 0) _sel = $('#pool_tabs span:eq(0)');
			_sel.trigger('click');
		},
	},
	ssl: {
		my_ssl_msg: null,
		my_select_domain_ssl_index: null,
		/**
		 * @description 设置域名信息
		 * @Date: 2021-03-31 17:05:38
		 * @param {*} oid
		 * @return {*}
		 */
		setupDomainInfo: function (oid, domains, path) {
			var html = '';
			for (var i = 0; i < domains.length; i++) {
				var item = domains[i];
				html += '<option value="' + item.value + '">' + item.title + '</option>';
			}
			bt.open({
				type: 1,
				title: '申请宝塔SSL证书',
				area: '520px',
				btn: ['确认', '取消'],
				content:
					'<div class="bt-form pd20"><div class="line">\
              <span class="tname">域名</span>\
              <div class="info-r"><select class="bt-input-text mr5 " name="domain" style="width:280px">' +
					html +
					'</select></div>\
            </div>\
            <ul class="help-info-text-info c7" style="position: relative;">\
              <li>申请之前，请确保域名已解析，如未解析会导致审核失败(包括根域名)</li>\
              <li>宝塔SSL申请的是TrustAsia DV SSL CA - G5证书，仅支持单个域名申请</li>\
              <li>有效期1年，不支持续签，到期后需要重新申请</li><li>建议使用二级域名为www的域名申请证书,此时系统会默认赠送顶级域名为可选名称</li>\
              <li>在未指定SSL默认站点时,未开启SSL的站点使用HTTPS会直接访问到已开启SSL的站点</li>\
              <li>宝塔SSL申请注意事项及教程 <a href="https://www.bt.cn/bbs/thread-33113-1-1.html" target="_blank" class="btlink"> 使用帮助</a></li><li><span style="color:red">IIS8.5以下版本，一台服务器只能存在一个SSL，多次部署会替换之前的SSL</span></li></ul>\
          </div>',
				yes: function () {
					bt_tools.send(
						'ssl/apply_order_byca',
						{ ssl_id: oid, domain: $('[name="domain"]').val(), path: path },
						function (res) {
							bt.msg(res);
						},
						{ plugin: true, load: '申请证书' }
					);
				},
			});
		},
		/**
		 * @description 证书caa解析验证
		 * @param {*} data
		 */
		ssl_caa_verify: function (data) {
			var data = JSON.parse(data),
				arry = [];
			if (!Array.isArray(data) && typeof data == 'object') {
				$.each(data, function (key, item) {
					$.each(item, function (index, items) {
						arry.push(
							$.extend(items, {
								domain: key,
								type: 'CAA记录',
							})
						);
					});
				});
			}
			bt.open({
				title: 'CAA记录检测',
				area: '500px',
				content:
					'<div class="pd15">' +
					'<div class="important-title" style="margin-bottom:10px">' +
					'<p><span class="glyphicon glyphicon-alert">&nbsp;检测到以下域名存在CAA记录，请手动删除，并重新申请。</span></p>' +
					'</div>' +
					'<div id="bt_caa_table"></div>' +
					'<ul class="help-info-text c7" style="font-size:13px;"><li>删除记录请到该域名对应的域名服务商，删除域名的CAA解析记录。</li></ul>' +
					'</div>',
				success: function () {
					var caa_table = bt_tools.table({
						el: '#bt_caa_table',
						data: arry,
						column: [
							{
								fid: 'domain',
								title: '域名',
							},
							{
								fid: 'type',
								title: '记录类型',
							},
							{
								fid: 'value',
								title: '记录值',
							},
						],
					});
				},
			});
		},
		//续签订单内
		renew_ssl: function (siteName, auth_type, index) {
			acme.siteName = siteName;
			if (index.length === 32 && index.indexOf('/') === -1) {
				acme.renew(index, function (rdata) {
					site.ssl.ssl_result(rdata, auth_type, siteName);
				});
			} else {
				acme.get_cert_init(index, siteName, function (cert_init) {
					acme.domains = cert_init.dns;
					var options = '<option value="http">文件验证 - HTTP</option>';
					for (var i = 0; i < cert_init.dnsapi.length; i++) {
						options += '<option value="' + cert_init.dnsapi[i].name + '">DNS验证 - ' + cert_init.dnsapi[i].title + '</option>';
					}
					acme.select_loadT = layer.open({
						title: "续签Let's Encrypt证书",
						type: 1,
						closeBtn: 2,
						shade: 0.3,
						area: '500px',
						offset: '30%',
						content:
							'<div style="margin: 10px;">\
                                    <div class="line ">\
                                        <span class="tname" style="padding-right: 15px;margin-top: 8px;">请选择验证方式</span>\
                                        <div class="info-r label-input-group ptb10">\
                                            <select class="bt-input-text" name="auth_to">' +
							options +
							'</select>\
                                            <span class="dnsapi-btn"></span>\
                                            <span class="renew-onkey"><button class="btn btn-success btn-sm mr5" style="margin-left: 10px;" onclick="site.ssl.renew_ssl_other()">一键续签</button></span>\
                                        </div>\
                                    </div>\
                                    <ul class="help-info-text c7">\
                                        <li>通配符证书不能使用【文件验证】，请选择DNS验证</li>\
                                        <li>使用【文件验证】，请确保没有开[启强制HTTPS/301重定向/反向代理]等功能</li>\
                                        <li>使用【阿里云DNS】【DnsPod】等验证方式需要设置正确的密钥</li>\
                                        <li>续签成功后，证书将在下次到期前30天尝试自动续签</li>\
                                        <li>使用【DNS验证 - 手动解析】续签的证书无法实现下次到期前30天自动续签</li>\
                                    </ul>\
                                  </div>',
						success: function (layers) {
							$("select[name='auth_to']").change(function () {
								var dnsapi = $(this).val();
								$('.dnsapi-btn').html('');
								for (var i = 0; i < cert_init.dnsapi.length; i++) {
									if (cert_init.dnsapi[i].name !== dnsapi) continue;
									acme.dnsapi = cert_init.dnsapi[i];
									if (!cert_init.dnsapi[i].data) continue;
									$('.dnsapi-btn').html('<button class="btn btn-default btn-sm mr5 set_dns_config" onclick="site.ssl.show_dnsapi_setup()">设置</button>');
									if (cert_init.dnsapi[i].data[0].value || cert_init.dnsapi[i].data[1].value) break;
									site.ssl.show_dnsapi_setup();
								}
							});
						},
					});
				});
			}
		},
		//续签其它
		renew_ssl_other: function () {
			var auth_to = $("select[name='auth_to']").val();
			var auth_type = 'http';
			if (auth_to === 'http') {
				if (JSON.stringify(acme.domains).indexOf('*.') !== -1) {
					layer.msg('包含通配符的域名不能使用文件验证(HTTP)!', {
						icon: 2,
					});
					return;
				}
				auth_to = acme.id;
			} else {
				if (auth_to !== 'dns') {
					if (auth_to === 'Dns_com') {
						acme.dnsapi.data = [
							{
								value: 'None',
							},
							{
								value: 'None',
							},
						];
					}
					if (!acme.dnsapi.data[0].value || !acme.dnsapi.data[1].value) {
						layer.msg('请先设置【' + acme.dnsapi.title + '】接口信息!', {
							icon: 2,
						});
						return;
					}
					auth_to = auth_to + '|' + acme.dnsapi.data[0].value + '|' + acme.dnsapi.data[1].value;
				}
				auth_type = 'dns';
			}
			layer.close(acme.select_loadT);
			acme.apply_cert(acme.domains, auth_type, auth_to, '0', function (rdata) {
				site.ssl.ssl_result(rdata, auth_type, acme.siteName);
			});
		},
		show_dnsapi_setup: function () {
			var dnsapi = acme.dnsapi;
			acme.dnsapi_loadT = layer.open({
				title: '设置【' + dnsapi.title + '】接口',
				type: 1,
				closeBtn: 0,
				shade: 0.3,
				area: '550px',
				offset: '30%',
				content:
					'<div class="bt-form bt-form pd20 pb70 ">\
                            <div class="line ">\
                                <span class="tname" style="width: 125px;">' +
					dnsapi.data[0].key +
					'</span>\
                                <div class="info-r" style="margin-left:120px">\
                                    <input name="' +
					dnsapi.data[0].name +
					'" class="bt-input-text mr5 dnsapi-key" type="text" style="width:330px" value="' +
					dnsapi.data[0].value +
					'">\
                                </div>\
                            </div>\
                            <div class="line ">\
                                <span class="tname" style="width: 125px;">' +
					dnsapi.data[1].key +
					'</span>\
                                <div class="info-r" style="margin-left:120px">\
                                    <input name="' +
					dnsapi.data[1].name +
					'" class="bt-input-text mr5 dnsapi-token" type="text" style="width:330px" value="' +
					dnsapi.data[1].value +
					'">\
                                </div>\
                            </div>\
                            <div class="bt-form-submit-btn">\
                                <button type="button" class="btn btn-sm btn-danger" onclick="layer.close(acme.dnsapi_loadT);">关闭</button>\
                                <button type="button" class="btn btn-sm btn-success dnsapi-save">保存</button>\
                            </div>\
                            <ul class="help-info-text c7">\
                                <li>' +
					dnsapi.help +
					'</li>\
                            </ul>\
                          </div>',
				success: function (layers) {
					$('.dnsapi-save').click(function () {
						var dnsapi_key = $('.dnsapi-key');
						var dnsapi_token = $('.dnsapi-token');
						pdata = {};
						pdata[dnsapi_key.attr('name')] = dnsapi_key.val();
						pdata[dnsapi_token.attr('name')] = dnsapi_token.val();
						acme.dnsapi.data[0].value = dnsapi_key.val();
						acme.dnsapi.data[1].value = dnsapi_token.val();
						bt.site.set_dns_api(
							{
								pdata: JSON.stringify(pdata),
							},
							function (ret) {
								if (ret.status) layer.close(acme.dnsapi_loadT);
								bt.msg(ret);
							}
						);
					});
				},
			});
		},
		set_cert: function (siteName, res) {
			var loadT = bt.load(lan.site.saving_txt);
			var pdata = {
				type: 1,
				siteName: siteName,
				key: res.private_key,
				csr: res.cert + res.root,
			};
			bt.send('SetSSL', 'site/SetSSL', pdata, function (rdata) {
				loadT.close();
				site.ssl.reload(2);
				layer.msg(res.msg, {
					icon: 1,
				});
			});
		},
		show_error: function (res, auth_type) {
			var area_size = '500px';
			var err_info = '';

			if (!res.msg[1].challenges[1]) {
				if (res.msg[1].challenges[0]) {
					res.msg[1].challenges[1] = res.msg[1].challenges[0];
				}
			}
			if (res.msg[1].status === 'invalid') {
				area_size = '600px';
				var trs = $('#dns_txt_jx tbody tr');
				var dns_value = '';

				for (var imd = 0; imd < trs.length; imd++) {
					if (trs[imd].outerText.indexOf(res.msg[1].identifier.value) == -1) continue;
					var s_tmp = trs[imd].outerText.split('\t');
					if (s_tmp.length > 1) {
						dns_value = s_tmp[1];
						break;
					}
				}

				err_info += '<p><span>验证域名:</span>' + res.msg[1].identifier.value + '</p>';
				if (auth_type === 'dns') {
					var check_url = '_acme-challenge.' + res.msg[1].identifier.value;
					err_info += '<p><span>验证解析:</span>' + check_url + '</p>';
					err_info += '<p><span>验证内容:</span>' + dns_value + '</p>';
					err_info += '<p><span>错误代码:</span>' + site.html_encode(res.msg[1].challenges[1].error.detail) + '</p>';
				} else {
					var check_url = 'http://' + res.msg[1].identifier.value + '/.well-known/acme-challenge/' + res.msg[1].challenges[0].token;
					err_info += "<p><span>验证URL:</span><a class='btlink' href='" + check_url + "' target='_blank'>点击查看</a></p>";
					err_info += '<p><span>验证内容:</span>' + res.msg[1].challenges[0].token + '</p>';
					err_info += '<p><span>错误代码:</span>' + site.html_encode(res.msg[1].challenges[0].error.detail) + '</p>';
				}
				err_info += "<p><span>验证结果:</span> <a style='color:red;'>验证失败</a></p>";

				layer.msg('<div class="ssl-file-error"><a style="color: red;font-weight: 900;">' + res.msg[0] + '</a>' + err_info + '</div>', {
					icon: 2,
					time: 0,
					shade: 0.3,
					shadeClose: true,
					area: area_size,
				});
			}
		},
		ssl_result: function (res, auth_type, siteName) {
			layer.close(acme.loadT);
			if (res.status === false && typeof res.msg === 'string') {
				bt.msg(res);
				return;
			}
			if (res.status === true || res.status === 'pending' || res.save_path !== undefined) {
				if (auth_type == 'dns' && res.status === 'pending') {
					var b_load = bt.open({
						type: 1,
						area: ['700px', '500px'],
						title: '手动解析TXT记录',
						closeBtn: 2,
						shift: 5,
						shadeClose: false,
						content:
							"<div class='divtable pd15 div_txt_jx' style='height:100%'>\
                                    <p class='mb15' >请按以下列表做TXT解析:</p>\
                                    <table id='dns_txt_jx' class='table table-hover'></table>\
                                    <div class='text-right mt10'>\
                                        <button class='btn btn-success btn-sm btn_check_txt' >验证</button>\
                                    </div>\
                                    </div>",
					});

					//手动验证事件
					$('.btn_check_txt').click(function () {
						acme.auth_domain(res.index, function (res1) {
							layer.close(acme.loadT);
							if (res1.status === true) {
								b_load.close();
								site.ssl.set_cert(siteName, res1);
							} else {
								site.ssl.show_error(res1, auth_type);
							}
						});
					});

					//显示手动验证信息
					setTimeout(function () {
						var data = [];
						acme_txt = '_acme-challenge.';
						for (var j = 0; j < res.auths.length; j++) {
							data.push({
								name: acme_txt + res.auths[j].domain.replace('*.', ''),
								type: 'TXT',
								txt: res.auths[j].auth_value,
								force: '是',
							});
							data.push({
								name: res.auths[j].domain.replace('*.', ''),
								type: 'CAA',
								txt: '0 issue "letsencrypt.org"',
								force: '否',
							});
						}
						bt.render({
							table: '#dns_txt_jx',
							columns: [
								{
									field: 'name',
									width: '220px',
									title: '解析域名',
								},
								{
									field: 'txt',
									title: '记录值',
								},
								{
									field: 'type',
									title: '类型',
								},
								{
									field: 'force',
									title: '必需',
								},
							],
							data: data,
						});
						$('.div_txt_jx').append(
							bt.render_help([
								'解析域名需要一定时间来生效,完成所以上所有解析操作后,请等待1分钟后再点击验证按钮',
								'可通过CMD命令来手动验证域名解析是否生效: nslookup -q=txt ' + acme_txt + res.auths[0].domain.replace('*.', ''),
								'若您使用的是宝塔云解析插件,阿里云DNS,DnsPod作为DNS,可使用DNS接口自动解析',
							])
						);
					});
					return;
				}
				site.ssl.set_cert(siteName, res);
				return;
			}

			site.ssl.show_error(res, auth_type);
		},
		get_renew_stat: function () {
			$.post('/ssl?action=Get_Renew_SSL', {}, function (task_list) {
				if (!task_list.status) return;
				var s_body = '';
				var b_stat = false;
				for (var i = 0; i < task_list.data.length; i++) {
					s_body += '<p>' + task_list.data[i].subject + ' >> ' + task_list.data[i].msg + '</p>';
					if (task_list.data[i].status !== true && task_list.data[i].status !== false) {
						b_stat = true;
					}
				}

				if (site.ssl.my_ssl_msg) {
					$('.my-renew-ssl').html(s_body);
				} else {
					site.ssl.my_ssl_msg = layer.msg('<div class="my-renew-ssl">' + s_body + '</div>', {
						time: 0,
						icon: 16,
						shade: 0.3,
					});
				}

				if (!b_stat) {
					setTimeout(function () {
						layer.close(site.ssl.my_ssl_msg);
						site.ssl.my_ssl_msg = null;
					}, 3000);
					return;
				}

				setTimeout(function () {
					site.ssl.get_renew_stat();
				}, 1000);
			});
		},
		onekey_ssl: function (partnerOrderId, siteName) {
			bt.site.get_ssl_info(partnerOrderId, siteName, function (rdata) {
				rdata.time = 0;
				bt.msg(rdata);
				if (rdata.status) site.reload(7);
			});
		},
		set_ssl_status: function (action, siteName) {
			bt.site.set_ssl_status(action, siteName, function (rdata) {
				bt.msg(rdata);
				if (rdata.status) {
					site.reload(7);
					if (action == 'CloseSSLConf') {
						layer.msg(lan.site.ssl_close_info, {
							icon: 1,
							time: 5000,
						});
					}
				}
			});
		},
		verify_domain: function (partnerOrderId, siteName) {
			bt.site.verify_domain(partnerOrderId, siteName, function (vdata) {
				bt.msg(vdata);
				if (vdata.status) {
					if (vdata.data.stateCode == 'COMPLETED') {
						site.ssl.onekey_ssl(partnerOrderId, siteName);
					} else {
						layer.msg('验证中,请等待CA机构验证,如第一次申请失败，请等待3小时或进入宝塔后台通过DNS方式验证.', {
							icon: 1,
							time: 0,
						});
					}
				}
			});
		},
		reload: function (index) {
			if (index == undefined) index = 0;
			var _sel = $('#ssl_tabs .on');
			if (_sel.length == 0) _sel = $('#ssl_tabs span:eq(0)');
			_sel.trigger('click');
		},
	},
	edit: {
		update_composer: function () {
			loadT = bt.load();
			$.post('/files?action=update_composer', { repo: $("select[name='repo']").val() }, function (v_data) {
				loadT.close();
				bt.msg(v_data);
				site.edit.set_composer(site.edit.compr_web);
			});
		},
		show_composer_log: function () {
			$.post('/ajax?action=get_lines', { filename: setup_path + '/panel/logs/composer.log', num: 30 }, function (v_body) {
				var log_obj = $('#composer-log');
				if (log_obj.length < 1) return;
				log_obj.html(v_body.msg);
				var div = document.getElementById('composer-log');
				div.scrollTop = div.scrollHeight;
				if (v_body.msg.indexOf('BT-Exec-Completed') != -1) {
					//layer.close(site.edit.comp_showlog);
					layer.msg('执行完成', { icon: 1 });
					site.edit.set_composer(site.edit.compr_web);
					return;
				}

				setTimeout(function () {
					site.edit.show_composer_log();
				}, 1000);
			});
		},
		comp_confirm: 0,
		comp_showlog: 0,
		exec_composer: function () {
			var title_msg = '执行Composer的影响范围取决于该目录下的composer.json配置文件，继续吗？';
			if ($("select[name='composer_args']").val()) {
				title_msg = '即将执行设定的composer命令，继续吗？';
			}
			site.edit.comp_confirm = layer.confirm(title_msg, { title: '确认执行Composer', closeBtn: 2, icon: 3 }, function (index) {
				layer.close(site.edit.comp_confirm);
				var pdata = {
					php_version: $("select[name='php_version']").val(),
					composer_args: $("select[name='composer_args']").val(),
					composer_cmd: $("input[name='composer_cmd']").val(),
					repo: $("select[name='repo']").val(),
					path: $("input[name='composer_path']").val(),
					user: $("select[name='composer_user']").val(),
				};
				var loading = bt.load();
				$.post('/files?action=exec_composer', pdata, function (rdatas) {
					loading.close();
					if (!rdatas.status) {
						layer.msg(rdatas.msg, { icon: 2 });
						return false;
					}
					if (rdatas.status === true) {
						site.edit.comp_showlog = layer.open({
							area: '800px',
							type: 1,
							shift: 5,
							closeBtn: 2,
							title: '在[' + pdata['path'] + ']目录执行Composer，执行完后，确认无问题后请关闭此窗口',
							content: "<pre id='composer-log' style='height: 400px;background-color: #333;color: #fff;margin: 0 0 0;'></pre>",
						});
						setTimeout(function () {
							site.edit.show_composer_log();
						}, 200);
					}
				});
			});
		},
		remove_composer_lock: function (path) {
			$.post('/files?action=DeleteFile', { path: path + '/composer.lock' }, function (rdata) {
				bt.msg(rdata);
				$('.composer-msg').remove();
				$('.composer-rm').remove();
			});
		},
		compr_web: null,
		set_composer: function (web) {
			site.edit.compr_web = web;
			$.post('/files?action=get_composer_version', { path: web.path }, function (v_data) {
				if (v_data.status === false) {
					bt.msg(v_data);
					return;
				}

				var php_versions = '';
				for (var i = 0; i < v_data.php_versions.length; i++) {
					if (v_data.php_versions[i].version == '00') continue;
					php_versions += '<option value="' + v_data.php_versions[i].version + '">' + v_data.php_versions[i].name + '</option>';
				}
				if (!php_versions) layer.msg('没有找到可用的PHP版本!', { time: 10000 });

				var msg = '';
				if (v_data.comp_lock) {
					msg += '<span>' + v_data.comp_lock + ' <a class="btlink composer-rm" onclick="site.edit.remove_composer_lock(\'' + web.path + '\')">[点击删除]</a></span>';
				}
				if (v_data.comp_json !== true) {
					msg += '<span>' + v_data.comp_json + '</span>';
				}

				var com_body =
					'<from class="bt-form" style="padding:30px 0;display:inline-block;width: 630px;">' +
					'<div class="line"><span style="width: 105px;" class="tname">Composer版本</span><div class="info-r"><input readonly="readonly" style="background-color: #eee;width:275px;" name="composer_version" class="bt-input-text" value="' +
					(v_data.msg ? v_data.msg : '未安装Composer') +
					'" /><button onclick="site.edit.update_composer();" style="margin-left: 5px;" class="btn btn-default btn-sm">' +
					(v_data.msg ? '升级Composer' : '安装Composer') +
					'</button></div></div>' +
					'<div class="line"><span style="width: 105px;" class="tname">PHP版本</span><div class="info-r">' +
					'<select class="bt-input-text" name="php_version" style="width:275px;">' +
					'<option value="auto">自动选择</option>' +
					php_versions +
					'</select>' +
					'</div></div>' +
					'<div class="line"><span style="width: 105px;" class="tname">执行参数</span><div class="info-r">' +
					'<select class="bt-input-text" name="composer_args" style="width:275px;">' +
					'<option value="install">install</option>' +
					'<option value="update">update</option>' +
					'<option value="create-project">create-project</option>' +
					'<option value="require">require</option>' +
					'<option value="other">自定义命令</option>' +
					'</select>' +
					'</div></div>' +
					'<div class="line"><span style="width: 105px;" class="tname">补充命令</span><div class="info-r">' +
					'<input style="width:275px;" class="bt-input-text" id="composer_cmd" name="composer_cmd"  placeholder="输入要操作的应用名称或完整Composer命令" type="text" value="" />' +
					'</div></div>' +
					'<div class="line"><span style="width: 105px;" class="tname">镜像源</span><div class="info-r">' +
					'<select class="bt-input-text" name="repo" style="width:275px;">' +
					'<option value="https://mirrors.aliyun.com/composer/">阿里源(mirrors.aliyun.com)</option>' +
					'<option value="https://mirrors.cloud.tencent.com/composer/">腾讯源(mirrors.cloud.tencent.com)</option>' +
					'<option value="repos.packagist">官方源(packagist.org)</option>' +
					'</select>' +
					'</div></div>' +
					'<div class="line"><span style="width: 105px;" class="tname">执行目录</span><div class="info-r">' +
					'<input style="width:275px;" class="bt-input-text" id="composer_path" name="composer_path" type="text" value="' +
					web.path +
					'" /><span class="glyphicon glyphicon-folder-open cursor ml5" onclick="bt.select_path(\'composer_path\')"></span>' +
					'</div></div>' +
					'<div class="line"><span style="width: 105px;height: 25px;" class="tname"> </span><span class="composer-msg" style="color:red;">' +
					msg +
					'</span></div>' +
					'<div class="line" style="clear:both"><span style="width: 105px;" class="tname"> </span><div class="info-r"><button class="btn btn-success btn-sm" onclick="site.edit.exec_composer()">执行</button></div></div>' +
					'</from>' +
					'<ul class="help-info-text-info c7" style="margin-top: 0;">' +
					'<li>Composer是PHP主流依赖包管理器，若您的项目使用Composer管理依赖包，可在此处对依赖进行升级或安装</li>' +
					'<li>执行目录：默认为当前网站根目录</li>' +
					'<li>镜像源：提供【阿里源】和【官方源】，建议国内服务器使用【阿里源】，海外服务器使用【官方源】</li>' +
					'<li>执行参数：按需选择执行参数,可配合补充命令使用</li>' +
					'<li>补充命令：若此处为空，则按composer.json中的配置执行，此处支持填写完整composer命令</li>' +
					'<li>PHP版本：用于执行composer的PHP版本，无特殊要求，默认即可，如安装出错，可尝试选择其它PHP版本</li>' +
					'<li>Composer版本：当前安装的Composer版本，可点击右侧的【升级Composer】将Composer升级到最新稳定版</li>' +
					'</ul>';
				$('#webedit-con').html(com_body);
			});
		},
		set_domains: function (web) {
			var _this = this;
			var list = [
				{
					items: [
						{
							name: 'newdomain',
							width: '340px',
							type: 'textarea',
							placeholder: '每行填写一个域名，默认为80端口<br>泛解析添加方法 *.domain.com<br>如另加端口格式为 www.domain.com:88',
						},
						{
							name: 'btn_submit_domain',
							text: '添加',
							type: 'button',
							callback: function (sdata) {
								var arrs = sdata.newdomain.split('\n');
								var domins = '';
								for (var i = 0; i < arrs.length; i++) domins += arrs[i] + ',';
								bt.site.add_domains(web.id, web.name, bt.rtrim(domins, ','), function (ret) {
									if (ret.status) site.reload(0);
								});
							},
						},
					],
				},
			];
			var _form_data = bt.render_form_line(list[0]),
				loadT = null,
				placeholder = null;
			$('#webedit-con').html(_form_data.html + "<div class='bt_table' id='domain_table'></div>");
			bt.render_clicks(_form_data.clicks);
			$('.btn_submit_domain').addClass('pull-right').css('margin', '30px 35px 0 0');
			placeholder = $('.placeholder');
			placeholder
				.click(function () {
					$(this).hide();
					$('.newdomain').focus();
				})
				.css({
					width: '340px',
					heigth: '100px',
					left: '0px',
					top: '0px',
					'padding-top': '10px',
					'padding-left': '15px',
				});
			$('.newdomain')
				.focus(function () {
					placeholder.hide();
					loadT = layer.tips(placeholder.html(), $(this), {
						tips: [1, '#20a53a'],
						time: 0,
						area: $(this).width(),
					});
				})
				.blur(function () {
					if ($(this).val().length == 0) placeholder.show();
					layer.close(loadT);
				});
			var site_table = bt_tools.table({
				el: '#domain_table',
				url: '/data?action=getData',
				height: 460,
				param: {
					table: 'domain',
					list: 'True',
					search: web.id,
				},
				dataFilter: function (res) {
					return {
						data: res,
					};
				},
				column: [
					{
						type: 'checkbox',
						width: 20,
					},
					{
						fid: 'name',
						title: '域名',
						template: function (row) {
							return '<a href="http://' + row.name + ':' + row.port + '" target="_blank" class="btlink">' + row.name + '</a>';
						},
					},
					{
						fid: 'port',
						title: '端口',
						width: 50,
						type: 'text',
					},
					{
						title: '操作',
						width: 80,
						type: 'group',
						align: 'right',
						group: [
							{
								title: '删除',
								template: function (row, that) {
									return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
								},
								event: function (row, index, ev, key, that) {
									if (that.data.length === 1) {
										bt.msg({
											status: false,
											msg: '最后一个域名不能删除!',
										});
										return false;
									}
									bt.confirm(
										{
											title: '删除域名【' + row.name + '】',
											msg: lan.site.domain_del_confirm,
										},
										function () {
											bt.site.del_domain(web.id, web.name, row.name, row.port, function (res) {
												if (res.status) that.$delete_table_row(index);
												bt.msg(res);
											});
										}
									);
								},
							},
						],
					},
				],
				tootls: [
					{
						// 批量操作
						type: 'batch',
						positon: ['left', 'bottom'],
						config: {
							title: '删除',
							url: '/site?action=DelDomain',
							param: function (row) {
								return {
									domain: row.name,
									port: row.port,
								};
							},
							callback: function (that) {
								bt.confirm(
									{
										title: '批量删除域名',
										msg: '是否批量删除选中的域名？',
										icon: 2,
									},
									function () {
										that.start_batch(
											{
												id: web.id,
												webname: web.name,
												batch: true,
											},
											function (list) {
												var html = '';
												for (var i = 0; i < list.length; i++) {
													var item = list[i];
													html +=
														'<tr><td>' +
														item.name +
														'</td><td><div style="float:right;"><span style="color:' +
														(item.request.status ? '#20a53a' : 'red') +
														';white-space: pre;">' +
														item.request.msg +
														'</span></div></td></tr>';
												}
												site_table.$batch_success_table({
													title: '批量删除域名',
													th: '站点域名',
													html: html,
												});
												site_table.$refresh_table_list(true);
											}
										);
									}
								);
							},
						},
					},
				],
			});
		},
		set_dirbind: function (web) {
			$('#webedit-con').html('<div id="sub_dir_table"></div>');
			bt_tools.table({
				el: '#sub_dir_table',
				url: '/site?action=GetDirBinding',
				param: { id: web.id },
				dataFilter: function (res) {
					if ($('#webedit-con').children().length === 2) return { data: res.binding };
					var dirs = [];
					for (var n = 0; n < res.dirs.length; n++) dirs.push({ title: res.dirs[n], value: res.dirs[n] });
					var data = {
						title: '',
						class: 'mb0',
						items: [
							{ title: '域名', width: '140px', name: 'domain' },
							{ title: '子目录', name: 'dirName', type: 'select', items: dirs },
							{
								text: '添加',
								type: 'button',
								name: 'btn_add_subdir',
								callback: function (sdata) {
									if (!sdata.domain || !sdata.dirName) {
										layer.msg(lan.site.d_s_empty, { icon: 2 });
										return;
									}
									if (sdata.domain.indexOf('*') >= 0 && bt.get_cookie('serverType') == 'iis') {
										bt.msg({
											msg: 'IIS不支持泛解析，如需使用，请通过设置默认站点实现。',
											icon: 2,
											time: 0,
										});
										return;
									}
									bt.site.add_dirbind(web.id, sdata.domain, sdata.dirName, function (ret) {
										layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
										if (ret.status) site.reload(1);
									});
								},
							},
						],
					};
					var _form_data = bt.render_form_line(data);
					$('#webedit-con').prepend(_form_data.html);
					bt.render_clicks(_form_data.clicks);
					return { data: res.binding };
				},
				column: [
					{ type: 'checkbox', width: 20, keepNumber: 1 },
					{
						fid: 'domain',
						title: '域名',
						width: 150,
						template: function (row) {
							return '<a class="btlink" href="http://' + row.domain + ':' + row.port + '" target="_blank" title="' + row.domain + '">' + row.domain + '</a>';
						},
					},
					{ fid: 'port', title: '端口', width: 70, type: 'text' },
					{ fid: 'path', title: '子目录', type: 'text' },
					{
						title: '操作',
						width: 110,
						type: 'group',
						align: 'right',
						group: [
							{
								title: '伪静态',
								event: function (row, index, ev, key, that) {
									bt.site.get_dir_rewrite({ id: row.id }, function (ret) {
										if (!ret.status) {
											var confirmObj = layer.confirm(lan.site.url_rewrite_alter, { icon: 3, closeBtn: 2 }, function () {
												bt.site.get_dir_rewrite({ id: row.id, add: 1 }, function (ret) {
													layer.close(confirmObj);
													show_dir_rewrite(ret);
												});
											});
											return;
										}
										show_dir_rewrite(ret);

										function get_rewrite_file(name) {
											if (name == lan.site.rewritename) {
												bt.site.get_site_rewrite(web.name + '_' + row.path, function (sdata) {
													$('.dir_config').text(sdata.data);
												});
											} else {
												var spath = setup_path + '/panel/rewrite/' + bt.get_cookie('serverType') + '/' + name + '.conf';
												bt.files.get_file_body(spath, function (sdata) {
													$('.dir_config').text(sdata.data);
												});
											}
										}

										function show_dir_rewrite(ret) {
											var load_form = bt.open({
												type: 1,
												area: ['510px', '515px'],
												title: lan.site.config_url,
												closeBtn: 2,
												shift: 5,
												skin: 'bt-w-con',
												shadeClose: true,
												content: "<div class='bt-form webedit-dir-box dir-rewrite-man-con'></div>",
												success: function () {
													var _html = $('.webedit-dir-box'),
														arrs = [];
													for (var i = 0; i < ret.rlist.length; i++) {
														arrs.push({ title: ret.rlist[i], value: ret.rlist[i] });
													}
													var datas = [
														{
															name: 'dir_rewrite',
															type: 'select',
															width: '130px',
															items: arrs,
															callback: function (obj) {
																get_rewrite_file(obj.val());
															},
														},
														{ items: [{ name: 'dir_config', type: 'textarea', value: ret.data, width: '470px', height: '260px' }] },
														{
															items: [
																{
																	name: 'btn_save',
																	text: '保存',
																	type: 'button',
																	callback: function (ldata) {
																		if (bt.os == 'Linux') {
																			bt.files.set_file_body(ret.filename, ldata.dir_config, 'utf-8', function (ret) {
																				if (ret.status) load_form.close();
																				bt.msg(ret);
																			});
																		} else {
																			var loading = bt.load();
																			bt.site.set_site_rewrite(web.name + '_' + row.path, ldata.dir_config, function (ret) {
																				loading.close();
																				if (ret.status) load_form.close();
																				bt.msg(ret);
																			});
																		}
																	},
																},
															],
														},
													];
													var clicks = [];
													for (var i = 0; i < datas.length; i++) {
														var _form_data = bt.render_form_line(datas[i]);
														_html.append(_form_data.html);
														var _other = bt.os == 'Linux' && i == 0 ? '<span>规则转换工具：<a href="https://www.bt.cn/Tools" target="_blank" style="color:#20a53a">Apache转Nginx</a></span>' : '';
														_html.find('.info-r').append(_other);
														clicks = clicks.concat(_form_data.clicks);
													}
													_html.append(bt.render_help(['请选择您的应用，若设置伪静态后，网站无法正常访问，请尝试设置回default', '您可以对伪静态规则进行修改，修改完后保存即可。']));
													bt.render_clicks(clicks);
													get_rewrite_file($('.dir_rewrite option:eq(0)').val());
												},
											});
										}
									});
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									bt.confirm({ title: '删除子目录绑定【' + row.path + '】', msg: lan.site.s_bin_del }, function () {
										bt.site.del_dirbind(row.id, function (res) {
											if (res.status) that.$delete_table_row(index);
											bt.msg(res);
										});
									});
								},
							},
						],
					},
				],
				tootls: [
					{
						// 批量操作
						type: 'batch',
						positon: ['left', 'bottom'],
						config: {
							title: '删除',
							url: '/site?action=delete_dir_bind_multiple',
							param: { id: web.id },
							paramId: 'id',
							paramName: 'bind_ids',
							theadName: '域名',
							confirmVerify: false, //是否提示验证方式
							refresh: true,
						},
					},
				],
			});
		},
		//禁用脚本
		set_en_script: function (siteName, name, status) {
			status = status ? 1 : 0;
			var loading = bt.load();
			bt.send(
				'set_en_script',
				'site/set_en_script',
				{
					siteName: siteName,
					name: name,
					status: status,
				},
				function (sdata) {
					loading.close();
					bt.msg(sdata);
				}
			);
		},
		set_dirpath: function (web) {
			var loading = bt.load();
			bt.site.get_site_path(web.id, function (path) {
				bt.site.get_dir_userini(web.id, path, function (rdata) {
					loading.close();
					if (rdata.status == false) {
						bt.msg(rdata);
						return;
					}
					var dirs = [];
					for (var n = 0; n < rdata.runPath.dirs.length; n++)
						dirs.push({
							title: rdata.runPath.dirs[n],
							value: rdata.runPath.dirs[n],
						});
					var datas = [
						{
							title: '',
							items: [
								{
									name: 'userini',
									type: 'checkbox',
									text: '防跨站攻击(open_basedir)<a href="https://www.bt.cn/bbs/thread-50988-1-1.html" target="_blank" class="bt-ico-ask">?</a>',
									value: rdata.userini,
									callback: function (sdata) {
										bt.site.set_dir_userini(web.name, path, function (ret) {
											if (ret.status) site.reload(2);
										});
									},
								},
								{
									name: 'logs',
									type: 'checkbox',
									text: '写访问日志',
									value: rdata.logs,
									callback: function (sdata) {
										bt.site.set_logs_status(web.id, function (ret) {
											if (ret.status) site.reload(2);
										});
									},
								},
							],
						},
						{
							title: '',
							items: [
								{
									name: 'en_asp',
									type: 'checkbox',
									text: '禁用Asp',
									value: rdata.asp,
									callback: function (sdata) {
										site.edit.set_en_script(web.name, 'asp', sdata.en_asp);
									},
								},
								{
									name: 'en_aspx',
									type: 'checkbox',
									text: '禁用Aspx',
									value: rdata.aspx,
									callback: function (sdata) {
										site.edit.set_en_script(web.name, 'aspx', sdata.en_aspx);
									},
								},
								{
									name: 'en_php',
									type: 'checkbox',
									text: '禁用PHP',
									value: rdata.php,
									callback: function (sdata) {
										site.edit.set_en_script(web.name, 'php', sdata.en_php);
									},
								},
							],
						},
						{
							name: 'config_lock',
							type: 'checkbox',
							text: '锁定配置文件(IIS部署Wordpress必选)<a href="https://www.bt.cn/bbs/thread-51149-1-1.html" target="_blank" class="bt-ico-ask">?</a>',
							value: rdata.locking,
							callback: function (sdata) {
								bt.site.set_config_locking(web.name, function (ret) {
									if (ret.status) site.reload();
									bt.msg(ret);
								});
							},
						},
						{
							name: 'directory_browse',
							type: 'checkbox',
							text: '目录浏览',
							value: rdata.directory_browse,
							callback: function (sdata) {
								bt.site.set_directory_browse(web.name, function (ret) {
									if (ret.status) site.reload();
									bt.msg(ret);
								});
							},
						},
						{
							title: '',
							items: [
								{
									name: 'path',
									title: '网站目录',
									width: '50%',
									value: path,
									event: {
										css: 'glyphicon-folder-open',
										callback: function (obj) {
											bt.select_path(obj);
										},
									},
								},
								{
									name: 'btn_site_path',
									type: 'button',
									text: '保存',
									callback: function (pdata) {
										bt.site.set_site_path({ id: web.id, path: pdata.path, check_dir: 1 }, function (ret) {
											if (ret.code == -2) {
												var dirConfirm = bt.show_confirm('网站目录', ret.msg, function () {
													bt.site.set_site_path({ id: web.id, path: pdata.path }, function (res) {
														if (res.status == false) {
															bt.msg(res);
															return;
														}
														layer.close(dirConfirm);
														if (res.status) site.reload();
													});
												});
												return;
											}
											if (ret.status == false) {
												bt.msg(ret);
												return;
											}
											if (ret.status) site.reload();
										});
									},
								},
							],
						},
						{
							title: '',
							items: [
								{
									title: '运行目录',
									width: '50%',
									value: rdata.runPath.runPath,
									name: 'dirName',
									type: 'select',
									items: dirs,
								},
								{
									name: 'btn_run_path',
									type: 'button',
									text: '保存',
									callback: function (pdata) {
										bt.site.set_site_runpath(web.id, pdata.dirName, function (ret) {
											if (ret.status) site.reload();
										});
									},
								},
							],
						},
					];
					var _html = $("<div class='webedit-box soft-man-con'></div>");
					var clicks = [];
					for (var i = 0; i < datas.length; i++) {
						var _form_data = bt.render_form_line(datas[i]);
						_html.append($(_form_data.html).addClass('line mtb10'));
						clicks = clicks.concat(_form_data.clicks);
					}
					_html.find('input[type="checkbox"]').parent().addClass('label-input-group ptb10');
					_html.find('button[name="btn_run_path"]').addClass('ml45');
					_html.find('button[name="btn_site_path"]').addClass('ml33');
					_html.append(
						bt.render_help([
							'部分程序需要指定二级目录作为运行目录，如ThinkPHP5，Laravel',
							'选择您的运行目录，点保存即可',
							'wordpress安装/修改模块导致网站500错误 <a style="color:#20a53a;" href="https://www.bt.cn/bbs/thread-33097-1-1.html" target="_blank">参考此贴</a>',
							'锁定配置将保护您的站点配置文件不被替换/修改等操作 <font style="color:red">(PS:可通过面板修改配置并校验格式正确性)</font>',
							'如锁定配置，需要手动删除网站目录的IIS_IUSRS权限',
						])
					);
					if (bt.os == 'Linux')
						_html.append(
							'<div class="user_pw_tit" style="margin-top: 2px;padding-top: 11px;"><span class="tit">密码访问</span><span class="btswitch-p"><input class="btswitch btswitch-ios" id="pathSafe" type="checkbox"><label class="btswitch-btn phpmyadmin-btn" for="pathSafe" ></label></span></div><div class="user_pw" style="margin-top: 10px; display: block;"></div>'
						);

					$('#webedit-con').append(_html);
					bt.render_clicks(clicks);
					$('#pathSafe').click(function () {
						var val = $(this).prop('checked');
						var _div = $('.user_pw');
						if (val) {
							var dpwds = [
								{
									title: '授权账号',
									width: '200px',
									name: 'username_get',
									placeholder: '不修改请留空',
								},
								{
									title: '访问密码',
									width: '200px',
									type: 'password',
									name: 'password_get_1',
									placeholder: '不修改请留空',
								},
								{
									title: '重复密码',
									width: '200px',
									type: 'password',
									name: 'password_get_2',
									placeholder: '不修改请留空',
								},
								{
									name: 'btn_password_get',
									text: '保存',
									type: 'button',
									callback: function (rpwd) {
										if (rpwd.password_get_1 != rpwd.password_get_2) {
											layer.msg(lan.bt.pass_err_re, {
												icon: 2,
											});
											return;
										}
										bt.site.set_site_pwd(web.id, rpwd.username_get, rpwd.password_get_1, function (ret) {
											if (ret.status) site.reload(2);
										});
									},
								},
							];
							for (var i = 0; i < dpwds.length; i++) {
								var _from_pwd = bt.render_form_line(dpwds[i]);
								_div.append("<div class='line'>" + _from_pwd.html + '</div>');
								bt.render_clicks(_from_pwd.clicks);
							}
						} else {
							bt.site.close_site_pwd(web.id, function (rdata) {
								layer.msg(rdata.msg, {
									icon: rdata.status ? 1 : 2,
								});
								_div.html('');
							});
						}
					});
					if (rdata.pass) $('#pathSafe').trigger('click');
				});
			});
		},
		set_apppool: function (web, index) {
			if (index == undefined) index = 0;
			var loadT = bt.load();
			bt.site.get_net_version_byaspp(web.name, function (ndata) {
				loadT.close();
				if (ndata.status === false) {
					bt.msg(ndata);
					return;
				}

				bt.site.get_iis_net_versions(function (ldata) {
					if (ldata.status === false) {
						bt.msg(ldata);
						return;
					}

					$('#webedit-con').html('<div id=\'pool_tabs\'></div><div class="tab-con" style="padding:20px 0px;"></div>');

					var _tabs = [
						{
							title: '基础设置',
							callback: function (robj) {
								var nets = [];
								for (var i = 0; i < ldata.length; i++)
									nets.push({
										title: ldata[i],
										value: ldata[i],
									});
								nets.push({
									title: '无托管代码',
									value: '',
								});

								var shtml =
									'<p  style="margin-left:30px;" class="status">当前状态：<span>开启</span><span style="color: #20a53a; margin-left: 3px;" class="glyphicon glyphicon glyphicon-play"></span>';
								var opttxt = '停止';
								if (ndata.status != 'Started') {
									shtml = '<p class="status">当前状态：<span>关闭</span><span style="color: red; margin-left: 3px;" class="glyphicon glyphicon-pause"></span>';
									opttxt = '启动';
								}
								shtml +=
									'<span class="app_status" style="margin-left:20px;"><button class="btn btn-default btn-sm">' + opttxt + '</button> <button class="btn btn-default btn-sm">重启</button></span></p>';

								var _html = $('<div class="webedit-box soft-man-con"> ' + shtml + ' </div>');

								var datas = [
									{
										title: '托管管道模式',
										name: 'model',
										type: 'select',
										value: ndata.type,
										items: [
											{
												title: '集成',
												value: 'Integrated',
											},
											{
												title: '经典',
												value: 'Classic',
											},
										],
									},
									{
										title: '.NET 版本',
										name: 'net_version',
										type: 'select',
										value: ndata.version,
										items: nets,
									},
									{
										title: '32位应用程序',
										name: 'enable32BitAppOnWin64',
										type: 'select',
										value: ndata.enable32BitAppOnWin64,
										ps: 'x64系统下仍加载x86应用程序池，默认开启',
										items: [
											{
												title: '启用',
												value: 'true',
											},
											{
												title: '停用',
												value: 'false',
											},
										],
									},
									{
										title: '队列长度',
										name: 'queueLength',
										width: '130px',
										type: 'number',
										value: ndata.queueLength,
										ps: '默认10000，超过此长度将响应503',
									},
									{
										title: '  ',
										name: 'btn_set_app',
										text: '保存',
										type: 'button',
										callback: function (ldata) {
											ldata['name'] = web.name;
											bt.site.set_iis_apppool(ldata, function (ret) {
												if (ret.status) site.edit.set_apppool(web, 0);
											});
										},
									},
								];
								robj.append(_html);
								for (var i = 0; i < datas.length; i++) {
									bt.render_form_line(datas[i], '', robj);
								}
								robj.append(
									bt.render_help([
										'注意：如果Aspx网站出现404，请使用在命令行输入以下命令启用Aspx.net',
										'  C:\\WINDOWS\\Microsoft.NET\\Framework\\v2.0.50727\\aspnet_regiis.exe -i',
										' C:\\WINDOWS\\Microsoft.NET\\Framework\\v4.0.30319\\aspnet_regiis.exe -i',
										'IIS性能调整与异常排除<a href="https://www.bt.cn/bbs/thread-33111-1-1.html" target="_blank" class="btlink"> 使用帮助</a>',
									])
								);

								$('.app_status button').click(function () {
									var _index = $(this).index();
									var opt = 'start';
									if (ndata.status == 'Started') opt = 'stop';
									if (_index == 1) opt = 'restart';
									var msg = lan.bt[opt];
									bt.confirm(
										{
											msg: '是否确定' + msg + '程序池[' + web.name + ']？',
											title: '提示',
										},
										function () {
											bt.site.set_apppool_status(web.name, opt, function (ret) {
												if (ret.status) {
													site.get_class_type();
													site.edit.set_apppool(web, 0);
												}
												bt.msg(ret);
											});
										}
									);
								});
							},
						},
						{
							title: '回收设置',
							callback: function (robj) {
								var periodicRestart = ndata.periodicRestart;
								var re_data = [
									{
										title: '内存限制',
										name: 'privateMemory',
										width: '120px',
										type: 'number',
										value: periodicRestart.privateMemory,
										unit: 'KB',
									},
									{
										title: '请求限制',
										name: 'requests',
										width: '120px',
										type: 'number',
										value: periodicRestart.requests,
									},
									{
										title: '固定回收时间',
										name: 'time',
										width: '180px',
										type: 'number',
										value: periodicRestart.time / 60,
										unit: '分',
									},
									{
										title: ' ',
										items: [
											{
												title: '  ',
												name: 'btn_site_app_recycling',
												text: '应用本站',
												type: 'button',
												callback: function (ldata) {
													ldata['is_global'] = 0;
													ldata['time'] = ldata['time'] * 60;
													site.edit.set_site_app_recycling(web, ldata);
												},
											},
											{
												title: '  ',
												name: 'btn_all_app_recycling',
												text: '应用所有',
												type: 'button',
												callback: function (ldata) {
													ldata['is_global'] = 1;
													ldata['time'] = ldata['time'] * 60;
													site.edit.set_site_app_recycling(web, ldata);
												},
											},
										],
									},
								];
								for (var i = 0; i < re_data.length; i++) {
									bt.render_form_line(re_data[i], '', robj);
								}
								$('.btn_all_app_recycling').removeClass('btn-success').addClass('btn-danger');

								robj.append(
									'<div style="border-bottom:#ccc 1px solid;margin-bottom:10px;padding-bottom:10px;margin-top: 20px;"> <input id="recycling_time" class="bt-input-text recycling_time" style="width:280px"  type="text" value=""  placeholder="每天定时回收程序池,格式：12:00"><button class="btn btn_add_recycling btn-success btn-sm va0 mlr15" >添加</button></div><div class="divtable" style="max-height:150px;overflow:auto;border:#ddd 1px solid"><table id="pool_recycling_list" class="table table-hover" style="border:none;"></table></div>'
								);

								var schedule_list = [];
								for (var i = 0; i < periodicRestart.schedule.length; i++)
									schedule_list.push({
										time_start: periodicRestart.schedule[i],
									});

								bt.render({
									table: '#pool_recycling_list',
									columns: [
										{
											field: 'time_start',
											title: '时间（24小时制）',
										},
										{
											field: 'opt',
											width: '70px',
											title: '操作',
											templet: function (item) {
												return '<a class="btlink pool_recycling_del">删除</a>';
											},
										},
									],
									data: schedule_list,
								});

								robj.append(
									bt.render_help([
										'内存限制：超过内存限制自动回收，0表示不限制',
										'请求限制：超过请求限制自动回收,0表示不限制',
										'固定回收时间：固定回收，默认1740分钟',
										'定时回收：表示每天固定时间回收程序池，建议设置在半夜。',
										'IIS性能调整与异常排除<a href="https://www.bt.cn/bbs/thread-33111-1-1.html" target="_blank" class="btlink"> 使用帮助</a>',
									])
								);

								$('.pool_recycling_del').click(function () {
									var item = $(this).parents('tr').data('item');
									site.edit.set_site_recycling_bytime(web, item.time_start, '0');
								});

								$('.btn_add_recycling').click(function () {
									site.edit.set_site_recycling_bytime(web, $('.recycling_time').val() + ':00', '1');
								});

								//时间选择器
								laydate.render({
									elem: '#recycling_time',
									type: 'time',
									trigger: 'click',
									theme: '#20a53a',
									format: 'HH:mm',
								});
							},
						},
						{
							title: '故障防护',
							callback: function (robj) {
								var failure = ndata.failure;
								var failure_data = [
									{
										title: '状态',
										name: 'rapidFailProtection',
										width: '120px',
										type: 'select',
										value: failure.rapidFailProtection,
										items: [
											{
												title: '开启',
												value: 'true',
											},
											{
												title: '关闭',
												value: 'false',
											},
										],
									},
									{
										title: '故障间隔',
										name: 'rapidFailProtectionInterval',
										width: '120px',
										type: 'number',
										value: failure.rapidFailProtectionInterval,
										unit: '分钟',
									},
									{
										title: '最大故障次数',
										name: 'rapidFailProtectionMaxCrashes',
										width: '120px',
										type: 'number',
										value: failure.rapidFailProtectionMaxCrashes,
										unit: '次',
									},
									{
										title: '故障处理方式',
										name: 'failure_type',
										width: '150px',
										type: 'select',
										value: failure.failure_type,
										items: [
											{
												title: '不处理',
												value: 'false',
											},
											{
												title: '重启当前程序池',
												value: 'start_pool',
											},
											{
												title: '重启IIS',
												value: 'restart_iis',
											},
										],
									},
									{
										title: ' ',
										items: [
											{
												title: '  ',
												name: 'btn_site_app_failure',
												text: '应用本站',
												type: 'button',
												callback: function (ldata) {
													ldata['is_global'] = 0;

													site.edit.set_site_app_failure(web, ldata);
												},
											},
											{
												title: '  ',
												name: 'btn_all_app_failure',
												text: '应用所有',
												type: 'button',
												callback: function (ldata) {
													ldata['is_global'] = 1;
													site.edit.set_site_app_failure(web, ldata);
												},
											},
										],
									},
								];
								for (var i = 0; i < failure_data.length; i++) {
									bt.render_form_line(failure_data[i], '', robj);
								}
								$('.btn_all_app_failure').removeClass('btn-success').addClass('btn-danger');

								robj.append(
									bt.render_help([
										'【故障间隔】内发送了【最大故障次数】错误则停止程序池，整站响应503错误',
										'故障处理方式：当应用程序池被异常关闭后触发的处理方式.',
										'IIS性能调整与异常排除<a href="https://www.bt.cn/bbs/thread-33111-1-1.html" target="_blank" class="btlink"> 使用帮助</a>',
									])
								);
							},
						},
						{
							title: '工作进程',
							callback: function (robj) {
								var process = ndata.processModel;
								var re_data = [
									{
										title: '最大工作进程',
										name: 'maxProcesses',
										width: '180px',
										type: 'number',
										value: process.maxProcesses,
									},
									{
										title: '启动超时',
										name: 'startupTimeLimit',
										width: '180px',
										type: 'number',
										value: process.startupTimeLimit,
										unit: ' 秒',
									},
									{
										title: '请求超时',
										name: 'shutdownTimeLimit',
										width: '180px',
										type: 'number',
										value: process.shutdownTimeLimit,
										unit: ' 秒',
									},
									{
										title: '闲置超时',
										name: 'idleTimeout',
										width: '180px',
										type: 'number',
										value: process.idleTimeout,
										unit: ' 秒',
									},
									{
										title: ' ',
										items: [
											{
												title: '  ',
												name: 'btn_site_app_process',
												text: '保存',
												type: 'button',
												callback: function (ldata) {
													site.edit.set_site_app_process(web, ldata);
												},
											},
										],
									},
								];

								for (var i = 0; i < re_data.length; i++) {
									bt.render_form_line(re_data[i], '', robj);
								}
								robj.append(
									bt.render_help([
										'启动超时：启动程序池超时时间',
										'请求超时：完成处理请求超时时间',
										'闲置超时：超过此时间未收到请求，此进程将进入闲置状态',
										'最大工作进程：应用池启动进程数,增加进程数可有效缓解进程池压力(<span style="color:red">注意：每增加一个进程将会增加200M内存占用，并且可能会造成用户登录状态丢失，谨慎使用。</span>)',
										'IIS性能调整与异常排除<a href="https://www.bt.cn/bbs/thread-33111-1-1.html" target="_blank" class="btlink"> 使用帮助</a>',
									])
								);
							},
						},
						{
							title: '活动进程',
							callback: function (robj) {
								var loading = bt.load();
								bt.send(
									'get_iis_process_list',
									'site/get_iis_process_list',
									{
										siteName: web.name,
									},
									function (rdata) {
										loading.close();

										if (rdata.status === false) {
											bt.msg(rdata);
											return;
										}
										var _total_html =
											' <table class="table table-hover table-bordered" style="width: 490px;margin-bottom:10px;background-color:#fafafa">\
					                        <tbody> <tr><th style="width:80px">总连接数：</th><td>' +
											rdata.total_request +
											'</td><th style="width:80px">总内存：</th><td>' +
											rdata.total_memory +
											' KB</td><th style="width:80px">总CPU：</th><td>' +
											rdata.total_cpu +
											' %</td></tr></tbody>\
					                    </table>';
										var con = "<div class='divtable style='padding-bottom: 0'><table width='100%' id='tab_iis_status' class='table table-hover'></table></div>";
										robj.html(_total_html + con);

										var _tab = bt.render({
											table: '#tab_iis_status',
											columns: [
												{
													field: 'name',
													title: '网站名',
													width: '100px',
												},
												{
													field: 'pid',
													title: '进程ID',
													width: '100px',
												},
												{
													field: 'cpu',
													title: 'CPU',
													width: '100px',
												},
												{
													field: 'memory',
													title: '内存(KB)',
													width: '100px',
												},
												{
													field: 'request',
													title: '活动连接数',
													width: '100px',
												},
												{
													field: 'opt',
													title: '操作',
													width: '100px',
													templet: function (item) {
														return '<a class="btlink get_request_info">查看</a>';
													},
												},
											],
											data: rdata.apps,
										});
										$('.get_request_info').click(function () {
											var _item = $(this).parents('tr').data('item');

											bt.soft.web.get_iis_request_list(_item.pid, function (res) {
												if ($('#iis_request_list').length <= 0) {
													bt.open({
														type: 1,
														title: '[' + _item.name + ']活动进程',
														area: ['500px', '500px'],
														closeBtn: 2,
														shadeClose: false,
														content:
															'<div class="pd15 div_cn_form"><div style="border-bottom:#ccc 1px solid;margin-bottom:10px;padding-bottom:10px"></div><div class="divtable" style="max-height:300px;overflow:auto;border:#ddd 1px solid"><table id="iis_request_list" class="table table-hover gztr" style="border:none;"></table></div></div>',
														success: function () {
															init_request_data_list(res);
														},
													});
												} else {
													init_request_data_list(res);
												}

												function init_request_data_list(res) {
													var _tab = bt.render({
														table: '#iis_request_list',
														columns: [
															{
																field: 'method',
																title: '类型',
																width: '100px',
															},
															{
																field: 'url',
																title: 'URL',
																width: '100px',
															},
															{
																field: 'time',
																title: '耗时',
																width: '100px',
															},
															{
																field: 'client',
																title: '客户端',
																width: '100px',
															},
															{
																field: 'module',
																title: '处理模块',
																width: '100px',
															},
														],
														data: res,
													});
												}
											});
										});
									}
								);
							},
						},
					];
					bt.render_tab('pool_tabs', _tabs);
					$('#pool_tabs span:eq(' + index + ')').trigger('click');
				});
			});
		},
		set_site_app_process: function (web, ldata) {
			ldata['siteName'] = web.name;
			var loading = bt.load();
			bt.send('set_site_app_process', 'site/set_site_app_process', ldata, function (rRet) {
				loading.close();
				if (rRet.status) {
					site.edit.set_apppool(web, 3);
				}
				bt.msg(rRet);
			});
		},
		set_site_recycling_bytime: function (web, recycling_time, stype) {
			var loading = bt.load();
			bt.send(
				'set_site_recycling_bytime',
				'site/set_site_recycling_bytime',
				{
					siteName: web.name,
					recycling_time: recycling_time,
					stype: stype,
				},
				function (rRet) {
					loading.close();
					if (rRet.status) {
						site.edit.set_apppool(web, 1);
					}
					bt.msg(rRet);
				}
			);
		},
		set_site_app_recycling: function (web, ldata) {
			ldata['siteName'] = web.name;
			var loading = bt.load();
			bt.send('set_iis_app_recycling', 'site/set_iis_app_recycling', ldata, function (rRet) {
				loading.close();
				if (rRet.status) {
					site.edit.set_apppool(web, 1);
				}
				bt.msg(rRet);
			});
		},
		set_site_app_failure: function (web, ldata) {
			ldata['siteName'] = web.name;
			var loading = bt.load();
			bt.send('set_iis_app_failure', 'site/set_iis_app_failure', ldata, function (rRet) {
				loading.close();
				if (rRet.status) {
					site.edit.set_apppool(web, 2);
				}
				bt.msg(rRet);
			});
		},
		set_error_page: function (web) {
			bt.site.get_site_error_pages(web.name, function (rdata) {
				if (rdata.status === false) {
					bt.msg(rdata);
					return;
				}
				var _from_data = {
					items: [
						{
							title: '响应错误模式：',
							width: '330px',
							name: 'error_model',
							type: 'select',
							value: rdata.error_model,
							items: [
								{
									title: '自定义错误页',
									value: 'Custom',
								},
								{
									title: '详细错误页',
									value: 'Detailed',
								},
								{
									title: '本地请求的详细错误页和远程请求的自定义错误页',
									value: 'DetailedLocalOnly',
								},
							],
						},
						{
							name: 'btn_set_error_model',
							text: '切换',
							type: 'button',
							callback: function (ldata) {
								ldata['name'] = web.name;
								bt.site.set_site_error_model(ldata, function (ret) {
									if (ret.status) {
										site.reload();
									}
									bt.msg(ret);
								});
							},
						},
					],
				};
				bt.render_form_line(_from_data, '', $('#webedit-con').empty());

				$('#webedit-con').append("<div class='divtable mtb15' style='height:380px;overflow:auto'><table id='error_page_table' class='table table-hover' width='100%'></table></div>");
				bt.render({
					table: '#error_page_table',
					columns: [
						{
							field: 'statusCode',
							width: '55px',
							title: '错误码',
							templet: function (item) {
								return item.statusCode;
							},
						},
						{
							field: 'responseMode',
							width: '60px',
							title: '类型',
							templet: function (item) {
								switch (item.responseMode) {
									case 'File':
										return '文件';
									case 'ExecuteURL':
										return '根目录';
										break;
									case 'Redirect':
										return '重定向';
										break;
								}
							},
						},
						{
							field: 'path',
							title: '路径',
							templet: function (item) {
								if (item.prefixLanguageFilePath != '') {
									var path = item.prefixLanguageFilePath + '\\' + item.path;
									return path;
								} else {
									return item.path;
								}
							},
						},
						{
							field: 'opt',
							width: '80px',
							title: '操作',
							templet: function (item) {
								return '<a class="btlink edit_error_page" href="javascript:;">编辑</a> | <a class="btlink re_error_page" href="javascript:;">还原</a>';
							},
						},
					],
					data: rdata.list,
				});
				$('.re_error_page').click(function () {
					var item = $(this).parents('tr').data('item');
					bt.confirm(
						{
							msg: '是否确定还原错误码[' + item.statusCode + ']显示页？',
							title: '提示',
						},
						function () {
							bt.site.re_error_page_bycode(web.name, item.statusCode, function (ret) {
								if (ret.status) {
									site.reload();
								}
								bt.msg(ret);
							});
						}
					);
				});

				$('.edit_error_page').click(function () {
					var item = $(this).parents('tr').data('item');
					bt.render_form({
						title: '编辑【' + item.statusCode + '】错误页',
						area: '530px',
						list: [
							{
								title: '错误码',
								name: 'code',
								value: item.statusCode,
								disabled: true,
							},
							{
								title: '类型',
								name: 'responseMode',
								type: 'select',
								value: item.responseMode,
								items: [
									{
										title: '根目录',
										value: 'ExecuteURL',
									},
									{
										title: '重定向',
										value: 'Redirect',
									},
								],
							},
							{
								title: '地址',
								name: 'path',
								value: item.path,
							},
						],
						btns: [
							{
								title: '关闭',
								name: 'close',
							},
							{
								title: '提交',
								name: 'submit',
								css: 'btn-success',
								callback: function (rdata, load, callback) {
									if (rdata.responseMode == 'Redirect') {
										if (!bt.check_url(rdata.path)) {
											bt.msg({
												icon: 2,
												msg: '地址格式不正确,格式为：https://www.bt.cn',
											});
											return;
										}
									} else {
										var reg = /^\/.+/;
										if (!reg.test(rdata.path)) {
											bt.msg({
												icon: 2,
												msg: '地址格式不正确,格式为：/404.html',
											});
											return;
										}
									}
									bt.confirm(
										{
											msg: '您确定修改' + item.statusCode + '错误页吗？',
											title: '编辑',
										},
										function () {
											var loading = bt.load();
											rdata['name'] = web.name;
											bt.send('set_error_page_bycode', 'site/set_error_page_bycode', rdata, function (rRet) {
												loading.close();
												if (rRet.status) {
													load.close();
													site.reload();
												}
												bt.msg(rRet);
											});
										}
									);
								},
							},
						],
					});
				});
				$('#webedit-con').append(
					bt.render_help([
						'重定向：302重定向到指定url(如：https://www.bt.cn)',
						'根目录：访问到网站根目录指定文件(如：/404.html)',
						'IIS出现500错误处理方案 <a href="https://www.bt.cn/bbs/thread-33102-1-1.html" target="_blank" class="btlink"> 使用帮助</a>',
					])
				);
			});
		},
		set_dirguard: function (web) {
			bt.site.get_dir_auth(web.id, function (res) {
				if (res.status == false) {
					bt.msg(res);
					return;
				}
				$('#webedit-con').html('<div id="set_dirguard"></div>');
				var tab =
					'\
                <div class="tab-nav mb15">\
                    <span class="on">加密访问</span><span>双向认证<b style="color: #fc6d26;">【推荐】</b></span>\
                </div>\
                <div class="tabs_content">\
                    <div class="tabpanel" id="dir_dirguard"></div>\
                    <div class="tabpanel" id="authentication" style="display: none;"></div>\
                </div>';
				$('#set_dirguard').html(tab);
				bt_tools.table({
					el: '#dir_dirguard',
					url: '/site?action=get_dir_auth',
					param: { id: web.id },
					height: 450,
					dataFilter: function (res) {
						return { data: res[web.name] };
					},
					column: [
						{ fid: 'name', title: '名称', type: 'text' },
						{ fid: 'site_dir', title: '保护的目录', type: 'text' },
						{
							title: '操作',
							width: 110,
							type: 'group',
							align: 'right',
							group: [
								{
									title: '编辑',
									event: function (row, index, ev, key, that) {
										site.edit.template_Dir(web.id, false, row);
									},
								},
								{
									title: '删除',
									event: function (row, index, ev, key, that) {
										bt.site.delete_dir_guard(web.id, row.name, function (res) {
											if (res.status) that.$delete_table_row(index);
											bt.msg(res);
										});
									},
								},
							],
						},
					],
					tootls: [
						{
							// 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [
								{
									title: '添加访问限制',
									active: true,
									event: function (ev) {
										site.edit.template_Dir(web.id, true);
									},
								},
							],
						},
					],
				});
				var theStatus = 1,
					authentication_table = null;
				function renderAuthentication() {
					//判断是否配置证书
					$.post('/plugin?action=a&name=ssl_verify&s=get_config', {}, function (rdata) {
						if (rdata.length == 0) {
							layer.msg('请先完善配置', { time: 700, icon: 2 }, function () {
								config_ssl_info(rdata);
							});
							return false;
						}
						$('#authentication').empty();
						authentication_table = bt_tools.table({
							el: '#authentication',
							url: '/plugin?action=a&name=ssl_verify&s=get_ssl_list',
							height: '411',
							beforeRequest: function (params) {
								return { status: theStatus, search: params.search };
							},
							column: [
								{ fid: 'client', title: '使用者', type: 'text' },
								{ fid: 'company', title: '公司名称', type: 'text' },
								{
									title: '到期时间',
									width: 150,
									type: 'text',
									template: function (row, index) {
										var lastTime = get_last_time(row.day, row.last_modify);
										var day = get_remaining_day(lastTime);
										return '<span>' + (row.status == 1 ? bt.format_data(lastTime, 'yyyy-MM-dd') + '(剩余' + day + '天)' : '-') + '</span>';
									},
								},
								{
									title: '状态',
									width: 52,
									type: 'text',
									template: function (row, index) {
										return get_cert_status(row.status);
									},
								},
								{
									title: '操作',
									type: 'group',
									width: 125,
									align: 'right',
									group: [
										{
											title: '续签',
											hide: function (rows) {
												var lastTime = get_last_time(rows.day, rows.last_modify);
												var day = get_remaining_day(lastTime);
												return day > 30 || rows.status != 1;
											},
											event: function (row, index, ev, key, that) {
												var loadT = layer.msg('正在续签证书，请稍侯...', {
													icon: 16,
													time: 0,
													shade: 0.3,
												});
												$.post('/plugin?action=a&name=ssl_verify&s=get_user_cert', { client: row.client }, function (rdata) {
													layer.close(loadT);
													if (rdata.status) {
														authentication_table.$refresh_table_list(true);
													}
													layer.msg(rdata.msg, {
														icon: rdata.status ? 1 : 2,
													});
												});
											},
										},
										{
											title: '下载',
											hide: function (rows) {
												return rows.status != 1;
											},
											event: function (row, index, ev, key, that) {
												var loadT = layer.msg('正在下载证书，请稍侯...', {
													icon: 16,
													time: 0,
													shade: 0.3,
												});
												$.post('/plugin?action=a&name=ssl_verify&s=down_client_pfx', { id: row.id }, function (rdata) {
													layer.close(loadT);
													if (rdata.status) {
														window.open('/download?filename=' + encodeURIComponent(rdata.msg));
													} else {
														layer.msg(rdata.msg, { icon: 2 });
													}
												});
											},
										},
										{
											title: '撤销',
											hide: function (rows) {
												return rows.status != 1;
											},
											event: function (row, index, ev, key, that) {
												layer.confirm(
													'是否撤销当前用户【' + row.client + '】的证书,是否继续？',
													{
														btn: ['确认', '取消'],
														icon: 3,
														closeBtn: 2,
														title: '撤销证书',
													},
													function () {
														var loadT = layer.msg('正在撤销证书，请稍侯...', {
															icon: 16,
															time: 0,
															shade: 0.3,
														});
														$.post('/plugin?action=a&name=ssl_verify&s=revoke_client_cert', { id: row.id }, function (rdata) {
															layer.close(loadT);
															if (rdata.status) {
																authentication_table.$refresh_table_list(true);
															}
															layer.msg(rdata.msg, {
																icon: rdata.status ? 1 : 2,
															});
														});
													}
												);
											},
										},
									],
								},
							],
							tootls: [
								{
									type: 'group',
									positon: ['left', 'top'],
									list: [
										{
											title: '生成证书',
											active: true,
											event: function () {
												layer.open({
													type: 1,
													area: '400px',
													title: '生成证书',
													closeBtn: 2,
													shift: 5,
													shadeClose: false,
													btn: ['提交', '取消'],
													content:
														'\
                                        <div class="cert_add_box">\
                                            <div class="bt-form" style="padding: 15px 25px;">\
                                                <div class="line">\
                                                    <span class="tname" style="width: 100px;">使用者</span>\
                                                    <div class="info-r">\
                                                        <input type="text" name="cert_client" class="bt-input-text mr5" style="width: 240px" value="" placeholder="请输入使用者（如“研发部-张三”）" />\
                                                    </div>\
                                                </div>\
                                            </div>\
                                        </div>\
                                    ',
													yes: function (index, layers) {
														var client = $('[name=cert_client]').val();
														if (client == '') {
															layer.msg('用户名不能为空', { icon: 2 });
															return false;
														}
														var loadT = layer.msg('正在生成证书，请稍侯...', {
															icon: 16,
															time: 0,
															shade: 0.3,
														});
														$.post('/plugin?action=a&name=ssl_verify&s=get_user_cert', { client: client }, function (rdata) {
															layer.close(loadT);
															if (rdata.status) {
																layer.close(index);
																authentication_table.$refresh_table_list(true);
															}
															layer.msg(rdata.msg, {
																icon: rdata.status ? 1 : 2,
															});
														});
													},
												});
											},
										},
									],
								},
								{
									type: 'search',
									positon: ['right', 'top'],
									placeholder: '请输入用户名',
									width: '150px',
									searchParam: 'search', //搜索请求字段，默认为 search
									value: '', // 当前内容,默认为空
								},
							],
							success: function (that) {
								var serachDom = $('.search_input_' + that.random).parent('.bt_search');
								var btnDom = $('.tootls_top .group_' + that.random + '_0').parent('.pull-left');
								if ($('.mutual_ssl').length == 0) {
									btnDom.append(
										'<div class="mutual_ssl pull-right" style="margin-left: 30px;"><span style="line-height: 22px;margin-right: 5px;">双向认证开关</span>\
                            <div class="mutual-switch" style="display: inline-block;vertical-align: middle;">\
                                <input class="btswitch btswitch-ios" id="mutualSwitch" type="checkbox">\
                                <label class="btswitch-btn" for="mutualSwitch"></label>\
                            </div></div>'
									);
									serachDom.prepend(
										'<div class="related_status" style="display: inline-block;margin-right: 10px;vertical-align: bottom;font-size: 0;"><span style="font-size:12px;vertical-align: middle;margin-right:5px">状态</span> <div class="btn-group">\
                                <button type="button" class="btn btn-default btn-sm">\
                                    <span>全部</span>\
                                    <input type="checkbox" class="hide" value="0">\
                                </button>\
                                <button type="button" class="btn btn-default btn-sm">\
                                    <span>正常</span>\
                                    <input type="checkbox" class="hide" value="1">\
                                </button>\
                                <button type="button" class="btn btn-default btn-sm">\
                                    <span>已撤销</span>\
                                    <input type="checkbox" class="hide" value="-1">\
                                </button>\
                            </div></div>'
									);
									$('.related_status button')
										.eq(theStatus == -1 ? 2 : theStatus)
										.addClass('btn-success');
									$('#authentication').append(
										'<button type="button" title="证书配置" class="btn btn-default config_ssl_info btn-sm mr5">证书配置</button><ul class="help-info-text c7" style="margin-top: 50px;"><li>双向认证仅支持【HTTPS访问】，如需全站设置，还需通过网站设置开启【强制HTTPS】.</li><li>给网站开启【双向认证】，开启后用户需要将【证书】导入到浏览器后才能访问该网站（目前支持Nginx/Apache）</li></ul>'
									);
									$('.config_ssl_info').click(function () {
										$.post('/plugin?action=a&name=ssl_verify&s=get_config', {}, function (rdata) {
											config_ssl_info(rdata);
										});
									});

									// 客户端证书列表搜索
									$('.related_status button').click(function () {
										var _class = 'btn-success';
										if ($(this).hasClass(_class)) return;
										$(this).addClass(_class).siblings().removeClass(_class);
										theStatus = $(this).find('input').val();
										authentication_table.$refresh_table_list(true);
									});
									getMutualStatus(function (str) {
										$('#mutualSwitch').prop('checked', str); //开关状态
									});
									$('[for=mutualSwitch]').click(function () {
										var _status = $('#mutualSwitch').prop('checked');
										var loadT = layer.msg('正在设置双向认证状态，请稍侯...', {
											icon: 16,
											time: 0,
											shade: 0.3,
										});
										$.post(
											'/plugin?action=a&name=ssl_verify&s=set_ssl_verify',
											{
												siteName: web.name,
												status: _status ? 0 : 1,
											},
											function (rdata) {
												layer.close(loadT);
												if (!rdata.status) $('#mutualSwitch').prop('checked', _status);
												layer.msg(rdata.msg, {
													icon: rdata.status ? 1 : 2,
												});
											}
										);
									});
								}
							},
						});
						/**
						 * 生成证书状态
						 * @param {*} status 状态值
						 */
						function get_cert_status(status) {
							if (status == 1) {
								return '<span>正常</span>';
							}
							if (status == -1) {
								return '<span class="error">已撤销</span>';
							}
							return '<span>未知</span>';
						}
						/**
						 * 获取证书到期的时间戳
						 * @param {*} day 证书可用天数
						 * @param {*} lastModify 生成证书的时间戳
						 */
						function get_last_time(day, lastModify) {
							day = day || 0;
							day = day * 24 * 60 * 60;
							lastModify = lastModify || 0;
							return day + lastModify;
						}
						/**
						 * 获取证书的剩余天数
						 * @param {*} lastTime 到期时间戳
						 */
						function get_remaining_day(lastTime) {
							var date = new Date();
							var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
							var todayTime = today.getTime() / 1000;
							var day = (lastTime - todayTime) / 60 / 60 / 24;
							return Math.floor(day);
						}
						function config_ssl_info(info) {
							var param = { company: '', domain: '' };
							if (info && info.length > 0) param = info[0];
							layer.open({
								type: 1,
								area: ['520px', '290px'],
								title: '证书配置',
								closeBtn: 2,
								shift: 5,
								shadeClose: false,
								btn: ['保存', '取消'],
								content:
									'\
                                    <div class="cert_add_box">\
                                        <div class="bt-form" style="padding: 15px 25px;">\
                                            <div class="line">\
                                                <span class="tname" style="width: 100px;">公司名称</span>\
                                                <div class="info-r">\
                                                    <input type="text" name="config_client" class="bt-input-text mr5" style="width: 340px" value="' +
									param.company +
									'" placeholder="请输入公司名称" />\
                                                </div>\
                                            </div>\
                                            <div class="line">\
                                            <span class="tname">域名列表</span>\
                                            <div class="info-r">\
                                                <textarea class="bt-input-text newdomain" name="config_domain" style="width: 340px;height: 100px;line-height: 22px;">' +
									param.domain +
									'</textarea>\
                                                <div class="placeholder c9" style="display: ' +
									(param.domain ? 'none' : 'block') +
									';top:15px;left:15px;">请输入域名列表<br>多个域名可以用英文状态下的逗号隔开</div>\
                                            </div>\
                                        </div>\
                                        </div>\
                                    </div>',
								success: function () {
									// 文本域选中
									$('[name=config_domain]')
										.focus(function () {
											$('.placeholder').hide();
										})
										.blur(function () {
											if ($(this).val().length == 0) $('.placeholder').show();
										});
									// 文本域描述点击
									$('.cert_add_box .placeholder').click(function (e) {
										$(this).hide();
										$(this).siblings('textarea').focus();
									});
								},
								yes: function (index, layers) {
									var client = $('[name=config_client]').val();
									var domain = $('[name=config_domain]').val();
									if (client == '') {
										layer.msg('公司名称不能为空', { icon: 2 });
										return false;
									}
									if (domain == '') {
										layer.msg('域名列表不能为空', { icon: 2 });
										return false;
									}
									var loadT = layer.msg('正在保存配置，请稍侯...', {
										icon: 16,
										time: 0,
										shade: 0.3,
									});
									$.post('/plugin?action=a&name=ssl_verify&s=set_config', { company: client, domain: domain }, function (rdata) {
										layer.close(loadT);
										if (rdata.status) {
											layer.close(index);
										}
										layer.msg(rdata.msg, {
											icon: rdata.status ? 1 : 2,
										});
									});
								},
							});
						}
						/**
						 * @descripttion: 请求双向认证状态
						 */
						function getMutualStatus(callback) {
							var loadT = layer.msg('正在双向认证状态，请稍侯...', {
								icon: 16,
								time: 0,
								shade: 0.3,
							});
							$.get('/plugin?action=a&name=ssl_verify&s=get_site_list', function (res) {
								layer.close(loadT);
								$.each(res, function (index, item) {
									if (item.name === web.name) {
										if (callback) callback(item.ssl_verify);
									}
								});
							});
						}
					});
				}

				// 访问限制tab切换
				$('#set_dirguard').on('click', '.tab-nav span', function () {
					var index = $(this).index();
					$(this).addClass('on').siblings('.on').removeClass('on');
					$('#set_dirguard .tabpanel').hide();
					$('#set_dirguard .tabpanel').eq(index).show();
					if (index == 1) {
						var _isInstall = site.edit.render_recommend_product();
						if (_isInstall) {
							renderAuthentication();
						}
					} else {
						$('.daily-thumbnail.recommend').remove();
					}
				});
			});
		},

		limit_network: function (web) {
			var loadT = bt.load();
			bt.site.get_limitnet(web.id, function (rdata) {
				loadT.close();
				if (rdata.status === false) {
					bt.msg(rdata);
					return;
				}
				var limits = [
					{
						title: '论坛/博客',
						value: 1,
						items: {
							perserver: 300,
							perip: 25,
							limit_rate: 512,
						},
					},
					{
						title: '图片站',
						value: 2,
						items: {
							perserver: 200,
							perip: 10,
							limit_rate: 1024,
						},
					},
					{
						title: '下载站',
						value: 3,
						items: {
							perserver: 50,
							perip: 3,
							limit_rate: 2048,
						},
					},
					{
						title: '商城',
						value: 4,
						items: {
							perserver: 500,
							perip: 10,
							limit_rate: 2048,
						},
					},
					{
						title: '门户',
						value: 5,
						items: {
							perserver: 400,
							perip: 15,
							limit_rate: 1024,
						},
					},
					{
						title: '企业',
						value: 6,
						items: {
							perserver: 60,
							perip: 10,
							limit_rate: 512,
						},
					},
					{
						title: '视频',
						value: 7,
						items: {
							perserver: 150,
							perip: 4,
							limit_rate: 1024,
						},
					},
				];
				var datas = [
					{
						items: [
							{
								name: 'status',
								type: 'checkbox',
								value: rdata.perserver != 0 ? true : false,
								text: '启用流量控制',
								callback: function (ldata) {
									if (ldata.status) {
										bt.site.set_limitnet(web.id, ldata, function (ret) {
											if (ret.status) site.reload(3);
										});
									} else {
										bt.site.close_limitnet(web.id, function (ret) {
											if (ret.status) site.reload(3);
										});
									}
								},
							},
						],
					},
					{
						items: [
							{
								title: '限制方案  ',
								width: '160px',
								name: 'limit',
								type: 'select',
								items: limits,
								callback: function (obj) {
									var data = limits.filter(function (p) {
										return p.value === parseInt(obj.val());
									})[0];
									for (var key in data.items) $('input[name="' + key + '"]').val(data.items[key]);
								},
							},
						],
					},
					{
						items: [
							{
								title: '并发限制   ',
								type: 'number',
								width: '200px',
								value: rdata.perserver,
								name: 'perserver',
							},
						],
					},
					{
						hide: bt.os == 'Linux' ? false : true,
						items: [
							{
								title: '单IP限制   ',
								type: 'number',
								width: '200px',
								value: rdata.perip,
								name: 'perip',
							},
						],
					},
					{
						hide: bt.os == 'Linux' ? true : false,
						items: [
							{
								title: '超时时间   ',
								type: 'number',
								width: '200px',
								value: rdata.timeout ? rdata.timeout : 120,
								name: 'timeout',
							},
						],
					},
					{
						items: [
							{
								title: '流量限制   ',
								type: 'number',
								width: '200px',
								value: rdata.limit_rate,
								name: 'limit_rate',
							},
						],
					},
					{
						name: 'btn_limit_get',
						text: rdata.perserver != 0 ? '保存' : '保存并启用',
						type: 'button',
						callback: function (ldata) {
							bt.site.set_limitnet(web.id, ldata, function (ret) {
								if (ret.status) site.reload(3);
								bt.msg(ret);
							});
						},
					},
				];
				var _html = $("<div class='webedit-box soft-man-con'></div>");
				var clicks = [];
				for (var i = 0; i < datas.length; i++) {
					var _form_data = bt.render_form_line(datas[i]);
					_html.append(_form_data.html);
					clicks = clicks.concat(_form_data.clicks);
				}
				_html.find('input[type="checkbox"]').parent().addClass('label-input-group ptb10');
				_html.append(bt.render_help(['限制当前站点最大并发数', '限制单个IP访问最大并发数', '限制每个请求的流量上限（单位：KB）']));
				$('#webedit-con').append(_html);
				bt.render_clicks(clicks);
				if (rdata.perserver == 0) $("select[name='limit']").trigger('change');
			});
		},
		get_rewrite_list: function (web) {
			var filename = '/www/server/panel/vhost/rewrite/' + web.name + '.conf';
			if (bt.get_cookie('serverType') == 'apache') filename = web.path + '/.htaccess';
			bt.site.get_rewrite_list(web.name, function (rdata) {
				var arrs = [];
				for (var i = 0; i < rdata.rewrite.length; i++)
					arrs.push({
						title: rdata.rewrite[i],
						value: rdata.rewrite[i],
					});

				var datas = [
					{
						name: 'rewrite',
						type: 'select',
						width: '130px',
						items: arrs,
						callback: function (obj) {
							var spath = filename;
							if (bt.os != 'Linux' && obj.val() == lan.site.rewritename) {
								var loadT = bt.load();
								bt.site.get_site_rewrite(web.name, function (ret) {
									if (ret.status === false) {
										bt.msg(ret);
										return;
									}
									loadT.close();
									editor.setValue(ret.data);
								});
							} else {
								if (obj.val() != lan.site.rewritename) spath = setup_path + '/panel/rewrite/' + bt.get_cookie('serverType') + '/' + obj.val() + '.conf';
								bt.files.get_file_body(spath, function (ret) {
									editor.setValue(ret.data);
								});
							}
						},
					},
					{
						items: [
							{
								name: 'config',
								type: 'textarea',
								value: rdata.data,
								widht: '340px',
								height: '200px',
							},
						],
					},
					{
						items: [
							{
								name: 'btn_save',
								text: '保存',
								type: 'button',
								callback: function (ldata) {
									if (bt.os == 'Linux') {
										bt.files.set_file_body(filename, editor.getValue(), 'utf-8', function (ret) {
											if (ret.status) site.reload(4);
											bt.msg(ret);
										});
									} else {
										var loading = bt.load();
										bt.site.set_site_rewrite(web.name, editor.getValue(), function (ret) {
											loading.close();
											if (ret.status) site.reload();
											bt.msg(ret);
										});
									}
								},
							},
							{
								name: 'btn_save_to',
								text: '另存为模板',
								type: 'button',
								callback: function (ldata) {
									var temps = {
										title: lan.site.save_rewrite_temp,
										area: '330px',
										list: [{ title: '模板名称', placeholder: '模板名称', width: '160px', name: 'tempname' }],
										btns: [
											{ title: '关闭', name: 'close' },
											{
												title: '提交',
												name: 'submit',
												css: 'btn-success',
												callback: function (rdata, load, callback) {
													var name = rdata.tempname;
													var isSameName = false;
													for (var i = 0; i < arrs.length; i++) {
														if (arrs[i].value == name) {
															isSameName = true;
															break;
														}
													}
													var save_to = function () {
														bt.site.set_rewrite_tel(name, editor.getValue(), function (rRet) {
															if (rRet.status) {
																load.close();
																site.reload(4);
															}
															bt.msg(rRet);
														});
													};
													if (isSameName) {
														return layer.msg('模板名称已存在，请重新输入模板名称!');
													} else {
														save_to();
													}
												},
											},
										],
									};
									bt.render_form(temps);
								},
							},
						],
					},
				];
				var _html = $("<div class='webedit-box soft-man-con'></div>");
				var clicks = [];
				for (var i = 0; i < datas.length; i++) {
					var _form_data = bt.render_form_line(datas[i]);
					_html.append(_form_data.html);
					var _other = bt.os == 'Linux' && i == 0 ? '<span>规则转换工具：<a href="https://www.bt.cn/Tools" target="_blank" style="color:#20a53a">Apache转Nginx</a></span>' : '';
					_html.find('.info-r').append(_other);
					clicks = clicks.concat(_form_data.clicks);
				}
				_html.append(bt.render_help(['请选择您的应用，若设置伪静态后，网站无法正常访问，请尝试设置回default', '您可以对伪静态规则进行修改，修改完后保存即可。']));
				$('#webedit-con').append(_html);
				bt.render_clicks(clicks);

				$('textarea.config').attr('id', 'config_rewrite');
				var editor = CodeMirror.fromTextArea(document.getElementById('config_rewrite'), {
					extraKeys: {
						'Ctrl-Space': 'autocomplete',
					},
					lineNumbers: true,
					matchBrackets: true,
				});
				$('.CodeMirror-scroll').css({
					height: '340px',
					margin: 0,
					padding: 0,
				});
				$('select.rewrite').trigger('change');
			});
		},
		set_default_index: function (web) {
			var loadT = bt.load();
			bt.site.get_index(web.id, function (rdata) {
				loadT.close();
				if (rdata.status === false) {
					bt.msg(rdata);
					return;
				}
				rdata = rdata.replace(new RegExp(/(,)/g), '\n');
				var data = {
					items: [
						{
							name: 'Dindex',
							height: '230px',
							width: '50%',
							type: 'textarea',
							value: rdata,
						},
						{
							name: 'btn_submit',
							text: '保存',
							type: 'button',
							callback: function (ddata) {
								var Dindex = ddata.Dindex.replace(new RegExp(/(\n)/g), ',');
								bt.site.set_index(web.id, Dindex, function (ret) {
									if (ret.status) site.reload(5);
									layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
								});
							},
						},
					],
				};
				var _form_data = bt.render_form_line(data);
				var _html = $(_form_data.html);
				_html.append(bt.render_help([lan.site.default_doc_help]));
				$('#webedit-con').append(_html);
				$('.btn_submit').addClass('pull-right').css('margin', '90px 100px 0 0');
				bt.render_clicks(_form_data.clicks);
			});
		},
		set_config: function (web) {
			var loadT = bt.load();
			bt.site.get_site_config(web.name, function (rdata) {
				loadT.close();
				if (rdata.status == false) {
					bt.msg(rdata);
					return;
				}
				var datas = [
					{
						items: [
							{
								name: 'site_config',
								type: 'textarea',
								value: rdata.data,
								widht: '340px',
								height: '200px',
							},
						],
					},
					{
						items: [
							{
								name: 'btn_config_submit',
								text: '保存',
								type: 'button',
								callback: function (ddata) {
									if (bt.get_cookie('serverType') == 'iis') {
										bt.confirm(
											{
												msg: "注意：此为网站配置文件，如擅自修改，可能会导致以下错误：<br>1、设置的PHP版本无效<br>2、301、302、伪静态、强制https等规则失效<br>3、默认文档设置无效<br>4、错误页设置无效<br><span style='color:red'>如需设置301、302、跳转https，请将规则粘贴到【伪静态】</span>",
												title: '警告',
											},
											function () {
												bt.site.set_site_config(web.name, editor.getValue(), rdata.encoding, function (ret) {
													if (ret.status) site.reload(6);
													bt.msg(ret);
												});
											}
										);
									} else {
										bt.site.set_site_config(web.name, editor.getValue(), rdata.encoding, function (ret) {
											if (ret.status) site.reload(6);
											bt.msg(ret);
										});
									}
								},
							},
						],
					},
				];
				if (web.type != 'java') {
					datas[1].items.push({
						name: 'btn_re_config_submit',
						text: '恢复默认配置',
						type: 'button',
						callback: function (ddata) {
							bt.confirm(
								{
									msg: '网站配置将会恢复到初始状态，是否继续修改？',
									title: '提示',
								},
								function () {
									bt.site.set_re_site_config(web.name, function (ret) {
										if (ret.status) site.reload(6);
										bt.msg(ret);
									});
								}
							);
						},
					});
				}
				var robj = $('#webedit-con');
				for (var i = 0; i < datas.length; i++) {
					var _form_data = bt.render_form_line(datas[i]);
					robj.append(_form_data.html);
					bt.render_clicks(_form_data.clicks);
				}
				var helps = [lan.site.web_config_help];
				if (bt.get_cookie('serverType') == 'iis') {
					helps.push('<span style="color:red">如您的部分操作不生效，请尝试将配置文件恢复到默认配置(如php版本，重定向等)</span>');
					helps.push('IIS配置文件格式说明 <a href="https://www.bt.cn/bbs/thread-33097-1-1.html" target="_blank" class="btlink"> 使用帮助</a>');
				}
				robj.append(bt.render_help(helps));
				$('textarea.site_config').attr('id', 'configBody');
				var editor = CodeMirror.fromTextArea(document.getElementById('configBody'), {
					extraKeys: {
						'Ctrl-Space': 'autocomplete',
					},
					lineNumbers: true,
					matchBrackets: true,
				});
				$('.CodeMirror-scroll').css({
					height: '400px',
					margin: 0,
					padding: 0,
				});
			});
		},
		set_ssl: function (web) {
			bt.site.get_site_ssl(web.name, function (rdata) {
				var isIIS = bt.get_cookie('serverType') == 'iis'; //是否为iis证书
				unidentification = rdata.data;
				if (!isIIS) {
					var type = rdata.type; // 类型
					var certificate = rdata.cert_data; // 证书信息
					var pushAlarm = rdata.push; // 是否推送告警
					var isStart = rdata.status; // 是否启用
					var layers = null;
					var expirationTime = certificate.endtime; // 证书过期时间
					var isRenew = (function () {
						// 是否续签
						var state = false;
						if (expirationTime <= 30) state = true;
						if (type === 2 && expirationTime < 0) state = true;
						if (type === 0 || type === -1) state = false;
						return state;
					})();

					// 续签视图
					function renewal_ssl_view(item) {
						bt.confirm(
							{
								title: '续签证书',
								msg: '当前证书订单需要重新生成新订单，需要手动续签，和重新部署证书，是否继续操作?',
							},
							function () {
								var loadT = bt.load('正在续签证书，可能等待时间较长，请稍候...');
								bt.send(
									'renew_cert_order',
									'ssl/renew_cert_order',
									{
										pdata: JSON.stringify({ oid: item.oid }),
									},
									function (res) {
										loadT.close();
										site.reload();
										setTimeout(function () {
											bt.msg(res);
										}, 1000);
									}
								);
							}
						);
					}

					// 申请宝塔证书
					function apply_bt_certificate() {
						var html = '';
						var domains = [];
						for (var i = 0; i < rdata.domain.length; i++) {
							var item = rdata.domain[i];
							if (item.name.indexOf('*') == -1) domains.push({ title: item.name, value: item.name });
						}
						for (var i = 0; i < domains.length; i++) {
							var item = domains[i];
							html += '<option value="' + item.value + '">' + item.title + '</option>';
						}
						bt.open({
							type: 1,
							title: '申请免费宝塔SSL证书',
							area: '610px',
							content:
								'<form class="bt_form perfect_ssl_info free_ssl_info" onsubmit="return false;">\
                            <div class="line">\
                                <span class="tname">证书信息</span>\
                                <div class="info-r">\
                                    <span class="ssl_title">TrustAsia TLS RSA CA(免费版)</span>\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">域名</span>\
                                <div class="info-r"><select class="bt-input-text mr5 " name="domain" style="width:200px">' +
								html +
								'</select></div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">个人/公司名称</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgName" value="" placeholder="请输入个人/公司名称，必填项" />\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">所在地区</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgRegion" value="" placeholder="请输入所在省份，必填项" style="width: 190px; margin-right:0;" >\
                                    <input type="text" class="bt-input-text mr5" name="orgCity" value="" placeholder="请输入所在市/县，必填项" style="width: 190px; margin-left: 15px;"  />\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">地址</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgAddress" value="" placeholder="请输入个人/公司地址，必填项" />\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">手机</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgPhone" value="" placeholder="请输入手机号码，必填项" />\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname">邮政编码</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgPostalCode" value="" placeholder="请输入邮政编码，必填项" />\
                                </div>\
                            </div>\
                            <div class="line" style="display:none;">\
                                <span class="tname">部门</span>\
                                <div class="info-r">\
                                    <input type="text" class="bt-input-text mr5" name="orgDivision" value="总务"/>\
                                </div>\
                            </div>\
                            <div class="line">\
                                <span class="tname"></span>\
                                <div class="info-r">\
                                    <span style="line-height: 20px;color:red;display: inline-block;">禁止含有诈骗、赌博、色情、木马、病毒等违法违规业务信息的站点申请SSL证书，如有违反，撤销申请，停用账号</span>\
                                </div>\
                            </div>\
                            <div class="line">\
                                <div class="info-r"><button class="btn btn-success submit_ssl_info">提交资料</button></div>\
                            </div>\
                        </form>',
							success: function (layero, index) {
								$('.submit_ssl_info').click(function () {
									var form = $('.free_ssl_info').serializeObject();
									for (var key in form) {
										if (Object.hasOwnProperty.call(form, key)) {
											var value = form[key],
												el = $('[name="' + key + '"]');
											if (value == '') {
												layer.tips(el.attr('placeholder'), el, { tips: ['1', 'red'] });
												el.focus();
												el.css('borderColor', 'red');
												return false;
											} else {
												el.css('borderColor', '');
											}
											switch (key) {
												case 'orgPhone':
													if (!bt.check_phone(value)) {
														layer.tips('手机号码格式错误', el, { tips: ['1', 'red'] });
														el.focus();
														el.css('borderColor', 'red');
														return false;
													}
													break;
												case 'orgPostalCode':
													if (!/^[0-9]\d{5}(?!\d)$/.test(value)) {
														layer.tips('邮政编号格式错误', el, { tips: ['1', 'red'] });
														el.focus();
														el.css('borderColor', 'red');
														return false;
													}
													break;
											}
										}
									}
									if (form.domain.indexOf('www.') != -1) {
										var rootDomain = form.domain.split(/www\./)[1];
										if (!$.inArray(domains, rootDomain)) {
											layer.msg('您为域名[' + form.domain + ']申请证书，但程序检测到您没有将其根域名[' + rootDomain + ']绑定并解析到站点，这会导致证书签发失败!', { icon: 2, time: 5000 });
											return;
										}
									}
									var loadT = bt.load('正在提交证书资料，请稍候...');
									bt.send('ApplyDVSSL', 'ssl/ApplyDVSSL', $.extend(form, { path: web.path }), function (tdata) {
										loadT.close();
										if (tdata.msg.indexOf('<br>') != -1) {
											layer.msg(tdata.msg, { time: 0, shadeClose: true, area: '600px', icon: 2, shade: 0.3 });
										} else {
											bt.msg(tdata);
										}
										if (tdata.status) {
											layer.close(index);
											site.ssl.verify_domain(tdata.data.partnerOrderId, web.name);
										}
									});
								});
								$('.free_ssl_info input').keyup(function (res) {
									var value = $(this).val();
									if (value == '') {
										layer.tips($(this).attr('placeholder'), $(this), { tips: ['1', 'red'] });
										$(this).focus();
										$(this).css('borderColor', 'red');
									} else {
										$(this).css('borderColor', '');
									}
								});
							},
						});
					}

					if (!Array.isArray(certificate.dns)) certificate = { dns: [] };

					$('#webedit-con').html(
						'<div class="warning_info mb10 ' +
							(!isRenew && isStart ? 'hide' : '') +
							'">' +
							'<p class="' +
							(isStart ? 'hide' : '') +
							'">温馨提示：当前站点未开启SSL证书访问，站点访问可能存在风险。<button class="btn btn-success btn-xs ml10 cutTabView">申请证书</button></p>' +
							'<p class="' +
							(isRenew && isStart ? '' : 'hide') +
							' ">温馨提示：当前[ <span class="ellipsis_text" style="display: inline-block;vertical-align:bottom;max-width: 250px;width: auto;" title="' +
							certificate.dns.join('、') +
							'">' +
							certificate.dns.join('、') +
							'</span> ]证书' +
							(expirationTime < 0 ? '已过期' : '即将过期') +
							'，请及时续签 <button class="btn btn-success btn-xs mlr15 renewCertificate" data-type="' +
							rdata.type +
							'">续签证书</button></p>' +
							'</div>' +
							'<div id="ssl_tabs"></div><div class="tab-con" style="padding:10px 0;"></div>'
					);
				} else {
					$('#webedit-con').html("<div id='ssl_tabs'></div><div class='tab-con' style='padding:10px 0;'></div>");
				}
				var _tabs = [
					{
						title: '当前、其他证书 ' + (isIIS ? '' : '- <i class="' + (rdata.status ? 'btlink' : 'bterror') + '">[' + (rdata.status ? '已部署' : '未部署') + ']</i>'),
						on: true,
						callback: function (content) {
							if (isIIS) {
								robj = $('#webedit-con .tab-con');
								var loading = bt.load();
								robj.append(
									'<button class="btn btn-success btn-sm mr10 upload_ssl" style="margin-top:10px">导入证书文件</button><div id=\'ssl_domain_list_panel\' class="divtable mtb15 table-fixed-box" style="max-height:500px;overflow-y: auto;"><table id=\'ssl_domain_list\' class=\'table table-hover\'></table></div>'
								);

								bt.send(
									'get_iis_ssl_bydomain',
									'site/get_iis_ssl_bydomain',
									{
										siteName: web.name,
									},
									function (res) {
										loading.close();
										if (res.status == false) {
											bt.msg(res);
											return;
										}
										var _tab = bt.render({
											table: '#ssl_domain_list',
											columns: [
												{
													field: 'name',
													title: '网站域名',
												},
												{
													field: 'subject',
													title: '证书域名',
													templet: function (item) {
														if (item.status) {
															return item.cert.dns.join('<br>');
														}
														return '--';
													},
												},
												{
													field: 'notAfter',
													width: 130,
													title: '到期时间',
													templet: function (item) {
														if (item.status) {
															return (
																item.cert.notAfter +
																'(<a class="c7 ' +
																(item.cert.endtime >= 0 ? 'btlink' : 'bterror') +
																'">' +
																(item.cert.endtime >= 0 ? item.cert.endtime + '天' : '已过期') +
																'</a>)'
															);
														}
														return '--';
													},
												},
												{
													field: 'status',
													width: 150,
													title: '部署状态',
													templet: function (item) {
														var msg = '';
														if (item.status == true) {
															msg = '<span>已部署';
															if ($.inArray(item.name, item.cert.dns) >= 0) {
																msg += '</span>';
															} else {
																var is_check = false;
																for (var i = 0; i < item.cert.dns; i++) {
																	if (item.cert.dns[i].indexOf('*') >= 0) {
																		if (item.name.indexOf(item.cert.dns[i].replace('*')) >= 0) {
																			is_check = true;
																			break;
																		}
																	}
																}
																if (!is_check) {
																	msg += ' <span  style="color:red">[证书不匹配]</span>';
																} else {
																	msg += '</span>';
																}
															}
														} else {
															msg = '<span>未部署</span>';
														}
														return msg;
													},
												},
												{
													field: 'name',
													align: 'right',
													title: '操作',
													width: 90,
													templet: function (item) {
														return '<a class="btlink" href="javascript:;" onclick="site.edit.set_iis_domain_ssl(\'' + web.name + '\',this,)">选择证书</a> ';
													},
												},
											],
											data: res,
										});
										robj.append(
											bt.render_help([
												'支持拖拽证书文件夹到当前页面进行导入证书文件，<span class="color-red">请导入证书压缩包中' + bt.get_cookie('serverType') + '目录下所有文件</span>',
												'IIS默认一个网站部署一个证书，如果需要给每个域名部署证书，请阅读 <a href="https://www.bt.cn/bbs/thread-35492-1-1.html" class="btlink" target="_blank">[帮助]</a>。',
												'证书不匹配：表示证书域名列表不包括此域名，需要自行设置有效的域名',
											])
										);
										layer.tips('导入证书文件或者将证书文件夹拖拽到当前页面导入', '.upload_ssl', { tips: [2, '#ff0000'], time: 3000 });
									}
								);
							} else {
								var typeList = ['其他证书', "Let's Encrypt", '宝塔SSL', '商业证书'];
								var state = $(
									'<div class="ssl_state_info ' +
										(!rdata.csr ? 'hide' : '') +
										'">' +
										'<div class="state_info_flex">' +
										'<div class="state_item"><span>证书品牌：</span><span class="ellipsis_text" title="' +
										certificate.issuer +
										'">' +
										certificate.issuer +
										'</span></div>' +
										'<div class="state_item"><span>认证域名：</span><span class="ellipsis_text" title="' +
										certificate.dns.join('、') +
										'">' +
										certificate.dns.join('、') +
										'</span></div>' +
										'</div>' +
										'<div class="state_info_flex">' +
										'<div class="state_item"><span>强制HTTPS：</span><span class="bt_switch"><input class="btswitch btswitch-ios" id="https" type="checkbox" ' +
										(rdata.httpTohttps ? 'checked' : '') +
										'><label class="btswitch-btn" for="https"></label></span></div>' +
										'<div class="state_item"><span>到期时间：</span><span  class="' +
										(expirationTime >= 30 ? 'btlink' : 'bterror') +
										'">' +
										(expirationTime >= 0 ? '剩余' + expirationTime.toFixed(0) + '天到期' : '证书已过期') +
										'</span><span style="border-left: 1px solid #ccc;margin: 0 10px;height: 18px;vertical-align: middle;"></span><span class="bt_switch"><input class="btswitch btswitch-ios" id="expiration" type="checkbox" ' +
										(pushAlarm.status ? 'checked' : '') +
										'><label class="btswitch-btn" for="expiration"></label></span><a class="btlink setAlarmMode" style="margin-left: 15px;" href="javascript:;">到期提醒配置</a></div>' +
										'</div>' +
										'</div>' +
										'<div class="custom_certificate_info">' +
										'<div class="state_item"><span>密钥(KEY)</span><textarea class="bt-input-text key" name="key">' +
										(rdata.key || '') +
										'</textarea></div>' +
										'<div class="state_item"><span>证书(PEM格式)</span><textarea class="bt-input-text key" name="csr">' +
										(rdata.csr || '') +
										'</textarea></div>' +
										'</div>' +
										'<div class="mt10">' +
										'<button type="button" class="btn btn-success btn-sm mr10 saveCertificate ' +
										(isStart ? '' : '') +
										'">' +
										(isStart ? '保存' : '保存并启用证书') +
										'</button>' +
										'<button type="button" class="btn btn-success btn-sm mr10 renewCertificate ' +
										(isRenew || type === 1 ? '' : 'hide') +
										'" data-type="' +
										rdata.type +
										'">续签证书</button>' +
										'<button type="button" class="btn btn-default btn-sm closeCertificate ' +
										(!isStart ? 'hide' : '') +
										'">关闭SSL</button>' +
										'<span style="border-left: 1px solid #ccc;margin: 0 15px 0 5px;"></span>' +
										'<button type="button" class="btn btn-default btn-sm mr10 downloadCertificate ' +
										(!rdata.csr ? 'hide' : '') +
										'">下载证书</button>' +
										'<button class="btn btn-default btn-sm mr10 upload_ssl">导入证书文件</button>' +
										'</div>'
								);
								content.append(state);
								content.append(
									bt.render_help([
										'支持拖拽证书文件夹到当前页面进行导入证书文件，<span class="color-red">请导入证书压缩包中' + bt.get_cookie('serverType') + '目录下所有文件</span>',
										'如果浏览器提示证书链不完整,请检查是否正确拼接PEM证书',
										'在未指定SSL默认站点时，未开启SSL的站点使用HTTPS会直接访问到已开启SSL的站点',
										'如开启后无法使用HTTPS访问，请检查安全组是否正确放行443端口',
									])
								);
								layer.tips('导入证书文件或者将证书文件夹拖拽到当前页面导入', '.upload_ssl', { tips: [2, '#ff0000'], time: 3000 });
								if (!pushAlarm.status && rdata.csr) layers = layer.tips('设置证书到期告警，证书到期后，将会自动推送到期信息。', '.setAlarmMode', { tips: [1, 'red'], time: 3000 });

								var moduleConfig = null;
								function cacheModule(callback) {
									if (moduleConfig && callback) return callback(moduleConfig);
									bt.site.get_module_config({ name: 'site_push', type: 'ssl' }, function (rdata1) {
										moduleConfig = rdata1;
										if (callback) callback(rdata1);
									});
								}

								/**
								 * 提醒到期弹框
								 * @param $check 到期提醒开关
								 */
								function alarmMode($check) {
									var time = new Date().getTime();
									var isExpiration = pushAlarm.status;
									if ($check) isExpiration = $check.is(':checked');
									layer.open({
										type: 1,
										title: '到期提醒配置',
										area: '470px',
										closeBtn: 2,
										content:
											'\
                                    <div class="pd25">\
                                      <div class="bt-form plr15">\
                                        <div class="line">\
                                          <span class="tname">到期提醒</span>\
                                          <div class="info-r line-switch">\
                                            <input type="checkbox" id="dueAlarm" class="btswitch btswitch-ios" name="due_alarm" ' +
											(isExpiration ? 'checked="checked"' : '') +
											' />\
                                            <label class="btswitch-btn" for="dueAlarm"></label>\
                                          </div>\
                                        </div>\
                                        <div class="line">\
                                          <span class="tname">设置站点</span>\
                                          <div class="info-r">\
                                            <input class="bt-input-text mr10" disabled style="width:200px;" value="' +
											web.name +
											'" />\
                                          </div>\
                                        </div>\
                                        <div class="line">\
                                          <span class="tname">证书有效期</span>\
                                          <div class="info-r">\
                                            <div class="inlineBlock">\
                                              <span>小于</span>\
                                              <input type="number" min="1" name="cycle" class="bt-input-text triggerCycle" style="width:50px;" value="' +
											(pushAlarm.cycle || '30') +
											'" />\
                                              <span class="unit">天，将每天发送1次提醒。</span>\
                                            </div>\
                                          </div>\
                                        </div>\
                                        <div class="line">\
                                          <span class="tname">通知方式</span>\
                                          <div class="info-r installPush"></div>\
                                        </div>\
                                        <div class="line">\
                                          <span class="tname">应用配置</span>\
                                          <div class="info-r">\
                                            <div class="inlineBlock module-check setAllSsl">\
                                              <div class="cursor-pointer form-checkbox-label mr10">\
                                                <i class="form-checkbox cust—checkbox cursor-pointer mr5"></i>\
                                                <input type="checkbox" class="form—checkbox-input hide mr10" name="allSsl"/>\
                                                <span class="vertical_middle">将当前配置应用到所有<span class="red">未设置过的站点</span></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                    </div>',
										btn: ['保存配置', '取消'],
										success: function () {
											cacheModule(function (rdata1) {
												// 获取配置
												bt.site.get_msg_configs(function (rdata) {
													var html = '',
														unInstall = '',
														pushList = rdata1.push;
													for (var key in rdata) {
														var item = rdata[key],
															_html = '',
															module = pushAlarm.module || [];
														if (pushList.indexOf(item.name) === -1) continue;
														_html =
															'<div class="inlineBlock module-check ' +
															(!item.setup ? 'check_disabled' : '') +
															'">' +
															'<div class="cursor-pointer form-checkbox-label mr10">' +
															'<i class="form-checkbox cust—checkbox cursor-pointer mr5 ' +
															(module.indexOf(item.name) > -1 ? 'active' : '') +
															'" data-type="' +
															item.name +
															'"></i>' +
															'<input type="checkbox" class="form—checkbox-input hide mr10" name="' +
															item.name +
															'" ' +
															(item.setup ? 'checked' : '') +
															'/>' +
															'<span class="vertical_middle" title="' +
															item.ps +
															'">' +
															item.title +
															(!item.setup ? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">点击安装</a>]' : '') +
															'</span>' +
															'</div>' +
															'</div>';
														if (!item.setup) {
															unInstall += _html;
														} else {
															html += _html;
														}
													}
													$('.installPush').html(html + unInstall);
													$('.setAllSsl').on('click', function () {
														var that = $(this).find('i');
														if (that.hasClass('active')) {
															that.removeClass('active');
															that.next().prop('checked', false);
														} else {
															that.addClass('active');
															that.next().prop('checked', true);
														}
													});
													if (pushAlarm.project === 'all' && pushAlarm.status) $('.setAllSsl').trigger('click');
												});
											});

											// 安装消息通道
											$('.installPush').on('click', '.form-checkbox-label', function () {
												var that = $(this).find('i');
												if (!that.parent().parent().hasClass('check_disabled')) {
													if (that.hasClass('active')) {
														that.removeClass('active');
														that.next().prop('checked', false);
													} else {
														that.addClass('active');
														that.next().prop('checked', true);
													}
												}
											});
											$('.triggerCycle').on('input', function () {
												$('.siteSslHelp span').html($(this).val());
											});

											$('.installPush').on('click', '.installNotice', function () {
												var type = $(this).data('type');
												open_three_channel_auth(type);
											});
										},
										yes: function (index) {
											var status = $('input[name="due_alarm"]').is(':checked');
											var cycle = $('.triggerCycle').val();
											var arry = [];
											var module = '';
											var isAll = $('[name="allSsl"]').is(':checked');
											$('.installPush .active').each(function (item) {
												var item = $(this).attr('data-type');
												arry.push(item);
											});
											if (!arry.length) return layer.msg('请选择至少一种告警通知方式', { icon: 2 });
											if (!parseInt(cycle)) return layer.msg('告警通知时间，不能小于1天', { icon: 2 });

											// 参数
											var data = {
												status: status,
												type: 'ssl',
												project: web.name,
												cycle: parseInt(cycle),
												title: '网站SSL到期提醒',
												module: arry.join(','),
												interval: 600,
											};

											// 判断是否点击全局应用
											if (isAll) {
												// 请求设置全局应用告警配置
												var allData = Object.assign({}, data);
												allData.status = true;
												allData.project = 'all';
												bt.site.set_push_config({
													name: 'site_push',
													id: time,
													data: JSON.stringify(allData),
												});
											}

											// 请求设置本站点告警配置
											bt.site.set_push_config(
												{
													name: 'site_push',
													id: pushAlarm.id ? pushAlarm.id : time,
													data: JSON.stringify(data),
												},
												function (rdata) {
													bt.msg(rdata);
													setTimeout(function () {
														site.reload();
													}, 1000);
													layer.close(index);
												}
											);
										},
										cancel: function () {
											$check && $check.prop('checked', !isExpiration);
										},
										btn2: function () {
											$check && $check.prop('checked', !isExpiration);
										},
									});
								}

								// 设置强制HTTPS
								$('#https').on('click', function () {
									var that = $(this),
										isHttps = $(this).is(':checked');
									if (!isHttps) {
										layer.confirm(
											'关闭强制HTTPS后需要清空浏览器缓存才能看到效果,继续吗?',
											{
												icon: 3,
												closeBtn: 2,
												title: '关闭强制HTTPS',
												cancel: function () {
													that.prop('checked', !isHttps);
												},
												btn2: function () {
													that.prop('checked', !isHttps);
												},
											},
											function () {
												bt.site.close_http_to_https(web.name, function (rdata) {
													if (rdata.status) {
														setTimeout(function () {
															site.reload(7);
														}, 3000);
													} else {
														that.prop('checked', !isHttps);
													}
												});
											}
										);
									} else {
										bt.site.set_http_to_https(web.name, function (rdata) {
											if (rdata.status) {
												setTimeout(function () {
													site.reload(7);
												}, 3000);
											} else {
												that.prop('checked', !isHttps);
											}
										});
									}
								});

								// 设置告警通知
								$('#expiration').on('click', function () {
									layer.close(layers);
									var _that = $(this);
									var isExpiration = $(this).is(':checked');
									var time = new Date().getTime();
									if (isExpiration) {
										alarmMode(_that);
									} else {
										var data = JSON.stringify({
											status: isExpiration,
											type: 'ssl',
											project: web.name,
											cycle: parseInt(pushAlarm.cycle),
											title: '网站SSL到期提醒',
											module: '',
											interval: 600,
										});
										var id = pushAlarm.id ? pushAlarm.id : time;
										if (pushAlarm.project === 'all') id = time;
										bt.site.set_push_config(
											{
												name: 'site_push',
												id: id,
												data: data,
											},
											function (rdata) {
												bt.msg(rdata);
												setTimeout(function () {
													site.reload();
												}, 1000);
											}
										);
									}
								});

								//当前证书内容发生改变
								$('.state_item .bt-input-text').on('change', function () {
									$('.saveCertificate').data('isSave', 1);
								});

								$('.saveCertificate')
									.parents()
									.find('.layui-layer-page')
									.find('.layui-layer-close')
									.click(function () {
										if ($('.saveCertificate').data('isSave')) {
											is_save();
										}
									});
								function is_save(isRefresh) {
									bt.confirm({ title: '提示', msg: '当前证书未保存，是否保存证书？', icon: 0 }, function (indexs) {
										var key = $('[name="key"]').val(),
											csr = $('[name="csr"]').val();
										if (key === '' || csr === '') return bt.msg({ status: false, msg: '请填写完整的证书内容，在保存' });
										bt.site.set_ssl(
											web.name,
											{
												type: rdata.type,
												siteName: rdata.siteName,
												key: key,
												csr: csr,
											},
											function (ret) {
												layer.closeAll();
												bt.msg(ret);
												if (isRefresh) {
													setTimeout(function () {
														window.location.reload();
													}, 2000);
												}
											}
										);
									});
								}
								$(window).on('beforeunload', function () {
									if ($('.saveCertificate').data('isSave')) {
										return '';
									}
								});
								$(document).on('keydown', function () {
									if (window.event.keyCode == 116 || (window.event.shiftKey && window.event.keyCode == 121)) {
										if ($('.saveCertificate').data('isSave')) {
											is_save(true);
											window.event.keyCode = 0;
											window.event.returnValue = false;
										}
									}
									if (window.event.altKey && window.event.keyCode == 115) {
										//屏蔽Alt+F4
										window.showModelessDialog('about:blank', '', 'dialogWidth:1px;dialogheight:1px');
										return false;
									}
								});

								// 保存证书
								$('.saveCertificate').on('click', function () {
									var key = $('[name="key"]').val(),
										csr = $('[name="csr"]').val();
									function set_ssl() {
										if (key === '' || csr === '') return bt.msg({ status: false, msg: '请填写完整的证书内容' });
										bt.site.set_ssl(
											web.name,
											{
												type: rdata.type,
												siteName: rdata.siteName,
												key: key,
												csr: csr,
											},
											function (ret) {
												if (ret.status) site.reload(7);
												if (site.model_table) site.model_table.$refresh_table_list(true);
												bt.msg(ret);
											}
										);
									}

									if ((key !== rdata.key && rdata.key) || (csr !== rdata.csr && rdata.key)) {
										layer.confirm(
											'当前证书内容发生改变，证书信息将同步更新，继续操作？',
											{
												icon: 3,
												closeBtn: 2,
												title: '证书保存提示',
											},
											set_ssl
										);
									} else {
										set_ssl();
									}
								});

								// 告警方式
								$('.setAlarmMode').on('click', function () {
									layer.close(layers);
									alarmMode();
								});

								// 续签证书
								$('.renewCertificate')
									.unbind('click')
									.on('click', function () {
										var type = parseInt($(this).attr('data-type'));
										switch (type /**/) {
											case 3: // 商业证书续签
												renewal_ssl_view({ oid: rdata.oid });
												break;
											case 2: // 宝塔证书 续签
												apply_bt_certificate();
												layer.msg('当前证书类型不支持一键续签操作，请重新填写信息申请', { icon: 2, time: 2000 });
												break;
											case 1: // Let's Encrypt 续签
												site.ssl.renew_ssl(web.name, rdata.auth_type, rdata.index);
												break;
										}
									});

								// 关闭证书
								$('.closeCertificate').on('click', function () {
									site.ssl.set_ssl_status('CloseSSLConf', web.name);
								});

								// 切换证书类型
								$('.cutSslType').on('click', function () {
									var type = $(this).attr('data-type');
									switch (type) {
										case '0':
											type = 0;
											break;
										case '1':
											type = 3;
											break;
										case '2':
											type = 2;
											break;
										case '3':
											type = 1;
											break;
									}
									$('#ssl_tabs span:eq(' + type + ')').trigger('click');
								});

								// 下载证书
								$('.downloadCertificate').on('click', function () {
									var key = $('[name="key"]').val(),
										pem = $('[name="csr"]').val();
									bt.site.download_cert(
										{
											siteName: web.name,
											pem: pem,
											key: key,
										},
										function (rdata) {
											if (rdata.status) window.open('/download?filename=' + encodeURIComponent(rdata.msg));
										}
									);
								});
							}
							$('.upload_ssl').on('click', function () {
								site.upload_ssl(web.id, web.name);
							});
						},
					},
					{
						title: "Let's Encrypt",
						callback: function (robj) {
							robj = $('#webedit-con .tab-con');
							acme.get_account_info(function (let_user) {});
							acme.id = web.id;
							if (rdata.status && rdata.type == 1) {
								var cert_info = '';
								if (rdata.cert_data['notBefore']) {
									cert_info =
										'<div style="margin-bottom: 10px;" class="alert alert-success">\
                                        <p style="margin-bottom: 9px;"><span style="width: 357px;display: inline-block;"><b>已部署成功：</b>将在距离到期时间1个月内尝试自动续签</span>\
                                        <span style="margin-left: 15px;display: inline-block;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;max-width: 140px;width: 140px;">\
                                        <b>证书品牌：</b>' +
										rdata.cert_data.issuer +
										'</span></p>\
                                        <span style="display:inline-block;max-width: 357px;overflow:hidden;text-overflow:ellipsis;vertical-align:-3px;white-space: nowrap;width: 357px;"><b>认证域名：</b> ' +
										rdata.cert_data.dns.join('、') +
										'</span>\
                                        <span style="margin-left: 15px;"><b>到期时间：</b> ' +
										rdata.cert_data.notAfter +
										'</span></div>';
								}
								robj.append(
									'<div>' +
										cert_info +
										'<div><span>密钥(KEY)</span><span style="padding-left:194px">证书(PEM格式)</span></div></div><div class="mask-tips" style="display:none;background: #fff;position: fixed;z-index: 1;width: 640px;height: 230px;line-height: 220px;font-size: 24px;text-align: center;padding: 10px 20px;border: 1px dashed #ccc;border-radius: 5px;margin-top: 5px;">IIS证书为二进制文件，无法显示</div>'
								);
								var datas = [
									{
										items: [
											{
												name: 'key',
												width: '45%',
												height: '220px',
												type: 'textarea',
												value: rdata.key,
											},
											{
												name: 'csr',
												width: '45%',
												height: '220px',
												type: 'textarea',
												value: rdata.csr,
											},
										],
									},
									{
										items: [
											{
												text: '关闭SSL',
												name: 'btn_ssl_close',
												hide: !rdata.status,
												type: 'button',
												callback: function (sdata) {
													site.ssl.set_ssl_status('CloseSSLConf', web.name);
												},
											},
											{
												text: '续签',
												name: 'btn_ssl_renew',
												hide: !rdata.status,
												type: 'button',
												callback: function (sdata) {
													site.ssl.renew_ssl(web.name, rdata.auth_type, rdata.index);
												},
											},
										],
									},
								];
								for (var i = 0; i < datas.length; i++) {
									var _form_data = bt.render_form_line(datas[i]);
									robj.append(_form_data.html);
									bt.render_clicks(_form_data.clicks);
								}
								if (rdata.csr == undefined && rdata.key == undefined) $('.mask-tips').show();
								robj.find('textarea').css('background-color', '#f6f6f6').attr('readonly', true);
								var helps = [
									'申请之前，请确保域名已解析，如未解析会导致审核失败(包括根域名)',
									'宝塔SSL申请的是免费版TrustAsia DV SSL CA - G5证书，仅支持单个域名申请',
									'有效期1年，不支持续签，到期后需要重新申请',
									'建议使用二级域名为www的域名申请证书,此时系统会默认赠送顶级域名为可选名称',
									'在未指定SSL默认站点时,未开启SSL的站点使用HTTPS会直接访问到已开启SSL的站点',
									'如果重新申请证书时提示【订单已存在】请登录宝塔官网删除对应SSL订单',
								];
								robj.append(bt.render_help(["已为您自动生成Let's Encrypt免费证书；", '如需使用其他SSL,请切换其他证书后粘贴您的KEY以及PEM内容，然后保存即可。']));
								return;
							}
							bt.site.get_site_domains(web.id, function (ddata) {
								var helps = [
									[
										'Let\'s Encrypt 证书申请和续签限制 <a class="btlink" target="_blank" href="https://letsencrypt.org/zh-cn/docs/rate-limits/">点击查看</a>',
										'申请之前，请确保域名已解析，如未解析会导致审核失败',
										"Let's Encrypt免费证书，有效期3个月，支持多域名。默认会自动续签",
										'若您的站点使用了CDN或301重定向会导致续签失败',
										'在未指定SSL默认站点时,未开启SSL的站点使用HTTPS会直接访问到已开启SSL的站点',
									],
									[
										'在DNS验证中，我们提供了多种自动化DNS-API，并提供了手动模式',
										'使用DNS接口申请证书可自动续期，手动模式下证书到期后需重新申请',
										'使用【DnsPod/阿里云DNS】等接口前您需要先在弹出的窗口中设置对应接口的API',
									],
								];
								var datas = [
									{
										title: '验证方式',
										items: [
											{
												name: 'check_file',
												text: '文件验证',
												type: 'radio',
												callback: function (obj) {
													$('.checks_line').remove();
													$(obj).siblings().removeAttr('checked');
													obj.next().css('margin-right', '20px');
													$('.help-info-text').html($(bt.render_help(helps[0])).html());
													//var _form_data = bt.render_form_line({ title: ' ', class: 'checks_line label-input-group', items: [{ name: 'force', type: 'checkbox', value: true, text: '提前校验域名(提前发现问题,减少失败率)' }] });
													//$(obj).parents('.line').append(_form_data.html);

													$('#ymlist li input[type="checkbox"]').each(function () {
														if ($(this).val().indexOf('*') >= 0) {
															$(this).parents('li').hide();
														}
													});
												},
											},
											{
												name: 'check_dns',
												text: 'DNS验证(支持通配符)',
												type: 'radio',
												callback: function (obj) {
													$('.checks_line').remove();
													$(obj).siblings().removeAttr('checked');
													$('.help-info-text').html($(bt.render_help(helps[1])).html());
													$('#ymlist li').show();

													var arrs_list = [],
														arr_obj = {};
													bt.site.get_dns_api(function (api) {
														site.dnsapi = {};

														for (var x = 0; x < api.length; x++) {
															site.dnsapi[api[x].name] = {};
															site.dnsapi[api[x].name].s_key = 'None';
															site.dnsapi[api[x].name].s_token = 'None';
															if (api[x].data) {
																site.dnsapi[api[x].name].s_key = api[x].data[0].value;
																site.dnsapi[api[x].name].s_token = api[x].data[1].value;
															}
															arrs_list.push({
																title: api[x].title,
																value: api[x].name,
															});
															arr_obj[api[x].name] = api[x];
														}

														var data = [
															{
																title: '选择DNS接口',
																class: 'checks_line',
																items: [
																	{
																		name: 'dns_select',
																		width: '120px',
																		type: 'select',
																		items: arrs_list,
																		callback: function (obj) {
																			var _val = obj.val();
																			$('.set_dns_config').remove();
																			var _val_obj = arr_obj[_val];
																			var _form = {
																				title: '',
																				area: '550px',
																				list: [],
																				btns: [
																					{
																						title: '关闭',
																						name: 'close',
																					},
																				],
																			};

																			var helps = [];
																			if (_val_obj.data !== false) {
																				_form.title = '设置【' + _val_obj.title + '】接口';
																				helps.push(_val_obj.help);
																				var is_hide = true;
																				for (var i = 0; i < _val_obj.data.length; i++) {
																					_form.list.push({
																						title: _val_obj.data[i].name,
																						name: _val_obj.data[i].key,
																						value: _val_obj.data[i].value,
																					});
																					if (!_val_obj.data[i].value) is_hide = false;
																				}
																				_form.btns.push({
																					title: '保存',
																					css: 'btn-success',
																					name: 'btn_submit_save',
																					callback: function (ldata, load) {
																						bt.site.set_dns_api(
																							{
																								pdata: JSON.stringify(ldata),
																							},
																							function (ret) {
																								if (ret.status) {
																									load.close();
																									robj.find('input[type="radio"]:eq(0)').trigger('click');
																									robj.find('input[type="radio"]:eq(1)').trigger('click');
																								}
																								bt.msg(ret);
																							}
																						);
																					},
																				});
																				if (is_hide) {
																					obj.after('<button class="btn btn-default btn-sm mr5 set_dns_config">设置</button>');
																					$('.set_dns_config').click(function () {
																						var _bs = bt.render_form(_form);
																						$('div[data-id="form' + _bs + '"]').append(bt.render_help(helps));
																					});
																				} else {
																					var _bs = bt.render_form(_form);
																					$('div[data-id="form' + _bs + '"]').append(bt.render_help(helps));
																				}
																			}
																		},
																	},
																],
															},
															{
																title: ' ',
																class: 'checks_line label-input-group',
																items: [
																	{
																		css: 'label-input-group ptb10',
																		text: '自动组合泛域名',
																		name: 'app_root',
																		type: 'checkbox',
																	},
																],
															},
														];
														for (var i = 0; i < data.length; i++) {
															var _form_data = bt.render_form_line(data[i]);
															$(obj).parents('.line').append(_form_data.html);
															bt.render_clicks(_form_data.clicks);
														}
													});
												},
											},
										],
									},
								];

								for (var i = 0; i < datas.length; i++) {
									var _form_data = bt.render_form_line(datas[i]);
									robj.append(_form_data.html);
									bt.render_clicks(_form_data.clicks);
								}
								var _ul = $('<ul id="ymlist" class="domain-ul-list"><li style="cursor: pointer;"><input class="checkbox-text" type="checkbox" value="all"><span>全选</span></li></ul>');
								for (var i = 0; i < ddata.domains.length; i++) {
									if (ddata.domains[i].binding === true) continue;
									_ul.append('<li style="cursor: pointer;"><input class="checkbox-text" type="checkbox" value="' + ddata.domains[i].name + '" ><span>' + ddata.domains[i].name + '</span></li>');
								}
								var _line = $("<div class='line mtb10'></div>");
								_line.append('<span class="tname text-center">域名</span>');
								_line.append(_ul);
								robj.append(_line);
								robj.find('input[type="radio"]').parent().addClass('label-input-group ptb10');

								$('#ymlist li input').click(function (e) {
									if ($(this).prop('checked')) {
										$(this).prop('checked', false);
										if ($(this).val() == 'all') {
											$("#ymlist input[type = 'checkbox']").prop('checked', false);
										}
									} else {
										$(this).prop('checked', true);
										if ($(this).val() == 'all') {
											$("#ymlist input[type = 'checkbox']").prop('checked', true);
										}
									}
									// e.stopPropagation();
								});
								$('#ymlist li').click(function () {
									var o = $(this).find('input');
									if (o.prop('checked')) {
										o.prop('checked', false);
										if (o.val() == 'all') {
											$("#ymlist input[type = 'checkbox']").prop('checked', false);
										}
									} else {
										o.prop('checked', true);
										if (o.val() == 'all') {
											$("#ymlist input[type = 'checkbox']").prop('checked', true);
										}
									}
								});
								var _btn_data = bt.render_form_line({
									title: ' ',
									text: '申请',
									name: 'letsApply',
									type: 'button',
									callback: function (ldata) {
										ldata['domains'] = [];
										$('#ymlist input[type="checkbox"]:checked').each(function () {
											if ($(this).val() != 'all') {
												if ($(this).parents('li').is(':visible')) {
													ldata['domains'].push($(this).val());
												}
											}
										});
										var auth_type = 'http';
										var auth_to = web.id;
										var auto_wildcard = '0';
										if (ldata.check_dns) {
											auth_type = 'dns';
											auth_to = 'dns';
											auto_wildcard = ldata.app_root ? '1' : '0';
											if (ldata.dns_select !== auth_to) {
												if (!site.dnsapi[ldata.dns_select].s_key) {
													layer.msg('指定dns接口没有设置密钥信息');
													return;
												}
												auth_to = ldata.dns_select + '|' + site.dnsapi[ldata.dns_select].s_key + '|' + site.dnsapi[ldata.dns_select].s_token;
											}
										}
										if (ldata.domains.length <= 0) {
											layer.msg('至少需要有一个域名', { icon: 2 });
											return;
										}
										acme.apply_cert(ldata['domains'], auth_type, auth_to, auto_wildcard, function (res) {
											site.ssl.ssl_result(res, auth_type, web.name);
										});
									},
								});
								robj.append(_btn_data.html);
								bt.render_clicks(_btn_data.clicks);
								robj.append(bt.render_help(helps[0]));
								robj.find('input[type="radio"]:eq(0)').trigger('click');
							});
						},
					},
					{
						title: '证书夹',
						callback: function (robj) {
							robj = $('#webedit-con .tab-con');
							robj.html("<div class='divtable' style='height:550px;overflow:auto'><table id='cer_list_table' class='table table-hover'></table></div>");
							bt.site.get_cer_list(function (rdata) {
								bt.render({
									table: '#cer_list_table',
									columns: [
										{
											field: 'subject',
											title: '域名',
											templet: function (item) {
												return item.dns.join('<br>');
											},
										},
										{
											field: 'notAfter',
											width: 90,
											title: '到期时间',
										},
										{
											field: 'issuer',
											width: 200,
											title: '品牌',
										},
										{
											field: 'opt',
											width: 75,
											align: 'right',
											title: '操作',
											templet: function (item) {
												var server_type = bt.get_cookie('serverType');
												var opt = '';
												if ((item.type == 'pfx' && server_type == 'iis') || (item.type == 'pem' && server_type != 'iis')) {
													opt +=
														'<a class="btlink" onclick="bt.site.set_cert_ssl(\'' +
														item.subject +
														"','" +
														web.name +
														'\',undefined,function(rdata){if(rdata.status){site.ssl.reload();}})" href="javascript:;">部署</a> |';
												}

												opt += '<a class="btlink" onclick="bt.site.remove_cert_ssl(\'' + item.subject + '\',function(rdata){if(rdata.status){site.ssl.reload();}})" href="javascript:;">删除</a>';
												return opt;
											},
										},
									],
									data: rdata,
								});

								robj.append(bt.render_help(["证书夹部署Let's Encrypt不具备自动续签功能"]));
							});
						},
					},
				];
				bt.render_tab('ssl_tabs', _tabs);
				if (isIIS) {
					$('#ssl_tabs').append(
						'<div class="ss-text pull-right mr30" style="position: relative;top:-4px"><em>强制HTTPS</em><div class="ssh-item"><input class="btswitch btswitch-ios" id="toHttps" type="checkbox"><label class="btswitch-btn" for="toHttps"></label></div></div>'
					);
					$('#toHttps').attr('checked', rdata.httpTohttps);
					$('#toHttps').click(function (sdata) {
						var isHttps = $('#toHttps').attr('checked');
						if (isHttps) {
							layer.confirm(
								'关闭强制HTTPS后需要清空浏览器缓存才能看到效果,继续吗?',
								{
									icon: 3,
									title: '关闭强制HTTPS',
								},
								function () {
									bt.site.close_http_to_https(web.name, function () {
										site.reload(7);
									});
								}
							);
						} else {
							if (rdata.status == false) {
								bt.msg({
									status: false,
									msg: '请先部署SSL证书，否则无法强制跳转HTTPS.',
								});
								$('#toHttps').attr('checked', false);
								return;
							}
							bt.site.set_http_to_https(web.name, function (res) {
								site.edit.show_rule_msg('强制HTTPS', res);
								if (!res.status) {
									$('#toHttps').attr('checked', rdata.httpTohttps);
								}
							});
						}
					});
				}
				$('.cutTabView').on('click', function () {
					$('#ssl_tabs span:eq(1)').trigger('click');
				});
				// 清理tips
				$('#ssl_tabs').on('click', 'span', function () {
					layer.closeAll('tips');
				});
				$('#ssl_tabs span:eq(0)').trigger('click');
				if (web.ssl_view_type) {
					$('#ssl_tabs span:eq(6)').trigger('click');
					return true;
				}
			});
		},
		set_iis_domain_ssl: function (siteName, obj) {
			var loading = bt.load();
			bt.send(
				'get_iis_ssl_file_list',
				'site/get_iis_ssl_file_list',
				{
					siteName: siteName,
				},
				function (res) {
					loading.close();
					if (res.status == false) {
						bt.msg(res);
						return;
					}
					var _domain = $(obj).parents('tr').data('item');
					site.ssl.my_select_domain_ssl_index = layer.open({
						type: 1,
						area: ['550px', '550px'],
						title: '部署域名【' + _domain.name + '】SSL证书',
						closeBtn: 2,
						shift: 0,
						content: "<div class='pd15 ssl_setup_dialog'><div id='ssl_setup_tab'></div><div class='tab-con' style='padding:10px 0;'></div></div>",
						success: function () {
							var _tab = [
								{
									title: '证书列表',
									on: true,
									callback: function (robj) {
										robj = $('.ssl_setup_dialog .tab-con');
										robj.append('<div class="divtable table-fixed-box" style="max-height:500px;overflow-y: auto;"><table id=\'ssl_select_list\' class=\'table table-hover\'></table></div>');
										bt.render({
											table: '#ssl_select_list',
											columns: [
												{
													field: 'subject',
													title: '证书域名',
													templet: function (item) {
														return item.dns.join('<br>');
													},
												},
												{
													field: 'notAfter',
													width: '83px',
													title: '到期时间',
												},
												{
													field: 'issuer',
													width: '130px',
													title: '品牌',
												},
												{
													field: 'name',
													align: 'right',
													title: '操作',
													width: 60,
													templet: function (item) {
														return '<a class="btlink" href="javascript:;" onclick="site.edit.set_domain_iis_byfile(\'' + _domain.name + "','" + item.path + '\')" >选择</a> ';
													},
												},
											],
											data: res,
										});
									},
								},
								{
									title: '未识别证书',
									callback: function (robj) {
										robj = $('.ssl_setup_dialog .tab-con');
										robj.append('<div class="divtable table-fixed-box" style="max-height:500px;overflow-y: auto;"><table id=\'ssl_unidentification_list\' class=\'table table-hover\'></table></div>');
										bt.render({
											table: '#ssl_unidentification_list',
											columns: [
												{
													field: 'name',
													title: '证书',
												},
												{
													field: 'name',
													align: 'right',
													title: '操作',
													width: 60,
													templet: function (item) {
														return '<a class="btlink set-ssl" href="javascript:;">部署</a> ';
													},
												},
											],
											data: unidentification,
										});
										$('a.set-ssl').click(function () {
											var _this = $(this);
											var item = $(this).parents('tr').data('item');

											bt.site.set_ssl(
												siteName,
												{
													cerName: item.name,
													password: item.password,
												},
												function (ret) {
													if (ret.status) {
														layer.close(site.ssl.my_select_domain_ssl_index);
														site.reload(7);
													}
													if (ret.msg.indexOf('password') >= 0) {
														var index = layer.open({
															type: 1,
															skin: 'demo-class',
															area: '350px',
															title: '填写证书密码',
															closeBtn: 2,
															shift: 5,
															shadeClose: false,
															content:
																"<div class='bt-form pd20 pb70' >\
							                        <div class='line'>\
							                        <span class='tname'>证书密码:</span><div class='info-r '><input  type='text' value='bt.cn' class='bt-input-text new_password' /></div>\
							                        </div>\
							                        <ul class='help-info-text c7'>\
								                        <li>在此处填写pfx证书密码!</li>\
								                        <li>宝塔证书默认密码bt.cn,其他证书咨询证书提供商!</li>\
							                        </ul>\
					                                <div class='bt-form-submit-btn'>\
								                        <button type='button' class='btn btn-danger btn-sm btn-title' onclick='layer.closeAll()'>取消</button>\
						                                <button type='button' class='btn btn-success btn-sm btn-title btnOtherSSL' >提交</button>\
					                                </div>\
					                                </div>",
															success: function () {
																layer.msg('证书密码错误！');
															},
														});
														setTimeout(function () {
															$('.btnOtherSSL').click(function () {
																item.password = $('.new_password').val();
																_this.parents('tr').data('item', item);
																_this.trigger('click');
																layer.close(index);
															});
														}, 100);
													}
												}
											);
										});
									},
								},
							];
							bt.render_tab('ssl_setup_tab', _tab);
							$('#ssl_setup_tab span:eq(0)').trigger('click');
						},
					});
				}
			);
		},
		set_domain_iis_byfile: function (domain, path, password) {
			var loading = bt.load('正在部署【' + domain + '】证书...');
			bt.send(
				'set_domain_iis_byfile',
				'site/set_domain_iis_byfile',
				{
					domain: domain,
					path: path,
					password: password,
				},
				function (res) {
					loading.close();

					if (res.msg.indexOf('password') >= 0) {
						var index = layer.open({
							type: 1,
							skin: 'demo-class',
							area: '350px',
							title: '填写证书密码',
							closeBtn: 2,
							shift: 5,
							shadeClose: false,
							content:
								"<div class='bt-form pd20 pb70' >\
							        <div class='line'>\
							        <span class='tname'>证书密码:</span><div class='info-r '><input  type='text' value='bt.cn' class='bt-input-text new_password' /></div>\
							        </div>\
							        <ul class='help-info-text c7'>\
								        <li>在此处填写pfx证书密码!</li>\
								        <li>宝塔证书默认密码bt.cn,其他证书咨询证书提供商!</li>\
							        </ul>\
					                <div class='bt-form-submit-btn'>\
								        <button type='button' class='btn btn-danger btn-sm btn-title' onclick='layer.closeAll()'>取消</button>\
						                <button type='button' class='btn btn-success btn-sm btn-title btnOtherSSL' >提交</button>\
					                </div>\
					                </div>",
							success: function () {
								layer.msg('证书密码错误！');
								$('.btnOtherSSL').click(function () {
									site.edit.set_domain_iis_byfile(domain, path, $('.new_password').val());
									layer.close(index);
								});
							},
						});
					} else {
						if (res.status) {
							if (site.ssl.my_select_domain_ssl_index) {
								layer.close(site.ssl.my_select_domain_ssl_index);
							}
							site.ssl.reload();
						}
						bt.msg(res);
					}
				}
			);
		},
		set_php_version: function (web) {
			var loadT = bt.load();
			bt.site.get_site_phpversion(web.name, function (sdata) {
				if (sdata.status === false) {
					bt.msg(sdata);
					return;
				}
				bt.site.get_all_phpversion(function (vdata) {
					loadT.close();
					var versions = [];
					for (var j = vdata.length - 1; j >= 0; j--) {
						var o = vdata[j];
						o.value = o.version;
						o.title = o.name;
						versions.push(o);
					}
					var data = {
						items: [
							{
								title: 'PHP版本',
								name: 'versions',
								value: sdata.phpversion,
								type: 'select',
								items: versions,
							},
							{
								text: '切换',
								name: 'btn_change_phpversion',
								type: 'button',
								callback: function (pdata) {
									bt.site.set_phpversion(web.name, pdata.versions, function (ret) {
										if (ret.status) site.reload();
										bt.msg(ret);
									});
								},
							},
						],
					};
					var _form_data = bt.render_form_line(data);
					var _html = $(_form_data.html);
					_html.append(bt.render_help(['请根据您的程序需求选择版本', '若非必要,请尽量不要使用PHP5.2,这会降低您的服务器安全性；', 'PHP7不支持mysql扩展，默认安装mysqli以及mysql-pdo。']));
					$('#webedit-con').append(_html);
					bt.render_clicks(_form_data.clicks);
				});
			});
		},
		templet_301: function (web, obj) {
			var is_create = false;
			if (obj === false) {
				is_create = true;
				obj = {
					redirectname: new Date().valueOf(),
					tourl: 'http://',
					redirectdomain: [],
					redirectpath: '',
					redirecttype: '',
					domainorpath: 'domain',
					type: 1,
					holdpath: 1,
				};
			}
			var helps = [
				'重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
				'目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
				'重定向方式：使用301表示永久重定向，使用302表示临时重定向',
				'保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
				'保留URI参数： http://b.com/1.html ---> http://a.com/1.html',
				'不保留URI参数：http://b.com/1.html ---> http://a.com',
				'路径重定向：将app目录重定向到www.bt.cn/app目录格式为 app/ ---> http://www.bt.cn',
			];
			bt.site.get_domains(web.id, function (rdata) {
				var domains = [];
				for (var i = 0; i < rdata.length; i++) {
					var val = rdata[i].name;
					if (rdata[i].port != 80) val += ':' + rdata[i].port;
					domains.push({
						title: val,
						value: val,
					});
				}

				var form_data = {
					title: is_create ? '创建重定向' : '修改重定向[' + obj.redirectname + ']',
					area: ['650px', '430px'],
					skin: 'site-301-form',
					list: [
						{
							class: 'btswitch-line ',
							items: [
								{
									title: '开启重定向  ',
									name: 'type',
									value: obj.type == 1 ? true : false,
									type: 'btswitch',
								},
								{
									title: '保留URI参数  ',
									name: 'holdpath',
									value: obj.holdpath == 1 ? true : false,
									type: 'btswitch',
								},
							],
						},
						{
							title: '重定向名称  ',
							value: obj.redirectname,
							name: 'redirectname',
							width: '300px',
							hide: true,
						},
						{
							items: [
								{
									title: '重定向类型  ',
									name: 'domainorpath',
									value: obj.domainorpath,
									type: 'select',
									items: [
										{
											title: '域名',
											value: 'domain',
										},
										{
											title: '路径',
											value: 'path',
										},
									],
									callback: function (sobj) {
										var subid = sobj.attr('name') + '_subid';
										$('#' + subid).remove();
										if (sobj.val() == 'domain') {
											var item = {
												items: [
													{
														title: '重定向域名 ',
														name: 'redirectdomain',
														width: '173px',
														type: 'select',
														class: 'selectpicker',
														items: domains,
													},
													{
														title: '目标URL  ',
														name: 'tourl',
														value: obj.tourl,
														width: '173px',
													},
												],
											};
											var _tr = bt.render_form_line(item);
											sobj.parents('div.line').append('<div class="line" id=' + subid + '>' + _tr.html + '</div>');
											site.edit.render_sel('redirectdomain', obj.redirectdomain);
										} else {
											var item = {
												items: [
													{
														title: '重定向路径  ',
														name: 'redirectpath',
														value: obj.redirectpath,
														width: '173px',
													},
													{
														title: '目标URL  ',
														name: 'tourl',
														value: obj.tourl,
														width: '173px',
													},
												],
											};
											var _tr = bt.render_form_line(item);
											sobj.parents('div.line').append('<div class="line" id=' + subid + '>' + _tr.html + '</div>');
										}
									},
								},
								{
									title: '重定向方式 ',
									name: 'redirecttype',
									value: obj.redirecttype,
									type: 'select',
									items: [
										{
											title: '301',
											value: '301',
										},
										{
											title: '302',
											value: '302',
										},
									],
								},
							],
						},
					],
					btns: [
						bt.form.btn.close(),
						bt.form.btn.submit('提交', function (rdata, form) {
							if (!rdata.hasOwnProperty('redirectpath')) {
								rdata['redirectpath'] = '';
							}
							rdata.type = rdata.type ? 1 : 0;
							rdata.holdpath = rdata.holdpath ? 1 : 0;

							rdata['sitename'] = web.name;
							rdata['redirectdomain'] = JSON.stringify($('.selectpicker').val() || []);
							if (is_create) {
								bt.site.create_redirect(rdata, function (rdata) {
									if (rdata.status) {
										form.close();
									}
									site.edit.show_rule_msg('添加重定向', rdata);
								});
							} else {
								bt.site.modify_redirect(rdata, function (rdata) {
									if (rdata.status) {
										form.close();
										site.edit.show_rule_msg('修改重定向', rdata);
									}
								});
							}
						}),
					],
					success: function () {
						$('.site-301-form').css('top', ($(window)[0].innerHeight - $('.site-301-form').height()) / 2 + 'px');
					},
				};
				bt.render_form(form_data);
				var h = $(bt.render_help(helps));
				h.css({
					bottom: '60px',
				});

				$('.' + form_data.skin + ' .bt-form').append(h);
				setTimeout(function () {
					$("select[name='domainorpath']").trigger('change');
				}, 100);
			});
		},
		edit_redirect: function (obj, name) {
			var item = $(obj).parents('tr').data('item');
			if (item[name]) {
				item[name] = 0;
			} else {
				item[name] = 1;
			}
			item['redirectdomain'] = JSON.stringify(item['redirectdomain'] || []);

			bt.site.modify_redirect(item, function (rdata) {
				site.edit.show_rule_msg('修改重定向', rdata);
			});
		},
		template_Dir: function (id, type, obj) {
			if (type) {
				obj = {
					name: '',
					sitedir: '',
					username: '',
					password: '',
				};
			} else {
				obj = {
					name: obj.name,
					sitedir: obj.site_dir,
					username: '',
					password: '',
				};
			}
			var form_directory = bt.open({
				type: 1,
				skin: 'demo-class',
				area: '550px',
				title: type ? '添加访问限制' : '修改访问限制',
				closeBtn: 2,
				shift: 5,
				shadeClose: false,
				content:
					"<form id='form_dir' class='divtable pd15' style='padding: 40px 0 90px 60px'>" +
					"<div class='line'>" +
					"<span class='tname'>名称</span>" +
					"<div class='info-r ml0'><input name='dir_name' class='bt-input-text mr10' type='text' style='width:270px' value='" +
					obj.name +
					"'>" +
					'</div></div>' +
					"<div class='line'>" +
					"<span class='tname'>保护的目录</span>" +
					"<div class='info-r ml0'><input name='dir_sitedir' placeholder='输入需要保护的目录，如：/text/' class='bt-input-text mr10' type='text' style='width:270px' value='" +
					obj.sitedir +
					"'>" +
					'</div></div>' +
					"<div class='line'>" +
					"<span class='tname'>用户名</span>" +
					"<div class='info-r ml0'><input name='dir_username' AUTOCOMPLETE='off' class='bt-input-text mr10' type='text' style='width:270px' value='" +
					obj.username +
					"'>" +
					'</div></div>' +
					"<div class='line'>" +
					"<span class='tname'>密码</span>" +
					"<div class='info-r ml0'><input name='dir_password' AUTOCOMPLETE='off' class='bt-input-text mr10' type='password' style='width:270px' value='" +
					obj.password +
					"'>" +
					'</div></div>' +
					"<ul class='help-info-text c7 plr20'>" +
					'<li>目录设置保护后，访问时需要输入账号密码才能访问</li>' +
					'<li>例如我设置了保护目录 /test/ ,那我访问 http://aaa.com/test/ 是就要输入账号密码才能访问</li>' +
					'<li>如需限定指定电脑访问，请使用企业版插件【限制访问型证书】</li>' +
					'</ul>' +
					"<div class='bt-form-submit-btn'><button type='button' class='btn btn-sm btn-danger btn-colse-guard'>关闭</button><button type='button' class='btn btn-sm btn-success btn-submit-guard'>" +
					(type ? '提交' : '保存') +
					'</button></div></form>',
			});
			$('.btn-colse-guard').click(function () {
				form_directory.close();
			});
			$('.btn-submit-guard').click(function () {
				var guardData = {};
				guardData['id'] = id;
				guardData['name'] = $('input[name="dir_name"]').val();
				guardData['site_dir'] = $('input[name="dir_sitedir"]').val();
				guardData['username'] = $('input[name="dir_username"]').val();
				guardData['password'] = $('input[name="dir_password"]').val();
				if (type) {
					bt.site.create_dir_guard(guardData, function (rdata) {
						if (rdata.status) {
							form_directory.close();
							site.reload();
						}
						bt.msg(rdata);
					});
				} else {
					bt.site.edit_dir_account(guardData, function (rdata) {
						if (rdata.status) {
							form_directory.close();
							site.reload();
						}
						bt.msg(rdata);
					});
				}
			});
			setTimeout(function () {
				if (!type) {
					$('input[name="dir_name"]').attr('disabled', 'disabled');
					$('input[name="dir_sitedir"]').attr('disabled', 'disabled');
				}
			}, 500);
		},
		set_301: function (web) {
			bt.site.get_redirect_list(web.name, function (rdata) {
				if (rdata.status === false) {
					bt.msg(rdata);
					return;
				}
				var datas = {
					items: [
						{
							name: 'add_proxy',
							text: '添加重定向',
							type: 'button',
							callback: function (data) {
								site.edit.templet_301(web, false);
							},
						},
					],
				};
				var form_line = bt.render_form_line(datas);
				$('#webedit-con').append(form_line.html);
				bt.render_clicks(form_line.clicks);
				$('#webedit-con').addClass('divtable').append('<div id="proxy_list"></div>');
				// $('#webedit-con').addClass('divtable').append('<table id="proxy_list" class="table table-hover"></table >');
				setTimeout(function () {
					// var _tab = bt.render({
					//     table: '#proxy_list',
					//     columns: [{
					//         field: '',
					//         title: '重定向名称',
					//         templet: function (item) {
					//             var conter = '';
					//             if (item.domainorpath == 'path') {
					//                 conter = item.redirectpath;
					//             } else {
					//                 conter = item.redirectdomain ? item.redirectdomain.join('、') : '空'
					//             }
					//             return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
					//         }
					//     },
					//     {
					//         field: 'redirecttype',
					//         title: '重定向方式'
					//     },
					//     {
					//         field: 'holdpath',
					//         index: true,
					//         title: '保留路径',
					//         templet: function (item) {
					//             return '<a href="javascript:;" onclick="site.edit.edit_redirect(this,\'holdpath\')" class="btlink set_path_state" style="display:" data-stuats="' + (item.holdpath == 1 ? 0 : 1) + '">' + (item.holdpath == 1 ? '<span style="color:#20a53a;" class="set_path_state">开启</span>' : '<span style="color:red;" class="set_path_state">关闭</span>') + '</a>';
					//         }
					//     },
					//     {
					//         field: 'type',
					//         title: '状态',
					//         index: true,
					//         templet: function (item) {
					//             return '<a href="javascript:;" onclick="site.edit.edit_redirect(this,\'type\')" class="btlink set_type_state" style="display:" data-stuats="' + (item.type == 1 ? 0 : 1) + '">' + (item.type == 1 ? '<span style="color:#20a53a;">运行中</span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span>' : '<span style="color:red;">已暂停</span><span style="color:red" class="glyphicon glyphicon-pause"></span>') + '</a>'
					//         }
					//     },
					//     {
					//         field: '',
					//         title: '操作',
					//         align: 'right',
					//         index: true,
					//         templet: function (item) {
					//             var redirectname = item.redirectname;
					//             var sitename = item.sitename;
					//             var open_file = '';
					//             if (bt.get_cookie("serverType") != 'iis') {
					//                 open_file = '<a class="btlink open_config_file" href="javascript:;">配置文件</a> | '
					//             }
					//             var conter = open_file + ' <a class="btlink edit_redirect"  href="javascript:;">编辑</a> | <a class="btlink" onclick="bt.site.remove_redirect(\'' + sitename + '\',\'' + redirectname + '\',function(rdata){if(rdata.status)site.reload(10)})" href="javascript:;">删除</a>';
					//             return conter
					//         }
					//     }
					//     ],
					//     data: rdata
					// });

					site.edit.redirect_table = bt_tools.table({
						el: '#proxy_list',
						url: '/site?action=GetRedirectList',
						param: { sitename: web.name },
						height: '500px',
						dataFilter: function (res) {
							$.each(res, function (i, item) {
								if (!item.hasOwnProperty('errorpage')) {
									item.errorpage = 0;
								}
							});
							return { data: res };
						},
						column: [
							{ type: 'checkbox', width: 20 },
							{
								fid: 'sitename',
								title: '重定向名称',
								type: 'text',
								width: 120,
								template: function (row, index) {
									var conter = '空';
									if (row.domainorpath == 'path' && row.errorpage !== 1) {
										conter = row.redirectpath || '空';
									} else {
										conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
									}
									return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
								},
							},
							{
								fid: 'redirecttype',
								title: '重定向方式',
								type: 'text',
								width: 90,
							},
							{
								field: 'holdpath',
								index: true,
								title: '保留路径',
								template: function (row) {
									if (row.holdpath == 1) {
										return '<a href="javascript:;"><span style="color:#20a53a;" class="set_path_state">开启</span></a>';
									} else {
										return '<a href="javascript:;"><span style="color:red;" class="set_path_state">关闭</span></a>';
									}
									// return '<a href="javascript:;" onclick="site.edit.edit_redirect(this,\'holdpath\')" class="btlink set_path_state" style="display:" data-stuats="' + (row.holdpath == 1 ? 0 : 1) + '">' + (row.holdpath == 1 ? '<span style="color:#20a53a;" class="set_path_state">开启</span>' : '<span style="color:red;" class="set_path_state">关闭</span>') + '</a>';
								},
								event: function (row) {
									if (row['holdpath']) {
										row['holdpath'] = 0;
									} else {
										row['holdpath'] = 1;
									}
									row['redirectdomain'] = JSON.stringify(row['redirectdomain'] || []);

									bt.site.modify_redirect(row, function (rdata) {
										site.edit.show_rule_msg('修改重定向', rdata);
									});
								},
							},
							{
								field: 'type',
								title: '状态',
								index: true,
								template: function (row) {
									if (row.type == 1) {
										return '<a href="javascript:;"><span style="color:#20a53a;">运行中</span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span></a>';
									} else {
										return '<a href="javascript:;"><span style="color:red;">已暂停</span><span style="color:red" class="glyphicon glyphicon-pause"></span></a>';
									}

									// return '<a href="javascript:;" onclick="site.edit.edit_redirect(\''+row+'\',\'type\')" class="btlink set_type_state" style="display:" data-stuats="' + (row.type == 1 ? 0 : 1) + '">' + (row.type == 1 ? '<span style="color:#20a53a;">运行中</span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span>' : '<span style="color:red;">已暂停</span><span style="color:red" class="glyphicon glyphicon-pause"></span>') + '</a>'
								},
								event: function (row) {
									if (row['type']) {
										row['type'] = 0;
									} else {
										row['type'] = 1;
									}
									row['redirectdomain'] = JSON.stringify(row['redirectdomain'] || []);

									bt.site.modify_redirect(row, function (rdata) {
										site.edit.show_rule_msg('修改重定向', rdata);
									});
								},
							},
							{
								title: '操作',
								width: 150,
								type: 'group',
								align: 'right',
								group: [
									{
										title: '配置文件',
										event: function (row, index, ev, key, that) {
											var sitename = web.name;
											var redirectname = row.redirectname;
											var redirect_config = '';
											bt.site.get_redirect_config(
												{
													sitename: sitename,
													redirectname: redirectname,
													webserver: bt.get_cookie('serverType'),
												},
												function (rdata) {
													if (typeof rdata == 'object' && rdata.constructor == Array) {
														if (!rdata[0].status) bt.msg(rdata);
													} else {
														if (rdata.status == false) bt.msg(rdata);
													}
													var datas = [
														{
															items: [
																{
																	name: 'redirect_configs',
																	type: 'textarea',
																	value: rdata[0].data,
																	widht: '340px',
																	height: '200px',
																},
															],
														},
														{
															name: 'btn_config_submit',
															text: '保存',
															type: 'button',
															callback: function (ddata) {
																bt.site.save_redirect_config(
																	{
																		path: rdata[1],
																		data: editor.getValue(),
																		encoding: rdata[0].encoding,
																	},
																	function (ret) {
																		if (ret.status) {
																			site.reload(11);
																			redirect_config.close();
																		}
																		bt.msg(ret);
																	}
																);
															},
														},
													];
													redirect_config = bt.open({
														type: 1,
														area: ['550px', '550px'],
														title: '编辑配置文件[' + redirectname + ']',
														closeBtn: 2,
														shift: 0,
														content: "<div class='bt-form'><div id='redirect_config_con' class='pd15'></div></div>",
													});
													var robj = $('#redirect_config_con');
													for (var i = 0; i < datas.length; i++) {
														var _form_data = bt.render_form_line(datas[i]);
														robj.append(_form_data.html);
														bt.render_clicks(_form_data.clicks);
													}
													robj.append(bt.render_help(['此处为重定向的配置文件，若您不了解配置规则,请勿随意修改。']));
													$('textarea.redirect_configs').attr('id', 'configBody');
													var editor = CodeMirror.fromTextArea(document.getElementById('configBody'), {
														extraKeys: {
															'Ctrl-Space': 'autocomplete',
														},
														lineNumbers: true,
														matchBrackets: true,
													});
													$('.CodeMirror-scroll').css({
														height: '350px',
														margin: 0,
														padding: 0,
													});
													setTimeout(function () {
														editor.refresh();
													}, 250);
												}
											);
										},
									},
									{
										title: '编辑',
										className: 'edit_redirect',
										event: function (row, index, ev, key, that) {
											site.edit.templet_301(web, row);
										},
									},
									{
										title: '删除',
										event: function (row, index, ev, key, that) {
											// 	bt.site.remove_redirect(web.name, row.redirectname, function (rdata) {
											// 		bt.msg(rdata);
											// 		if (rdata.status) that.$delete_table_row(index);
											// 	});
											bt.site.remove_redirect(row.sitename, row.redirectname, function (rdata) {
												if (rdata.status) site.reload(10);
											});
										},
									},
								],
							},
						],
					});
				}, 100);
			});
		},
		render_sel: function (name, data) {
			var _domain_sel = $("select[name='" + name + "']");
			_domain_sel.attr('data-actions-box', true);
			_domain_sel.attr('data-size', 5);
			_domain_sel.attr('multiple', true);
			_domain_sel.attr('data-live-search', false);
			_domain_sel.addClass('selectpicker show-tick form-control');
			_domain_sel.selectpicker({
				noneSelectedText: '请选择站点...',
				selectAllText: '全选',
				deselectAllText: '取消全选',
			});
			_domain_sel.parents('.bootstrap-select').removeClass('bt-input-text').attr('style', 'float: inherit!important');
			if (typeof data != 'undefined') _domain_sel.selectpicker('val', data);
		},
		templet_proxy: function (web, obj) {
			var is_create = false;
			if (obj === false) {
				is_create = true;
				obj = {
					proxyname: new Date().valueOf(),
					tourl: 'http://',
					proxydomains: [],
					to_domian: '$host',
					open: 1,
					cache_open: 1,
					path_open: 0,
					root_path: '/',
				};
			}
			if (!obj.hasOwnProperty('sub1')) {
				obj['sub1'] = '';
				obj['sub2'] = '';
			}
			var helps = [
				'代理目录：访问这个目录时将会把目标URL的内容返回并显示(需要开启高级功能)',
				'目标URL：可以填写你需要代理的站点，目标URL必须为可正常访问的URL，否则将返回错误',
				'发送域名：将域名添加到请求头传递到代理服务器，默认为目标URL域名，若设置不当可能导致无法正常运行',
				'内容替换：只能在使用nginx时提供，多个内容用逗号分开，如sub1,sub2替换为str1,str2',
			];
			bt.site.get_domains(web.id, function (rdata) {
				var domains = [];
				for (var i = 0; i < rdata.length; i++) {
					var val = rdata[i].name;
					if (rdata[i].port != 80) val += ':' + rdata[i].port;
					domains.push({
						title: val,
						value: val,
					});
				}
				var form_data = {
					title: is_create ? '创建反向代理' : '修改反向代理[' + obj.proxyname + ']',
					area: ['650px', '470px'],
					skin: 'site-proxy-form',
					list: [
						{
							class: 'btswitch-line ',
							items: [
								{
									title: '开启代理  ',
									name: 'open',
									value: obj.open == 1 ? true : false,
									type: 'btswitch',
								},
								{
									title: '开启缓存  ',
									name: 'cache_open',
									hide: bt.get_cookie('serverType') == 'iis' ? false : true,
									value: obj.cache_open == 1 ? true : false,
									type: 'btswitch',
								},
								{
									title: '高级功能  ',
									name: 'path_open',
									value: obj.path_open == 1 ? true : false,
									type: 'btswitch',
								},
							],
						},
						{
							items: [
								{
									title: '代理名称   ',
									disabled: is_create ? false : true,
									width: '200px',
									value: obj.proxyname,
									name: 'proxyname',
								},
							],
						},
						{
							class: 'root_path-line',
							items: [
								{
									title: '代理路径   ',
									width: '200px',
									value: obj.root_path,
									name: 'root_path',
								},
							],
						},
						{
							items: [
								{
									title: '请求域名   ',
									hide: bt.get_cookie('serverType') == 'iis' ? false : true,
									name: 'proxydomains',
									type: 'select',
									class: 'selectpicker',
									items: domains,
								},
							],
						},
						{
							items: [
								{
									title: '目标URL   ',
									name: 'tourl',
									value: obj.tourl,
									width: '200px',
									callback: function (robj) {
										$(robj[0]).keyup(function () {
											var val = $(this).val(),
												ip_reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
											val = val.replace(/^http[s]?:\/\//, '');
											// val = val.replace(/:([0-9]*)$/, '');
											val = val.replace(/(:|\?|\/|\\)(.*)$/, '');
											if (ip_reg.test(val) || bt.get_cookie('serverType') == 'iis') {
												$("input[name='to_domian']").val('$host');
											} else {
												$("input[name='to_domian']").val(val);
											}
										});
									},
								},
								{
									title: '发送域名   ',
									name: 'to_domian',
									value: obj.to_domian,
									width: '200px',
								},
							],
						},
						{
							hide: bt.get_cookie('serverType') == 'nginx' ? false : true,
							items: [
								{
									title: '替换内容   ',
									name: 'sub1',
									value: obj.sub1,
									width: '200px',
								},
								{
									title: '&nbsp;&nbsp;&nbsp;替换为   ',
									name: 'sub2',
									value: obj.sub2,
									width: '200px',
								},
							],
						},
					],
					btns: [
						bt.form.btn.close(),
						bt.form.btn.submit('提交', function (rdata, load) {
							if (rdata.sub1.split(',').length != rdata.sub2.split(',').length) {
								bt.msg({
									status: false,
									msg: '替换内容个数必须与替换后个数量相等.',
								});
								return;
							}
							rdata.open = rdata.open ? 1 : 0;
							rdata.cache_open = obj['cache_open'];
							rdata.path_open = rdata.path_open ? 1 : 0;
							rdata['sitename'] = web.name;
							rdata['proxydomains'] = JSON.stringify($('.selectpicker').val() || []);
							if (is_create) {
								bt.site.create_proxy(rdata, function (ret) {
									if (ret.status) {
										load.close();
									}
									site.edit.show_rule_msg('添加反向代理', ret);
								});
							} else {
								bt.site.modify_proxy(rdata, function (ret) {
									if (ret.status) {
										load.close();
									}
									site.edit.show_rule_msg('修改反向代理', ret);
								});
							}
						}),
					],
					sucess: function () {},
				};
				bt.render_form(form_data);
				var h = $(bt.render_help(helps));
				h.css({
					bottom: '60px',
				});

				$('.' + form_data.skin + ' .bt-form').append(h);
				site.edit.render_sel('proxydomains', obj.proxydomains);
				$('#path_open').change(function () {
					var robj = $('.root_path-line');
					if ($(this).prop('checked')) {
						robj.show();
					} else {
						robj.hide();
					}
				});
				$('#path_open').trigger('change');
				$('.proxydomains').selectpicker('val', obj.proxydomains);
			});
		},
		edit_proxy: function (obj, name) {
			var item = $(obj).parents('tr').data('item');
			if (item[name]) {
				item[name] = 0;
			} else {
				item[name] = 1;
			}
			item['proxydomains'] = JSON.stringify(item['proxydomains'] || []);

			bt.site.modify_proxy(item, function (ret) {
				site.edit.show_rule_msg('修改反向代理', ret);
			});
		},
		show_rule_msg: function (title, ret) {
			if (ret.status) {
				site.reload();
			}
			if (ret.hasOwnProperty('xml')) {
				site.reload();
				layer.open({
					type: 1,
					title: title,
					area: ['650px', '420px'],
					closeBtn: 2,
					shadeClose: false,
					content:
						'<div class="redireSiteTips pd15 pb70">\
									<div class="redireTipsHead">\
										<div class="info-title-tips" style="line-height: 27px;padding: 5px 10px;">\
											<p>\
												<span class="glyphicon glyphicon-alert" style="color: #f39c12; margin-right: 10px;"></span>\
												<span style="line-height:22px">' +
						ret.msg +
						'，<a class="btlink" href="https://www.bt.cn/bbs/thread-51777-1-1.html" target="_blank">详细教程>></a></span>\
											</p>\
										</div></div>\
									<div class="redireTipsBody">\
										<textarea class="bt-input-text" style="height: 200px; line-height: 18px; display: none;" id="redireSiteCode"></textarea>\
									</div>\
								</div>\
								<div class="bt-form-submit-btn">\
									<button type="button" class="btn btn-sm btn-success" id="xml-copy">复制</button>\
								</div>',
					success: function (layers, index) {
						$('#xml-copy').click(function () {
							bt.pub.copy_pass(ret.xml);
						});
						$('#redireSiteCode').empty().text(ret.xml);
						$('.CodeMirror').remove();
						var editor = CodeMirror.fromTextArea(document.getElementById('redireSiteCode'), {
							extraKeys: {
								'Ctrl-Space': 'autocomplete',
							},
							lineNumbers: true,
							matchBrackets: true,
						});
						editor.focus();
						$('.CodeMirror-scroll').css({
							height: '200px',
							margin: 0,
							padding: 0,
						});
					},
				});
				return;
			}
			bt.msg(ret);
		},
		set_proxy: function (web) {
			bt.site.get_proxy_list(web.name, function (rdata) {
				if (rdata.status === false) {
					rdata.time = 0;
					bt.msg(rdata);
					return;
				}
				var robj = $('#webedit-con');
				var datas = {
					items: [
						{
							name: 'add_proxy',
							text: '添加反向代理',
							type: 'button',
							callback: function (data) {
								site.edit.templet_proxy(web, false);
							},
						},
					],
				};
				var form_line = bt.render_form_line(datas);
				$('#webedit-con').append(form_line.html);
				bt.render_clicks(form_line.clicks);
				$('#webedit-con').addClass('divtable').append('<table id="proxy_list" class="table table-hover"></table>');
				setTimeout(function () {
					var _tab = bt.render({
						table: '#proxy_list',
						columns: [
							{
								field: 'proxyname',
								title: '名称',
								templet: function (item) {
									return '<span style="width:70px;" title="' + item.proxyname + '">' + item.proxyname + '</span>';
								},
							},
							{
								field: 'root_path',
								title: '目录',
								templet: function (item) {
									return '<span style="max-width:170px;" title="' + item.root_path + '">' + item.root_path + '</span>';
								},
							},
							{
								field: 'tourl',
								title: '目标url',
								templet: function (item) {
									return '<span style="width:70px;" title="' + item.tourl + '">' + item.tourl + '</span>';
								},
							},
							{
								field: 'open',
								title: '状态',
								index: true,
								templet: function (item) {
									return (
										'<a href="javascript:;" onclick="site.edit.edit_proxy(this,\'open\')" class="btlink set_type_state" style="display:" data-stuats="' +
										(item.open == 1 ? 0 : 1) +
										'">' +
										(item.open == 1
											? '<span style="color:#20a53a;">运行中</span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span>'
											: '<span style="color:red;">已暂停</span><span style="color:red" class="glyphicon glyphicon-pause"></span>') +
										'</a>'
									);
								},
							},
							{
								field: 'cache_open',
								title: '缓存',
								index: true,
								templet: function (item) {
									return (
										'<a href="javascript:;" onclick="site.edit.edit_proxy(this,\'cache_open\')" class="btlink set_type_state" style="display:" data-stuats="' +
										(item.cache_open == 1 ? 0 : 1) +
										'">' +
										(item.cache_open == 1
											? '<span style="color:#20a53a;">开启</span><span style="color:#5CB85C" class="glyphicon glyphicon-play"></span>'
											: '<span style="color:red;">关闭</span><span style="color:red" class="glyphicon glyphicon-pause"></span>') +
										'</a>'
									);
								},
							},
							{
								field: '',
								title: '操作',
								width: '150px',
								align: 'right',
								index: true,
								templet: function (item) {
									var redirectname = item.redirectname;
									var sitename = item.sitename;
									var open_file = '';
									if (bt.get_cookie('serverType') != 'iis') {
										open_file = '<a class="btlink open_config_file" href="javascript:;">配置文件</a> | ';
									}
									var conter =
										open_file +
										' <a class="btlink edit_proxy"  href="javascript:;">编辑</a> | <a class="btlink" onclick="bt.site.remove_proxy(\'' +
										sitename +
										"','" +
										item.proxyname +
										'\',function(rdata){if(rdata.status)site.reload()})" href="javascript:;">删除</a>';
									return conter;
								},
							},
						],
						data: rdata,
					});
					$('.open_config_file').click(function () {
						var item = $(this).parents('tr').data('item');
						var sitename = web.name;
						var proxyname = item.proxyname;

						var proxy_config = '';
						bt.site.get_proxy_config(
							{
								sitename: sitename,
								proxyname: proxyname,
								webserver: bt.get_cookie('serverType'),
							},
							function (rdata) {
								if (typeof rdata == 'object' && rdata.constructor == Array) {
									if (!rdata[0].status) bt.msg(rdata);
								} else {
									if (rdata.status == false) bt.msg(rdata);
								}
								var datas = [
									{
										items: [
											{
												name: 'proxy_configs',
												type: 'textarea',
												value: rdata[0].data,
												widht: '340px',
												height: '200px',
											},
										],
									},
									{
										name: 'btn_config_submit',
										text: '保存',
										type: 'button',
										callback: function (ddata) {
											bt.site.save_proxy_config(
												{
													path: rdata[1],
													data: editor.getValue(),
													encoding: rdata[0].encoding,
												},
												function (ret) {
													if (ret.status) {
														site.reload(12);
														proxy_config.close();
													}
													bt.msg(ret);
												}
											);
										},
									},
								];
								proxy_config = bt.open({
									type: 1,
									area: ['550px', '550px'],
									title: '编辑配置文件[' + proxyname + ']',
									closeBtn: 2,
									shift: 0,
									content: "<div class='bt-form'><div id='proxy_config_con' class='pd15'></div></div>",
								});
								var robj = $('#proxy_config_con');
								for (var i = 0; i < datas.length; i++) {
									var _form_data = bt.render_form_line(datas[i]);
									robj.append(_form_data.html);
									bt.render_clicks(_form_data.clicks);
								}
								robj.append(bt.render_help(['此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。']));
								$('textarea.proxy_configs').attr('id', 'configBody');
								var editor = CodeMirror.fromTextArea(document.getElementById('configBody'), {
									extraKeys: {
										'Ctrl-Space': 'autocomplete',
									},
									lineNumbers: true,
									matchBrackets: true,
								});
								$('.CodeMirror-scroll').css({
									height: '350px',
									margin: 0,
									padding: 0,
								});
								setTimeout(function () {
									editor.refresh();
								}, 250);
							}
						);
					});
					$('.edit_proxy').click(function () {
						var item = $(this).parents('tr').data('item');
						site.edit.templet_proxy(web, item);
					});
				});
			});
		},
		set_security: function (web) {
			bt.site.get_site_security(web.id, web.name, function (rdata) {
				var robj = $('#webedit-con');
				var datas = [
					{ title: 'URL后缀', name: 'sec_fix', value: rdata.fix, disabled: rdata.status, width: '300px' },
					{ title: '许可域名', type: 'textarea', name: 'sec_domains', value: rdata.domains.replace(/,/g, '\n'), disabled: rdata.status, width: '300px', height: '210px' },
					{ title: '响应资源', name: 'return_rule', disabled: true, value: rdata.return_rule, width: '300px' },
					{
						title: ' ',
						class: 'label-input-group',
						items: [
							{
								text: '启用防盗链',
								name: 'status',
								value: rdata.status,
								type: 'checkbox',
								callback: function (sdata) {
									bt.site.set_site_security(web.id, web.name, sdata.sec_fix, sdata.sec_domains.split('\n').join(','), sdata.status, sdata.return_rule, sdata.none, function (ret) {
										if (ret.status) site.reload(13);
										bt.msg(ret);
									});
								},
							},
							{
								text: '允许空HTTP_REFERER请求',
								name: 'none',
								value: rdata.none,
								type: 'checkbox',
								callback: function (sdata) {
									if (!sdata.status) return layer.msg('请先开启防盗链', { icon: 2 });
									bt.site.set_site_security(web.id, web.name, sdata.sec_fix, sdata.sec_domains.split('\n').join(','), sdata.status, sdata.return_rule, sdata.none, function (ret) {
										if (ret.status) site.reload(13);
										bt.msg(ret);
									});
								},
							},
						],
					},
				];
				for (var i = 0; i < datas.length; i++) {
					var _form_data = bt.render_form_line(datas[i]);
					robj.append(_form_data.html);
					bt.render_clicks(_form_data.clicks);
				}
				var helps = [
					'【URL后缀】一般填写文件后缀，每行一个后缀,如: png',
					'【许可域名】允许作为来路的域名，每行一个域名,如: www.bt.cn',
					'【允许空HTTP_REFERER请求】是否允许浏览器直接访问，若您的网站访问异常，可尝试开启此功能',
				];
				robj.append(bt.render_help(helps));
			});
		},
		set_tomact: function (web) {
			bt.site.get_site_phpversion(web.name, function (rdata) {
				var robj = $('#webedit-con');
				if (!rdata.tomcatversion) {
					robj.html('<font>' + lan.site.tomcat_err_msg1 + '</font>');
					layer.msg(lan.site.tomcat_err_msg, {
						icon: 2,
					});
					return;
				}
				var data = {
					class: 'label-input-group',
					items: [
						{
							text: lan.site.enable_tomcat,
							name: 'tomcat',
							value: rdata.tomcat == -1 ? false : true,
							type: 'checkbox',
							callback: function (sdata) {
								bt.site.set_tomcat(web.name, function (ret) {
									if (ret.status) site.reload(9);
									bt.msg(ret);
								});
							},
						},
					],
				};
				var _form_data = bt.render_form_line(data);
				robj.append(_form_data.html);
				bt.render_clicks(_form_data.clicks);
				var helps = [lan.site.tomcat_help1 + ' ' + rdata.tomcatversion + ',' + lan.site.tomcat_help2, lan.site.tomcat_help3, lan.site.tomcat_help4, lan.site.tomcat_help5];
				robj.append(bt.render_help(helps));
			});
		},
		get_site_logs: function (web) {
			$('#webedit-con').append('<div id="tabLogs" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');
			var _tab = [
				{
					title: '响应日志',
					on: true,
					callback: function (robj) {
						bt.site.get_site_logs(web.name, function (rdata) {
							var _logs = '';
							if (rdata.path != '' && rdata.path != undefined) {
								_logs +=
									'<div style="margin-bottom: 5px; position: relative; height:30px;line-height:30px;">日志路径：<a class="btlink c7" title="打开目录" href="javascript:openPath(\'' +
									rdata.path +
									'\');">' +
									rdata.path +
									'</a>';
								if (bt.get_cookie('serverType') == 'iis') {
									_logs += '<button style="position: absolute;right:0" onclick="site.edit.check_log_time()" class ="btn btn-success btn-sm btn-title">校对IIS日志时间</button>';
								}
								_logs += '</div>';
								robj.append(_logs);
							}
							var logs = {
								class: 'bt-logs',
								items: [
									{
										name: 'site_logs',
										height: '530px',
										value: rdata.msg,
										width: '100%',
										type: 'textarea',
									},
								],
							};
							var _form_data = bt.render_form_line(logs);
							robj.append(_form_data.html);
							bt.render_clicks(_form_data.clicks);
							$('textarea[name="site_logs"]').attr('readonly', true);
							$('textarea[name="site_logs"]').scrollTop(100000000000);
						});
					},
				},
				{
					title: '错误日志',
					callback: function (robj) {
						//   console.log(robj)
						bt.site.get_site_error_logs(web.name, function (rdata) {
							var logs = { class: 'bt-logs', items: [{ name: 'site_logs', height: '590px', value: rdata.msg, width: '100%', type: 'textarea' }] },
								_form_data = bt.render_form_line(logs);
							robj.append(_form_data.html);
							bt.render_clicks(_form_data.clicks);
							$('textarea[name="site_logs"]').attr('readonly', true);
							$('textarea[name="site_logs"]').scrollTop(100000000000);
						});
					},
				},
				{
					title: '日志安全分析',
					callback: function (robj) {
						var progress = ''; //扫描进度
						$.post('/site?action=get_scan_files&siteName=' + web.name, function (fileList) {
							//1.扫描按钮/日志列表
							var logOption = '';
							if (fileList.data.length > 0) {
								$.each(fileList.data, function (index, item) {
									logOption += '<option value="' + item + '">' + item + '</option>';
								});
							}
							var analyes_log_btn =
								'<select class="bt-input-text mr5" name="scan_log_file">' +
								logOption +
								'</select><button type="button" title="日志扫描" class="btn btn-success analyes_log btn-sm mr5"><span>日志扫描</span></button>';

							//2.功能介绍
							var analyse_help =
								'<ul class="help-info-text c7">\
                        <li>日志安全分析：扫描网站(.log)日志中含有攻击类型的请求(类型包含：<em style="color:red">xss,sql,scan,php</em>)</li>\
                        <li>分析的日志数据包含已拦截的请求</li>\
                        <li>默认展示上一次扫描数据(如果没有请点击日志扫描）</li>\
                        <li>如日志文件过大，扫描可能等待时间较长，请耐心等待</li>\
                        </ul>';

							robj.append(analyes_log_btn + '<div class="analyse_log_table"></div>' + analyse_help);
							render_analyse_list(); //加载模板
							//首次获取进度
							detect_progress('init', function () {
								var loadT = bt.load('正在获取日志分析数据，请稍候...');
								$.post('/site?action=get_scan_result&siteName=' + web.name, function (rdata) {
									loadT.close();
									render_analyse_list(rdata);
								});
								//事件
								$(robj)
									.find('.analyes_log')
									.click(function () {
										var _file = $('[name=scan_log_file]').val();
										if (!_file) return layer.msg('没有日志文件', { icon: 2 });

										bt.confirm(
											{
												title: '扫描网站日志',
												msg: '建议在服务器负载较低时进行安全分析，本次将对【' + _file + '】文件进行扫描，可能等待时间较长，是否继续？',
											},
											function (index) {
												layer.close(index);
												$('.analyes_log').attr('disabled', true);
												// 开启扫描并且持续获取进度
												$.post('/site?action=start_scan_logs&siteName=' + web.name + '&path=' + _file, function (rdata) {
													if (rdata.status) {
														open_scan_dialog();
													} else {
														layer.close(progress);
														layer.msg(rdata.msg, { icon: 2, time: 0, shade: 0.3, shadeClose: true });
													}
												});
											}
										);
									});
							});
						});

						// 渲染分析日志列表
						function render_analyse_list(rdata) {
							var analyse_list =
								'<div class="divtable" style="margin-top: 10px;"><table class="table table-hover">\
                        <thead><tr><th>文件名</th><th width="142">扫描时间</th><th>总条数</th><th>耗时</th><th>XSS</th><th>SQL</th><th>扫描</th><th>PHP攻击</th><th>合计</th></tr></thead>\
                        <tbody class="analyse_body">';
							if (rdata && rdata.length > 0) {
								//检测是否有扫描数据
								$.each(rdata, function (index, item) {
									var numTotal = item.xss + item.sql + item.scan + item.php;
									analyse_list +=
										'<tr name="' +
										item.filename +
										'">\
                                    <td title="' +
										item.filepath +
										'"><span class="size_ellipsis" style="width:90px">' +
										item.filename +
										'</span></td>\
                                    <td>' +
										bt.format_data(item.start) +
										'</td>\
                                    <td>' +
										item.total +
										'</td>\
                                    <td>' +
										item.time.toString().substring(0, 4) +
										'秒</td>\
                                    <td class="onChangeLogDatail" ' +
										(item.xss > 0 ? 'style="color:red"' : '') +
										' name="xss">' +
										item.xss +
										'</td>\
                                    <td class="onChangeLogDatail" ' +
										(item.sql > 0 ? 'style="color:red"' : '') +
										' name="sql">' +
										item.sql +
										'</td>\
                                    <td class="onChangeLogDatail" ' +
										(item.scan > 0 ? 'style="color:red"' : '') +
										' name="scan">' +
										item.scan +
										'</td>\
                                    <td class="onChangeLogDatail" ' +
										(item.php > 0 ? 'style="color:red"' : '') +
										' name="php">' +
										item.php +
										'</td>\
                                    <td>' +
										numTotal +
										'</td>\
                                </tr>';
								});
							} else {
								analyse_list += '<tr><td colspan="9" style="text-align: center;">没有扫描数据</td></tr>';
							}

							analyse_list += '</tbody></table></div>';
							$('.analyse_log_table').html(analyse_list);
							$('.onChangeLogDatail').css('cursor', 'pointer').attr('title', '点击查看详情');
							//查看详情
							$('.onChangeLogDatail').on('click', function () {
								get_analysis_data_datail($(this).attr('name'), $(this).parents('tr').attr('name'));
							});
							$('.analyes_log').attr('disabled', false);
						}
						// 扫描进度界面
						function open_scan_dialog() {
							progress = layer.open({
								type: 1,
								closeBtn: 1,
								title: '日志扫描',
								shade: 0,
								maxmin: true,
								area: '500px',
								skin: 'scan_logs_view',
								content:
									'<div class="pro_style">\
                                <pre style="margin-bottom: 0px;height:300px;border-radius:0px; text-align: left;background-color: #000;color: #fff;white-space: pre-wrap;" id="scan_result_progress"></pre>\
                                </div>',
								success: function () {
									detect_progress();
								},
								full: function () {
									$('#scan_result_progress').height($('.scan_logs_view .layui-layer-content').height() - 50);
								},
								restore: function () {
									$('#scan_result_progress').height('279px');
								},
								cancel: function (index) {
									layer.confirm(
										'正在对日志扫描中，此操作将会停止日志扫描，是否继续？',
										{
											title: '停止扫描',
											icon: 0,
										},
										function (indexs) {
											$.post('/site?action=stop_scan_logs&siteName=' + web.name, function (rdata) {
												if (rdata.status) {
													layer.close(indexs);
												}
												layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
											});
										}
									);
									return false;
								},
							});
						}
						// 扫描进度
						function detect_progress(type, callback) {
							$.post('/site?action=speed_log&siteName=' + web.name, function (res) {
								var pro = res.code;
								if (type == 'init' && pro != 1) {
									// 是否有扫描进度界面
									if ($('#scan_result_progress').length > 0) {
										detect_progress();
									} else {
										open_scan_dialog();
									}
									$('.analyes_log').attr('disabled', true);
								} else if (type == 'init' && pro == 1) {
									callback();
								} else {
									if (pro !== 1) {
										$('#scan_result_progress').html(res.msg).scrollTop(100000000000);
										setTimeout(function () {
											detect_progress();
										}, 1000);
									} else {
										layer.msg('扫描完成', { icon: 1, timeout: 4000 });
										layer.close(progress);
										get_analysis_data();
									}
								}
							});
						}
						// 获取扫描结果
						function get_analysis_data() {
							var loadTGA = bt.load('正在获取日志分析数据，请稍候...');
							$.post('/site?action=get_scan_result&siteName=' + web.name, function (rdata) {
								loadTGA.close();
								render_analyse_list(rdata);
							});
						}
						// 获取扫描结果详情日志
						function get_analysis_data_datail(name, filename) {
							layer.open({
								type: 1,
								closeBtn: 1,
								shadeClose: false,
								maxmin: true,
								title: '【文件：' + filename + '】【类型：' + name + '】日志详情',
								area: '650px',
								skin: 'scan_type_details',
								content: '<pre id="analysis_pre" style="background-color: #333;color: #fff;height:545px;margin: 0;white-space: pre-wrap;border-radius: 0;"></pre>',
								success: function () {
									var loadTGD = bt.load('正在获取日志详情数据，请稍候...');
									$.post('/site?action=get_detailed&siteName=' + web.name + '&filename=' + filename + '&type=' + name + '', function (logs) {
										loadTGD.close();
										$('#analysis_pre').html(logs.msg);
									});
								},
								full: function () {
									$('#analysis_pre').height($('.scan_type_details .layui-layer-content').height() - 50);
								},
								restore: function () {
									$('#analysis_pre').height('524px');
								},
							});
						}
					},
				},
			];
			bt.render_tab('tabLogs', _tab);
			$('#tabLogs span:eq(0)').click();
		},
		check_log_time: function () {
			bt.confirm(
				{
					msg: '是否立即校对IIS日志时间，校对后日志统一使用北京时间记录？',
					title: '提示',
				},
				function () {
					var loading = bt.load();
					bt.send('check_log_time', 'site/check_log_time', {}, function (rdata) {
						loading.close();
						if (rdata.status) {
							site.reload();
						}
						bt.msg(rdata);
					});
				}
			);
		},
		render_recommend_product: function () {
			var _config = $('.bt-w-menu.site-menu p.bgw').data('recom'),
				pay_status = product_recommend.get_pay_status(),
				recom_Template = '',
				_introduce = '';
			// 1.未安装
			try {
				if (!_config['isBuy'] || !_config['install']) {
					if ($('#webedit-con').find('.daily-thumbnail.recommend').length >= 1) return;

					$.each(_config['product_introduce'], function (index, item) {
						_introduce += '<li>' + item + '</li>';
					});
					recom_Template =
						'\
                    <div class="daily-thumbnail recommend">\
                        <div class="thumbnail-box">\
                            <div class="pluginTipsGg"></div>\
                        </div>\
                        <div class="thumbnail-introduce">\
                            <span>' +
						_config['title'] +
						'功能介绍：</span>\
                            <ul>' +
						_introduce +
						'</ul>\
                            <div class="daily-product-buy">\
                            ' +
						(_config['isBuy'] && !_config['install']
							? '<button class="btn btn-sm btn-success" style="margin-left:0;" onclick="bt.soft.install(\'' + _config['name'] + '\')">立即安装</button>'
							: '<a class="btn btn-sm btn-default mr5 ' +
							  (!_config.preview ? 'hide' : '') +
							  '" href="' +
							  _config.preview +
							  '" target="_blank">功能预览</a><button type="submit" class="btn btn-sm btn-success" onclick="product_recommend.pay_product_sign(\'ltd\',' +
							  _config.pay +
							  ",'" +
							  _config.pluginType +
							  '\')">立即购买</button>') +
						'\
                            </div>\
                        </div>\
                    </div>';
				} else {
					return true;
				}

				$('#webedit-con').append(recom_Template);
				$('.pluginTipsGg').css('background-image', 'url(' + _config.previewImg + ')');
				$('.thumbnail-box').on('click', function () {
					layer.open({
						title: false,
						btn: false,
						shadeClose: true,
						closeBtn: 1,
						area: ['700px', '650px'],
						content: '<img src="' + _config.previewImg + '" style="width: 700px;"/>',
						success: function (layero) {
							$(layero).find('.layui-layer-content').css('padding', '0');
						},
					});
				});
			} catch (err) {
				console.log(err);
			}
		},
	},
	node: {
		/**
		 * @description 渲染node项目使用情况
		 * @param el {object} 当前element节点
		 * @param row {object} 当前项目数据
		 */
		reander_node_service_condition: function (el, row) {
			if (!row.run) {
				el.html('').next().removeClass('hide');
				if (el.next().find('.node_mask_module_text').length === 1) {
					el.next()
						.find('.node_mask_module_text')
						.hide()
						.parent()
						.append('<div class="node_mask_module_text">请先启动服务后重新尝试，<a href="javascript:;" class="btlink" onclick="site.node.simulated_click(7)">设置服务状态</a></div');
				} else {
					el.next().find('.node_mask_module_text:eq(1)').show().prev().hide();
				}
				return false;
			}
			el.html(
				'<div class="line" style="padding-top: 0;"><span class="tname" style="width: 30px;text-align:left;padding-right: 5px;">PID</span><div class="info-r"><select class="bt-input-text mr5" name="node_project_pid"></select></div></div><div class="node_project_pid_datail"></div>'
			);
			var _option = '',
				tabelCon = '';
			for (var load in row.load_info) {
				if (row.load_info.hasOwnProperty(load)) {
					_option += '<option value="' + load + '">' + load + '</option>';
				}
			}
			var node_pid = $('[name=node_project_pid]');
			node_pid.html(_option);
			node_pid
				.change(function () {
					var _pid = $(this).val(),
						rdata = row['load_info'][_pid],
						fileBody = '',
						connectionsBody = '';
					if (rdata.open_files) {
						for (var i = 0; i < rdata.open_files.length; i++) {
							var itemi = rdata.open_files[i];
							fileBody +=
								'<tr>' +
								'<td>' +
								itemi['path'] +
								'</td>' +
								'<td>' +
								itemi['mode'] +
								'</td>' +
								'<td>' +
								itemi['position'] +
								'</td>' +
								'<td>' +
								itemi['flags'] +
								'</td>' +
								'<td>' +
								itemi['fd'] +
								'</td>' +
								'</tr>';
						}
					}
					for (var k = 0; k < rdata.connections.length; k++) {
						var itemk = rdata.connections[k];
						connectionsBody +=
							'<tr>' +
							'<td>' +
							itemk['client_addr'] +
							'</td>' +
							'<td>' +
							itemk['client_rport'] +
							'</td>' +
							'<td>' +
							itemk['family'] +
							'</td>' +
							'<td>' +
							itemk['fd'] +
							'</td>' +
							'<td>' +
							itemk['local_addr'] +
							'</td>' +
							'<td>' +
							itemk['local_port'] +
							'</td>' +
							'<td>' +
							itemk['status'] +
							'</td>' +
							'</tr>';
					}

					//     tabelCon = reand_table_config([
					//         [{"名称":rdata.name},{"PID":rdata.pid},{"状态":rdata.status},{"父进程":rdata.ppid}],
					//         [{"用户":rdata.user},{"Socket":rdata.connects},{"CPU":rdata.cpu_percent},{"线程":rdata.threads}],
					//         [{"内存":rdata.user},{"io读":rdata.connects},{"io写":rdata.cpu_percent},{"启动时间":rdata.threads}],
					//         [{"启动命令":rdata.user}],
					//     ])
					//
					// console.log(tabelCon)
					//
					//
					//     function reand_table_config(conifg){
					//         var html = '';
					//         for (var i = 0; i < conifg.length; i++) {
					//             var item = conifg[i];
					//             html += '<tr>';
					//             for (var j = 0; j < item; j++) {
					//                 var items = config[j],name = Object.keys(items)[0];
					//                 console.log(items,name)
					//                 html += '<td>'+  name +'</td><td>'+ items[name] +'</td>'
					//             }
					//             console.log(html)
					//             html += '</tr>'
					//         }
					//         return '<div class="divtable"><table class="table"><tbody>'+ html  +'</tbody></tbody></table></div>';
					//     }

					tabelCon =
						'<div class="divtable">' +
						'<table class="table">' +
						'<tbody>' +
						'<tr>' +
						'<th width="50">名称</th><td  width="100">' +
						rdata.name +
						'</td>' +
						'<th width="50">状态</th><td  width="90">' +
						rdata.status +
						'</td>' +
						'<th width="60">用户</th><td width="100">' +
						rdata.user +
						'</td>' +
						'<th width="80">启动时间</th><td width="150">' +
						getLocalTime(rdata.create_time) +
						'</td>' +
						'</tr>' +
						'<tr>' +
						'<th>PID</th><td  >' +
						rdata.pid +
						'</td>' +
						'<th>PPID</th><td >' +
						rdata.ppid +
						'</td>' +
						'<th>线程</th><td>' +
						rdata.threads +
						'</td>' +
						'<th>Socket</th><td>' +
						rdata.connections.length +
						'</td>' +
						'</tr>' +
						'<tr>' +
						'<th>CPU</th><td>' +
						rdata.cpu_percent +
						'%</td>' +
						'<th>内存</th><td>' +
						ToSize(rdata.memory_used) +
						'</td>' +
						'<th>io读</th><td>' +
						ToSize(rdata.io.read) +
						'</td>' +
						'<th>io写</th><td>' +
						ToSize(rdata.io.write) +
						'</td>' +
						'</tr>' +
						'<tr>' +
						'</tr>' +
						'<tr>' +
						'<th width="50">命令</th><td colspan="7" style="word-break: break-word;width: 570px">' +
						rdata.exe +
						'</td>' +
						'</tr>' +
						'</tbody>' +
						'</table>' +
						'</div>' +
						'<h3 class="tname">网络</h3>' +
						'<div class="divtable" >' +
						'<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeNetworkList">' +
						'<table class="table table-hover" style="border:none">' +
						'<thead>' +
						'<tr>' +
						'<th>客户端地址</th>' +
						'<th>客户端端口</th>' +
						'<th>协议</th>' +
						'<th>FD</th>' +
						'<th>本地地址</th>' +
						'<th>本地端口</th>' +
						'<th>状态</th>' +
						'</tr>' +
						'</thead>' +
						'<tbody>' +
						connectionsBody +
						'</tbody>' +
						'</table>' +
						'</div>' +
						'</div>' +
						'<h3 class="tname">打开的文件列表</h3>' +
						'<div class="divtable" >' +
						'<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeFileList">' +
						'<table class="table table-hover" style="border:none">' +
						'<thead>' +
						'<tr>' +
						'<th>文件</th>' +
						'<th>mode</th>' +
						'<th>position</th>' +
						'<th>flags</th>' +
						'<th>fd</th>' +
						'</tr>' +
						'</thead>' +
						'<tbody>' +
						fileBody +
						'</tbody>' +
						'</table>' +
						'</div>' +
						'</div>';
					$('.node_project_pid_datail').html(tabelCon);
					bt_tools.$fixed_table_thead('#nodeNetworkList');
					bt_tools.$fixed_table_thead('#nodeFileList');
				})
				.change()
				.html(_option);
		},
	},
	sync_iis: function () {
		bt.confirm(
			{
				msg: '此功能仅用于重装系统后，恢复网站到IIS，是否立即恢复？',
				title: '提示',
			},
			function () {
				var arr = [];
				$('input[type="checkbox"].check:checked').each(function () {
					var _val = $(this).val();
					if (!isNaN(_val)) arr.push($(this).parents('tr').data('item')['id']);
				});
				if (arr.length > 0) {
					var loading = bt.load();
					bt.send(
						'sync_iis_site',
						'site/sync_iis_site',
						{
							ids: JSON.stringify(arr),
						},
						function (rdata) {
							loading.close();
							if (rdata.status) {
								site.reload();
							}
							bt.msg(rdata);
						}
					);
				}
			}
		);
	},
	create_let: function (ddata, callback) {
		bt.site.create_let(ddata, function (ret) {
			if (ret.status) {
				if (callback) {
					callback(ret);
				} else {
					site.ssl.reload();
					bt.msg(ret);
					return;
				}
			} else {
				if (!ret.out) {
					bt.msg(ret);
					return;
				}
				var data = '<p>' + ret.msg + '</p><hr />';
				if (ret.err[0].length > 10) data += '<p style="color:red;">' + ret.err[0].replace(/\n/g, '<br>') + '</p>';
				if (ret.err[1].length > 10) data += '<p style="color:red;">' + ret.err[1].replace(/\n/g, '<br>') + '</p>';

				layer.msg(data, {
					icon: 2,
					area: '500px',
					time: 0,
					shade: 0.3,
					shadeClose: true,
				});
			}
		});
	},
	//导入证书文件
	upload_ssl: function (id, name) {
		uploadFiles.init_upload_path();
		uploadFiles.upload_layer();
	},
	upload_pfx: function () {
		var path = setup_path + '/temp/ssl/';
		bt_upload_file.open(path, '.pfx', ' <span style="color:red;">请上传pfx文件</span>', function (path) {
			site.reload();
		});
		return;

		var path = setup_path + '/temp/ssl/';
		var index = layer.open({
			type: 1,
			closeBtn: 2,
			title: '上传IIS证书文件 --- <span style="color:red;">请上传pfx文件</span>',
			area: ['500px', '500px'],
			shadeClose: false,
			content:
				'<div class="fileUploadDiv">\
                            <input type="hidden" id="input-val" value="' +
				path +
				'" />\
				            <input type="file" id="file_input" multiple="true" autocomplete="off" />\
				            <button type="button"  id="opt" autocomplete="off">添加文件</button>\
				            <button type="button" id="up" autocomplete="off" >开始上传</button>\
				            <span id="totalProgress" style="position: absolute;top: 7px;right: 147px;"></span>\
                            <input type="hidden" id ="fileCodeing" value ="utf-8" />\
				            <button type="button" id="filesClose" autocomplete="off">关闭</button>\
				            <ul id="up_box"></ul>\
                        </div>',
		});
		$('#filesClose').click(function () {
			layer.close(index);
			site.reload();
			setTimeout(site.ssl.reload(), 200);
		});
		UploadStart(false);
	},
	reload: function (index) {
		if (index == undefined) index = 0;
		var _sel = $('.site-menu p.bgw');
		if (_sel.length == 0) _sel = $('.site-menu p:eq(0)');
		_sel.trigger('click');
	},
	//拆分多个配置
	set_iis_multiple: function (siteName) {
		bt.confirm(
			{
				msg: '是否确定执行自动解析？',
				title: '提示',
			},
			function () {
				var loading = bt.load();
				bt.send(
					'set_iis_multiple',
					'site/set_iis_multiple',
					{
						siteName: siteName,
					},
					function (rdata) {
						loading.close();
						if (rdata.status) {
							site.reload();
						}
						bt.msg(rdata);
					}
				);
			}
		);
	},
	plugin_firewall: function () {
		var typename = bt.get_cookie('serverType');
		var name = 'waf_' + typename;

		bt.plugin.get_plugin_byhtml(name, function (rhtml) {
			if (rhtml.status === false) return;

			var list = rhtml.split('<script type="javascript/text">');
			if (list.length > 1) {
				rcode = rhtml.split('<script type="javascript/text">')[1].replace('</script>', '');
			} else {
				list = rhtml.split('<script type="text/javascript">');
				rcode = rhtml.split('<script type="text/javascript">')[1].replace('</script>', '');
			}
			rcss = rhtml.split('<style>')[1].split('</style>')[0];
			$('body').append('<div style="display:none"><style>' + rcss + '</style><script type="javascript/text">' + rcode + '</script></div>');
			setTimeout(function () {
				if (!!(window.attachEvent && !window.opera)) {
					execScript(rcode);
				} else {
					window.eval(rcode);
				}
			}, 200);
		});
	},

	select_site_txt: function (box) {
		layer.open({
			type: 1,
			closeBtn: 2,
			title: '自定义域名',
			area: '600px',
			btn: ['确认', '取消'],
			content:
				'<div class="pd20"><div class="line "><span class="tname">自定义域名</span><div class="info-r "><input  name="site_name" placeholder="请输入需要申请证书的域名（单域名证书），必填项，例如：www.bt.cn" class="bt-input-text mr5 ssl_site_name_rc" type="text" style="width:400px" value=""></div></div>\
            <ul class="help-info-text c7">\
                    <li> 申请之前，请确保域名已解析，如未解析会导致审核失败(包括根域名)</li>\
                    <li>申请www.bt.cn这种以www为二级域名的证书，需绑定并解析顶级域名(bt.cn)，否则将验证失败</li>\
                    <li>SSL证书可选名称赠送规则：</li>\
                    <li>1、申请根域名(如：bt.cn),赠送下一级为www的域名(如：www.bt.cn)</li>\
                    <li>2、申请当前host为www的域名（如：www.bt.cn）,赠送上一级域名，(如: bt.cn)</li>\
                    <li>3、申请其它二级域名，(如：app.bt.cn)，赠送下一级为www的域名 (如：www.app.bt.cn)</li>\
                </ul >\
            </div>',
			success: function () {},
			yes: function (layers, index) {
				layer.close(layers);
				$('#' + box).val($('.ssl_site_name_rc').val());
			},
		});
	},

	/**
	 * @descripttion: 选择站点
	 * @author: Lifu
	 * @Date: 2020-08-14
	 * @param {String} box 输出时所用ID
	 * @return: 无返回值
	 */
	select_site_list: function (box, code) {
		var _optArray = [],
			all_site_list = [];
		$.post(
			'/data?action=getData',
			{
				tojs: 'site.get_list',
				table: 'domain',
				limit: 10000,
				search: '',
				p: 1,
				order: 'id desc',
				type: -1,
			},
			function (res) {
				var _tbody = '';
				if (res.data.length > 0) {
					$.each(res.data, function (index, item) {
						_body =
							'<tr>' +
							'<td>' +
							'<div class="box-group" style="height:16px">' +
							'<div class="bt_checkbox_groups"></div>' +
							'</div>' +
							'</td>' +
							'<td><span class="overflow_style" style="width:210px">' +
							item['name'] +
							'</span></td>' +
							'</tr>';

						if (code.indexOf('wildcard') > -1) {
							if (item['name'].indexOf('*.') > -1) {
								all_site_list.push(item['name']);
								_tbody += _body;
							}
						} else {
							all_site_list.push(item['name']);
							_tbody += _body;
						}
					});
					if (all_site_list.length == 0) {
						_tbody = '<tr><td colspan="2">暂无数据</td></tr>';
						if (code.indexOf('wildcard') > -1) {
							_tbody = '<tr><td colspan="2">暂未绑定泛域名，请先添加.</td></tr>';
						}
					}
				} else {
					_tbody = '<tr><td colspan="2">暂无数据</td></tr>';
				}

				layer.open({
					type: 1,
					closeBtn: 2,
					title: '选择站点',
					area: '600px',
					btn: ['确认', '取消'],
					content:
						'<div class="pd20 dynamic_head_box"><div class="line"><input type="text" name="serach_site" class="bt-input-text" style="width: 560px;" placeholder="支持字段模糊搜索"></div>\
                <div class="bt-table dynamic_list_table">\
                    <div class="divtable" style="height:281px">\
                        <table class="table table-hover">\
                            <thead>\
                                <th width="30">\
                                    <div class="box-group" style="height:16px">\
                                        <div class="bt_checkbox_groups" data-key="0"></div>\
                                    </div>\
                                </th>\
                                <th>域名</th>\
                            </thead>\
                            <tbody class="dynamic_list">' +
						_tbody +
						'</tbody>\
                        </table>\
                    </div>\
                </div>\
                <ul class="help-info-text c7">\
                    <li> 申请之前，请确保域名已解析，如未解析会导致审核失败(包括根域名)</li>\
                    <li>申请www.bt.cn这种以www为二级域名的证书，需绑定并解析顶级域名(bt.cn)，否则将验证失败</li>\
                    <li>SSL证书可选名称赠送规则：</li>\
                    <li>    1、申请根域名(如：bt.cn),赠送下一级为www的域名(如：www.bt.cn)</li>\
                    <li>    2、申请当前host为www的域名（如：www.bt.cn）,赠送上一级域名，(如: bt.cn)</li>\
                    <li>    3、申请其它二级域名，(如：app.bt.cn)，赠送下一级为www的域名 (如：www.app.bt.cn)</li>\
                </ul >\
                </div> ',
					success: function () {
						// 固定表格头部
						if (jQuery.prototype.fixedThead) {
							$('.dynamic_list_table .divtable').fixedThead({
								resize: false,
							});
						} else {
							$('.dynamic_list_table .divtable').css({
								overflow: 'auto',
							});
						}
						//检索输入
						$('input[name=serach_site]').on('input', function () {
							var _serach = $(this).val();
							if (_serach.trim() != '') {
								$('.dynamic_list tr').each(function () {
									var _td = $(this).find('td').eq(1).html();
									if (_td.indexOf(_serach) == -1) {
										$(this).hide();
									} else {
										$(this).show();
									}
								});
							} else {
								$('.dynamic_list tr').show();
							}
						});

						// 单选设置
						$('.dynamic_list').on('click', '.bt_checkbox_groups', function (e) {
							var _tr = $(this).parents('tr');
							if ($(this).hasClass('active')) {
								$(this).removeClass('active');
							} else {
								$('.dynamic_list .bt_checkbox_groups').removeClass('active');
								$(this).addClass('active');
								_optArray = [_tr.find('td').eq(1).text()];
							}
							e.preventDefault();
							e.stopPropagation();
						});
						// tr点击时
						$('.dynamic_list').on('click', 'tr', function (e) {
							$(this).find('.bt_checkbox_groups').click();
							e.preventDefault();
							e.stopPropagation();
						});
					},
					yes: function (layers, index) {
						var _olist = [];
						if (_optArray.length > 0) {
							$.each(_optArray, function (index, item) {
								if ($.inArray(item, _olist) == -1) {
									_olist.push(item);
								}
							});
						}
						layer.close(layers);
						$('#' + box).val(_olist.join('\n'));
						$('textarea[name=lb_site]').focus();

						// 检测url是否异常
						$('.perfect_ssl_info .testVerify').removeClass('hide');
						$('.perfect_ssl_info .testVerify').html('<img class="loading-ico" src="/static/images/loading-2.gif" /></img><span>检测中</span>');
						bt.send('check_ssl_method', 'ssl/check_ssl_method', { domain: _olist[0] }, function (res) {
							$.each(res, function (key, item) {
								var str = item === 1 ? '<a class="btlink" href="javascript:;">正常</a>' : '<a class="red error-link" href="javascript:;">异常</a>';
								$('.' + key + ' .testVerify').html(str);
								$('.' + key).data('error-data', item == 1 ? false : item);
								$('.' + key).data('show-tips', true);
							});
							for (var i = 0; i < $('.check_model_line .check_method_item').length; i++) {
								var $item = $($('.check_model_line .check_method_item')[i]);
								var data = $item.data('error-data');
								if (!data) {
									$('input[name="dcvMethod"]').removeAttr('checked');
									$item.find('input[name="dcvMethod"]').click();
									break;
								}
							}
						});
					},
				});
			}
		);
	},
	site_waf: function (siteName) {
		try {
			site_waf_config(siteName);
		} catch (err) {
			site.no_firewall();
		}
	},
	web_edit: function (obj) {
		var _this = this,
			item = obj;
		bt.open({
			type: 1,
			area: ['780px', '732px'],
			title: lan.site.website_change + '[' + item.name + ']  --  ' + lan.site.addtime + '[' + item.addtime + ']',
			closeBtn: 2,
			shift: 0,
			content: "<div class='bt-form'><div class='bt-w-menu site-menu pull-left' style='height: 100%;'></div><div id='webedit-con' class='bt-w-con webedit-con pd15'></div></div>",
			success: function () {
				var webcache =
					bt.get_cookie('serverType') == 'openlitespeed'
						? {
								title: 'LS-Cache',
								callback: site.edit.ols_cache,
						  }
						: '';
				var menus = [
					{ title: '域名管理', callback: site.edit.set_domains },
					{ title: '子目录绑定', callback: site.edit.set_dirbind },
					{ title: '网站目录', callback: site.edit.set_dirpath },
					{ title: '访问限制', callback: site.edit.set_dirguard },
					{ title: '应用程序池', os: 'Windows', callback: site.edit.set_apppool },
					{ title: '错误页', os: 'Windows', callback: site.edit.set_error_page },
					{ title: '流量限制', callback: site.edit.limit_network },
					{ title: '伪静态', callback: site.edit.get_rewrite_list },
					{ title: '默认文档', callback: site.edit.set_default_index },
					{ title: '配置文件', callback: site.edit.set_config },
					{ title: 'SSL', callback: site.edit.set_ssl },
					{ title: 'PHP版本', callback: site.edit.set_php_version },
					{ title: 'Composer', callback: site.edit.set_composer },
					{ title: 'Tomact', os: 'Linux', callback: site.edit.set_tomact },
					{ title: '重定向', callback: site.edit.set_301 },
					{ title: '反向代理', callback: site.edit.set_proxy },
					{ title: '防盗链', callback: site.edit.set_security },
					{ title: '响应日志', callback: site.edit.get_site_logs },
				];
				if (webcache !== '') menus.splice(3, 0, webcache);
				for (var i = 0; i < menus.length; i++) {
					var men = menus[i];
					if (men.os == undefined || men.os == bt.os) {
						var _p = $('<p>' + men.title + '</p>');
						_p.data('callback', men.callback);
						$('.site-menu').append(_p);
					}
				}
				// 推荐安全软件
				product_recommend.init(function () {
					try {
						var recomConfig = product_recommend.get_recommend_type(6);
						if (recomConfig && recomConfig.list) {
							$.each(recomConfig.list, function (index, item) {
								$('.site-menu p:eq(' + item.menu_id + ')').data('recom', item);
							});
						}
					} catch (err) {
						console.log(err);
					}

					$('.site-menu p').click(function () {
						$('#webedit-con').html('');
						$(this).addClass('bgw').siblings().removeClass('bgw');
						var callback = $(this).data('callback');
						if (callback) callback(item);
						layer.closeAll('tips');
					});

					site.reload(0);
				});
			},
			cancel: function (index) {
				if (!$('.saveCertificate').data('isSave')) {
					layer.close(index);
				}
				return false;
			},
		});
	},
};

function GetSpeed() {
	if (!$('.depSpeed')) return;
	$.get('/deployment?action=GetSpeed', function (speed) {
		if (speed.status === false) return;
		if (speed.name == '下载文件') {
			speed =
				'<p>正在' +
				speed.name +
				' <img src="/static/img/ing.gif"></p>\
                  <div class="bt-progress"><div class="bt-progress-bar" style="width:' +
				speed.pre +
				'%"><span class="bt-progress-text">' +
				speed.pre +
				'%</span></div></div>\
                  <p class="f12 c9"><span class="pull-left">' +
				ToSize(speed.used) +
				'/' +
				ToSize(speed.total) +
				'</span><span class="pull-right">' +
				ToSize(speed.speed) +
				'/s</span></p>';
			$('.depSpeed').prev().hide();
			$('.depSpeed').css({
				'margin-left': '-37px',
				width: '380px',
			});
			$('.depSpeed').parents('.layui-layer').css({
				'margin-left': '-100px',
			});
		} else {
			speed = '<p>' + speed.name + '</p>';
			$('.depSpeed').prev().show();
			$('.depSpeed').removeAttr('style');
			$('.depSpeed').parents('.layui-layer').css({
				'margin-left': '0',
			});
		}
		$('.depSpeed').html(speed);
		// setTimeout(function () {
		//   GetSpeed();
		// }, 1000);
	});
}

$('#cutMode .tabs-item[data-type="' + (bt.get_cookie('site_model') || 'php') + '"]').trigger('click');
