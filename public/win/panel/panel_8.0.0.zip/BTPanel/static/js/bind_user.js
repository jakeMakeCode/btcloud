/*
 * @Description:
 * @Version: 1.0
 * @Autor: chudong
 * @Date: 2021-11-16 15:09:43
 * @LastEditors: chudong
 * @LastEditTime: 2021-11-16 15:15:46
 */
function BindAccount (config) {
  this.verifyCode = false; // 是否需要验证码
  this.verifyParam = {};
  this.element = config;
}

BindAccount.prototype = {
  /**
   * @description 初始化
   * 
   */
  init: function () {
    var _this = this;
    this.element = {
      username: $("input[name='username']"),
      password: $("input[name='password']"),
      verifyCode: $("input[name='verifyCode']"),
      verifyCodeView: $(".verifyCodeView"),
      getVerifyCode: $(".getVerifyCode"),
      loginButton: $(".login-button")
    };

    _this.element.loginButton.on("click", function () {
      var param = {
        username: _this.element.username.val(),
        password: _this.element.password.val()
      };
      if (_this.verifyCode) {
        param['code'] = _this.element.verifyCode.val();
        param['token'] = _this.verifyParam.token;
      }
      if (!param.username || !param.password) {
        layer.msg('请输入用户名和密码', { icon: 2 });
        return;
      }
      if (param.username.length !== 11 && !bt.check_phone(param.username)) {
        layer.msg('请输入正确的手机号', { icon: 2 });
        return;
      }
      if (this.verifyCode && !param.code) {
        layer.msg('请输入验证码', { icon: 2 });
        return;
      }
      _this.getAuthToken(param);
    });

    _this.element.password.on("keydown", simulatedClick);
    _this.element.verifyCode.on("keydown", simulatedClick);
    function simulatedClick (ev) {
      if (e.keyCode == 13) _this.element.loginButton.click();
    }
    _this.element.getVerifyCode.on("click", function () {
      var data = $(this).data();
      if ($(this).hasClass('active')) return;
      _this.countDown(60);
      _this.getBindCode(_this.verifyParam);
    });
  },

  /**
   * @description 登录绑定账号
   * @param {object} param 参数{username:用户名,password:密码,code:验证码,可选}
   * @param {function} callback 回调函数
   * @returns void
   */
  getAuthToken: function (param) {
    var _this = this;
    var loadT = bt.load(lan.config.token_get);
    bt.send('GetAuthToken', 'ssl/GetAuthToken', param, function (rdata) {
      loadT.close();
      if (rdata.status) {
        bt.msg(rdata);
        if (rdata.status) window.location.href = "/"
      }
      if (typeof rdata.data == "undefined") return false
      if (!rdata.status && JSON.stringify(rdata.data) === '[]') bt.msg(rdata);
      if (rdata.data.code === -1) {
        layer.msg(rdata.msg)
        _this.verifyParam = { username: param.username, token: rdata.data.token }
        _this.verifyCodeView();
      }
    })
  },

  /**
   * @description 倒计时
   * @param {object} param 
  */
  countDown: function (time, callback) {
    var _this = this;
    setInterval(function () {
      time--;
      if (time <= 0) {
        _this.element.getVerifyCode.removeClass('active');
        _this.element.getVerifyCode.text('获取验证码');
        callback && callback();
        return;
      }
      _this.element.getVerifyCode.addClass('active');
      _this.element.getVerifyCode.text('重新发送(' + time + 's)');
    }, 1000)
  },

  /**
   * @description 验证触发
   * @param {object} rdata 需要传递的参数 {token:token,username:用户名}
   */
  verifyCodeView: function () {
    this.verifyCode = true;
    this.element.verifyCodeView.show();
    this.element.getVerifyCode.click();
    this.element.verifyCode.focus();
    this.element.username.attr('disabled', true);
    this.element.password.attr('disabled', true);
  },

  /**
   * @description 发送验证码
   * @param {object} param 参数{token:登录信息,username:用户名}
   * @param {function} callback 回调函数
   * @returns void
   */
  getBindCode: function (param, callback) {
    var loadT = bt.load('获取验证码，请稍后...');
    bt.send('GetBindCode', 'ssl/GetBindCode', param, function (rdata) {
      loadT.close();
      if (callback) callback(rdata);
    })
  }
}

new BindAccount();