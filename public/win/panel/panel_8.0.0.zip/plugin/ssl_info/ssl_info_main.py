# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# |  SSL INFO
# +---------------------------------------
import sys, os

panel_path = os.getenv("BT_PANEL")
os.chdir(panel_path)
sys.path.append("class/")
from common import dict_obj

import public,panelSite
class ssl_info_main:
    site_obj = None

    # 显示所有网站信息
    def get_sites(self, get):
        self.site_obj = panelSite.panelSite()

        data = public.M('sites').field('id,name,path,status,ps,addtime,edate').select()
        for i in data:
            get_new = dict_obj();
            get_new.siteName = i['name']
            data2 = self.site_obj.GetSSL(get_new)
            i['ssl'] = data2['status']
            if data2['status']:
                i['time'] = data2['cert_data']
            else:
                i['time'] = False
            i['toHttps'] = data2['httpTohttps']
        print('ssl_info',data)
        return data

    def get_databases(self, get):
        data = public.M('databases').field('id,name,username,password,accept,ps,addtime').select()
        return data



