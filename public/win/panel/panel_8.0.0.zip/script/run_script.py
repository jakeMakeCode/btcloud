#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http:#bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: hwliang <hwl@bt.cn>
#-------------------------------------------------------------------

#------------------------------
# 项目开机自启调用脚本
#------------------------------
import os,sys
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")
import public,time,psutil

def project_model_auto_run():
    '''
        @name 项目模型自启调用
        @author hwliang<2021-08-09>
        @return bool
    '''
    project_model_path = '{}/projectModel'.format(public.get_class_path())
    if not os.path.exists(project_model_path): return False
    for mod_name in os.listdir(project_model_path):
        if mod_name in ['base.py','__init__.py']: continue
        mod_file = "{}/{}".format(project_model_path,mod_name)
        if not os.path.exists(mod_file): continue
        if not os.path.isfile(mod_file): continue
        tmp_mod = public.get_script_object(mod_file)
        if not hasattr(tmp_mod,'main'):continue
        try:
            run_object = getattr(tmp_mod.main(),'auto_run',None)
            if run_object: run_object()
        except:pass

def start():
    boot_time = psutil.boot_time()
    stime = time.time()
    if int(stime)-int(boot_time) > 360:return
    #--------------------- 调用自启动程序 ---------------------
    project_model_auto_run()
    # --------------------- 结束调用 ---------------------


if __name__ == '__main__':
    start()