/*
 * @Description: 统计用户常规点击
 * @Version: 1.0
 * @Autor: chudong
 * @Date: 2021-11-05 22:15:54
 * @LastEditors: chudong
 * @LastEditTime: 2021-11-10 16:19:40
 */

try {
  function Catcher(){
    this.selectorList = {}; // 选择器列表
    this.monitorQuantity = 4; // 监听数量
    this.createGlobalCapture()
  }
  
  
  
  Catcher.prototype = {
    /**
     * @description 添加捕获选择器
     * @param {string} selector 
     */
    addCaptureSelector(selector){
      let captureCount = new Number(window.localStorage.getItem('captureCount')) || 0; // 捕获数量
      this.selectorList = JSON.parse(window.localStorage.getItem('selectorList')) || {}; // 选择器列表
      this.selectorList[selector] = (this.selectorList[selector] + 1) || 1; // 捕获选择器列表
      window.localStorage.setItem('selectorList',JSON.stringify(this.selectorList));
      window.localStorage.setItem('captureCount', captureCount + 1);
      if(captureCount >= this.monitorQuantity){
        this.selectorList = JSON.parse(window.localStorage.getItem('selectorList'))
        this.http('/config?action=set_click_logs',{ndata: JSON.stringify(this.selectorList)},(rdata)=>{
          this.selectorList = {}
          window.localStorage.setItem('selectorList',JSON.stringify({}));
          window.localStorage.setItem('captureCount', 0);
        })
      }
    },
    
    /**
     * @description: 创建全局捕获
     */
    createGlobalCapture(){
      document.addEventListener('click', (ev)=>{
        let that = ev.target,
          $this = $(that),
          route = window.location.pathname.substr(1),
          arry = [],
          typeList = ['input', 'textarea', 'select', 'button', 'label', 'span', 'a', 'li', 'p','tr'];
        if(that.tagName === 'A'){
          let className = $this.attr('class');
          if(typeof className != "undefined"){
            let status = 0;
            if(className.indexOf('menu_') > -1) status += 1;
            if(status > 0 && (that.parentNode.id.indexOf('memu') > -1 || that.parentNode.id.indexOf('dologin') > -1) ) {
              arry.push('menu-' + '#' +that.parentNode.id + '>.' + className);
              this.addCaptureSelector(arry.join('|'));
              return true;
            }
          }
        }
        if ($this.hasClass('layui-layer-close') || $this.hasClass('layui-layer-btn0') || $this.hasClass('layui-layer-btn1')) return true;
        if (typeList.indexOf(that.tagName.toLowerCase()) > -1 || typeof that.onclick === "function" ) {
          let parseNodes = this.getParentNodes(that), layers = '';
          parseNodes.forEach(item => {
            if(typeof item.className !== "undefined"){
              if(item.className.indexOf('layui-layer-page') > -1 && layers == '') layers = item;
            }
            if($(item).hasClass('mem-release')){
              that = $this.parent().parent()[0];
            }
          });
          let config = this.iterateOverParentNode(that,parseNodes),selectStr = config.selectList.join('>');
          arry.push((route || 'home') + '-' + selectStr);
          if(typeof layers !== "string"){
            let layerTitlte = layers.querySelector('.layui-layer-title'),title = ''
            if(layerTitlte){
              title = layerTitlte.innerText.split('[')[0].split('【')[0].split('-')[0];  // 标题
            }
            arry.push('layer-' + title);
          }
          if($(selectStr).length > 1) arry.push('contains-' + config.contains);
          if(config.selectList.indexOf('table') > -1 && route === 'soft'){
            let trIndex = config.selectList.indexOf('tr'),data = config.selectList.slice(1,trIndex - 1);
            if(typeof $(data.join('>')).data().item != "undefined"){
              let item = $(data.join('>')).data().item;
              arry.push('table-' + item.title);
            }
          }
          this.addCaptureSelector(arry.join('|'));
        }
      })
    },
  
    /**
     * @description 遍历父节点
     * @param {object} element 节点
     * @param {Number} max 遍历最大次数
     */
    iterateOverParentNode(element,parentNodes){ 
      let selectList = [],index = 0,isState = false,layerElement = $('.layui-layer-page')
      function parentNodeRender(el,status) {
        index = index + 1;
        if(isState) return '';
        let className = '',
        idName = el.id || '',
        formName = el.name || '',
        localName = el.localName,
        $el = $(el),
        indexs = $el.index(),
        subscript = '';
        if(localName === 'body'){ // 判断是否为BODY内容
          isState = true;
          selectList.push('body');
        }else if($el.hasClass('layui-layer-page')){ // 判断是否为弹出层内容
          isState = true;
        }else if(localName === 'table'){ //判断类型为TABLE
          let parentNode = el.parentNode ,nodeClass = parentNode.classList,className = nodeClass.length > 0? '.' + nodeClass[0]:'',idName = parentNode.id? '#' + parentNode.id:'';
          isState = true;
          selectList.push(localName);
          selectList.push(parentNode.localName + (formName || idName || className));
        }else if(index <= 4){
          if (el.classList.length > 0) className = '.' + el.classList[0];
          if (idName) {
            idName = '#' + idName;
            if (idName.indexOf('layui-layer') > -1) idName = '';
          }
          if(el.parentNode.tagName === 'TD' || el.parentNode.tagName === 'TR'){
            index = index - 1;
          }
          if(el.parentNode.tagName === 'A'){
            index = index - 1;
          }else{
            let prevAll = $el.prevAll(),siblingsList = $el.siblings();
            if (formName) formName = '[name="' + formName + '"]';
            if (index !== 4 && ((siblingsList.length > 0 && el.tagName != 'TR' && el.tagName != 'DIV') || el.className.indexOf('libPay-menu-type') > -1)) {
              let same = 0;
              prevAll.each(function (i, v) {
                if(i < indexs){
                  if (v.localName === localName){
                    same = same + 1;
                  }
                }
              })
              if(!subscript) subscript = ':eq(' + same + ')';
            }
          }
          if(className.indexOf('event_') > -1) className = '';
          let select = idName ||  (el.localName + (formName || (!subscript?className:'') + (!idName ? subscript : '')))
          selectList.push(select)
          parentNodeRender(el.parentNode,true)
          if(status) return select
          return selectList
        }else{
          isState = true;
        }
        return selectList;
      }
      parentNodeRender(element);
      selectList = selectList.reverse();
      let coordinate = 0;
      $.each(selectList, function (i, v) {
        if (v.indexOf('a') === 0 || v.indexOf('button') === 0) {
          coordinate = i;
          return false;
        }
      })
      if(coordinate !== 0) selectList.splice(coordinate + 1, selectList.length);
      return {
        selectList:selectList,
        contains:$(element).text()
      }
    },
  
    /**
     * @description:获取父节点
     * @param {string} selector 选择器
     */
    getParentNodes(element){
      let parentNodes = [];
      function parentNode(param) {
        let node = param.parentNode;
        if(node.localName === 'body') return false;
        parentNodes.push(parentNode(node));
        return node;
      }
      parentNode(element)
      return parentNodes;
    },
  
    /**
     * @description: 请求封装
     */
    http(url, data,callback,error){
      $.ajax({
        url: url,
        type: 'post',
        data: data,
        success: function (res) {
          if(callback) callback(res);
        },
        error: function (err) {
          if(error) error(err);
        }
      })
    }
  }
  
  let catcher = new Catcher();
  
} catch (error) {
  console.log(error);
}

